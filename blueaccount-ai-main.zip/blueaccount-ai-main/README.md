# BlueAccount MVP 1

**Aplicação full-stack NestJS + React** para gestão financeira de escritórios de contabilidade com extração de dados via agentes IA.

**Índice:**
- [Visão Geral](#visão-geral)
- [Arquitetura](#arquitetura)
- [Pré-requisitos](#pré-requisitos)
- [Quick Start](#quick-start)
- [Backend NestJS](#backend-nestjs)
- [Frontend React](#frontend-react)
- [Desenvolvimento](#desenvolvimento)
- [Troubleshooting](#troubleshooting)

---

## Visão Geral

**BlueAccount MVP 1** é um monorepo que combina:

- **Backend** — API NestJS com autenticação Cognito, multi-tenant RLS, agentes IA/AgentCore, integração S3 e workflows OCR/extração
- **Frontend** — React 18 + Vite SPA com autenticação, cockpit MVP para clientes, documentos, contratos, relatórios, excedentes e faturamento
- **Database** — PostgreSQL com Row-Level Security (RLS) para isolamento de dados por tenant
- **Services** — AWS SAM + Step Functions para OCR/extração e agentes Python em Amazon Bedrock AgentCore Runtime

**Status:** MVP operacional em refinamento contínuo. Use os READMEs de cada app e [`docs/PROJECT_NAVIGATION.md`](./docs/PROJECT_NAVIGATION.md) como fontes atuais para ownership, rotas de leitura e estado estrutural.

---

## Arquitetura

```
blueaccount-mvp-1/
├── apps/
│   ├── backend/                    ← NestJS API
│   │   ├── src/
│   │   │   ├── main.ts             ← Bootstrap
│   │   │   ├── modules/            ← Feature modules (auth, agentes, clientes, etc)
│   │   │   ├── domain/             ← Regra de negócio
│   │   │   ├── http/               ← Controllers + middlewares
│   │   │   ├── infrastructure/     ← AWS, BD, logging, IA
│   │   │   ├── database/           ← TypeORM, migrations, RLS
│   │   │   ├── agent/              ← Agentes IA (Bedrock)
│   │   │   └── tools/              ← Utilitários
│   │   ├── README.md               ← Documentação completa backend
│   │   └── package.json
│   │
│   ├── client/                     ← Cliente local Python (Domínio/SQL Anywhere);
│   │                                 roda na máquina do escritório, API em 127.0.0.1
│   │
│   ├── frontend/                   ← React + Vite SPA
│       ├── src/
│       │   ├── main.tsx            ← Entry point React
│       │   ├── App.tsx             ← Root com Router
│       │   ├── pages/              ← Rotas MVP e páginas legadas
│       │   ├── components/         ← Componentes reutilizáveis
│       │   ├── contexts/           ← AuthContext (global)
│       │   ├── lib/                ← api.ts (HTTP client), auth.ts
│       │   └── index.css           ← Estilos globais
│       ├── README.md               ← Documentação completa frontend
│       └── package.json
│
│   └── services/                   ← OCR, extrações SAM e agentes AgentCore
│
│   └── e2e/                        ← Testes E2E Playwright (gate de PR e deploy)
│
├── planos_execucao/                ← Planos e histórico de decisões
├── docs/                           ← Guias de desenvolvimento e qualidade
├── package.json                    ← Root workspace
├── tsconfig.json
└── .env                            ← Variáveis (não commitar)
```

**npm workspaces** gerencia ambas aplicações como um projeto único.

### Comandos de Workspace

```bash
# Instalar deps de um workspace específico
npm install --workspace apps/backend
npm install --workspace apps/frontend

# Adicionar pacote a um workspace
npm install express --workspace apps/backend

# Rodar script de um workspace diretamente
npm run build --workspace apps/backend
npm run dev --workspace apps/frontend
```

### TypeScript

- `tsconfig.base.json` — configuração compartilhada (paths, strict, target)
- `apps/backend/tsconfig.json` — estende a base, adiciona NestJS decorators (`experimentalDecorators`, `emitDecoratorMetadata`)
- `apps/frontend/tsconfig.json` — estende a base, adiciona React JSX e DOM types

---

## Pré-requisitos

- **Node.js 22+**
- **PostgreSQL 15+** (local ou Docker)
- **AWS Cognito, Bedrock, S3** — credenciais configuradas
- **npm 10+** (workspaces)

---

## Quick Start

### 1. Clonar e Instalar

```bash
git clone <repo>
cd blueaccount-mvp-1
npm install
```

### 2. Configurar Variáveis de Ambiente

**Arquivo:** `apps/backend/.env`

```bash
# Server
PORT=3000
NODE_ENV=development

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/blueaccount

# AWS
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
AWS_COGNITO_USER_POOL_ID=us-east-1_xxx
AWS_COGNITO_CLIENT_ID=xxx

# Google OAuth login
PUBLIC_BASE_URL=http://localhost:3000
FRONTEND_BASE_URL=http://localhost:5173
GOOGLE_OAUTH_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_OAUTH_CLIENT_SECRET=xxx
# Opcional: se omitido, usa PUBLIC_BASE_URL + /api/auth/google/callback
GOOGLE_OAUTH_REDIRECT_URI=http://localhost:3000/api/auth/google/callback
# Opcional: usado pelo fluxo OAuth externo, como ChatGPT/MCP, quando habilitado
GOOGLE_OAUTH_MCP_REDIRECT_URI=http://localhost:3000/oauth/google/callback
GOOGLE_OAUTH_STATE_SECRET=um-segredo-longo

# Frontend (para dev server)
FRONTEND_DIST_DIR=../../dist/apps/frontend
```

No Google Cloud, crie um OAuth Client do tipo **Web application** e adicione como Authorized redirect URI o callback do app (`/api/auth/google/callback`). Se também usar o fluxo OAuth externo da BlueAccount, adicione `/oauth/google/callback`.

### 3. Setup Banco de Dados

```bash
# Criar schemas e rodar migrations
npm run db:bootstrap-tenants
```

Ou passo a passo:
```bash
npm run migration:run           # Migrations públicas
npm run migration:sync-tenants  # Migrations por tenant
```

### 4. Rodar Backend e Frontend

O caminho local recomendado é `./runapp.py`: sem flags inicia backend, MCP, frontend e worker
de simulações. O worker fiscal é explícito: `--ingestao-documentos-fiscais-worker` para uploads,
`--distribuicao-dfe-worker` para scans ou ambas para um processo com dois laços. Ambos consomem
filas Postgres e persistem notas no Postgres. Aplicar migrations no banco dedicado e configurar
S3, XSD e credencial fiscal antes de iniciar; veja o README de `apps/services/documentos-fiscais`.

**Terminal 1 — Backend**

```bash
npm run serve
# Backend em http://localhost:3000
```

**Terminal 2 — Frontend**

```bash
npm run dev:frontend
# Frontend em http://localhost:5173
# Proxy /api/* → http://localhost:3000
```

### 5. Acessar Aplicação

- **Frontend:** http://localhost:5173
- **Admin Backend:** http://localhost:3000/admin
- **API:** http://localhost:3000/api/*

---

## Backend NestJS

### Stack

- **NestJS 11** — Framework web
- **TypeORM + PostgreSQL** — ORM e banco relacional
- **AWS Cognito** — Autenticação
- **AWS Bedrock + Strands Agents** — Agentes IA
- **AWS S3** — Storage de documentos
- **Express** — HTTP server subjacente

### Estrutura de Camadas

```
src/
├── app/                    ← Bootstrap e AppModule
├── modules/                ← Controllers, services orquestração
│   ├── auth/              ← Login, logout, me, admin-login
│   ├── agentes/           ← CRUD de agentes e ações de IA
│   ├── clientes/          ← CRUD de clientes
│   ├── contratos/         ← Gestão de contratos
│   ├── documentos/        ← Upload/download de arquivos
│   ├── relatorios/        ← Gestão de relatórios
│   ├── extracao/          ← Endpoints /api/extract, /api/extract-report
│   └── escritorios/       ← CRUD de escritórios (admin)
│
├── domain/                 ← Lógica de negócio (sem Nest, sem HTTP)
│   ├── autenticacao/
│   ├── agentes/
│   ├── clientes/
│   ├── contratos/
│   ├── documentos/
│   ├── escritorios/
│   ├── extracao/
│   └── relatorios/
│
├── http/                   ← Middlewares e controladores HTTP genéricos
│   ├── controllers/
│   └── middlewares/
│       ├── auth.middleware.ts      ← Valida sessão
│       └── api-context-middleware.ts
│
├── infrastructure/         ← Integrações técnicas
│   ├── ai/                ← Factory de agentes
│   ├── database/          ← DataSource, bootstrap
│   ├── external-services/ ← Cognito, Bedrock, S3
│   └── logging/           ← Logger
│
├── database/              ← Entidades, migrations, RLS
│   ├── entities/
│   ├── migrations/
│   └── modules/
│       ├── public/        ← Schema público
│       └── tenant/        ← Schemas por tenant
│
├── agent/                 ← Implementações IA
│   ├── extract-contract-agent.ts
│   └── extract-report-agent.ts
│
└── tools/                 ← Utilitários
```

### Ordem de Decisão para Features

1. **Servidor subindo?** → `src/app`
2. **Composição Nest?** → `src/modules`
3. **HTTP (controllers)?** → `src/http`
4. **Agentes/automação?** → `src/modules/agentes` + `src/infrastructure/ai`
5. **Regra de negócio?** → `src/domain`
6. **Banco/AWS/Log/IA?** → `src/infrastructure`
7. **Autenticação?** → `src/modules/auth`

### Módulos Principais

#### `POST /auth/login`
```json
Request: { "email": "user@example.com", "password": "..." }
Response: { "userId": "uuid", "role": "user" }
```

#### `GET /clientes` | `POST /clientes` | `PATCH /clientes/:id` | `DELETE /clientes/:id`
CRUD de clientes (nome, CNPJ, fantasia).

#### `GET /contratos/:id` | `POST /contratos` | `PATCH /contratos/:id`
Contratos extraídos de PDFs, com arrays editáveis (cláusulas, apêndices).

#### `POST /clientes/:id/documentos` (multipart)
Upload de documentos (PDF, DOCX, CSV) com metadados (módulo, competência).

#### `POST /api/extract` (multipart)
```json
FormData { file, cliente_id? }
Response: { "documento_id"?: "uuid", "extracao_id"?: "uuid", "payload_normalizado_ui"?: {...}, ... }
```
Extrai contrato de PDF via agente IA. Quando `cliente_id` é enviado, salva documento e extração para revisão.

#### `POST /api/extract-report` (multipart)
```json
FormData { file, cliente_id? }
Response: { "relatorios": [...] }
```
Extrai relatório(s) de PDF/DOCX/CSV.

#### `GET /api/extracoes`
Lista extrações recentes de um cliente autenticado.

#### `GET /relatorios` | `POST /relatorios` | `PATCH /relatorios/:id`
Gestão de relatórios mensais/periódicos.

#### `GET /escritorios` (admin) | `POST` | `PATCH` | `DELETE`
Gestão de escritórios de contabilidade.

#### `POST /api/agent/plan`
Gera plano estruturado de ação para o widget e fluxos assistidos.

### Desenvolvimento Backend

**Rodar servidor:**
```bash
npm run dev       # CLI com tsx
npm run serve     # HTTP server
```

**Testes:**
```bash
npm run test                   # Unit tests
npm run test:integration       # Integração com BD
npm run test:integration:watch # Watch mode
```

**Migrations:**
```bash
npm run migration:generate --name=AddField    # Gera migration
npm run migration:run                          # Executa
npm run migration:sync-tenants                 # Sincroniza schemas
```

**Padrão de Controllers:**

```typescript
@Controller('clientes')
@UseGuards(AuthGuard)
export class ClientesController {
  constructor(private service: ClientesService) {}

  @Get()
  async list() {
    return this.service.findAll();
  }

  @Post()
  async create(@Body() body: CreateDTO) {
    return this.service.create(body);
  }

  @Patch(':id')
  async update(@Param('id') id: string, @Body() body: UpdateDTO) {
    return this.service.update(id, body);
  }

  @Delete(':id')
  async delete(@Param('id') id: string) {
    return this.service.delete(id);
  }
}
```

**Padrão de Services (Domain):**

```typescript
export class ClientesService {
  async create(data: CreateInput): Promise<Cliente> {
    this.validateData(data);
    return this.repository.save(data);
  }

  private validateData(data: CreateInput) {
    if (!data.razao_social) throw new Error('razao_social required');
  }
}
```

### Multi-Tenant e RLS

- **Schema `public`** — Tabelas compartilhadas (usuarios, sessões)
- **Schema `tenant_{id}`** — Dados isolados por escritório
- **Row-Level Security** — Cada usuário acessa só seu tenant via RLS policies

Ao provisionar novo escritório:
```bash
npm run db:create-tenant-schemas  # Cria schema
npm run migration:sync-tenants    # Sincroniza migrations
```

### Agentes IA

**Fluxo:**

1. Frontend seleciona PDF → `POST /api/extract`
2. `ExracaoController` passa para `ExracaoService`
3. `ExracaoService` chama `DocumentIngestionAgent`
4. Agent executa via Bedrock/Strands, retorna JSON estruturado
5. Frontend mostra painel de revisão
6. Frontend confirma via endpoints de domínio (`contratos` ou `relatorios`)
7. Dados revisados são salvos no banco pelos services Nest/domínio

**Implementação:**
- Agentes: `src/agent/document-ingestion-agent.ts`, `report-ingestion-agent.ts`, `executor-agent.ts`
- Factory: `src/infrastructure/ai/ai.factory.service.ts`
- Orquestração: `src/modules/agentes/acoes-ai.service.ts` e `src/modules/agentes/agentes.service.ts`

---

## Frontend React

### Stack

- **React 18** + TypeScript 5
- **Vite 5** — Dev server com HMR
- **React Router v6** — Roteamento com proteção
- **CSS vanilla** — Sem frameworks (classes globais)
- **Fetch API** — Cliente HTTP customizado

### Estrutura

```
src/
├── main.tsx                    ← Entry point, BrowserRouter + AuthProvider
├── App.tsx                     ← Root component, todas as rotas
├── index.css                   ← Estilos globais (navbar, páginas, botões)
│
├── lib/
│   ├── api.ts                  ← Cliente HTTP com credentials
│   └── auth.ts                 ← Utilitários de cookies/sessão
│
├── contexts/
│   └── AuthContext.tsx         ← Estado global autenticação
│
├── components/
│   ├── PrivateRoute.tsx        ← Guard para rotas autenticadas
│   ├── AdminRoute.tsx          ← Guard para rotas admin-only
│   └── AiChatWidget.tsx        ← Widget de chat IA flutuante
│
└── pages/
    ├── MvpHomePage.tsx        ← Home operacional
    ├── LoginPage.tsx           ← Login de usuário
    ├── AdminLoginPage.tsx      ← Login de admin
    ├── ClientesPage.tsx        ← CRUD clientes com busca
    ├── ClienteDetailPage.tsx   ← Detalhe do cliente
    ├── DocumentosPage.tsx      ← Gestão de documentos
    ├── DocumentoDetailPage.tsx ← Visualização de arquivo/OCR
    ├── MvpContratosPage.tsx    ← Cockpit de contratos
    ├── MvpReviewPage.tsx       ← Revisão de contrato extraído
    ├── MvpRelatoriosPage.tsx   ← Cockpit de relatórios
    ├── MvpRevisaoRelatorioPage.tsx
    ├── MvpExcedentesPage.tsx   ← Valores a cobrar e comparação
    ├── CadastrosPage.tsx       ← Escritórios + usuários (admin)
    └── AdminPage.tsx           ← Dashboard admin
```

### Páginas Principais

#### **LoginPage** (`/login`)
- Formulário de login (email + senha)
- Valida contra `POST /auth/login`
- Redireciona para `/home` ao sucesso
- Mostra erros de credenciais

#### **ClientesPage** (`/clientes`)
- Lista todos os clientes
- Busca/filtro por nome ou CNPJ
- CRUD completo (criar, editar, deletar)
- Click em cliente → `ClienteDetailPage`

#### **Cockpit MVP** (`/home`, `/contratos`, `/relatorios`, `/excedentes`, `/cobrancas`)
- `/home` consolida visão operacional de contratos, relatórios e valores a cobrar
- `/contratos` dispara upload de contrato e acompanha processamento/revisão
- `/relatorios` dispara upload de relatórios, consulta estatísticas e envia para QA
- `/excedentes` lista valores a cobrar e comparação com faturamento anterior
- `/cobrancas` lista cobranças emitidas em plataformas externas (Asaas) com filtros de status

#### **Revisão e Detalhes** (`/processar/*`, `/revisar/*`, `/revisar-relatorio/*`, `/detalhes/*`, `/relatorios/*`, `/excedentes/*`)
- Telas full-bleed para processamento assíncrono, revisão de payload normalizado e edição de resultados
- Contratos usam `GET /documentos/:id/resultado-contrato` antes da confirmação
- Relatórios usam `GET /documentos/:id/resultado-relatorio`, `GET /relatorios/estatisticas` e confirmação por documento
- Excedentes permitem serviços extras, geração por agente e envio da cobrança para plataforma externa (Asaas — boleto/PIX) com sincronização de status via webhook ou consulta manual

#### **DocumentosPage** (`/documentos`)
- Lista documentos de todos os clientes
- Visualizar arquivo/OCR, reprocessar, marcar erro, deletar, busca
- Mostra cliente, módulo, competência

#### **CadastrosPage** (`/cadastros`)
Admin: gerenciar escritórios e usuários

1. **Escritórios** — CRUD com nome, endereço, contato
2. **Usuários** — CRUD com email, escritório, role

#### **AdminPage** (`/admin`)
Dashboard admin com:
- Escritórios, usuários e auditoria de contextos
- Provisionamento de schema e execução manual de migrations
- Status da API

### Autenticação Frontend

**Flow:**
```
LoginPage → POST /auth/login { email, password }
  → AuthContext.login() armazena no cookie
  → Redireciona /home
  → PrivateRoute valida session
```

**Proteção:**
- `PrivateRoute` — Rota autenticada
- `AdminRoute` — Rota admin-only
- `GET /auth/me` — Valida sessão ao carregar app
- Cookies HTTP-only + `credentials: "include"` em requests

**API Client (`src/lib/api.ts`):**

```typescript
export const api = {
  get: <T>(endpoint: string) => Promise<T>,
  post: <T>(endpoint: string, body: unknown) => Promise<T>,
  patch: <T>(endpoint: string, body: unknown) => Promise<T>,
  delete: <T>(endpoint: string) => Promise<T>,
};
```

⚠️ **Para FormData (uploads):** Use `fetch` direto, não `api.post`.

### Arrays Editáveis

Quando dados extraídos contêm arrays, renderizam como tabelas:
- Colunas automáticas dos keys
- Inputs editáveis
- Botão "✕" remove linha
- Botão "+ Adicionar linha" insere

```json
{
  "tipo_contrato": "Serviço",
  "clausulas": [
    { "numero": "1", "descricao": "Vigência" },
    { "numero": "2", "descricao": "Responsabilidades" }
  ]
}
```

### Desenvolvimento Frontend

**Rodar dev server:**
```bash
npm run dev:frontend
# http://localhost:5173
# Proxy /api/* → http://localhost:3000
```

**Build:**
```bash
npm run build
# Artefatos em dist/apps/frontend/
```

**Padrão de Componentes:**

```typescript
import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { api } from "../lib/api";

export function PageName() {
  const { session } = useAuth();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const result = await api.get("/endpoint");
        setData(result);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Erro");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="page-loading">Carregando...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return <div className="page-container">{/* Conteúdo */}</div>;
}
```

**Estilos (CSS globals):**
```css
.page-*              /* Container de página */
.btn-primary         /* Botão primário */
.btn-secondary       /* Botão secundário */
.btn-danger          /* Botão perigoso */
.error-message       /* Mensagem de erro */
.success-message     /* Mensagem de sucesso */
.array-table         /* Tabela editável */
.navbar              /* Barra de navegação */
```

---

## Desenvolvimento

### Instalação

```bash
npm install
npx simple-git-hooks
```

### Scripts Raiz

```bash
# Backend
npm run dev:backend         # CLI backend
npm run serve              # Server HTTP
npm run test              # Tests
npm run test:integration  # Integration tests

# Frontend
npm run dev:frontend      # Dev server
npm run build:frontend    # Build

# Ambos
npm run build             # Build backend + frontend
npm run migration:run     # Migrations
npm run db:bootstrap-tenants  # Bootstrap completo

# Seeds
npm run seed -- --seed-id <id> --user <email> --password <senha>  # Reaplica seeds/seed-run-<id>.json em escritório vazio
```

### Workflow de Feature

1. Identificar a camada (backend) ou página (frontend)
2. Ler documentação da camada (`src/README.md` no backend)
3. Criar tests
4. Implementar
5. Testar end-to-end
6. Documentar e deixar alterações para revisão

### Testes

**Backend:**
```bash
npm run test                 # Unit tests
npm run test:integration     # Com banco
npm run test:integration:watch
```

**Frontend:**
```bash
npm run test:frontend        # Testes frontend
npm run test --workspace apps/frontend
npm run test:all             # Backend + frontend
```

### Migrations

```bash
# Gerar
npm run migration:generate -- --name=AddClienteField

# Executar
npm run migration:run

# Sincronizar schemas tenant
npm run migration:sync-tenants

# Revert
npm run migration:revert
```

---

## Troubleshooting

### Backend

**Porta 3000 já em uso?**
```bash
lsof -i :3000
kill -9 <PID>
```

**Migrations falhando?**
```bash
npm run migration:revert
npm run migration:run
```

**RLS não funcionando?**
- Verifique `src/database/modules/tenant/rls-policy.sql`
- Check: `SELECT * FROM pg_policies WHERE tablename = 'clientes';`

**Agente IA retornando erro?**
- Verifique Bedrock credentials em `.env`
- Logs em `logs/`
- Teste: `curl -X POST http://localhost:3000/api/extract -F "file=@test.pdf"`

### Frontend

**CORS errors?**
- Backend deve estar em `http://localhost:3000`
- Dev server proxeia `/api/*` automaticamente
- Em produção: frontend e backend mesmo domínio

**FormData não funciona?**
- Use `fetch` direto, não `api.post`
- Não defina `Content-Type` (browser auto-detecta)

**Sessão expirada?**
- `GET /auth/me` valida ao iniciar
- Se expirada, redireciona `/login`

**Campos extraídos não aparecem?**
- Verifique `/api/extract` retorna JSON válido
- Console DevTools mostra erros

### Geral

**Dependências desatualizadas?**
```bash
npm update
npm audit fix
```

**Cache do Vite problemático?**
```bash
rm -rf node_modules dist
npm install
npm run build
```

---

## Documentação Completa

Para detalhes aprofundados:

- **Backend:** Leia [`apps/backend/README.md`](./apps/backend/README.md)
- **Frontend:** Leia [`apps/frontend/README.md`](./apps/frontend/README.md)
- **Monorepo (histórico):** [`planos_execucao/MONOREPO.md`](./planos_execucao/MONOREPO.md)
- **Camadas Backend:** Leia [`apps/backend/src/README.md`](./apps/backend/src/README.md)

---

## Status do Projeto

O status detalhado muda rápido. Para navegar o estado atual:

- Estrutura e ownership: [`docs/PROJECT_NAVIGATION.md`](./docs/PROJECT_NAVIGATION.md)
- Backend: [`apps/backend/README.md`](./apps/backend/README.md)
- Frontend: [`apps/frontend/README.md`](./apps/frontend/README.md)
- Services/AgentCore: [`apps/services/README.md`](./apps/services/README.md)
- MCP: [`apps/mcp/README.md`](./apps/mcp/README.md)
- E2E: [`apps/e2e/README.md`](./apps/e2e/README.md)
- Plugin/skills do MCP: [`apps/mcp/plugin/kontiva-copilot/README.md`](./apps/mcp/plugin/kontiva-copilot/README.md)
- Cliente local (Domínio): [`apps/client/README.md`](./apps/client/README.md) — roda na máquina
  do escritório, fora da infraestrutura da Kontiva

---

**Última atualização:** 2026-07-07  
**Mantido por:** Equipe BlueAccount

## MCP administrativo local

`apps/mcp-admin` é um servidor stdio independente para administração da plataforma.
Use `npm run build:mcp-admin`, `npm run test:mcp-admin` e o helper
`npm run login --workspace apps/mcp-admin`. Configuração e limites: [guia do app](apps/mcp-admin/README.md).
