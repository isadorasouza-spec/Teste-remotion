# CLAUDE.md

## Critical Instructions

- Do not commit code.
- Use the project skills before acting. They are the source of truth for routing, conventions, and local patterns.
- Do not guess file locations, architecture, naming, or ownership. Read the nearest README/skill guidance first.

## Required Skill Routing

Always invoke `blueaccount-project-navigator` before project work, including reading structure, answering implementation questions, planning, editing, debugging, testing, or reviewing.

After that:

- If the task touches `apps/frontend` pages, components, styles, CSS, layout, routes, visible text, or i18n, also invoke `blueaccount-frontend-ui`.
- If the task touches `apps/backend`, also invoke `blueaccount-backend-navigator`.
- If the task touches `apps/services`, also invoke `blueaccount-services-navigator`.
- If the task touches `apps/mcp`, also invoke `blueaccount-mcp-navigator`.
- If responsibilities, workflow contracts, architecture, or developer entry points change, update the nearest README or guide in the same change.

## Infrastructure as Code

- The AWS IaC is accessed through the repository-root symlink `blueaccount/`. Its target is a
  separate Git repository, so inspect and preserve the status of both repositories independently.
- Before any IaC work, verify that `blueaccount/` exists, resolves successfully, and is a directory,
  then read `blueaccount/README.md` before inspecting or changing Terraform.
- If `blueaccount/` is missing, broken, or does not resolve to a directory, stop and ask the user
  for the IaC repository location. Do not guess another path, search the machine for it, or recreate
  the symlink without the user's direction.
- Keep deployable Terraform `.tf` files in the `blueaccount/` root module unless intentionally
  extracting a real Terraform module with an explicit state-migration plan.

## Naming Language

Even when the user prompt or implementation instructions are in English, new project-owned function, class, module, folder, service, domain, and business type names must follow the repo standard and be written in Portuguese.

Allowed exceptions:

- stable public contracts, HTTP route slugs, API payload fields, MCP tool names, env vars, and third-party protocol names;
- framework/library concepts, SDK classes, and external service names;
- existing documented exceptions such as `src/modules/auth`;
- compatibility shims when renaming would break callers.

Prefer extending the existing Portuguese module/domain vocabulary over introducing parallel English names.

## Running Locally

Two Python launchers at the repo root drive the local stack. Both parse the root `.env`.

### `runapp.py` — app processes (+ optional agent/ingestion harness)

Runs the long-lived app services. No flags → starts **backend + mcp + frontend + simulation worker** together.

| Flag | Effect |
|---|---|
| `-b` / `--backend` | backend only (`migration:run` → `migration:sync-tenants` → `serve`, port 3000) |
| `-f` / `--frontend` | frontend dev server |
| `-m` / `--mcp` | MCP server (`dev:mcp`, points at `http://localhost:3000`) |
| `-w` / `--simulation-worker` | Simulation calculation worker (`simulation-worker`). Drains the Postgres queue `simulacao_calculos_fila` and publishes results. **Without it, every edited simulation stays in `na_fila` forever** and export/report/cash-flow answer `409 SIMULACAO_CALCULO_DESATUALIZADO`. Needs a backend running (it goes to the DB directly, not through the API) |
| `-s` / `--harness` | **AgentCore dev runtimes** only — `RelatorioExtracaoAgent` (:8080) + `ContractAgent` (:8081), used by the `engine=agent` paths. Starts nothing else; the runtimes still call the backend at `localhost:3000`, so run one separately (e.g. `./runapp.py -b` in another shell) |

`-s` now starts **only** the AgentCore dev runtimes. The local State Machine stack (Step Functions
Local + SAM Local + lambda proxy + SM registration) moved to `./runservice.py --all` (below). Full
`engine=agent` reports/contracts path = run **both** `./runservice.py --all` (SMs) and
`./runapp.py -s` (agents). The two are lazily coupled: the reports/contracts SAM Local dials the
agents at :8080/:8081 only when an `InvokeReportAgent`/`InvokeContractAgent` step runs, so boot order
between them does not matter.

Examples:
- `./runapp.py` — backend + mcp + frontend + simulation worker
- `./runapp.py -b -f` — backend + frontend, no MCP and **no simulation worker** (simulations stay queued)
- `./runapp.py -w` — simulation worker only (needs a backend running elsewhere)
- `./runapp.py -s` — AgentCore dev runtimes only (needs a backend running elsewhere)

### `runservice.py` — SAM State Machines on Step Functions Local

Two modes:

- **`./runservice.py --all`** — brings up **every** SM-bearing service on **one** Step Functions
  Local (:8083) behind **one** lambda proxy (:3003), so the backend's single
  `STEP_FUNCTIONS_ENDPOINT` reaches all of them. The proven trio (`ocr-pipeline` :3001,
  `relatorios` :3002, `contratos` :3004) is registered by the existing
  `relatorios/scripts/registrar-step-functions-local.mjs` + proxy; the remaining services
  (`conector-drive` :3005, `ingestao-payload` :3006, `receita-recuperada` :3007,
  `cobranca` :3008) register via the
  generic engine and are added to the proxy via `relatorios/.step-functions-local/proxy-routes.json`.
  `--all` runs `local:preparar`, `sam build` (reused unless `--rebuild`), exports AWS creds, and
  prints the new `*_STATE_MACHINE_ARN` lines for the backend `.env`. Same prerequisites as the old
  harness: `AWS_PROFILE` in the root `.env` + a valid `aws sso login`.
- **`./runservice.py <service>`** (e.g. `./runservice.py conector-drive`) — a **single** service in
  isolation on its own Step Functions Local (:8083) + SAM Local (:3001), **no proxy**. Unchanged.

Both parse `template.yaml`, resolve `DefinitionSubstitutions`, write
`.step-functions-local/env-vars.local.json` (rewriting `localhost`→`host.docker.internal`) and the
root `runservice.json` manifest (local ARNs/ids, no secrets). Requires `docker`, `sam`, `aws` in PATH.
Full topology: `docs/architecture/LOCAL_REPORTS_AGENT_HARNESS.md`.

Local SMs use the synthetic account `123456789012`, name suffix `-local` (e.g.
`arn:aws:states:us-east-1:123456789012:stateMachine:blueaccount-conector-drive-local`). Paste the
printed ARN into the matching `*_STATE_MACHINE_ARN` in the backend `.env` so the backend dispatches
to the local SM (`STEP_FUNCTIONS_ENDPOINT=http://localhost:8083` routes SFN calls there).

## Agent Spawning
When Spawning an agent you should breakdown the tasks in a TODO list specifying what needs to be modified in a way that it contains:

1. Objectives:
    a. Where it needs to update code
    b. What code and functionalities need to be implemented
2. What is affected (including side effects that need toi be addressed)
    a. The risk
    b. How to avoid the risk
    c. What was done to mitigate the risk
3. Testing requirements
4. Documentation updates.

Note that you are repsonsible to create the TODO list accurately, specially when dealing with risks.

After it is done the agent should not document directly, Tthe Orchestrator agent should review the documentation and code to see if it makes sense and asses the risk mitigation measures.

Agents are only needed for large specialized tasks. Small fixes don't need the overhead, unless the user requests

## Worker fiscal unificado explícito

`./runapp.py --ingestao-documentos-fiscais-worker` seleciona uploads;
`--distribuicao-dfe-worker` seleciona SEFAZ. Com ambas, inicia um único
`documentos_fiscais.worker_fiscal`, duas threads e dois pools Postgres. Nenhum laço é default.
O backend enfileira uploads em `public.ingestoes_fiscais_fila` e scans em
`public.distribuicoes_dfe_fila`; o Python processa e publica nas tabelas fiscais Postgres.
`DOCUMENTOS_FISCAIS_PROCESSADOR=worker`, `NOTAS_FISCAIS_FONTE=postgres` e modo fiscal explícito
selecionam o fluxo. O launcher pré-valida antes de iniciar processos/migrations. DFe exige
certificado A1, XSD e a mesma SECRETS_ENCRYPTION_KEY do backend. Encerrar só processos do launcher.
Configuração local/produtiva, callback e rollout: `apps/services/documentos-fiscais/README.md`.

## Harness fiscal integrada

Com `DOCUMENTOS_FISCAIS_PROCESSADOR=worker`, `runservice.py documentos-fiscais` e `runservice.py --all`
iniciam o supervisor Python/Postgres; `--all` exclui o SAM fiscal/Glue nesse modo. A harness prepara
S3 local e pode publicar o ZIP XSD pinado via `DOCUMENTOS_FISCAIS_XSD_BUNDLE_LOCAL`. Banco/role técnica
precisam existir; migrations/sync continuam em `runapp.py -b`. Ambos os launchers aceitam
`--env-file /caminho/fiscal-local.env` como overlay; shell tem precedência. Não editar `.env` para
alternar o piloto. Guia completo: `apps/services/documentos-fiscais/README.md#harness-local-fiscal-postgres`.
