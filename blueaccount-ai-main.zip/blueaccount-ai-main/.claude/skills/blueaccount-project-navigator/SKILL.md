---
name: blueaccount-project-navigator
description: MANDATORY first step for any work in the BlueAccount/Kontiva MVP monorepo — reading structure, answering implementation questions, planning, editing, debugging, testing, or reviewing. Use it to pick the owning app (backend, frontend, services, mcp, e2e), find the layer and the authoritative README/doc, and route to the matching sub-navigator skill before touching code. Invoke even when the target seems obvious or the change spans several apps.
---

# BlueAccount Project Navigator

Invoke this skill before changing code or answering implementation questions in the BlueAccount/Kontiva
MVP monorepo — it is the entry point that routes every task to the right app, layer, docs, and
sub-navigator. Do this even when the target seems obvious; "obvious" guesses are how work lands in the
wrong app or bypasses a required contract.

The canonical navigation guide is `docs/PROJECT_NAVIGATION.md`. Read it first when a task touches architecture, app ownership, cross-app flows, agent tooling, or documentation structure.

The current project is not just backend + frontend. The active codebase is split across:

- `apps/backend` for the NestJS API and database-backed business flows
- `apps/frontend` for the React + Vite product UI
- `apps/services` for OCR, extraction, async ingestion, SAM workflows, and AgentCore runtimes
- `apps/mcp` for the MCP server that exposes a safe subset of the API to AI agents
- `apps/e2e` for the Playwright E2E suite that gates PRs and deploys (local stack + deployed smoke)
- `blueaccount/` for the symlinked AWS IaC root module in its separate Git repository
- `docs` and `planos_execucao` for operational guides, test strategy, architecture notes, and rollout plans

## Route To The Sub-Navigator First

Classify the task, then invoke the matching skill before opening implementation files. Most work needs
exactly one of these; cross-app work needs the navigator for each app it touches.

| If the task touches… | Invoke | Read first |
| --- | --- | --- |
| `apps/backend` (API, auth, domain rules, DB, migrations, RLS, backend agents) | `blueaccount-backend-navigator` | `apps/backend/README.md`, `apps/backend/src/README.md` |
| `apps/frontend` (pages, components, CSS, layout, routes, visible text, i18n) | `blueaccount-frontend-ui` | `apps/frontend/README.md`, `apps/frontend/src/README.md`, `.../pages/README.md` |
| `apps/services` (OCR, extraction, ingestion, SAM/Step Functions, AgentCore) | `blueaccount-services-navigator` | `apps/services/README.md` |
| `apps/mcp` (tool surface, resources, prompts, OAuth/session forwarding) | `blueaccount-mcp-navigator` | `apps/mcp/README.md`, `docs/AI_AGENT_TOOLS.md` |
| `apps/e2e`, docs, or a flow spanning apps | (stay here) | `docs/PROJECT_NAVIGATION.md` |
| `blueaccount/` (AWS IaC/Terraform) | (stay here) | verify the symlink, then `blueaccount/README.md` |

## Start Here

1. Classify the target area and invoke the sub-navigator from the table above.
2. Read the app-level README before opening implementation files.
3. Read the layer README for the exact area you will touch, when it exists.
4. Reuse the current pattern in that app instead of inventing a new structure.
5. If responsibilities moved, update the matching README in the same change.
6. If a local README does not exist, follow the fallback workflow in `docs/PROJECT_NAVIGATION.md` and inspect nearby files, imports, and tests.

## Fast Path

For low-token routing, do only enough reading to identify the owner:

1. Classify the request as `backend`, `frontend`, `services`, `mcp`, `e2e`, docs, or cross-app.
2. Open the app README and the nearest layer/module README.
3. Stop broad exploration once the owning module/service is clear; then inspect only nearby files,
   imports, and tests.
4. Use `docs/PROJECT_NAVIGATION.md` for deep maps, exceptions, and cross-app ownership instead of
   duplicating that context in the prompt.

Primary entry points:

- `README.md` for monorepo overview, quick start, workspace scripts, and current MVP status
- `docs/PROJECT_NAVIGATION.md` for app/layer ownership, reading order, and known README exceptions
- `docs/DEVELOPMENT_GUIDE.md` for local setup and day-to-day commands
- `docs/API_ENDPOINTS.md` for endpoint contracts
- `docs/AI_AGENT_TOOLS.md` for backend agent tools and MCP tool surface boundaries
- `docs/TESTING_STRATEGY.md` and `docs/TEST_CASE_MATRIX.md` for validation expectations
- `planos_execucao/MONOREPO.md` for workspace structure
- `apps/backend/README.md`
- `apps/frontend/README.md`
- `apps/services/README.md`
- `apps/mcp/README.md`
- `blueaccount/README.md` for the symlinked Terraform root module

## Infrastructure as Code

AWS IaC is available through the repository-root symlink `blueaccount/`. Its target is a separate
Git repository and must be treated as a separate working tree.

Before IaC work:

1. Verify that `blueaccount/` exists, resolves successfully, and is a directory.
2. Read `blueaccount/README.md`.
3. Inspect the Git status of both the application repository and the symlink target.
4. Keep deployable `.tf` files in the IaC root module; nested folders are only loaded when they are
   explicitly declared as Terraform modules.

If the symlink is missing, broken, or does not resolve to a directory, stop and ask the user for the
IaC repository location. Do not guess a replacement, scan the machine for it, or create a new
symlink without user direction.

## Choose The App Before The File

### `apps/backend`

Use for:

- HTTP APIs
- auth and OAuth
- database persistence
- multi-tenant/RLS flows
- orchestration of document, report, billing, and AI actions

Read first:

- `apps/backend/README.md`
- `apps/backend/src/README.md`

For any change inside `apps/backend`, also invoke the `blueaccount-backend-navigator` skill. It
maps the Nest layers, domain/database/infrastructure boundaries, RLS/migration rules, backend
tests, and backend documentation triggers.

Then pick the layer:

- `src/app` for bootstrap and root application wiring
- `src/modules` for Nest modules, controllers, guards, and orchestration services
- `src/http` for generic HTTP controllers and middlewares
- `src/domain` for business rules, calculations, normalization, and use-case logic
- `src/infrastructure` for AWS, DB, logging, external clients, and technical adapters
- `src/database` for entities, migrations, RLS helpers, and tenant schema tooling
- `src/agent` for backend-side AI agent adapters and execution wrappers
- `src/tools` for reusable technical or agent-support utilities

Backend rule of thumb:

- If the code does not need Nest, HTTP, or persistence details, prefer `src/domain`.
- Keep controllers and transport handlers thin.
- Keep technical integration code out of `src/domain`.

Backend hotspots in the current MVP: see the module/layer map in `apps/backend/src/README.md` and
`docs/PROJECT_NAVIGATION.md` (kept current there; not duplicated here to avoid drift).

Be careful with naming and documentation coverage:

- even when instructions are in English, new project-owned function, class, module, folder, service,
  domain, and business type names must be in Portuguese, matching the repo vocabulary
- stable public contracts, HTTP route slugs, API payload fields, env vars, MCP tool names, SDK/framework
  concepts, and documented compatibility exceptions may stay English
- `src/modules/auth` is a deliberate English naming exception because it is the stable Nest auth entrypoint; domain rules still live under `src/domain/autenticacao`
- API route slugs such as `billing-complexities`, `contract-extraction-complexities`, and `extraction-models` remain English for compatibility even though their backend domains are `complexidades-cobranca`, `complexidades-extracao-contrato`, and `modelos-extracao`

### `apps/frontend`

Use for:

- pages, navigation, and authenticated product flows
- review screens for contratos and relatorios
- operational cockpits for documentos, excedentes, faturamento, and AI actions
- reusable UI blocks and global auth/session state

Read first:

- `apps/frontend/README.md`
- `apps/frontend/src/README.md`

Then pick the layer:

- `src/pages` for route-level orchestration and screen state
- `src/components` for reusable UI blocks by domain
- `src/contexts` for auth/session global state
- `src/lib` for API client and integration helpers
- `src/styles` for tokens and shared CSS
- `src/kontiva` for internal design-system/navigation support
- `src/test` for shared frontend test setup

Frontend rule of thumb:

- keep page orchestration in `src/pages`
- keep API access centralized in `src/lib/api.ts`
- keep shared rendering concerns in `src/components`
- update page/component READMEs when route ownership or module responsibilities change

Current frontend flows to recognize before editing: see the page/route catalog in
`apps/frontend/src/pages/README.md` (authoritative; not duplicated here to avoid drift).

### `apps/services`

Use for:

- OCR pipelines
- document extraction
- contract consolidation
- async ingestion payload generation
- Step Functions and Lambda orchestration
- AgentCore Python runtimes

Read first:

- `apps/services/README.md`

For any change inside `apps/services`, also invoke the `blueaccount-services-navigator` skill. It
maps SAM workflow services, Step Functions, TypeScript Lambdas, AgentCore Python runtimes, callback
contracts, validation commands, and service documentation triggers.

Agent rule of thumb:

- when the user says they want to change an "agent", start in `apps/services`
- if the work is about ingestion, normalization, OCR, extraction, polling, callback, or async pipeline orchestration, it usually belongs to one of the SAM services with Lambdas and Step Functions
- if the work is not an ingestion pipeline and is really about agent behavior, prompts, tools, runtime config, or model execution, it usually belongs to `apps/services/agents`
- only move to backend agent adapters after confirming the change is not actually in the service runtime itself

Then choose the service: see the service catalog in `apps/services/README.md` (authoritative; not
duplicated here to avoid drift).

Services rule of thumb:

- keep workflow contracts aligned across `template.yaml`, `statemachine`, `events`, `src`, and README docs
- for TypeScript Lambdas, reuse a service's `src/shared` helpers when that directory exists before duplicating parsing or S3/Bedrock code
- `apps/services/ingestao-payload` and `apps/services/agents` do not necessarily follow the `src/shared` convention; match the local structure there
- for Python agents, preserve deterministic business logic where possible so tests can run without AWS

### `apps/mcp`

Use for:

- MCP transport
- tool exposure for the Kontiva API
- OAuth/session propagation for agent calls

Read first:

- `apps/mcp/README.md`

For any change inside `apps/mcp`, also invoke the `blueaccount-mcp-navigator` skill — it maps the
per-concern module layout (`client/`, `tools/`, `resources/`, `prompts/`, `shared.ts`, `content.ts`),
the acyclic dependency rule, and the tool-surface guardrails.

Use `apps/mcp` when the change is about:

- which tools are exposed to AI clients
- session cookie or bearer-token forwarding
- MCP transport mode (`stdio` or `http`)
- audit headers or connector-safe sanitization

Do not place product business rules here; those stay in backend domain/modules.

## Cross-App Flow Map

Use this mental model for end-to-end work:

1. `frontend` initiates upload, review, QA, AI action, or billing workflow
2. `backend` authenticates, persists state, exposes review endpoints, and orchestrates business transitions
3. `services/ocr-pipeline`, `services/contratos`, `services/relatorios`, or `services/ingestao-payload` run async extraction flows
4. `services/agents` runs AgentCore workloads when reasoning should happen outside the API process
5. `apps/mcp` exposes selected backend data/tools to interactive AI agents

If a feature spans more than one app, inspect the docs in each touched app before editing code.

## Suggested Reading Order By Task

### Add or change a backend endpoint

1. `apps/backend/README.md`
2. `apps/backend/src/README.md`
3. invoke `blueaccount-backend-navigator`
4. the target module README in `apps/backend/src/modules/*/README.md`
5. `docs/API_ENDPOINTS.md`

### Change business rules

1. `apps/backend/src/README.md`
2. invoke `blueaccount-backend-navigator`
3. the relevant README in `apps/backend/src/domain/*/README.md`
4. nearby tests in the same domain folder

### Change a frontend screen

1. `apps/frontend/README.md`
2. `apps/frontend/src/README.md`
3. `apps/frontend/src/pages/README.md`
4. the component README for the touched domain, if any

### Change OCR, extraction, or ingestion

Ingestion changes go to the **State Machine**, **not the backend** — the backend only enqueues.
See the "Intake e router de ingestão" section in `apps/services/README.md` for the queue →
router → SM flow and where to edit each piece.

1. `apps/services/README.md` (authoritative: queue + router + flow + where to edit)
2. invoke `blueaccount-services-navigator`
3. the real SM in the module's SAM service (`apps/services/contratos`, `apps/services/relatorios`,
   or `apps/services/ocr-pipeline`)
4. the backend module README — only when the SQS message contract or a callback endpoint changes

### Change agent behavior

1. `apps/services/README.md`
2. invoke `blueaccount-services-navigator`
3. decide whether the request is really ingestion or runtime-agent behavior
4. if it is ingestion, open the matching service README under `apps/services/*`
5. if it is non-ingestion agent behavior, open `apps/services/agents/README.md`
6. only then inspect backend adapters such as `apps/backend/src/agent` or `apps/backend/src/modules/agentes` when the caller/integration also needs to change

### Change MCP behavior

1. `apps/mcp/README.md`
2. `docs/AI_AGENT_TOOLS.md`
3. the backend auth/OAuth docs it depends on
4. the consuming agent docs under `apps/services/agents`, when applicable

## Code Placement Rules

- Prefer extending an existing module/domain/service over creating parallel structures.
- Do not introduce raw Express routes for new backend features; use Nest modules/controllers.
- Do not put backend business rules inside frontend helpers, MCP tools, or SAM Lambdas unless that logic truly belongs there.
- Do not bypass the async ingestion flow by hardcoding review payload assumptions in the frontend.
- Keep tests near the touched app/layer whenever the repo already follows that pattern.
- When adding a new tenant entity used via `runQueryWithRls`, register it in BOTH `entities` arrays — `src/database/data-source.ts` (runtime/RLS) AND `src/database/modules/tenant/entities`'s `tenant-datasource.ts` (migrations). Missing the `data-source.ts` one compiles fine but throws `No metadata for "X"` (HTTP 500) at runtime. See `apps/backend/src/database/README.md` → "adicionar uma nova entidade/tabela em tenant".

## Fast Lookup

Use `rg` for text search and `rg --files` for file discovery.

Useful starting points:

- `apps/backend/src/modules`
- `apps/backend/src/domain`
- `apps/backend/src/infrastructure`
- `apps/backend/src/database`
- `apps/frontend/src/pages`
- `apps/frontend/src/components`
- `apps/frontend/src/lib/api.ts`
- `apps/services/README.md`
- `apps/services/agents/README.md`
- `apps/mcp/src`
- `docs/PROJECT_NAVIGATION.md`
- `docs/API_ENDPOINTS.md`
- `docs/AI_AGENT_TOOLS.md`
- `docs/TESTING_STRATEGY.md`
- `docs/TEST_CASE_MATRIX.md`

## Documentation Rule

When you change architecture, ownership, workflow contracts, or developer entry points, update the nearest README or guide in the same change.

At minimum, consider whether you also need to touch:

- `README.md`
- `docs/PROJECT_NAVIGATION.md`
- `docs/DEVELOPMENT_GUIDE.md`
- `docs/API_ENDPOINTS.md`
- `docs/AI_AGENT_TOOLS.md`
- `apps/backend/src/README.md`
- `apps/frontend/src/README.md`
- `apps/services/README.md`
- the README inside the exact module/domain/service you edited
