---
name: blueaccount-backend-navigator
description: Use after blueaccount-project-navigator for any work in `apps/backend` of the BlueAccount/Kontiva MVP monorepo — NestJS controllers/modules/services, HTTP APIs, auth/OAuth, domain business rules, TypeORM entities, migrations, RLS/tenant queries, AWS/database infrastructure adapters, backend-side AI agents, backend tests, or backend README/API docs. Maps the Nest layer boundaries, RLS/migration rules, verification commands, and documentation triggers.
---

# BlueAccount Backend Navigator

Use this skill after `blueaccount-project-navigator` points the task at `apps/backend`.

## Start Here

1. Read `apps/backend/README.md`.
2. Read `apps/backend/src/README.md`.
3. Read the nearest layer, module, domain, infrastructure, database, or agent README before opening implementation files.
4. Use `docs/API_ENDPOINTS.md` when a public HTTP contract changes.
5. Use `docs/AI_AGENT_TOOLS.md` when backend agent behavior or MCP-facing backend contracts change.

## Choose The Layer

- `src/modules` is for Nest modules, controllers, guards, and orchestration providers.
- `src/http` is for generic HTTP controllers, middleware, filters, and transport concerns.
- `src/domain` is for business rules, validation, calculations, normalization, and use-case coordination.
- `src/database` is for TypeORM entities, migrations, tenant schema tooling, and RLS helpers.
- `src/infrastructure` is for AWS, database, logging, AI factories, storage, and external clients.
- `src/agent` is for backend-side adapters that call or wrap AI/AgentCore behavior.
- `src/tools` is for reusable technical or agent-support utilities.

Rule of thumb: controllers stay thin, orchestration stays in modules, business decisions stay in
domain, and low-level integration details stay in infrastructure or database.

## Backend Guardrails

- Follow the project naming rule: new project-owned functions, classes, modules, folders, services,
  domains, and business types are Portuguese unless they are a documented public-contract exception.
- Do not add raw Express routes for new product flows; use Nest controllers/modules.
- For tenant queries, use the existing `runQueryWithRls` pattern and preserve tenant isolation.
- When adding a tenant entity used through `runQueryWithRls`, register it in both runtime and tenant
  migration DataSource entity arrays as documented in `apps/backend/src/database/README.md`.
- Generate and review migrations instead of hand-writing schema drift into runtime code.
- Keep backend business rules out of frontend helpers, MCP tools, and SAM Lambdas unless ownership is
  explicitly cross-app and documented.

## Documentation

Update the nearest README or guide when changing ownership, workflow contracts, routes, developer
entry points, migrations, or module responsibilities.

Common docs to check:

- `apps/backend/src/modules/<modulo>/README.md` for controller/module contracts.
- `apps/backend/src/domain/<dominio>/README.md` for business rules.
- `apps/backend/src/database/README.md` for entity, migration, or RLS changes.
- `docs/API_ENDPOINTS.md` for HTTP contract changes.
- `docs/AI_AGENT_TOOLS.md` for backend agent or AI-tool contracts.

## Verify

Choose the narrowest verification that covers the changed layer:

```bash
npm run test --workspace apps/backend
npm run build --workspace apps/backend
npm run test:integration --workspace apps/backend
```

For database work, also validate migration generation/apply paths documented in
`apps/backend/src/database/README.md`.
