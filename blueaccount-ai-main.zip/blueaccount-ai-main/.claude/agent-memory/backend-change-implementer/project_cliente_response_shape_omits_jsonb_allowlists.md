---
name: project-cliente-response-shape-omits-jsonb-allowlists
description: ClientePatchResult/ClienteCreateResult (cliente.service.ts) deliberately do not echo jsonb allowlist/array fields back in the response body
metadata:
  type: project
---

`ClientePatchResult`/`ClienteCreateResult` (`apps/backend/src/domain/clientes/cliente.service.ts`,
`createCliente`/`patchCliente`) return a `cliente: {...}` object that omits `cnaes_secundarios`,
`cnaes_fornecedores_permitidos`, and (added 2026-08-06) `ncms_permitidos` entirely — these jsonb
array fields are persisted and validated but never echoed in the create/patch response, even though
they DO appear in `ClienteDetalhe` (the GET-by-id read shape) and in `ClienteCreateInput`/
`ClientePatchInput`.

**Why:** confirmed by reading the existing code before assuming it was a gap — `cnaes_secundarios`/
`cnaes_fornecedores_permitidos` already followed this pattern before the NCM allowlist feature was
added, so it's an established convention, not an oversight. The existing
`cliente.service.test.ts` test `"persists a manually typed cnaes_fornecedores_permitidos allowlist
on creation"` asserts `result.cliente` explicitly does NOT have that property.

**How to apply:** when adding a new jsonb array/allowlist-style field to `Cliente` (mirroring CNAE
column conventions), do NOT add it to `ClientePatchResult`/`ClienteCreateResult` unless the sibling
CNAE fields already have it — check the actual type body before assuming symmetry with
`ClienteDetalhe`. Only the plain scalar fields (id, cnpj, razao_social, regime_tributario, etc.) are
echoed in create/patch responses; jsonb arrays are read back via the separate GET (`ClienteDetalhe`).
See [[project_blueaccount]] for the wider domain map.
