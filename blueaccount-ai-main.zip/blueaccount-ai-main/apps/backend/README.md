# BlueAccount Backend

**NestJS + TypeORM + Multi-Tenant**

API completa para gestão de clientes, contratos, relatórios e análise de cobrança com extração estruturada via IA.

## Agent/Skill Routing

Antes de alterar `apps/backend`, invoque `blueaccount-project-navigator` e depois
`blueaccount-backend-navigator`. Esses skills definem a ordem de leitura, a camada correta
(`modules`, `domain`, `database`, `infrastructure`, `agent`, `http`), as regras de RLS/migrations
e quando atualizar READMEs ou contratos HTTP.

**Índice:**
- [Quick Start](#quick-start)
- [Stack](#stack)
- [Arquitetura](#arquitetura)
- [Módulos](#módulos)
- [Fluxos Principais](#fluxos-principais)
- [Database & RLS](#database--rls)
- [Desenvolvimento](#desenvolvimento)
- [Troubleshooting](#troubleshooting)

---

## Quick Start

```bash
# 1. Setup
npm install
npm run migration:run
npm run migration:sync-tenants

# 2. Dev
npm run dev:backend
# Em outro processo (ou use ./runapp.py sem flags)
npm run --workspace @blueaccount/backend simulation-worker

# 3. Abrir http://localhost:3000
```

**Com frontend:**
```bash
# Terminal 1
npm run dev:backend

# Terminal 2 (em apps/frontend)
npm run dev:frontend
```

O cálculo de simulações não roda nas requisições HTTP. O processo
`worker-calculo-simulacoes.ts` consome a fila PostgreSQL e publica o resultado durável; export XLSX,
relatórios e fluxo de caixa respondem `409 / SIMULACAO_CALCULO_DESATUALIZADO` enquanto o resultado
não estiver atual. Operações disponíveis: `POST /api/simulacoes/:id/recalcular` e os controles admin
sob `/api/admin/simulacoes/fila`.

---

## Stack

- **NestJS 11** - Framework
- **TypeScript 5** - Linguagem
- **PostgreSQL + TypeORM** - Banco + ORM
- **Row-Level Security (RLS)** - Multi-tenant
- **AWS Cognito** - Autenticação
- **AWS Bedrock + Claude** - IA Estruturada
- **AWS S3** - Storage
- **Express** - HTTP Server

---

## Arquitetura

```
┌─────────────────────────────────┐
│       Frontend (React)           │
│  (apps/frontend)                │
└──────────────┬──────────────────┘
               │ /api/*
               ↓
┌──────────────────────────────────────┐
│  HTTP Layer (NestJS)                 │
│  - Controllers                       │
│  - AuthGuard, RLS middleware         │
└──────────────┬───────────────────────┘
               │
    ┌──────────┴──────────┐
    ↓                     ↓
┌──────────────────┐ ┌────────────────────┐
│ Modules          │ │ Domain             │
│ - auth           │ │ - contratos        │
│ - clientes       │ │ - valores-a-cobrar │
│ - contratos      │ │ - relatorios       │
│ - relatorios     │ │ - (etc)            │
│ - documentos     │ │                    │
│ - valores-a-cobr │ │ (Lógica pura)      │
│ - agentes        │ │                    │
│                  │ │                    │
│ (Controllers +   │ │                    │
│  Orquestração)   │ │                    │
└────────┬─────────┘ └────────┬───────────┘
         │                    │
         └────────┬───────────┘
                  │
    ┌─────────────┴──────────────┐
    ↓                            ↓
┌──────────────────┐   ┌─────────────────┐
│ Infrastructure   │   │ Database        │
│ - AWS Cognito    │   │ - PostgreSQL    │
│ - AWS Bedrock    │   │ - RLS Policies  │
│ - AWS S3         │   │ - Migrations    │
│ - AI Factory     │   │ - Entities      │
└──────────────────┘   └─────────────────┘
```

**Padrão de Camadas:**
1. **HTTP Layer** — Controllers (NestJS)
2. **Modules** — Orquestração e serviços (Nest)
3. **Domain** — Lógica de negócio pura
4. **Infrastructure** — Integrações técnicas
5. **Database** — Persistência e RLS

---

## Módulos

Cada módulo tem **documentation próprio**. Acesse:

| Módulo | Descrição | Docs |
|--------|-----------|------|
| **auth** | Autenticação com Cognito | [📄](src/modules/auth/README.md) |
| **clientes** | CRUD de clientes | [📄](src/modules/clientes/README.md) |
| **contratos** | Gestão de contratos | [📄](src/modules/contratos/README.md) |
| **relatorios** | Extração de relatórios | [📄](src/modules/relatorios/README.md) |
| **documentos** | Upload e OCR | [📄](src/modules/documentos/README.md) |
| **extracao** | IA estruturada | [📄](src/modules/extracao/README.md) |
| **valores-a-cobrar** | Consolidação de cobrança | [📄](src/modules/valores-a-cobrar/README.md) |
| **cobrancas** | Emissão e provedores de cobrança | [📄](src/modules/cobrancas/README.md) |
| **faturamento** | Faturamento observado | [📄](src/modules/faturamento/README.md) |
| **eval-cobranca** | Avaliação de cobrança para escritórios teste | [📄](src/modules/eval-cobranca/README.md) |
| **servicos-contratados** | Gestão de serviços | [📄](src/modules/servicos-contratados/README.md) |
| **escritorios** | Bootstrap multi-tenant | [📄](src/modules/escritorios/README.md) |
| **agentes** | Orquestração IA e ações de IA | [📄](src/modules/agentes/README.md) |
| **assinaturas-eletronicas** | OAuth, sincronização e importação de contratos assinados | [📄](src/modules/assinaturas-eletronicas/README.md) |

**Para mudanças específicas de um módulo, comece pelo README dele.**

---

## Fluxos Principais

### 1. Upload e Extração de Contrato

O fluxo é dividido em duas etapas independentes:

**Etapa 1 — Ingestão (automática, assíncrona):**
```
Upload PDF
  ↓
POST /api/documentos
  ↓
State Machine (AWS Step Functions)
  ↓ OCR (Textract) + extração estruturada (Bedrock)
  ↓
IngestaoPayloadAgent (normalizador)
  gera payload_normalizado_ui com:
  - displayFields (campos para o frontend)
  - payloadInsercaoDb (campos prontos para o banco)
  ↓
payload_normalizado_ui salvo no Documento
```

**Etapa 2 — Confirmação pelo usuário:**
```
Frontend exibe payload_normalizado_ui para revisão
  ↓
Usuário confirma (com ou sem ajustes em campos_editados)
  ↓
POST /contratos/:documentoId/confirmar
  ↓
Backend lê payloadInsercaoDb do documento
aplica campos_editados
desativa contratos anteriores do cliente
salva novo Contrato (com valores_contratados e excedentes como JSONB)
salva ClausulasExcedentes relacionais
  ↓
Contrato criado em banco
```

**Módulos envolvidos:** documentos → (SM + IngestaoPayloadAgent) → contratos → domain/contratos

### 2. Extração de Relatório

```
Upload XLSX/PDF
  ↓
POST /api/extract-report (IA lê estrutura)
  ↓
Retorna dados estruturado
  ↓
Usuário revisa e confirma no fluxo de relatórios
  ↓
Domínio de relatórios salva o registro
  ↓
(background) consolidarCompetencia()
  ↓
valores_a_cobrar atualizado
```

**Módulos envolvidos:** documentos → extracao → relatorios → valores-a-cobrar

### 3. Consolidação de Cobrança

```
Novo relatório salvo
  ↓
relatorio.service.ts dispara:
  consolidarCompetencia(cliente_id, competencia)
  ↓
Busca contrato ativo + relatórios
  ↓
Extrai valores_observados por tipo_relatorio
  ↓
Upsert em valores_a_cobrar
  ↓
Status: "aberto" (aguardando IA calcular)
  ↓
(futuro) IA calcula valores_calculados
```

**Módulos envolvidos:** relatorios → valores-a-cobrar → domain/consolidacao

---

## Database & RLS

### Estrutura Multi-Tenant

- **Schema `public`** — Shared data (escritorios, usuarios, admin_sessions)
- **Schema `tenant_<id>`** — Isolado por cliente (clientes, contratos, documentos, etc)

### Row-Level Security (RLS)

Cada query executa com `SET app.current_tenant_id = '<id>'`

```sql
CREATE POLICY "isolate_by_tenant" ON clientes
  USING (escritorio_id = current_setting('app.current_tenant_id'));
```

**Framework responsável:** `src/database/data-source.ts` (`runQueryWithRls`)

### Migrations

```bash
# Criar migrations
npm run migration:generate -- --name=AddField

# Executar
npm run migration:run

# Sincronizar schemas de tenant
npm run migration:sync-tenants

# Reverter
npm run migration:revert
```

**Docs:** Veja `src/database/README.md`

---

## Desenvolvimento

### Estrutura de Pastas

```
src/
├── main.ts                    ← Bootstrap
├── app.module.ts             ← Root module
│
├── modules/                   ← Feature modules (HTTP)
│   ├── auth/
│   ├── clientes/
│   ├── contratos/
│   ├── documentos/
│   ├── relatorios/
│   ├── extracao/
│   ├── valores-a-cobrar/
│   ├── servicos-contratados/
│   ├── escritorios/
│   └── agentes/
│
├── domain/                    ← Regra de negócio pura
│   ├── contratos/
│   ├── relatorios/
│   ├── valores-a-cobrar/
│   ├── servicos-contratados/
│   └── (etc)
│
├── infrastructure/            ← Integrações técnicas
│   ├── ai/                    ← AI Factory
│   ├── database/              ← TypeORM config
│   ├── external-services/     ← Cognito, Bedrock, S3
│   └── logging/               ← Logger
│
├── database/                  ← Schema, migrations, entities
│   ├── entities/
│   ├── migrations/
│   └── modules/
│       ├── public/            ← Shared schema
│       └── tenant/            ← Tenant schemas
│
└── tools/                     ← Utilitários
```

### Adicionando Novo Módulo

1. **Criar estrutura**
   ```
   src/modules/{novo}/
   ├── {novo}.controller.ts
   ├── {novo}.service.ts
   ├── {novo}.module.ts
   └── README.md
   
   src/domain/{novo}/
   ├── {novo}.service.ts
   └── tests/
   ```

2. **Implementar controller** — orquestração HTTP
3. **Implementar service** — delegar para domain
4. **Implementar domain** — lógica pura
5. **Documentar** — README com endpoints

### Padrão: Controller → Service → Domain

```typescript
// Controller (HTTP entry)
@Post('/something')
async create(@Body() body) {
  return this.service.create(body);
}

// Service (Orquestração Nest)
@Injectable()
export class SomeService {
  async create(body) {
    return this.domainService.create(body);
  }
}

// Domain (Lógica pura)
export async function create(input) {
  // Validação, cálculo, persistência
  return db.save(result);
}
```

### Testes

```bash
# Testes unitários
npm run test

# Watch mode
npm run test:watch

# Coverage
npm run test:cov
```

**Padrão:** `*.test.ts` ao lado do arquivo testado

### Validação com Zod

```typescript
import { z } from 'zod';

const createSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
});

export async function create(input: unknown) {
  const data = createSchema.parse(input); // Lança ZodError
  // ... resto
}
```

---

## Troubleshooting

### Porta 3000 já em uso?

```bash
lsof -i :3000
kill -9 <PID>
```

### Migrations falhando?

```bash
# Reverter e rodar novamente
npm run migration:revert
npm run migration:run
```

### RLS não funcionando?

- Verifique: `src/database/data-source.ts` está setando `app.current_tenant_id`
- Teste: `SELECT current_setting('app.current_tenant_id');`
- Check policies: `SELECT * FROM pg_policies WHERE tablename = 'clientes';`

### Relatório não consolida?

- Verifique logs: `tail -f logs/*.log`
- Check: `GET /api/valores-a-cobrar?cliente_id=<id>`
- Manual: `POST /api/valores-a-cobrar/consolidar/<cliente_id>/<competencia>`

### IA retorna erro?

- Verifique credenciais AWS (`AWS_REGION`, perfil ou IAM role) em `.env`
- Verifique `DOCUMENT_BEDROCK_INFERENCE_PROFILE_ID` configurado
- Logs: `npm run dev` e monitore console

### Sessão não persiste?

- Frontend deve enviar `credentials: "include"`
- CORS config em `main.ts`
- Cookie HTTP-only sendo setado corretamente?

---

## Próximos Passos

**Curto prazo:**
- [ ] Endpoint IA calcular valores_calculados
- [ ] Workflow de aprovação de cobrança
- [ ] Relatório PDF de faturamento

**Médio prazo:**
- [ ] E2E tests
- [ ] Webhooks (documento enviado, extração concluída)
- [ ] Rate limiting
- [ ] Audit logs

**Longo prazo:**
- [ ] Integrações com ERPs (SAP, Omie)
- [ ] Suporte XML, EDI
- [ ] Machine learning para análise de riscos

---

**Última atualização:** 2026-04-29  
**Mantido por:** Equipe BlueAccount

Para dúvidas sobre um módulo específico, acesse o README dele (links acima). 

**Para planos e histórico de decisões:**
→ **[`planos_execucao/`](../../planos_execucao/)**

## Integração HubSpot

`python3 runservice.py integracoes-crm` inicia a harness SAM/Step Functions; não existe worker CRM.
[Configuração, testes e rollout](src/modules/integracoes-crm/README.md).

## Réplicas ECS e encerramento

`DB_POOL_MAX` limita **cada** pool TypeORM compartilhado (owner e RLS): padrão 10,
inteiro positivo até 10.000; entradas inválidas usam o padrão. A API e o worker de
simulações recebem 2 no ECS, portanto até 4 conexões compartilhadas por processo.
Os DataSources próprios de migration pública/tenant usam duas conexões cada. Pools
por tenant durante provisionamento são adicionais e entram no orçamento de pico.

`DB_SYNC_TENANTS_ON_BOOT` é `true` por padrão; `false` inicializa o datasource sem
executar a varredura de schemas. No ECS é `false`, pois o job de migrations do deploy
provisiona/sincroniza tenants antes do rollout. Provisionamento explícito de escritórios
continua disponível. `runapp.py -b` executa `migration:sync-tenants` antes de subir a API;
para verificar apenas o flag, iniciar `npm run serve` diretamente com banco de teste.

SIGTERM/SIGINT usam somente os hooks do Nest: drenar HTTP, depois fechar os pools.
O prazo é 100 s, com saída 1 ao exceder; ECS permite 120 s. Não há garantia de concluir
requisições maiores que esse prazo. Rate limits em memória continuam por réplica.
A expansão fica bloqueada no Terraform até validar o orçamento real de conexões;
consulte `blueaccount/README.md`, seção de escalabilidade.
