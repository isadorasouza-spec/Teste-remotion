import "reflect-metadata";
import assert from "node:assert/strict";
import { AppDataSource, runQueryWithRls, RlsDataSource } from "../src/database/data-source.js"; // rls-guard-ok: script local fecha o pool ao terminar
import { ConsultaNotasPostgres, montarConsultaPostgres } from "../src/infrastructure/database/consulta-notas-postgres.js";
if (process.env.DB_HOST !== "127.0.0.1" || process.env.DB_DATABASE !== "kontiva_fiscal_piloto") throw new Error("Destino fora do piloto.");
const escritorio="01993000-0000-7000-8000-000000000001", cliente="01993000-0000-7000-9000-000000000001";
const empresas=[{id:cliente,cnpj:"12345678000195",razao_social:"Empresa piloto"}];
const filtros={empresa_id:cliente,tipo:"todos" as const,movimento:"todos" as const,data_inicio:"2020-01-01",data_fim:"2030-12-31"};
const adapter=new ConsultaNotasPostgres();
try {
  const id=await adapter.iniciar(escritorio,empresas,filtros);
  assert.equal(await adapter.estado(escritorio,id),"SUCCEEDED");
  const primeira=await adapter.pagina(escritorio,id);
  assert.ok(primeira.items.length>0);
  assert.ok(primeira.items.every(n=>typeof n.valor_nota==='string' && !('_normalizado_uri' in n)));
  // Mutação concorrente de fatos é coberta na suíte de integração; esta sonda só lê.
  assert.deepEqual(await adapter.pagina(escritorio,id),primeira);
  await assert.rejects(adapter.estado("01993000-0000-7000-8000-000000000002",id));
  const q=montarConsultaPostgres(escritorio,empresas,filtros);
  const plano=await runQueryWithRls({escritorio_id:escritorio},m=>m.query(`EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ${q.sql}`,q.parametros));
  console.log(JSON.stringify({consulta:id,notas:primeira.items.length,plano},null,2));
} finally {
  if (AppDataSource.isInitialized) await AppDataSource.destroy();
  if (RlsDataSource.isInitialized) await RlsDataSource.destroy(); // rls-guard-ok: fechamento do pool de teste local
}
