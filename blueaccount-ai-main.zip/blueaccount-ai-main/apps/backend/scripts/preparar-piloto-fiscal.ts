/** Provisionamento exclusivamente local. Não lê nem copia dados de outro banco. */
import "reflect-metadata";
import { AppDataSource } from "../src/database/data-source.js";
import { provisionEscritorioSchema } from "../src/database/escritorio-schema.js";
import { buildEscritorioSchemaName, buildEscritorioRoleName } from "../src/database/tenant-naming.js";
if (process.env.DB_HOST !== "127.0.0.1" || process.env.DB_DATABASE !== "kontiva_fiscal_piloto") throw new Error("Destino fora do piloto local.");
await AppDataSource.initialize();
try {
  const existe = await AppDataSource.query("SELECT 1 FROM pg_roles WHERE rolname='fiscal_piloto'");
  if (!existe.length) await AppDataSource.query("CREATE ROLE fiscal_piloto LOGIN PASSWORD 'local-piloto' NOSUPERUSER NOBYPASSRLS NOINHERIT");
  for (let i=1;i<=3;i++) {
    const escritorio = `01993000-0000-7000-8000-00000000000${i}`;
    const cliente = `01993000-0000-7000-9000-00000000000${i}`;
    await AppDataSource.query("INSERT INTO public.escritorios(id,nome) VALUES($1,$2) ON CONFLICT DO NOTHING",[escritorio,`Piloto ${i}`]);
    await provisionEscritorioSchema(AppDataSource.manager, escritorio);
    const schema=buildEscritorioSchemaName(escritorio), role=buildEscritorioRoleName(escritorio);
    await AppDataSource.query(`GRANT "${role}" TO fiscal_piloto`);
    await AppDataSource.query(`INSERT INTO "${schema}".clientes(id,escritorio_id,cnpj,razao_social) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`,[cliente,escritorio,`1234567800010${i}`,`Empresa piloto ${i}`]);
    console.log(`Tenant ${i} provisionado: ${schema}`);
  }
} finally { await AppDataSource.destroy(); }
