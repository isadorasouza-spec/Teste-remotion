#!/usr/bin/env python3
"""Reproduz o snapshot CONFAZ revisado; não consulta a rede nem altera banco.

Uso: python3 apps/backend/scripts/gerar-catalogo-cfop.py /tmp/cfop-anexo.html
Baixe o HTML da fonte indicada abaixo. Mudança de hash exige revisão legal e do parser.
"""
import hashlib
import json
import re
import sys
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

FONTE = "https://www.confaz.fazenda.gov.br/legislacao/ajustes/sinief/cfop_cvsn_1-6.24"
PADRAO_CODIGO = re.compile(r"^([123567])\.(\d{3})\s*[-–]\s*(.+)")
TOTAIS = {"1": 131, "2": 125, "3": 32, "5": 154, "6": 149, "7": 28}


class Paragrafos(HTMLParser):
    def __init__(self):
        super().__init__()
        self.atual = None
        self.itens = []

    def handle_starttag(self, tag, atributos):
        if tag == "p":
            self.atual = [dict(atributos).get("class", ""), ""]

    def handle_data(self, texto):
        if self.atual is not None:
            self.atual[1] += texto

    def handle_endtag(self, tag):
        if tag == "p" and self.atual is not None:
            classe, texto = self.atual
            self.itens.append((classe, re.sub(r"\s+", " ", texto).strip()))
            self.atual = None


def extrair(conteudo):
    if hashlib.sha256(conteudo).hexdigest() != "51d12b7f9e1c2f08b9665a06875a64737726ce4a633138f437a90e431eb659e0":
        raise ValueError("Fonte alterada: revisar atos, vigências e parser antes de atualizar o hash e a data deste snapshot.")
    parser = Paragrafos()
    parser.feed(conteudo.decode("utf-8"))
    registros, historico = [], []
    atual = None
    for classe, texto in parser.itens:
        if classe not in ("A5-1TextoAcordo", "A8-3RedacaoAnt") or not texto:
            continue
        cabecalho = PADRAO_CODIGO.match(texto)
        if cabecalho:
            grupo, sufixo, descricao = cabecalho.groups()
            descricao, separador, nota = descricao.partition(" Classificam-se ")
            atual = {"codigo": grupo + sufixo, "descricao": descricao,
                     "nota_explicativa": "Classificam-se " + nota if separador else ""}
            (historico if classe == "A8-3RedacaoAnt" else registros).append(atual)
        elif re.match(r"^[123567]\.\d{3}", texto):
            raise ValueError(f"Cabeçalho não interpretado: {texto}")
        elif atual is not None and not texto.startswith("DAS "):
            atual["nota_explicativa"] += (" " if atual["nota_explicativa"] else "") + texto

    # O consolidado distingue cabeçalhos por títulos em maiúsculas. Há grupos x150,
    # x250 etc.; testar apenas o sufixo 00 aceitava 32 cabeçalhos como operações.
    grupos = [r for r in registros if r["descricao"].isupper()]
    cfops = [r for r in registros if not r["descricao"].isupper()]
    assert len(cfops) == len({r["codigo"] for r in cfops}) == 619, "Catálogo incompleto/duplicado"
    assert Counter(r["codigo"][0] for r in cfops) == TOTAIS, "Cobertura por grupo mudou"
    assert len(grupos) == 76
    assert all(r["nota_explicativa"] for r in registros + historico)
    assert [r["codigo"] for r in historico] == ["7667"], "Revisar histórico novo"
    assert "Saída de combustíveis" in next(r for r in cfops if r["codigo"] == "7667")["descricao"]
    for r in cfops:
        r["vigencia_redacao_inicio"] = "2026-02-01" if r["codigo"] == "7667" else "2024-06-01"
        r["vigencia_redacao_fim"] = None
    historico[0].update(vigencia_redacao_inicio="2024-06-01", vigencia_redacao_fim="2026-01-31")
    return {
        "versao": "2026-09-17",
        "verificado_em": "2026-09-17",
        "fonte": FONTE,
        "sha256_fonte": hashlib.sha256(conteudo).hexdigest(),
        "atos": [
            "https://www.confaz.fazenda.gov.br/legislacao/ajustes/2024/AJ003_24",
            "https://www.confaz.fazenda.gov.br/legislacao/ajustes/2025/AJ039_25",
        ],
        "cobertura_inicio": "2024-06-01",
        "grupos": grupos,
        "cfops": cfops,
        "historico_redacoes": historico,
    }


if __name__ == "__main__":
    catalogo = extrair(Path(sys.argv[1]).read_bytes())
    destino = Path(__file__).resolve().parents[1] / "src/domain/simulacoes/nfe/catalogo-cfop.dados.ts"
    # Uma linha por registro mantém o diff revisável sem repetir dezenas de milhares de linhas.
    linhas = []
    for chave, valor in catalogo.items():
        if chave in ("grupos", "cfops", "historico_redacoes"):
            linhas.append(f'  "{chave}": [\n' + ',\n'.join('    ' + json.dumps(r, ensure_ascii=False) for r in valor) + '\n  ]')
        else:
            linhas.append('  ' + json.dumps(chave) + ': ' + json.dumps(valor, ensure_ascii=False))
    destino.write_text('// Gerado por scripts/gerar-catalogo-cfop.py; revisar a fonte antes de regenerar.\nexport default {\n' + ',\n'.join(linhas) + '\n};\n')
    print(f"{len(catalogo['cfops'])} CFOPs, {len(catalogo['grupos'])} grupos; {destino}")
