"""Gera casos sintéticos de paridade usando o parser fiscal Python, sem serviços externos.
Executar com apps/services/documentos-fiscais/.venv/bin/python a partir da raiz.
"""
import json
import sys
from pathlib import Path

raiz = Path(__file__).resolve().parents[3]
servico = raiz / "apps/services/documentos-fiscais"
sys.path[:0] = [str(servico), str(servico / "tests")]
from test_nfe import contexto, FIXTURES
from documentos_fiscais.registro import adaptar_documento

nomes = ["nfe55-itens-icms-iss.xml", "nfe55-itens-ipi.xml", "nfe55-venda-nfeproc.xml",
         "nfce65-consumidor.xml", "nfe55-frete-fob.xml", "nfe55-frete-cif-confirmado.xml",
         "nfe55-frete-linha-propria-cfop5352.xml"]
casos = []
for caminho in [*(FIXTURES / nome for nome in nomes), servico / "tests/fixtures/nfse-nacional-1.01.xml"]:
    xml = caminho.read_bytes()
    resultado = adaptar_documento(xml, contexto(caminho.name, xml))
    resultado.total.update(carga_concluida=True, normalizado_uri="s3://bucket/normalizado", fonte="xml", versao_contrato="2.0")
    resultado.total["proveniencia"]["ingerido_em_utc"] = "2026-09-17T00:00:00Z"
    casos.append(dict(nome=caminho.name, total=resultado.total, itens=resultado.itens, esperado=resultado.projecao_simulacao))
(raiz / "apps/backend/src/domain/simulacoes/nfe/tests/fixtures/projecao-postgres.json").write_text(
    json.dumps(casos, default=str, ensure_ascii=False, indent=2) + "\n")
