"""Gera snapshot completo da tabela pública SVRS a partir do HTML salvo.
Uso: python3 apps/backend/scripts/gerar-catalogo-cclasstrib.py fonte.html
"""
import hashlib, json, sys
from pathlib import Path
conteudo = Path(sys.argv[1]).read_bytes()
grupos = json.JSONDecoder().raw_decode(conteudo.decode().split("var dadosOriginais = ", 1)[1])[0]
itens = [{"codigo": c["CodClassTrib"], "cst": g["Cst"], "descricao_cst": g["NomeCst"],
          "descricao": c["NomeClassTrib"].strip(), "descricao_reduzida": c["NomeReduzido"].strip(),
          "vigencia_inicio": c["DthIniVig"][:10], "vigencia_fim": c["DthFimVig"][:10] if c["DthFimVig"] else None,
          "publicacao": c["DthPublicacao"][:10], "fundamento_legal": c["TexUrlLegislacao"]}
         for g in grupos for c in g["ClassificacoesTributarias"]]
assert itens and len({i["codigo"] for i in itens}) == len(itens)
assert all(len(i["codigo"]) == 6 and i["codigo"].isdigit() and i["codigo"].startswith(i["cst"]) for i in itens)
destino = Path(__file__).resolve().parents[1] / "src/domain/simulacoes/nfe/catalogo-cclasstrib.dados.ts"
destino.write_text("// Gerado por scripts/gerar-catalogo-cclasstrib.py; não editar.\nexport const SHA256_CCLASSTRIB = " + json.dumps(hashlib.sha256(conteudo).hexdigest()) + ";\nexport const DADOS_CCLASSTRIB = " + json.dumps(sorted(itens, key=lambda i:i["codigo"]),ensure_ascii=False,indent=2) + ";\n")
print(f"{len(itens)} códigos gerados")
