#!/usr/bin/env node
// Guarda de isolamento multi-tenant (RLS).
//
// Toda leitura/escrita em tabela de tenant deve passar por `runQueryWithRls`
// (que usa o `RlsDataSource` com `SET LOCAL ROLE user_escritorio_<uuid>`).
// O `AppDataSource` conecta com o role dono do schema, que IGNORA o isolamento
// por schema/role e enxerga todos os escritórios. Portanto:
//
//   1. `AppDataSource.getRepository(<EntidadeDeTenant>)` é proibido — vaza entre
//      tenants. Use `runQueryWithRls({ escritorio_id }, (m) => m.getRepository(X))`.
//   2. `RlsDataSource` só pode ser referenciado em `database/data-source.ts` —
//      qualquer outro uso pula o wrapper `runQueryWithRls` (que aplica o role).
//
// Exceção legítima (ex.: analytics de plataforma cross-tenant, admin-gated):
// anote a linha com `// rls-guard-ok: <motivo>` na própria linha ou na de cima.
//
// Roda sem dependências. `node scripts/verificar-rls-tenant.mjs` a partir de apps/backend.

import { readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";

const backendRoot = join(dirname(fileURLToPath(import.meta.url)), "..");
const srcRoot = join(backendRoot, "src");
const tenantEntitiesDir = join(srcRoot, "database/modules/tenant/entities");
const dataSourceFile = join(srcRoot, "database/data-source.ts");

const ALLOW_MARKER = "rls-guard-ok";

/** Lista arquivos .ts sob `dir`, ignorando testes e a pasta scripts. */
function listarArquivosTs(dir) {
  const saida = [];
  for (const nome of readdirSync(dir)) {
    const caminho = join(dir, nome);
    const info = statSync(caminho);
    if (info.isDirectory()) {
      if (nome === "tests" || nome === "node_modules" || nome === "dist") continue;
      saida.push(...listarArquivosTs(caminho));
    } else if (nome.endsWith(".ts") && !nome.endsWith(".test.ts") && !nome.endsWith(".spec.ts")) {
      saida.push(caminho);
    }
  }
  return saida;
}

/** Nomes das classes de entidade de tenant (fonte da verdade = os .entity.ts). */
function coletarEntidadesDeTenant() {
  const nomes = new Set();
  for (const nome of readdirSync(tenantEntitiesDir)) {
    if (!nome.endsWith(".entity.ts")) continue;
    const conteudo = readFileSync(join(tenantEntitiesDir, nome), "utf8");
    for (const m of conteudo.matchAll(/export\s+class\s+(\w+)/g)) {
      nomes.add(m[1]);
    }
  }
  return nomes;
}

/** True se a linha do achado (ou a anterior) tiver o marcador de exceção. */
function temExcecao(linhas, indiceZeroBased) {
  const atual = linhas[indiceZeroBased] ?? "";
  const anterior = linhas[indiceZeroBased - 1] ?? "";
  return atual.includes(ALLOW_MARKER) || anterior.includes(ALLOW_MARKER);
}

const entidadesTenant = coletarEntidadesDeTenant();
if (entidadesTenant.size === 0) {
  console.error("[rls-guard] Nenhuma entidade de tenant encontrada — verifique o caminho das entidades.");
  process.exit(2);
}

const arquivos = listarArquivosTs(srcRoot);
const violacoes = [];

// Regex 1: AppDataSource.getRepository(<EntidadeDeTenant>) — tolera espaços/quebras.
const listaEntidades = [...entidadesTenant].join("|");
const reGetRepository = new RegExp(
  `AppDataSource\\s*\\.\\s*getRepository\\s*\\(\\s*(?:${listaEntidades})\\b`,
  "g",
);
// Regex 2: uso de RlsDataSource fora de data-source.ts.
const reRlsDataSource = /\bRlsDataSource\b/g;

for (const arquivo of arquivos) {
  const conteudo = readFileSync(arquivo, "utf8");
  const linhas = conteudo.split("\n");
  const rel = relative(backendRoot, arquivo);

  const empurrar = (regex, mensagem) => {
    for (const m of conteudo.matchAll(regex)) {
      const linha0 = conteudo.slice(0, m.index).split("\n").length - 1;
      if (temExcecao(linhas, linha0)) continue;
      violacoes.push({ rel, linha: linha0 + 1, trecho: (linhas[linha0] ?? "").trim(), mensagem });
    }
  };

  empurrar(
    reGetRepository,
    "AppDataSource.getRepository() em entidade de tenant ignora RLS — use runQueryWithRls().",
  );

  if (arquivo !== dataSourceFile) {
    empurrar(reRlsDataSource, "RlsDataSource referenciado fora de data-source.ts — use runQueryWithRls().");
  }
}

if (violacoes.length > 0) {
  console.error(`\n[rls-guard] ${violacoes.length} violação(ões) de isolamento multi-tenant:\n`);
  for (const v of violacoes) {
    console.error(`  ${v.rel}:${v.linha}`);
    console.error(`    ${v.trecho}`);
    console.error(`    → ${v.mensagem}\n`);
  }
  console.error("Se for cross-tenant intencional e admin-gated, anote a linha com `// rls-guard-ok: <motivo>`.");
  console.error("Cobertura: não detecta SQL cru com schema de tenant interpolado (ex.: AppDataSource.query com buildEscritorioSchemaName). Revise esses casos manualmente.\n");
  process.exit(1);
}

console.log(`[rls-guard] OK — ${arquivos.length} arquivos, ${entidadesTenant.size} entidades de tenant, nenhuma violação.`);
