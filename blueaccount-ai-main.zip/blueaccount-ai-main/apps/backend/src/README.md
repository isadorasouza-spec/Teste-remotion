# `src/`

Esta pasta é o ponto de entrada para desenvolvedores que vão adicionar ou alterar features no BlueAccount.

A ideia principal é simples:

- `src/app` organiza o bootstrap da aplicação
- `src/main.ts` concentra o bootstrap Nest da aplicação
- `src/http` recebe requests e devolve responses
- `src/domain` guarda regra de negócio
- `src/infrastructure` concentra a parte técnica e externa
- `src/modules` organiza a composição modular do Nest
- `src/modules/auth` concentra o fluxo novo de autenticação no Nest (exceção de naming mantida em inglês por estabilidade)
- `src/modules/oauth` concentra o fluxo OAuth externo (clients/agentes que consomem a API)
- `src/modules/agentes` concentra o coração do app no runtime Nest (CRUD de agentes + ações de IA)
- `src/modules/documentos`, `src/modules/contratos`, `src/modules/relatorios`, `src/modules/valores-a-cobrar` e `src/modules/faturamento` concentram o fluxo operacional recente de documentos, contratos, QA, cobrança e faturamento
- `src/modules/assinaturas-eletronicas` concentra OAuth, reconciliação incremental, download para o ledger e processamento sob demanda de envelopes assinados
- `src/infrastructure/ai` instancia os agentes usados pelo módulo de agentes
- `src/infrastructure/external-services` concentra clients externos como Cognito, Bedrock e S3
- `src/agent` concentra as implementações concretas de IA e automação

Se você estiver em dúvida sobre onde colocar um arquivo novo, comece por aqui.

## Como pensar a estrutura

Quando uma feature nova surgir, siga esta ordem de decisão:

1. a mudança é sobre como o servidor sobe? use `src/app`
2. a mudança é sobre a composição do Nest? use `src/modules`
3. a mudança é sobre a API HTTP? use `src/http`
4. a mudança é sobre agentes ou automação do usuário? use `src/modules/agentes`
5. a mudança é sobre regra de negócio? use `src/domain`
6. a mudança é sobre banco, AWS, log, IA ou integração externa? use `src/infrastructure`
7. a mudança é sobre autenticação? use `src/modules/auth`

## Naming

Mesmo quando o pedido estiver em inglês, nomes novos controlados pelo projeto devem seguir o padrão
do repositório e nascer em português: funções, classes, módulos, pastas, services, domínios e tipos
de negócio.

Exceções permitidas: contratos públicos estáveis, slugs de rota HTTP, campos de payload/API, env
vars, nomes de tools MCP, conceitos de SDK/framework/serviço externo e exceções documentadas como
`src/modules/auth`.

## Mapa rápido

```txt
src/
  app/
  database/
  domain/
  http/
  infrastructure/
  modules/
  agent/
  tools/
  data_manipulation/
  public/
```

## O que cada pasta faz

### `src/app`

Bootstrap da aplicação.

Aqui vivem:

- `tests/`
- testes de bootstrap em `src/app/tests`

Use esta pasta para:

- iniciar o servidor
- centralizar a composição inicial do Nest

Não coloque aqui:

- regra de negócio
- queries complexas
- orquestração de casos de uso

### `src/http`

Camada HTTP da aplicação.

Aqui vivem:

- `controllers/`
- `middlewares/`

Use esta pasta para:

- validar requests
- converter entrada HTTP em chamada de serviço
- devolver status e payloads

Os testes dessa camada ficam em:

- `src/http/middlewares/tests`
- `src/http/controllers/tests` quando aplicável

### `src/modules`

Camada de composição dos módulos Nest.

Aqui vivem:

- módulos de feature
- controllers Nest
- providers de orquestração

Use esta pasta para:

- ligar controllers a services
- declarar dependências de módulo
- preparar migração gradual para Nest

Se a mudança for sobre autenticação nova, comece por `src/modules/auth`.
Se a mudança for sobre agentes e automação de alto nível, comece por `src/modules/agentes`.

Exceção de naming: `src/modules/auth` permanece em inglês mesmo com `src/domain/autenticacao` em PT, porque é o ponto de entrada Nest de autenticação e é muito referenciado por módulos, guards, docs e rotas existentes.

Não coloque aqui:

- regra de negócio central
- migrations
- integração técnica de baixo nível

### `src/domain`

Camada de regra de negócio.

Hoje a estrutura já está dividida em:

- `clientes`
- `fornecedores` (cadastro de contrapartes de compra + derivação do crédito IBS/CBS)
- `cobrancas` (cálculo comparativo, emissão, provedores e eval de cobrança)
- `complexidades-cobranca`
- `complexidades-extracao-contrato`
- `contratos`
- `escritorios`
- `extracao`
- `autenticacao`
- `oauth`
- `relatorios`
- `documentos`
- `modelos-extracao`
- `agentes` (CRUD da entidade `Agente`)
- `acoes-ai` (ações de IA e execução)
- `valores-a-cobrar`
- `faturamento`

Use esta pasta para:

- regras de negócio
- normalização de dados
- validações de domínio
- cálculo
- coordenação de fluxos de caso de uso

Cada domínio pode manter seus testes em `tests/` ao lado do serviço principal.

### `src/infrastructure`

Camada de infraestrutura.

Esta pasta já começa a concentrar implementação técnica concreta.

Use esta pasta no futuro para:

- banco de dados
- TypeORM
- migrations
- logger
- integrações com Cognito
- integrações com Bedrock
- factories de agentes
- storage e adaptadores de arquivos

Essa camada responde ao "como acessar ou executar tecnicamente" e não ao "o que o negócio quer fazer".

### `src/agent`

Implementações concretas de agentes de IA e automação.

Use esta pasta para:

- ingestão de documentos
- ingestão de relatórios
- normalização de payloads para revisão do frontend
- execução de planos
- persistência orientada por LLM

O módulo Nest que expõe esses fluxos ao restante do app fica em `src/modules/agentes`.
A fábrica técnica que cria o executor fica em `src/infrastructure/ai`.
O runtime Python/AgentCore independente fica em `apps/services/agents`; use `src/agent` para adaptadores do backend e `apps/services/agents` para agentes executados fora do processo Nest.

Quando a lógica virar regra de negócio pura, mova para `src/domain`.
Quando for só integração técnica ou criação de agente, considere `src/infrastructure`.

### `src/database`

Modelo relacional, conexão com o banco e migrations.

Os migrations públicos seguem em `src/database/migrations/`, enquanto as migrations tenant-aware vivem em `src/database/tenant-schema-migrations.ts` e são sincronizadas automaticamente no bootstrap ou manualmente com `npm run migration:sync-tenants`.

Use esta pasta para:

- entidades
- data source
- helpers de query
- migrations
- RLS

### `src/tools`

Funções reutilizáveis para automação, agentes e consultas de alto nível.

Use esta pasta quando a função servir como utilitário de apoio e ainda fizer sentido fora de um endpoint específico.

### `src/data_manipulation`

Rotinas auxiliares de manipulação e agregação de dados.

Essa pasta é mais transitória e deve ser revisada conforme a regra de negócio for migrando para `src/domain`.

### `src/public`

Arquivos estáticos servidos pela aplicação.

Use para:

- HTML
- CSS
- JS do front-end
- assets estáticos

## Ordem recomendada para criar uma feature

Quando precisar adicionar algo novo, a ordem mais segura costuma ser:

1. identificar o domínio
2. criar ou atualizar o serviço em `src/domain`
3. expor o caso de uso em um controller HTTP ou módulo Nest
4. ligar o controller ao módulo correspondente
5. adicionar ou atualizar testes
6. atualizar a documentação da pasta afetada

## Onde procurar primeiro

Se estiver mexendo em uma feature existente, normalmente este é o caminho:

- feature de endpoint: `src/modules` quando a feature já for Nest, ou `src/http/controllers` para a borda HTTP
- feature de regra: `src/domain`
- feature de banco: `src/database`
- feature de IA: `src/modules/agentes` e `src/infrastructure/ai`
- feature de cliente externo: `src/infrastructure/external-services`
- feature de integração técnica: `src/infrastructure`

## Boas práticas

- mantenha handlers finos
- deixe regra de negócio fora do Express
- prefira testes próximos da camada onde a regra vive
- documente a pasta certa quando mover uma responsabilidade
- evite introduzir novos arquivos na pasta errada "só por enquanto"

## Situação atual

A aplicação já passou por um house cleaning importante:

- bootstrap saiu de arquivos grandes
- rotas foram separadas
- controllers foram extraídos
- várias regras de negócio já vivem em `src/domain`
- middlewares HTTP ficaram em `src/http/middlewares`
- documentos, relatórios e valores a cobrar já rodam como módulos Nest com testes próximos
- fluxos assíncronos chegam por callbacks internos e atualizam status/payloads para revisão

O próximo passo de desenvolvimento deve seguir essa mesma linha: escolher a camada certa antes de escrever a feature.

### Integração HubSpot

`modules/integracoes-crm` recebe webhooks assinados e expõe configuração/controle admin.
`domain/integracoes-crm` contém persistência e etapas retomáveis; o workflow Standard vive em
`apps/services/integracoes-crm` e reutiliza esse domínio nas Lambdas.
Guia: [integrações CRM](modules/integracoes-crm/README.md).
