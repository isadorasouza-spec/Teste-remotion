#!/usr/bin/env node
/**
 * CLI entry point for DocumentIngestionAgent and ReportIngestionAgent.
 *
 * Usage:
 *   npx tsx src/cli.ts --file ./contrato.pdf
 *   npx tsx src/cli.ts --file ./relatorio.pdf --agent report
 *   npx tsx src/cli.ts --input-key contratos/contrato-exemplo.pdf
 */

// Primeiro import do processo: fixa o relógio em UTC (ver src/relogio-utc.ts).
import "./relogio-utc.js";
import { parseArgs } from "node:util";
import { writeFileSync, mkdirSync } from "node:fs";
import { resolve, basename, parse as parsePath } from "node:path";

import { DocumentIngestionAgent, ReportIngestionAgent } from "./agent/index.js";

async function main() {
  const { values } = parseArgs({
    options: {
      file: { type: "string", short: "f" },
      "input-key": { type: "string" },
      agent: { type: "string", short: "a", default: "document" },
      "input-bucket": { type: "string" },
      "output-bucket": { type: "string" },
      "model-id": { type: "string" },
      "inference-profile-id": { type: "string" },
      region: { type: "string" },
      "output-dir": { type: "string", default: "output" },
      help: { type: "boolean", short: "h" },
    },
    strict: true,
  });

  if (values.help || (!values.file && !values["input-key"])) {
    console.log(`
Usage:
  npx tsx src/cli.ts --file <local-path>                      (contrato local)
  npx tsx src/cli.ts --file <local-path> --agent report       (relatório local)
  npx tsx src/cli.ts --input-key <s3-key>                     (S3 object)

Options:
  -f, --file              Local file path (PDF, DOC, DOCX, JPG, PNG)
  -a, --agent             Agent to use: "document" (default) or "report"
  --input-key             S3 object key
  --input-bucket          Override input S3 bucket
  --output-bucket         Override output S3 bucket
  --model-id              Bedrock model identifier
  --inference-profile-id  Bedrock inference profile ARN
  --region                AWS region
  --output-dir            Local directory for the JSON result (default: output)
  -h, --help              Show this help
`);
    process.exit(values.help ? 0 : 1);
  }

  const agentType = values.agent === "report" ? "report" : "document";
  const agentCfg = {
    inputBucket: values["input-bucket"],
    outputBucket: values["output-bucket"],
    modelId: values["model-id"],
    inferenceProfileId: values["inference-profile-id"],
    region: values.region,
  };

  const agent = agentType === "report"
    ? new ReportIngestionAgent(agentCfg)
    : new DocumentIngestionAgent(agentCfg);

  let stem: string;
  let batch: any;

  if (values.file) {
    const filePath = resolve(values.file);
    console.log(`\nProcessing local file: ${filePath}\n`);
    if (agentType === "report") {
      batch = await agent.ingestFromFile(filePath);
    } else {
      batch = await agent.ingestFromFile(filePath);
    }
    stem = parsePath(basename(filePath)).name;
  } else {
    const inputKey = values["input-key"]!;
    console.log(`\nProcessing S3: ${inputKey}\n`);
    if (agentType === "report") {
      batch = JSON.parse(await agent.ingest(inputKey));
    } else {
      batch = JSON.parse(await agent.ingest(inputKey));
    }
    stem = parsePath(basename(inputKey)).name;
  }

  const outDir = resolve(values["output-dir"]!);
  mkdirSync(outDir, { recursive: true });

  if (agentType === "report") {
    const relatorios = Array.isArray(batch.relatorios) ? batch.relatorios : [];
    if (!relatorios.length) {
      console.error("No relatorios extracted.");
      process.exit(2);
    }
    relatorios.forEach((item: any, idx: number) => {
      const outPath = resolve(outDir, `${stem}.report.${idx + 1}.json`);
      writeFileSync(outPath, JSON.stringify(item, null, 2), "utf-8");
      console.log(`Saved: ${outPath}`);
    });
    if (batch.metadados_extracao) {
      console.log("\nExtraction metadata:");
      console.log(JSON.stringify(batch.metadados_extracao, null, 2));
    }
  } else {
    const outPath = resolve(outDir, `${stem}.extraction.json`);
    writeFileSync(outPath, JSON.stringify(batch, null, 2), "utf-8");
    console.log(`\nExtraction saved to ${outPath}`);
    console.log(`\n${JSON.stringify(batch, null, 2)}\n`);
  }
}

main().catch((err) => {
  console.error("Fatal:", err);
  process.exit(1);
});
