import { describe, expect, it, vi } from "vitest";

const serverMocks = vi.hoisted(() => {
  const apiLogger = {};
  const useStaticAssets = vi.fn();
  const use = vi.fn();
  const listen = vi.fn(async (_port: number) => undefined);
  const set = vi.fn();
  const enableCors = vi.fn();
  const useGlobalFilters = vi.fn();
  const ensureInitialized = vi.fn(async () => undefined);
  const nestApp = {
    enableShutdownHooks: vi.fn(),
    get: vi.fn((token: unknown) => {
      if (typeof token === "function" && token.name === "DatabaseBootstrapService") {
        return { ensureInitialized };
      }
      if (typeof token === "function" && token.name === "ApiLogger") {
        return apiLogger;
      }
      return {};
    }),
    use,
    set,
    useStaticAssets,
    listen,
    enableCors,
    useGlobalFilters,
  };

  return {
    useStaticAssets,
    use,
    listen,
    enableCors,
    ensureInitialized,
    apiLogger,
    nestApp,
    nestCreate: vi.fn(async () => nestApp),
  };
});

vi.mock("@nestjs/core", () => ({
  NestFactory: {
    create: serverMocks.nestCreate,
  },
}));

vi.mock("@nestjs/swagger", () => {
  class DocumentBuilder {
    setTitle() {
      return this;
    }

    setDescription() {
      return this;
    }

    setVersion() {
      return this;
    }

    addCookieAuth() {
      return this;
    }

    addBearerAuth() {
      return this;
    }

    build() {
      return {};
    }
  }

  return {
    ApiTags: () => () => undefined,
    DocumentBuilder,
    SwaggerModule: {
      createDocument: vi.fn(() => ({ paths: {} })),
      setup: vi.fn(),
    },
  };
});

vi.mock("../../infrastructure/logging/api.logger.js", () => ({
  ApiLogger: class ApiLogger {},
}));

const { bootstrap, collectContentSecurityFormActionSources } = await import("../../main.js");
const { AppModule } = await import("../app.module.js");

describe("bootstrap", () => {
  it("initializes the database before starting the listener", async () => {
    await bootstrap(4321);

    expect(serverMocks.ensureInitialized).toHaveBeenCalledTimes(1);
    expect(serverMocks.nestCreate).toHaveBeenCalledWith(AppModule, { bufferLogs: true, bodyParser: false });
    expect(serverMocks.use).toHaveBeenCalled();
    expect(serverMocks.nestApp.useGlobalFilters).toHaveBeenCalledTimes(1);
    expect(serverMocks.useStaticAssets).toHaveBeenCalledTimes(1);
    expect(serverMocks.listen).toHaveBeenCalledWith(4321);
  });

  it("allows OAuth form posts to configured public backend origins", () => {
    const originalEnv = {
      PUBLIC_BASE_URL: process.env.PUBLIC_BASE_URL,
      API_PUBLIC_BASE_URL: process.env.API_PUBLIC_BASE_URL,
      OAUTH_ISSUER_URL: process.env.OAUTH_ISSUER_URL,
    };
    process.env.PUBLIC_BASE_URL = "https://dqllb6ovvf0sk.cloudfront.net";
    process.env.API_PUBLIC_BASE_URL = "https://dqllb6ovvf0sk.cloudfront.net/api";
    process.env.OAUTH_ISSUER_URL = "https://app.kontiva.ai";

    try {
      expect(collectContentSecurityFormActionSources(["https://app.kontiva.ai"])).toEqual([
        "'self'",
        "https://app.kontiva.ai",
        "https://dqllb6ovvf0sk.cloudfront.net",
      ]);
    } finally {
      restoreEnv("PUBLIC_BASE_URL", originalEnv.PUBLIC_BASE_URL);
      restoreEnv("API_PUBLIC_BASE_URL", originalEnv.API_PUBLIC_BASE_URL);
      restoreEnv("OAUTH_ISSUER_URL", originalEnv.OAUTH_ISSUER_URL);
    }
  });
});

function restoreEnv(name: string, value: string | undefined): void {
  if (value === undefined) {
    delete process.env[name];
    return;
  }
  process.env[name] = value;
}
