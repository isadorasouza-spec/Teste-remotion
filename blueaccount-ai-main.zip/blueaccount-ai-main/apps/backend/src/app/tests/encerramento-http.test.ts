import { spawn } from "node:child_process";
import { once } from "node:events";
import { expect, it } from "vitest";

it("SIGTERM drena HTTP antes de fechar os pools pelo hook do Nest", async () => {
  const codigo = `
    import 'reflect-metadata';
    import { Module } from '@nestjs/common';
    import { NestFactory } from '@nestjs/core';
    import { DatabaseBootstrapService } from './src/infrastructure/database/database.bootstrap.service.ts';
    import { AppDataSource, RlsDataSource } from './src/database/data-source.ts';
    let concluiu = false;
    for (const fonte of [AppDataSource, RlsDataSource]) {
      fonte.isInitialized = true;
      fonte.destroy = async () => { process.send({ poolFechado: true, concluiu }); fonte.isInitialized = false; };
    }
    class ModuloTeste {}
    Module({ providers: [DatabaseBootstrapService] })(ModuloTeste);
    const app = await NestFactory.create(ModuloTeste, { logger: false });
    app.enableShutdownHooks(['SIGTERM', 'SIGINT']);
    app.use((req, res) => {
      res.writeHead(200); res.write('inicio');
      setTimeout(() => { concluiu = true; res.end('-fim'); }, 300);
    });
    await app.listen(0, '127.0.0.1');
    process.send({ porta: app.getHttpServer().address().port });
  `;
  const filho = spawn(process.execPath, ["--import", "tsx", "--input-type=module", "-e", codigo], {
    cwd: new URL("../../..", import.meta.url), stdio: ["ignore", "ignore", "pipe", "ipc"],
  });
  const mensagens: Array<{ poolFechado?: boolean; concluiu?: boolean }> = [];
  filho.on("message", (mensagem) => mensagens.push(mensagem as typeof mensagens[number]));
  const terminou = once(filho, "exit");
  try {
    const [{ porta }] = await once(filho, "message") as [{ porta: number }];
    const resposta = await fetch(`http://127.0.0.1:${porta}`, { signal: AbortSignal.timeout(10_000) });
    filho.kill("SIGTERM");
    expect(await resposta.text()).toBe("inicio-fim");
    const [codigoSaida, sinal] = await terminou;
    expect(codigoSaida === 0 || sinal === "SIGTERM").toBe(true);
    expect(mensagens.filter((m) => m.poolFechado)).toEqual([
      { poolFechado: true, concluiu: true }, { poolFechado: true, concluiu: true },
    ]);
  } finally {
    if (filho.exitCode === null && filho.signalCode === null) filho.kill("SIGKILL");
  }
}, 15_000);
