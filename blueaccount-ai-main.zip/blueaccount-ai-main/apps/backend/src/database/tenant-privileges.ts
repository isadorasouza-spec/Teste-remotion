import type { EntityManager } from "typeorm";
import { buildEscritorioRoleName, buildEscritorioSchemaName } from "./tenant-naming.js";

export type TenantPrivilegeTarget = {
  schemaName: string;
  roleName: string;
};

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

function uniqueValues(values: Array<string | null | undefined>): string[] {
  return [...new Set(
    values
      .map((value) => value?.trim())
      .filter((value): value is string => Boolean(value)),
  )];
}

export function resolveTenantObjectOwnerRole(): string {
  const envRole = process.env.DB_USERNAME?.trim()
    || process.env.DB_AI_USERNAME?.trim();
  if (envRole) {
    return envRole;
  }
  return "postgres";
}

export function resolveRuntimeRoles(): string[] {
  return uniqueValues([
    process.env.DOCUMENTOS_FISCAIS_DB_USERNAME,
    process.env.DB_AI_USERNAME,
    process.env.DB_USERNAME,
  ]);
}

export function buildTenantPrivilegeTarget(escritorioId: string): TenantPrivilegeTarget {
  return {
    schemaName: buildEscritorioSchemaName(escritorioId),
    roleName: buildEscritorioRoleName(escritorioId),
  };
}

export async function ensureTenantRole(
  manager: Pick<EntityManager, "query">,
  roleName: string,
): Promise<void> {
  const existingRole = await manager.query("SELECT 1 FROM pg_roles WHERE rolname = $1 LIMIT 1", [roleName]);
  if (!Array.isArray(existingRole) || existingRole.length === 0) {
    await manager.query(`CREATE ROLE ${quoteIdentifier(roleName)} NOLOGIN`);
  }
}

export async function grantTenantRoleToRuntimeRoles(
  manager: Pick<EntityManager, "query">,
  roleName: string,
  runtimeRoles = resolveRuntimeRoles(),
): Promise<void> {
  if (runtimeRoles.length === 0) {
    return;
  }

  const existingRoles = await manager.query(
    "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
    [runtimeRoles],
  );
  const existingRoleSet = new Set(
    Array.isArray(existingRoles) ? existingRoles.map((row) => String(row.rolname)) : [],
  );

  for (const runtimeRole of runtimeRoles) {
    if (!existingRoleSet.has(runtimeRole)) {
      if (runtimeRole === process.env.DOCUMENTOS_FISCAIS_DB_USERNAME?.trim()) {
        throw new Error("A role técnica fiscal deve existir antes do provisionamento de escritórios.");
      }
      continue;
    }
    await manager.query(`GRANT ${quoteIdentifier(roleName)} TO ${quoteIdentifier(runtimeRole)}`);
  }
}

/** Recupera grants de migrations que passaram antes da configuração da credencial fiscal. */
export async function reconciliarPrivilegiosWorkerFiscal(manager: Pick<EntityManager, "query">): Promise<void> {
  const usuario = process.env.DOCUMENTOS_FISCAIS_DB_USERNAME?.trim();
  if (!usuario) {
    if (process.env.DOCUMENTOS_FISCAIS_PROCESSADOR === "worker") throw new Error("Credencial fiscal obrigatória na reconciliação.");
    return;
  }
  const [role] = await manager.query("SELECT rolsuper,rolbypassrls,rolinherit FROM pg_roles WHERE rolname=$1", [usuario]);
  if (!role || role.rolsuper || role.rolbypassrls || role.rolinherit) throw new Error("Worker exige NOSUPERUSER NOBYPASSRLS NOINHERIT.");
  const tabelas = await manager.query(`SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
    WHERE n.nspname='public' AND c.relkind='r' AND c.relname IN ('ingestoes_fiscais_fila','distribuicoes_dfe_fila')`);
  for (const { relname } of tabelas) {
    await manager.query(`GRANT SELECT,UPDATE ON public.${quoteIdentifier(String(relname))} TO ${quoteIdentifier(usuario)}`);
  }
}

export async function reconcileTenantPrivileges(
  manager: Pick<EntityManager, "query">,
  { schemaName, roleName }: TenantPrivilegeTarget,
  ownerRole = resolveTenantObjectOwnerRole(),
): Promise<void> {
  const quotedSchemaName = quoteIdentifier(schemaName);
  const quotedRoleName = quoteIdentifier(roleName);
  const quotedOwnerRole = quoteIdentifier(ownerRole);

  await ensureTenantRole(manager, roleName);
  await manager.query(`GRANT USAGE ON SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(`GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(`GRANT USAGE ON ALL SEQUENCES IN SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(
    `ALTER DEFAULT PRIVILEGES FOR ROLE ${quotedOwnerRole} IN SCHEMA ${quotedSchemaName} ` +
    `GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ${quotedRoleName}`,
  );
  await manager.query(
    `ALTER DEFAULT PRIVILEGES FOR ROLE ${quotedOwnerRole} IN SCHEMA ${quotedSchemaName} ` +
    `GRANT USAGE ON SEQUENCES TO ${quotedRoleName}`,
  );
}

export async function revokePublicTablePrivilegesFromTenantRole(
  manager: Pick<EntityManager, "query">,
  roleName: string,
): Promise<void> {
  const quotedRoleName = quoteIdentifier(roleName);

  await manager.query(`REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM ${quotedRoleName}`);
}
