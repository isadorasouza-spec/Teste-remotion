import { IsNull } from "typeorm";
import { AppDataSource } from "./data-source.js";
import { AdminSession } from "./modules/public/entities/admin-session.entity.js";
import { DesafioMfa } from "./modules/public/entities/desafio-mfa.entity.js";
import { FatorMfaAdminPlataforma } from "./modules/public/entities/fator-mfa-admin-plataforma.entity.js";
import { EventoAuditoriaSeguranca } from "./modules/public/entities/evento-auditoria-seguranca.entity.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";

const CONFIRMACAO = "RESETAR-MFA-ADMIN";

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const confirmIndex = args.indexOf("--confirm");
  if (confirmIndex < 0 || args[confirmIndex + 1] !== CONFIRMACAO) {
    throw new Error(`Confirmação obrigatória. Use --confirm ${CONFIRMACAO}.`);
  }

  await AppDataSource.initialize();
  const now = new Date();
  let fatorRemovido = false;
  try {
    await AppDataSource.transaction(async (manager) => {
      const result = await manager.getRepository(FatorMfaAdminPlataforma).delete({ username: "admin" });
      fatorRemovido = (result.affected ?? 0) > 0;
      await manager.getRepository(DesafioMfa).delete({ admin_username: "admin" });
      await manager.getRepository(AdminSession).update(
        { username: "admin", revoked_at: IsNull() },
        { revoked_at: now },
      );
      await manager.getRepository(EventoAuditoriaSeguranca).save({
        evento: "mfa_break_glass",
        identidade_tipo: "admin_plataforma",
        usuario_id: null,
        resultado: "sucesso",
        metadados: { fator_removido: fatorRemovido },
      });
    });
    new AgentLogger("admin-usuarios").warn("mfa_admin_plataforma_resetado_cli", {
      tipo: "admin_plataforma",
      status: fatorRemovido ? "resetado" : "ja_pendente",
    });
    console.info(fatorRemovido
      ? "MFA do admin da plataforma resetado; o próximo login exigirá novo cadastro."
      : "O admin da plataforma já estava sem fator; sessões e desafios foram revogados.");
  } finally {
    await AppDataSource.destroy();
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
