import { existsSync, readFileSync } from "node:fs";

/**
 * Lê o bundle de CA apontado por `DB_SSL_CA_PATH`.
 *
 * Todo DataSource que fala com o RDS precisa passar esse `ca`. Sem ele, um ambiente
 * com `DB_SSL_REJECT_UNAUTHORIZED=true` falha o handshake com
 * "self-signed certificate in certificate chain", porque a cadeia da Amazon não está
 * no trust store padrão do Node.
 */
export function resolverCaSsl(): string | undefined {
  const caPath = process.env.DB_SSL_CA_PATH?.trim();
  if (!caPath) return undefined;
  if (!existsSync(caPath)) {
    throw new Error(`DB_SSL_CA_PATH não encontrado: ${caPath}`);
  }
  return readFileSync(caPath, "utf8");
}
