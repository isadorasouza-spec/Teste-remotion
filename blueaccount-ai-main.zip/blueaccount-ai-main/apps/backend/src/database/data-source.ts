import { resolverLimitePool } from "./limite-pool.js";
import { ImportacaoOperacionalMensal } from "./modules/tenant/entities/importacao-operacional-mensal.entity.js";
import { RegistroOperacional } from "./modules/tenant/entities/registro-operacional.entity.js";
import { DocumentoFiscalTotal } from "./modules/tenant/entities/documento-fiscal-total.entity.js";
import { DocumentoFiscalItem } from "./modules/tenant/entities/documento-fiscal-item.entity.js";
import { ConsultaNotasFiscal } from "./modules/tenant/entities/consulta-notas-fiscal.entity.js";
import { ResultadoConsultaNotasFiscal } from "./modules/tenant/entities/resultado-consulta-notas-fiscal.entity.js";
import { ExecucaoWorkerFiscal } from "./modules/tenant/entities/execucao-worker-fiscal.entity.js";
import "reflect-metadata";
import { DataSource, type EntityManager } from "typeorm";
import { config } from "dotenv";
import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { AdminSession } from "./modules/public/entities/admin-session.entity.js";
import { DesafioMfa } from "./modules/public/entities/desafio-mfa.entity.js";
import { FatorMfaAdminPlataforma } from "./modules/public/entities/fator-mfa-admin-plataforma.entity.js";
import { FatorMfaUsuario } from "./modules/public/entities/fator-mfa-usuario.entity.js";
import { EventoAuditoriaSeguranca } from "./modules/public/entities/evento-auditoria-seguranca.entity.js";
import { AgentLog } from "./modules/public/entities/agent-log.entity.js";
import { AlertaAgentcore } from "./modules/public/entities/alerta-agentcore.entity.js";
import { BillingComplexity } from "./modules/public/entities/billing-complexity.entity.js";
import { Contexto } from "./modules/public/entities/contexto.entity.js";
import { ContractExtractionComplexity } from "./modules/public/entities/contract-extraction-complexity.entity.js";
import { Escritorio } from "./modules/public/entities/escritorio.entity.js";
import { ExtractionModelConfig } from "./modules/public/entities/extraction-model-config.entity.js";
import { Feedback } from "./modules/public/entities/feedback.entity.js";
import { ModelUsagePricing } from "./modules/public/entities/model-usage-pricing.entity.js";
import { OAuthAccessToken } from "./modules/public/entities/oauth-access-token.entity.js";
import { OAuthAuthorizationCode } from "./modules/public/entities/oauth-authorization-code.entity.js";
import { OAuthClient } from "./modules/public/entities/oauth-client.entity.js";
import { OAuthRefreshToken } from "./modules/public/entities/oauth-refresh-token.entity.js";
import { SeedRun } from "./modules/public/entities/seed-run.entity.js";
import { SeedRunApiCall } from "./modules/public/entities/seed-run-api-call.entity.js";
import { Sessao } from "./modules/public/entities/sessao.entity.js";
import { UsageEvent } from "./modules/public/entities/usage-event.entity.js";
import { UsagePricing } from "./modules/public/entities/usage-pricing.entity.js";
import { Usuario } from "./modules/public/entities/usuario.entity.js";
import { IngestaoControleConcorrencia } from "./modules/public/entities/ingestao-controle-concorrencia.entity.js";
import { IngestaoPermissaoProcessamento } from "./modules/public/entities/ingestao-permissao-processamento.entity.js";
import { CobrancaFila } from "./modules/public/entities/cobranca-fila.entity.js";
import { SimulacaoCalculoFila } from "./modules/public/entities/simulacao-calculo-fila.entity.js";
import { SimulacaoFilaControle } from "./modules/public/entities/simulacao-fila-controle.entity.js";
import { ProjecaoDocumentoFiscalFila } from "./modules/public/entities/projecao-documento-fiscal-fila.entity.js";
import { DistribuicaoDfeFila } from "./modules/public/entities/distribuicao-dfe-fila.entity.js";
import { IndiceInflacao } from "./modules/public/entities/indice-inflacao.entity.js";
import { CadastroCnpj } from "./modules/public/entities/cadastro-cnpj.entity.js";
import { CnaeReferencia } from "./modules/public/entities/cnae-referencia.entity.js";
import { NcmReferencia } from "./modules/public/entities/ncm-referencia.entity.js";
import { NbsReferencia } from "./modules/public/entities/nbs-referencia.entity.js";
import { SimplesCnae } from "./modules/public/entities/simples-cnae.entity.js";
import { SimplesAnexo } from "./modules/public/entities/simples-anexo.entity.js";
import { SimplesAnexoReparticao } from "./modules/public/entities/simples-anexo-reparticao.entity.js";
import { SolicitacaoPrivacidade } from "./modules/public/entities/solicitacao-privacidade.entity.js";
import { IncidenteDadosPessoais } from "./modules/public/entities/incidente-dados-pessoais.entity.js";
import { TombstonePrivacidade } from "./modules/public/entities/tombstone-privacidade.entity.js";
import { Cliente } from "./modules/tenant/entities/cliente.entity.js";
import { Fornecedor } from "./modules/tenant/entities/fornecedor.entity.js";
import { Documento } from "./modules/tenant/entities/documento.entity.js";
import { Contrato } from "./modules/tenant/entities/contrato.entity.js";
import { ContratoDocumentoAnexo } from "./modules/tenant/entities/contrato-documento-anexo.entity.js";
import { ClausulasExcedentes } from "./modules/tenant/entities/clausulas-excedentes.entity.js";
import { ServicosContratados } from "./modules/tenant/entities/servicos-contratados.entity.js";
import { Relatorio } from "./modules/tenant/entities/relatorio.entity.js";
import { RelatorioEstatisticaCliente } from "./modules/tenant/entities/relatorio-estatistica-cliente.entity.js";
import { Faturamento } from "./modules/tenant/entities/faturamento.entity.js";
import { ValoresACobrar } from "./modules/tenant/entities/valores-a-cobrar.entity.js";
import { ValoresACobrarVersao } from "./modules/tenant/entities/valores-a-cobrar-versoes.entity.js";
import { CobrancaTest } from "./modules/tenant/entities/cobranca-test.entity.js";
import { Extracao } from "./modules/tenant/entities/extracao.entity.js";
import { Agente } from "./modules/tenant/entities/agente.entity.js";
import { AcaoAi } from "./modules/tenant/entities/acao-ai.entity.js";
import { HistoricoAcaoAi } from "./modules/tenant/entities/historico-acao-ai.entity.js";
import { Simulacao } from "./modules/tenant/entities/simulacao.entity.js";
import { SimulacaoEntrada } from "./modules/tenant/entities/simulacao-entrada.entity.js";
import { SimulacaoGrupo } from "./modules/tenant/entities/simulacao-grupo.entity.js";
import { SimulacaoGrupoItem } from "./modules/tenant/entities/simulacao-grupo-item.entity.js";
import { SimulacaoNotaFiscal } from "./modules/tenant/entities/simulacao-nota-fiscal.entity.js";
import { AcumuladorSimulacao } from "./modules/tenant/entities/acumulador-simulacao.entity.js";
import { AcumuladorSimulacaoCliente } from "./modules/tenant/entities/acumulador-simulacao-cliente.entity.js";
import { SimulacaoEntradaExcluida } from "./modules/tenant/entities/simulacao-entrada-excluida.entity.js";
import { SimulacaoResultadoCache } from "./modules/tenant/entities/simulacao-resultado-cache.entity.js";
import { SimulacaoCalculoEntrada } from "./modules/tenant/entities/simulacao-calculo-entrada.entity.js";
import { SimulacaoCalculo } from "./modules/tenant/entities/simulacao-calculo.entity.js";
import { ModeloRelatorioSimulacao } from "./modules/tenant/entities/modelo-relatorio-simulacao.entity.js";
import { PlataformaCobranca } from "./modules/tenant/entities/plataforma-cobranca.entity.js";
import { Cobranca } from "./modules/tenant/entities/cobranca.entity.js";
import { ClientePlataformaCobranca } from "./modules/tenant/entities/cliente-plataforma-cobranca.entity.js";
import { ConectorDriveExecucao } from "./modules/tenant/entities/conector-drive-execucao.entity.js";
import { ConectorDriveArquivo } from "./modules/tenant/entities/conector-drive-arquivo.entity.js";
import { ConectorSharePointConexao } from "./modules/tenant/entities/conector-sharepoint-conexao.entity.js";
import { ConectorSharePointExecucao } from "./modules/tenant/entities/conector-sharepoint-execucao.entity.js";
import { ConectorSharePointArquivo } from "./modules/tenant/entities/conector-sharepoint-arquivo.entity.js";
import { ConexaoAssinaturaEletronica } from "./modules/tenant/entities/conexao-assinatura-eletronica.entity.js";
import { EnvelopeAssinaturaEletronica } from "./modules/tenant/entities/envelope-assinatura-eletronica.entity.js";
import { OportunidadeRecuperacao } from "./modules/tenant/entities/oportunidade-recuperacao.entity.js";
import { LoteIngestaoDocumentoFiscal } from "./modules/tenant/entities/lote-ingestao-documento-fiscal.entity.js";
import { ArquivoIngestaoDocumentoFiscal } from "./modules/tenant/entities/arquivo-ingestao-documento-fiscal.entity.js";
import { CertificadoDigitalCliente } from "./modules/tenant/entities/certificado-digital-cliente.entity.js";
import { CursorDistribuicaoDfe } from "./modules/tenant/entities/cursor-distribuicao-dfe.entity.js";
import { buildEscritorioRoleName, buildEscritorioSchemaName } from "./tenant-naming.js";

config();

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (typeof value !== "string") {
    return fallback;
  }
  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "y", "on"].includes(normalized)) {
    return true;
  }
  if (["0", "false", "no", "n", "off"].includes(normalized)) {
    return false;
  }
  return fallback;
}

function createDataSource(useAiCredentials: boolean): DataSource {
  const sslEnabled = parseBoolean(process.env.DB_SSL, false);
  const sslRejectUnauthorized = parseBoolean(process.env.DB_SSL_REJECT_UNAUTHORIZED, true);

  return new DataSource({
    poolSize: resolverLimitePool(),
    type: "postgres",
    host: process.env.DB_HOST ?? "localhost",
    port: Number(process.env.DB_PORT ?? 5432),
    username: useAiCredentials
      ? process.env.DB_AI_USERNAME ?? process.env.DB_USERNAME ?? "blueaccount"
      : process.env.DB_USERNAME ?? "blueaccount",
    password: useAiCredentials
      ? process.env.DB_AI_PASSWORD ?? process.env.DB_PASSWORD ?? "blueaccount"
      : process.env.DB_PASSWORD ?? "blueaccount",
    database: process.env.DB_DATABASE ?? "blueaccount",
    synchronize: process.env.DB_SYNCHRONIZE === "true",
    logging: process.env.DB_LOGGING === "true",
    ssl: sslEnabled
      ? {
          rejectUnauthorized: sslRejectUnauthorized,
          ...(resolveSslCa() ? { ca: resolveSslCa() } : {}),
        }
      : false,
    entities: [
      Cliente,
      Fornecedor,
      Contrato,
      ContratoDocumentoAnexo,
      ServicosContratados,
      ClausulasExcedentes,
      Relatorio,
      RelatorioEstatisticaCliente,
      Faturamento,
      ValoresACobrar,
      ValoresACobrarVersao,
      CobrancaTest,
      Documento,
      Extracao,
      Agente,
      AcaoAi,
      HistoricoAcaoAi,
      Simulacao,
      SimulacaoEntrada,
      SimulacaoGrupo,
      SimulacaoGrupoItem,
      SimulacaoNotaFiscal,
      AcumuladorSimulacao,
      AcumuladorSimulacaoCliente,
      SimulacaoEntradaExcluida,
      SimulacaoResultadoCache,
      SimulacaoCalculo,
      SimulacaoCalculoEntrada,
      ModeloRelatorioSimulacao,
      PlataformaCobranca,
      Cobranca,
      ClientePlataformaCobranca,
      ConectorDriveExecucao,
      ConectorDriveArquivo,
      ConectorSharePointConexao,
      ConectorSharePointExecucao,
      ConectorSharePointArquivo,
      ConexaoAssinaturaEletronica,
      EnvelopeAssinaturaEletronica,
      OportunidadeRecuperacao,
      LoteIngestaoDocumentoFiscal,
      ArquivoIngestaoDocumentoFiscal,
      CertificadoDigitalCliente,
      CursorDistribuicaoDfe,
      RegistroOperacional,
      ImportacaoOperacionalMensal,
      DocumentoFiscalTotal,
      DocumentoFiscalItem,
      ConsultaNotasFiscal,
      ResultadoConsultaNotasFiscal,
      ExecucaoWorkerFiscal,

      AgentLog,
      AlertaAgentcore,
      Contexto,
      Escritorio,
      OAuthAccessToken,
      OAuthAuthorizationCode,
      OAuthClient,
      OAuthRefreshToken,
      SeedRun,
      SeedRunApiCall,
      Usuario,
      Sessao,
      AdminSession,
      DesafioMfa,
      FatorMfaAdminPlataforma,
      FatorMfaUsuario,
      EventoAuditoriaSeguranca,
      UsageEvent,
      UsagePricing,
      ModelUsagePricing,
      BillingComplexity,
      ContractExtractionComplexity,
      ExtractionModelConfig,
      Feedback,
      IngestaoControleConcorrencia,
      IngestaoPermissaoProcessamento,
      CobrancaFila,
      SimulacaoCalculoFila,
      SimulacaoFilaControle,
      ProjecaoDocumentoFiscalFila,
      DistribuicaoDfeFila,
      IndiceInflacao,
      CadastroCnpj,
      CnaeReferencia,
      NcmReferencia,
      NbsReferencia,
      SimplesCnae,
      SimplesAnexo,
      SimplesAnexoReparticao,
      SolicitacaoPrivacidade,
      IncidenteDadosPessoais,
      TombstonePrivacidade,
    ],
    // Glob absoluto (CWD-independente). Ver nota em migration-data-source-runtime.ts.
    migrations: [join(dirname(fileURLToPath(import.meta.url)), "modules/public/migrations/*.{ts,js}")],
  });
}

function resolveSslCa(): string | undefined {
  const caPath = process.env.DB_SSL_CA_PATH?.trim();
  if (!caPath) return undefined;
  if (!existsSync(caPath)) {
    throw new Error(`DB_SSL_CA_PATH não encontrado: ${caPath}`);
  }
  return readFileSync(caPath, "utf8");
}

const ENTIDADES_PUBLIC = new Set<Function>([
  AdminSession,
  DesafioMfa,
  FatorMfaAdminPlataforma,
  FatorMfaUsuario,
  EventoAuditoriaSeguranca,
  AgentLog,
  AlertaAgentcore,
  BillingComplexity,
  Contexto,
  ContractExtractionComplexity,
  Escritorio,
  ExtractionModelConfig,
  Feedback,
  ModelUsagePricing,
  OAuthAccessToken,
  OAuthAuthorizationCode,
  OAuthClient,
  OAuthRefreshToken,
  SeedRun,
  SeedRunApiCall,
  Sessao,
  UsageEvent,
  UsagePricing,
  Usuario,
  IngestaoControleConcorrencia,
  IngestaoPermissaoProcessamento,
  CobrancaFila,
  SimulacaoCalculoFila,
  SimulacaoFilaControle,
  ProjecaoDocumentoFiscalFila,
  DistribuicaoDfeFila,
  IndiceInflacao,
  CadastroCnpj,
  CnaeReferencia,
  NcmReferencia,
  NbsReferencia,
  SimplesCnae,
  SimplesAnexo,
  SimplesAnexoReparticao,
  SolicitacaoPrivacidade,
  IncidenteDadosPessoais,
  TombstonePrivacidade,
]);

// rls-guard-ok: lista espelha data-source.ts só p/ montar o Set de guarda runtime, não é acesso via AppDataSource.
const ENTIDADES_TENANT = new Set<Function>([
  Cliente,
  Fornecedor,
  Documento,
  Contrato,
  ContratoDocumentoAnexo,
  ClausulasExcedentes,
  ServicosContratados,
  Relatorio,
  RelatorioEstatisticaCliente,
  Faturamento,
  ValoresACobrar,
  ValoresACobrarVersao,
  CobrancaTest,
  Extracao,
  Agente,
  AcaoAi,
  HistoricoAcaoAi,
  Simulacao,
  SimulacaoEntrada,
  SimulacaoGrupo,
  SimulacaoGrupoItem,
  SimulacaoNotaFiscal,
  AcumuladorSimulacao,
  AcumuladorSimulacaoCliente,
  SimulacaoEntradaExcluida,
  SimulacaoResultadoCache,
  SimulacaoCalculo,
  SimulacaoCalculoEntrada,
  PlataformaCobranca,
  Cobranca,
  ClientePlataformaCobranca,
  ConectorDriveExecucao,
  ConectorDriveArquivo,
  ConectorSharePointConexao,
  ConectorSharePointExecucao,
  ConectorSharePointArquivo,
  ConexaoAssinaturaEletronica,
  EnvelopeAssinaturaEletronica,
  OportunidadeRecuperacao,
  LoteIngestaoDocumentoFiscal,
  ArquivoIngestaoDocumentoFiscal,
  CertificadoDigitalCliente,
  CursorDistribuicaoDfe,
  RegistroOperacional,
  ImportacaoOperacionalMensal,
  DocumentoFiscalTotal,
  DocumentoFiscalItem,
  ConsultaNotasFiscal,
  ResultadoConsultaNotasFiscal,
  ExecucaoWorkerFiscal,

]);

/**
 * Envolve um objeto com `getRepository` (DataSource ou EntityManager) num Proxy que barra as
 * entidades em `entidadesProibidas`, falhando com o nome da entidade em vez de deixar o erro
 * genérico de permissão do Postgres (ou, pior, um vazamento cross-tenant silencioso) explicar sozinho.
 */
function comGuardaDeRepositorio<T extends { getRepository: (...args: never[]) => unknown }>(
  alvo: T,
  entidadesProibidas: Set<Function>,
  formatarMensagem: (nome: string) => string,
): T {
  return new Proxy(alvo, {
    get(target, prop, receiver) {
      if (prop === "getRepository") {
        return (entity: Function) => {
          if (entidadesProibidas.has(entity)) {
            const nome = (entity as { name?: string }).name ?? String(entity);
            throw new Error(formatarMensagem(nome));
          }
          return (target.getRepository as (e: unknown) => unknown)(entity);
        };
      }
      return Reflect.get(target, prop, receiver);
    },
  });
}

/**
 * `runQueryWithRls` roda com role de tenant, que tem privilégios revogados nas tabelas do schema
 * `public` — pegar a entidade errada já falharia no Postgres, mas com um erro de permissão genérico.
 * Este guard falha antes, com a entidade nomeada, para não depender de decifrar o erro do driver.
 */
function comGuardaDeEntidadePublica(manager: EntityManager): EntityManager {
  return comGuardaDeRepositorio(
    manager,
    ENTIDADES_PUBLIC,
    (nome) => `runQueryWithRls: "${nome}" é entidade do schema public — use AppDataSource diretamente, não o wrapper de RLS.`,
  );
}

/**
 * `AppDataSource` conecta com o role dono do schema, que IGNORA o isolamento por schema/role — pegar
 * uma entidade de tenant por aqui vaza dados entre escritórios (ver `verificar-rls-tenant.mjs`, que
 * cobre o mesmo caso via regex sobre texto). Este guard é o equivalente em runtime: pega o uso real,
 * não o texto, então não falsopositiva em comentário, mas também não cobre `AppDataSource.manager
 * .getRepository(...)` (o getter `.manager` retorna o EntityManager sem o Proxy) — mesmo ponto cego
 * do script antigo. Cross-tenant intencional e admin-gated: anote `// rls-guard-ok: <motivo>`.
 */
export const AppDataSource = comGuardaDeRepositorio(
  createDataSource(false),
  ENTIDADES_TENANT,
  (nome) => `AppDataSource.getRepository("${nome}") ignora isolamento RLS — use runQueryWithRls().`,
);
export const RlsDataSource = createDataSource(true);

/** Fecha os pools após drenar HTTP, sem expor o datasource RLS à camada de bootstrap. */
export async function encerrarConexoesBanco(): Promise<void> {
  await Promise.all([AppDataSource, RlsDataSource].map(async (fonte) => {
    if (fonte.isInitialized) await fonte.destroy();
  }));
}

export type RlsSessionContext = {
  escritorio_id: string;
  schema_name?: string;
  role_name?: string;
};

function quoteSqlIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

async function applyRlsSessionContext(manager: EntityManager, context: RlsSessionContext): Promise<void> {
  const schemaName = context.schema_name?.trim() || buildEscritorioSchemaName(context.escritorio_id);
  const roleName = context.role_name?.trim() || buildEscritorioRoleName(context.escritorio_id);
  const searchPath = `${schemaName}, public`;

  await manager.query(`SET LOCAL ROLE ${quoteSqlIdentifier(roleName)}`);
  await manager.query("SELECT set_config('search_path', $1, true)", [searchPath]);
  const schemaCheck = await manager.query("SELECT current_schema() = $1 AS schema_matches", [schemaName]);
  const schemaMatches = Array.isArray(schemaCheck) && schemaCheck.length > 0
    ? Boolean((schemaCheck[0] as { schema_matches?: unknown }).schema_matches)
    : false;
  if (!schemaMatches) {
    throw new Error(`RLS context inválido: search_path não ativou o schema "${schemaName}".`);
  }
  await manager.query("SELECT set_config('app.escritorio_id', $1, true)", [context.escritorio_id]);
}

export async function runQueryWithRls<T>(
  context: RlsSessionContext,
  callback: (manager: EntityManager) => Promise<T>,
): Promise<T> {
  if (!RlsDataSource.isInitialized) {
    await RlsDataSource.initialize();
  }

  return await RlsDataSource.transaction(async (manager) => {
    await applyRlsSessionContext(manager, context);
    return await callback(comGuardaDeEntidadePublica(manager));
  });
}
