import "reflect-metadata";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { DataSource } from "typeorm";
import { CreateNbsReferencia1789300000000 } from "../modules/public/migrations/1789300000000-create_nbs_referencia.js";
import { PublicarCatalogoNbsLocal1793000000000 } from "../modules/public/migrations/1793000000000-publicar-catalogo-nbs-local.js";
import { CATALOGO_NBS } from "../modules/public/migrations/dados/nbs-catalogo-20260917.js";
import { METADADOS_CATALOGO_NBS } from "../modules/public/migrations/dados/nbs-metadados-20260917.js";
import { NbsReferencia } from "../modules/public/entities/nbs-referencia.entity.js";
import { SeedNbsReferenciaCatalogo1789400000000 } from "../modules/public/migrations/1789400000000-seed_nbs_referencia_catalogo.js";
import { SeedRegrasLegaisNbs1789500000000 } from "../modules/public/migrations/1789500000000-seed_regras_legais_nbs.js";

const url = process.env.NBS_TEST_DATABASE_URL;
(url ? describe : describe.skip).sequential("publicação NBS em Postgres descartável", () => {
  let ds: DataSource;
  beforeAll(async () => {
    const destino = new URL(url!);
    if (!["localhost", "127.0.0.1"].includes(destino.hostname) || destino.port !== "55440" || destino.pathname !== "/nbs_test") throw new Error("Teste restrito a localhost:55440/nbs_test.");
    ds = new DataSource({ type: "postgres", url, entities: [NbsReferencia] }); await ds.initialize();
  });
  afterAll(async () => { if (ds?.isInitialized) await ds.destroy(); });
  it("substitui integralmente regras e overrides, preserva histórico e permite rollback transacional", async () => {
    const q = ds.createQueryRunner(); await q.connect();
    try {
      await q.query(`DROP SCHEMA public CASCADE; CREATE SCHEMA public`);
      await q.query(`CREATE FUNCTION uuid_generate_v7() RETURNS uuid LANGUAGE sql AS 'SELECT gen_random_uuid()'`);
      await new CreateNbsReferencia1789300000000().up(q);
      await new SeedNbsReferenciaCatalogo1789400000000().up(q);
      await new SeedRegrasLegaisNbs1789500000000().up(q);
      await q.query(`INSERT INTO nbs_referencia (codigo, descricao, fator_ibs, fator_cbs, gera_credito_adquirente, regime_especifico)
        VALUES ('101', 'Prefixo legado', 0.7, 0.7, false, 'legado'), ('101011100', 'Override antigo', 0, 0.7, false, 'legado'), ('199999999', 'Fora da fonte', 0, 0, false, 'legado')
        ON CONFLICT (codigo) DO UPDATE SET descricao = EXCLUDED.descricao, fator_ibs = EXCLUDED.fator_ibs,
          fator_cbs = EXCLUDED.fator_cbs, gera_credito_adquirente = false, regime_especifico = 'legado',
          origem_configuracao_fatores = 'admin-plataforma'`);
      await q.query(`CREATE TABLE simulacao_entradas (nbs text, fator_ibs numeric, origem_fator_ibs text);
        INSERT INTO simulacao_entradas VALUES ('101011100', 0.7, 'manual'), ('199999999', 0, 'nbs')`);
      const historico = await q.query(`SELECT * FROM simulacao_entradas`);
      const antes = await q.query(`SELECT * FROM nbs_referencia ORDER BY codigo`);
      await q.startTransaction();
      await new PublicarCatalogoNbsLocal1793000000000().up(q);
      await q.rollbackTransaction();
      expect(await q.query(`SELECT * FROM nbs_referencia ORDER BY codigo`)).toEqual(antes);
      expect((await q.query(`SELECT to_regclass('public.nbs_arquivo_20260917') AS tabela`))[0].tabela).toBeNull();
      await q.startTransaction();
      await new PublicarCatalogoNbsLocal1793000000000().up(q);
      await q.commitTransaction();
      expect(await q.query(`SELECT * FROM nbs_arquivo_20260917 ORDER BY codigo`)).toEqual(antes);
      expect(await q.query(`SELECT * FROM simulacao_entradas`)).toEqual(historico);
      const rows = await ds.getRepository(NbsReferencia).find({ order: { fonte_linha: "ASC" } });
      expect(rows).toHaveLength(920);
      expect(rows.map(r => ({ codigo: r.codigo, descricao: r.descricao, capitulo: r.capitulo,
        fator: Number(r.fator_ibs), categoria: r.categoria, fundamento: r.fundamento_legal_fatores,
        observacao: r.condicoes_aplicacao_fatores, linha: r.fonte_linha }))).toEqual(CATALOGO_NBS);
      expect(rows.every(r => Number(r.fator_ibs) === Number(r.fator_cbs) && r.aplicacao_automatica && r.gera_credito_adquirente && r.regime_especifico === null)).toBe(true);
      expect((await q.query(`SELECT metadados FROM nbs_catalogo_versoes`))[0].metadados).toEqual(METADADOS_CATALOGO_NBS);
      await expect(q.query(`INSERT INTO nbs_referencia (codigo, descricao) VALUES ('123', 'Legado')`)).rejects.toThrow();
    } finally {
      if (q.isTransactionActive) await q.rollbackTransaction();
      await q.release();
    }
  });
});
