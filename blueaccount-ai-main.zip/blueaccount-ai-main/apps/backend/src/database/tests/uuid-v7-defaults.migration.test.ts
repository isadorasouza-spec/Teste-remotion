import { describe, expect, it, vi } from "vitest";
import { UuidV7Defaults1786500000000 } from "../modules/public/migrations/1786500000000-uuid_v7_defaults.js";
import { UuidV7Defaults1786600000000 } from "../modules/tenant/migrations/1786600000000-uuid_v7_defaults.js";
import {
  SQL_CRIAR_FUNCAO_UUID_V7,
  SQL_VERIFICAR_FUNCAO_UUID_V7,
  sqlTrocarDefaultsUuid,
} from "../uuid-v7.js";

/**
 * A correção dos bits do UUIDv7 não é testada aqui: é verificada pelo próprio banco, via
 * `SQL_VERIFICAR_FUNCAO_UUID_V7`, que roda dentro da migration e a faz falhar se a função gerar
 * versão, variante ou timestamp errados. Estes testes garantem que essa verificação não seja
 * removida e que a troca de DEFAULT continue restrita ao que deve tocar.
 */
describe("migrations UUIDv7", () => {
  it("cria a função, autoverifica e só então troca os defaults (schema público)", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new UuidV7Defaults1786500000000().up({ query } as never);

    const statements = query.mock.calls.map(([statement]) => statement as string);
    expect(statements).toEqual([
      SQL_CRIAR_FUNCAO_UUID_V7,
      SQL_VERIFICAR_FUNCAO_UUID_V7,
      sqlTrocarDefaultsUuid("uuid_generate_v7"),
    ]);
  });

  it("aplica exatamente o mesmo corpo no schema de tenant", async () => {
    const queryPublico = vi.fn().mockResolvedValue(undefined);
    const queryTenant = vi.fn().mockResolvedValue(undefined);

    await new UuidV7Defaults1786500000000().up({ query: queryPublico } as never);
    await new UuidV7Defaults1786600000000().up({ query: queryTenant } as never);

    expect(queryTenant.mock.calls).toEqual(queryPublico.mock.calls);
  });

  it("não derruba a função ao reverter — schemas de tenant podem depender dela", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new UuidV7Defaults1786500000000().down({ query } as never);

    const statements = query.mock.calls.map(([statement]) => statement as string);
    expect(statements).toEqual([sqlTrocarDefaultsUuid("gen_random_uuid")]);
    expect(statements.join(" ")).not.toMatch(/DROP\s+FUNCTION/i);
  });

  it("não reescreve linha nenhuma: só ALTER ... SET DEFAULT", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new UuidV7Defaults1786500000000().up({ query } as never);
    await new UuidV7Defaults1786600000000().up({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).not.toMatch(/\bUPDATE\b/i);
    expect(sql).not.toMatch(/\bDELETE\b/i);
    expect(sql).not.toMatch(/\bDROP\s+TABLE\b/i);
  });
});

describe("SQL_CRIAR_FUNCAO_UUID_V7", () => {
  it("delega para o uuidv7() nativo no PG18+ e cai no shim abaixo disso", () => {
    expect(SQL_CRIAR_FUNCAO_UUID_V7).toContain("current_setting('server_version_num')::int >= 180000");
    expect(SQL_CRIAR_FUNCAO_UUID_V7).toContain("SELECT uuidv7()");
    expect(SQL_CRIAR_FUNCAO_UUID_V7).toContain("uuid_send(gen_random_uuid())");
  });

  it("mantém o nome que o TypeORM reconhece como coluna gerada", () => {
    // typeorm/driver/postgres/PostgresQueryRunner.js aceita /^uuid_generate_v\d\(\)/ ou
    // gen_random_uuid(). Outro nome faria o migration:generate reverter todas as PKs para v4.
    expect(/^uuid_generate_v\d\(\)/.test("uuid_generate_v7()")).toBe(true);
    expect(SQL_CRIAR_FUNCAO_UUID_V7).toContain("FUNCTION public.uuid_generate_v7()");
  });

  it("declara os dois corpos como VOLATILE, senão o default seria dobrado em constante", () => {
    const ocorrencias = SQL_CRIAR_FUNCAO_UUID_V7.match(/VOLATILE/g) ?? [];
    expect(ocorrencias).toHaveLength(2);
  });

  it("é idempotente — as duas migrations declaram a função", () => {
    const ocorrencias = SQL_CRIAR_FUNCAO_UUID_V7.match(/CREATE OR REPLACE FUNCTION/g) ?? [];
    expect(ocorrencias).toHaveLength(2);
  });
});

describe("SQL_VERIFICAR_FUNCAO_UUID_V7", () => {
  it("falha a migration se versão, variante ou timestamp saírem errados", () => {
    expect(SQL_VERIFICAR_FUNCAO_UUID_V7).toContain("versao invalida");
    expect(SQL_VERIFICAR_FUNCAO_UUID_V7).toContain("variante invalida");
    expect(SQL_VERIFICAR_FUNCAO_UUID_V7).toContain("timestamp fora de hora");
    expect(SQL_VERIFICAR_FUNCAO_UUID_V7).toMatch(/RAISE EXCEPTION/);
  });
});

describe("sqlTrocarDefaultsUuid", () => {
  const paraV7 = sqlTrocarDefaultsUuid("uuid_generate_v7");

  it("limita-se ao schema corrente, a tabelas base e a colunas uuid", () => {
    expect(paraV7).toContain("c.table_schema = current_schema()");
    expect(paraV7).toContain("t.table_type = 'BASE TABLE'");
    expect(paraV7).toContain("c.data_type = 'uuid'");
  });

  it("grava o DEFAULT sem qualificar o schema, senão o TypeORM deixa de reconhecer a coluna como gerada", () => {
    expect(paraV7).toContain("SET DEFAULT uuid_generate_v7()");
    expect(paraV7).not.toContain("SET DEFAULT public.uuid_generate_v7()");
  });

  it("converte tanto colunas em gen_random_uuid() quanto em uuid_generate_v4()", () => {
    expect(paraV7).toContain("c.column_default = 'gen_random_uuid()'");
    expect(paraV7).toContain("c.column_default ~ '^uuid_generate_v\\d\\(\\)'");
  });

  it("na volta, mexe só no que está em v7", () => {
    const paraV4 = sqlTrocarDefaultsUuid("gen_random_uuid");
    expect(paraV4).toContain("c.column_default = 'uuid_generate_v7()'");
    expect(paraV4).toContain("SET DEFAULT gen_random_uuid()");
  });
});
