import { describe, expect, it, vi } from "vitest";
import { AddResumoResultadoSimulacoes1790100000000 } from "../modules/tenant/migrations/1790100000000-add-resumo-resultado-simulacoes.js";

describe("AddResumoResultadoSimulacoes1790100000000", () => {
  it("adiciona o snapshot jsonb à simulação", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddResumoResultadoSimulacoes1790100000000().up({ query } as never);
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('ADD COLUMN "resumo_resultado" jsonb'),
    );
  });

  it("remove o snapshot no rollback", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddResumoResultadoSimulacoes1790100000000().down({ query } as never);
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining('DROP COLUMN "resumo_resultado"'),
    );
  });
});
