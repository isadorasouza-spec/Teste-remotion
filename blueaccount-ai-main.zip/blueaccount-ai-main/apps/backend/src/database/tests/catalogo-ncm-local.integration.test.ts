import "reflect-metadata";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { DataSource } from "typeorm";
import { previaCatalogoNcm } from "../previa-catalogo-ncm.js";
import { CreateNcmsReferencia1786100000000 } from "../modules/public/migrations/1786100000000-create_ncms_referencia.js";
import { EnriquecerNcmsReferenciaComArvore1786101000000 } from "../modules/public/migrations/1786101000000-enriquecer_ncms_referencia_com_arvore.js";
import { AddFatoresIbsCbsNcms1787800000000 } from "../modules/public/migrations/1787800000000-add-fatores-ibs-cbs-ncms.js";
import { EnforceHerancaFatoresNcm1789100000000 } from "../modules/public/migrations/1789100000000-enforce-heranca-fatores-ncm.js";
import { RevisarBeneficiosNcm1792800000000 } from "../modules/public/migrations/1792800000000-revisar-beneficios-ncm.js";
import { PublicarCatalogoNcmLocal1792900000000 } from "../modules/public/migrations/1792900000000-publicar-catalogo-ncm-local.js";
import { RepublicarCatalogoNcmReconciliado1792900001000 } from "../modules/public/migrations/1792900001000-republicar-catalogo-ncm-reconciliado.js";
import { CreateSimulacaoCalculosFila1791000000000 } from "../modules/public/migrations/1791000000000-create-simulacao-calculos-fila.js";

// Exclusivamente banco descartável. Nunca reutilizar a configuração/credenciais do app.
const url = process.env.NCM_TEST_DATABASE_URL;
const suite = url ? describe : describe.skip;
suite.sequential("catálogo NCM: migrations reais em Postgres descartável", () => {
  let ds: DataSource;
  beforeAll(async () => {
    const destino = new URL(url!);
    if (!['localhost', '127.0.0.1'].includes(destino.hostname) || destino.pathname !== '/ncm_test' || destino.port !== '55439') throw new Error('Teste restrito a localhost:55439/ncm_test descartável.');
    ds = new DataSource({ type: "postgres", url }); await ds.initialize();
  });
  afterAll(async () => { if (ds?.isInitialized) await ds.destroy(); });
  async function preparar() {
    const q = ds.createQueryRunner(); await q.connect();
    await q.query(`DROP SCHEMA public CASCADE; CREATE SCHEMA public`);
    for (const M of [CreateNcmsReferencia1786100000000, EnriquecerNcmsReferenciaComArvore1786101000000, AddFatoresIbsCbsNcms1787800000000, EnforceHerancaFatoresNcm1789100000000, RevisarBeneficiosNcm1792800000000]) await new M().up(q);
    return q;
  }
  it("prévia é somente leitura e conta mudanças antes da publicação", async () => {
    const q = await preparar();
    const escritorio = '00000000-0000-0000-0000-000000000003';
    const schema = 'escritorio_00000000_0000_0000_0000_000000000003';
    await q.query(`CREATE TABLE public.escritorios (id uuid PRIMARY KEY); INSERT INTO public.escritorios VALUES ('${escritorio}')`);
    await q.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE; CREATE SCHEMA ${schema}`);
    await q.query(`CREATE TABLE ${schema}.simulacoes (id uuid PRIMARY KEY, escritorio_id uuid, simulacao_origem_id uuid)`);
    await q.query(`CREATE TABLE ${schema}.simulacao_entradas (simulacao_id uuid, escritorio_id uuid, ncm text, fator_ibs numeric, fator_cbs numeric, origem_fator_ibs text, origem_fator_cbs text)`);
    await q.query(`INSERT INTO ${schema}.simulacoes VALUES ('10000000-0000-0000-0000-000000000003',$1,NULL)`, [escritorio]);
    await q.query(`INSERT INTO ${schema}.simulacao_entradas VALUES ('10000000-0000-0000-0000-000000000003',$1,'99999999',0,0.4,'ncm','manual')`, [escritorio]);
    const antes = await q.query(`SELECT * FROM ${schema}.simulacao_entradas`);
    const resultado = await previaCatalogoNcm(ds);
    expect(resultado.simulacoes_historicas_preservadas).toBe(true);
    expect(resultado.catalogo.requerem_revisao).toBe(1606);
    expect(resultado.reconciliacao.conflitos).toHaveLength(345);
    expect(resultado.reconciliacao.conflitos).toContainEqual({ codigo: "96190000", fator_publicado: 0, fator_planilha: 0.4, fator_revisao: 0 });
    expect(resultado.reconciliacao.por_motivo).toMatchObject({ divergencia_fator: 345, condicao_preservada: 449, anexo_sem_revisao_legal: 389, medicamento_requer_confirmacao: 423 });
    expect(resultado.tenants).toEqual([expect.objectContaining({ escritorio_id: escritorio, entradas_fora_catalogo: 1, fatores_ibs_divergentes: 1, fatores_cbs_divergentes: 0, simulacoes_com_ncm_ou_vinculadas: 1 })]);
    expect(await q.query(`SELECT * FROM ${schema}.simulacao_entradas`)).toEqual(antes);
    expect((await q.query(`SELECT to_regclass('public.ncms_arquivo_20260916') AS tabela`))[0].tabela).toBeNull();
    await q.release();
  });
  it("instala após migrations históricas e publica todos os códigos exatamente", async () => {
    const q = await preparar();
    await q.startTransaction(); await new PublicarCatalogoNcmLocal1792900000000().up(q); await q.commitTransaction();
    expect(await q.query(`SELECT fator_ibs::text AS fator, count(*)::int AS total FROM ncms_referencia GROUP BY fator_ibs ORDER BY fator_ibs`)).toEqual([
      { fator: "0.000000", total: 481 }, { fator: "0.400000", total: 1008 }, { fator: "1.000000", total: 9449 },
    ]);
    expect(await q.query(`SELECT situacao_revisao AS situacao, count(*)::int AS total FROM ncms_referencia GROUP BY situacao_revisao ORDER BY situacao_revisao`)).toEqual([
      { situacao: "automatica", total: 9332 }, { situacao: "condicional", total: 1261 }, { situacao: "conflito", total: 345 },
    ]);
    // A garantia central da reconciliação: fator reduzido só é automático onde as duas fontes concordam.
    const [automaticos] = await q.query(`SELECT count(*)::int AS total FROM ncms_referencia WHERE aplicacao_automatica = true AND fator_ibs < 1`);
    expect(automaticos.total).toBe(316);
    expect((await q.query(`SELECT count(*)::int AS total FROM ncms_referencia
      WHERE aplicacao_automatica = true AND fator_ibs < 1 AND jsonb_array_length(evidencias_revisao) <> 2`))[0].total).toBe(0);
    // 9619.00.00 carrega saúde menstrual (art. 147, fator 0) e fraldas (Anexo VIII, 0,4) no mesmo código.
    expect((await q.query(`SELECT fator_ibs::text AS fator, aplicacao_automatica AS automatico, situacao_revisao AS situacao,
      motivos_revisao AS motivos, jsonb_array_length(evidencias_revisao)::int AS evidencias FROM ncms_referencia WHERE codigo = '96190000'`))[0])
      .toEqual({ fator: "0.000000", automatico: false, situacao: "conflito", motivos: ["divergencia_fator"], evidencias: 2 });
    expect((await q.query(`SELECT count(*)::int AS total FROM ncms_referencia WHERE motivos_revisao ? 'medicamento_requer_confirmacao' AND observacao IS NOT NULL`))[0].total).toBe(423);
    expect((await q.query(`SELECT codigo FROM ncms_referencia WHERE length(codigo) <> 8`))).toHaveLength(0);
    await expect(q.query(`INSERT INTO ncms_referencia (codigo, descricao, resposta_brasilapi) VALUES ('12345678', 'Escritor legado', '{}')`)).rejects.toThrow();
    await q.release();
  });
  it("arquiva overrides e permite rollback transacional de uma carga interrompida", async () => {
    const q = await preparar();
    await q.query(`INSERT INTO ncms_referencia (codigo, descricao, resposta_brasilapi, fator_ibs, fator_cbs, origem_configuracao_fatores) VALUES ('99999999', 'Legado', '{}', 0.2, 0.3, 'admin-plataforma')`);
    await q.startTransaction(); await new PublicarCatalogoNcmLocal1792900000000().up(q); await q.rollbackTransaction();
    expect((await q.query(`SELECT codigo FROM ncms_referencia WHERE codigo = '99999999'`))).toHaveLength(1);
    expect((await q.query(`SELECT to_regclass('public.ncms_arquivo_20260916') AS tabela`))[0].tabela).toBeNull();
    await q.startTransaction(); await new PublicarCatalogoNcmLocal1792900000000().up(q); await q.commitTransaction();
    expect((await q.query(`SELECT fator_ibs::text AS fator, origem_configuracao_fatores AS origem FROM ncms_arquivo_20260916 WHERE codigo = '99999999'`))[0]).toEqual({ fator: "0.200000", origem: "admin-plataforma" });
    expect(await q.query(`SELECT codigo FROM ncms_referencia WHERE codigo = '99999999'`)).toHaveLength(0);
    await q.release();
  });
  // Banco que publicou a versão de fonte única precisa da republicação, senão o runtime filtra por
  // uma versão que não existe e devolve fora_catalogo para todo NCM.
  it("republica sobre a versão anterior e é no-op quando a versão corrente já está publicada", async () => {
    const q = await preparar();
    await q.startTransaction(); await new PublicarCatalogoNcmLocal1792900000000().up(q); await q.commitTransaction();
    // Simula o estado de um banco publicado antes da reconciliação.
    await q.query(`UPDATE public.ncm_catalogo_versoes SET versao = 'ncm-20260916-v1'`);
    await q.query(`ALTER TABLE public.ncms_referencia DROP CONSTRAINT "CHK_ncm_catalogo_local"`);
    await q.query(`UPDATE public.ncms_referencia SET versao_catalogo = 'ncm-20260916-v1', situacao_revisao = 'automatica',
      aplicacao_automatica = true, motivos_revisao = '[]'::jsonb, evidencias_revisao = '[]'::jsonb`);

    await q.startTransaction(); await new RepublicarCatalogoNcmReconciliado1792900001000().up(q); await q.commitTransaction();
    expect((await q.query(`SELECT count(*)::int AS total FROM public.ncms_referencia WHERE versao_catalogo = 'ncm-20260916-v2'`))[0].total).toBe(10938);
    expect((await q.query(`SELECT count(*)::int AS total FROM public.ncms_referencia WHERE situacao_revisao = 'conflito'`))[0].total).toBe(345);
    expect((await q.query(`SELECT count(*)::int AS total FROM public.ncms_arquivo_reconciliacao_20260917 WHERE versao_catalogo = 'ncm-20260916-v1'`))[0].total).toBe(10938);

    // Segunda execução não duplica publicação nem reescreve o arquivo da anterior.
    await q.startTransaction(); await new RepublicarCatalogoNcmReconciliado1792900001000().up(q); await q.commitTransaction();
    expect((await q.query(`SELECT count(*)::int AS total FROM public.ncm_catalogo_versoes`))[0].total).toBe(2);
    await q.release();
  });

  it("publica sem alterar fatores, resultados, caches, filas ou cópias de qualquer tenant", async () => {
    const q = await preparar();
    await q.query(`CREATE FUNCTION public.uuid_generate_v7() RETURNS uuid LANGUAGE SQL AS 'SELECT gen_random_uuid()'`);
    await new CreateSimulacaoCalculosFila1791000000000().up(q);
    for (const schema of ['ncm_tenant_a', 'ncm_tenant_b']) {
      await q.query(`DROP SCHEMA IF EXISTS ${schema} CASCADE; CREATE SCHEMA ${schema}`);
      await q.query(`CREATE TABLE ${schema}.simulacoes (id uuid PRIMARY KEY, escritorio_id uuid NOT NULL, simulacao_origem_id uuid, status_calculo text DEFAULT 'calculado', calculo_solicitado_em timestamptz, calculo_iniciado_em timestamptz, erro_calculo text)`);
      await q.query(`CREATE TABLE ${schema}.simulacao_entradas (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), escritorio_id uuid NOT NULL, simulacao_id uuid, ncm varchar(8), fator_ibs numeric, fator_cbs numeric, origem_fator_ibs text, origem_fator_cbs text)`);
      await q.query(`CREATE TABLE ${schema}.simulacao_resultados_cache (simulacao_id uuid, escritorio_id uuid, versao_motor int DEFAULT 8, payload text DEFAULT 'resultado histórico')`);
    }
    for (const schema of ['ncm_tenant_a', 'ncm_tenant_b']) {
      await q.query(`CREATE TABLE ${schema}.simulacao_calculos (LIKE ${schema}.simulacao_resultados_cache INCLUDING ALL)`);
    }
    const a = '00000000-0000-0000-0000-000000000001', b = '00000000-0000-0000-0000-000000000002';
    const s1 = '10000000-0000-0000-0000-000000000001', s2 = '10000000-0000-0000-0000-000000000002';
    await q.query(`INSERT INTO ncm_tenant_a.simulacoes (id, escritorio_id, simulacao_origem_id) VALUES ($1,$3,NULL),($2,$3,$1)`, [s1,s2,a]);
    await q.query(`INSERT INTO ncm_tenant_b.simulacoes (id, escritorio_id) VALUES ($1,$2)`, [s1,b]);
    await q.query(`INSERT INTO ncm_tenant_a.simulacao_entradas (escritorio_id,simulacao_id,ncm,fator_ibs,fator_cbs,origem_fator_ibs,origem_fator_cbs) VALUES
      ($1,$2,'07141000',0.2,0.7,'manual','ncm'), ($1,$2,'99999999',0,0,'ncm','ncm'),
      ($1,$2,'96190000',0.4,0.6,'ncm','manual'), ($1,$2,'01012100',1,1,'ncm','ncm')`, [a,s1]);
    await q.query(`INSERT INTO ncm_tenant_b.simulacao_entradas (escritorio_id,simulacao_id,ncm,fator_ibs,fator_cbs,origem_fator_ibs,origem_fator_cbs) VALUES ($1,$2,'07141000',0.7,0.7,'ncm','ncm')`, [b,s1]);
    await q.query(`INSERT INTO ncm_tenant_a.simulacao_resultados_cache (simulacao_id, escritorio_id) VALUES ($1,$3),($2,$3)`, [s1,s2,a]);
    await q.query(`INSERT INTO ncm_tenant_b.simulacao_resultados_cache (simulacao_id, escritorio_id) VALUES ($1,$2)`, [s1,b]);
    for (const schema of ['ncm_tenant_a', 'ncm_tenant_b']) {
      await q.query(`INSERT INTO ${schema}.simulacao_calculos SELECT * FROM ${schema}.simulacao_resultados_cache`);
    }
    // Inclui uma fila já existente: a publicação não deve alterar sua geração nem criar jobs.
    await q.query(`SELECT set_config('app.escritorio_id', $1, false)`, [b]);
    await q.query(`SELECT public.enfileirar_calculos_simulacao($1, ARRAY[$2]::uuid[], true)`, [b,s1]);
    const tabelas = ['ncm_tenant_a', 'ncm_tenant_b'].flatMap(schema =>
      ['simulacoes', 'simulacao_entradas', 'simulacao_resultados_cache', 'simulacao_calculos'].map(tabela => `${schema}.${tabela}`));
    tabelas.push('public.simulacao_calculos_fila');
    const snapshot = async () => {
      const dados = [];
      for (const tabela of tabelas) dados.push(await q.query(`SELECT * FROM ${tabela} ORDER BY 1, 2`));
      return dados;
    };
    const antes = await snapshot();
    await q.startTransaction();
    await new PublicarCatalogoNcmLocal1792900000000().up(q);
    await q.commitTransaction();
    expect(await snapshot()).toEqual(antes);
    expect((await q.query(`SELECT count(*)::int AS total FROM public.ncms_referencia`))[0].total).toBe(10938);
    await q.release();
  });
});
