import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { AppDataSource } from "../data-source.js";

// Mock AppDataSource
vi.mock("../data-source.js", () => ({
  AppDataSource: {
    isInitialized: false,
    initialize: vi.fn().mockResolvedValue(undefined),
    destroy: vi.fn().mockResolvedValue(undefined),
    query: vi.fn(),
    getRepository: vi.fn(),
  },
}));

vi.mock("../tenant-naming.js", () => ({
  buildEscritorioSchemaName: (id: string) => `escritorio_${id.replace(/-/g, "_")}`,
}));

vi.mock("../tenant-module-runner.js", () => ({
  runTenantMigrations: vi.fn().mockResolvedValue(undefined),
  runModuleMigrations: vi.fn().mockResolvedValue(undefined),
  MODULE_FACTORIES: { tenant: {} },
}));

import { buildEscritorioSchemaName } from "../tenant-naming.js";
import { runTenantMigrations, runModuleMigrations } from "../tenant-module-runner.js";

describe("sync-tenant-schemas", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("ensureTenantMigrationStateTable", () => {
    it("creates tenant_migration_state table if not exists", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce(undefined);

      // Simulate the function locally since we can't import it directly
      const quoteIdentifier = (value: string) => `"${value.replace(/"/g, '""')}"`;
      const MIGRATION_STATE_TABLE = "tenant_migration_state";

      await AppDataSource.query(`
        CREATE TABLE IF NOT EXISTS public.${quoteIdentifier(MIGRATION_STATE_TABLE)} (
          schema_name text NOT NULL,
          module_name text NOT NULL,
          last_migration_timestamp bigint,
          last_migration_name text,
          updated_at timestamptz NOT NULL DEFAULT now(),
          CONSTRAINT pk_tenant_migration_state PRIMARY KEY (schema_name, module_name)
        )
      `);

      expect(mockQuery).toHaveBeenCalled();
      const call = mockQuery.mock.calls[0][0];
      expect(call).toContain("CREATE TABLE IF NOT EXISTS");
      expect(call).toContain("tenant_migration_state");
    });
  });

  describe("readLatestTenantMigrationFromSchema", () => {
    it("returns null when schema has no _tenant_migrations table", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const error = new Error("relation not found");
      (error as any).code = "42P01";
      mockQuery.mockRejectedValueOnce(error);

      const schemaName = "test_schema";
      const quoteIdentifier = (value: string) => `"${value.replace(/"/g, '""')}"`;

      try {
        await AppDataSource.query(
          `SELECT timestamp, name FROM ${quoteIdentifier(schemaName)}."_tenant_migrations" ORDER BY timestamp DESC LIMIT 1`,
        );
      } catch (error: any) {
        expect(error.code).toBe("42P01");
      }
    });

    it("returns latest migration when table exists", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce([
        { timestamp: 1234567890, name: "add_column_x" },
      ]);

      const schemaName = "escritorio_abc123";
      const quoteIdentifier = (value: string) => `"${value.replace(/"/g, '""')}"`;

      const result = await AppDataSource.query(
        `SELECT timestamp, name FROM ${quoteIdentifier(schemaName)}."_tenant_migrations" ORDER BY timestamp DESC LIMIT 1`,
      );

      expect(result).toHaveLength(1);
      expect(result[0]).toEqual({
        timestamp: 1234567890,
        name: "add_column_x",
      });
    });

    it("returns null when no migrations exist", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce([]);

      const schemaName = "new_schema";
      const quoteIdentifier = (value: string) => `"${value.replace(/"/g, '""')}"`;

      const result = await AppDataSource.query(
        `SELECT timestamp, name FROM ${quoteIdentifier(schemaName)}."_tenant_migrations" ORDER BY timestamp DESC LIMIT 1`,
      );

      expect(result).toHaveLength(0);
    });
  });

  describe("persistTenantMigrationState", () => {
    it("inserts new migration state record", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce(undefined);

      const schemaName = "escritorio_test";
      const moduleName = "tenant";
      const state = { timestamp: 1234567890, name: "add_column" };

      await AppDataSource.query(
        `INSERT INTO public."tenant_migration_state"
          (schema_name, module_name, last_migration_timestamp, last_migration_name, updated_at)
        VALUES ($1, $2, $3, $4, now())
        ON CONFLICT (schema_name, module_name)
        DO UPDATE SET
          last_migration_timestamp = EXCLUDED.last_migration_timestamp,
          last_migration_name = EXCLUDED.last_migration_name,
          updated_at = now()`,
        [schemaName, moduleName, state.timestamp, state.name],
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("INSERT INTO public"),
        [schemaName, moduleName, state.timestamp, state.name],
      );
    });

    it("updates existing migration state record", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce(undefined);

      const schemaName = "escritorio_existing";
      const moduleName = "tenant";
      const state = { timestamp: 9999999999, name: "new_migration" };

      await AppDataSource.query(
        `INSERT INTO public."tenant_migration_state"
          (schema_name, module_name, last_migration_timestamp, last_migration_name, updated_at)
        VALUES ($1, $2, $3, $4, now())
        ON CONFLICT (schema_name, module_name)
        DO UPDATE SET
          last_migration_timestamp = EXCLUDED.last_migration_timestamp,
          last_migration_name = EXCLUDED.last_migration_name,
          updated_at = now()`,
        [schemaName, moduleName, state.timestamp, state.name],
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("ON CONFLICT"),
        [schemaName, moduleName, state.timestamp, state.name],
      );
    });

    it("handles null migration state", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce(undefined);

      const schemaName = "new_schema";
      const moduleName = "tenant";

      await AppDataSource.query(
        `INSERT INTO public."tenant_migration_state"
          (schema_name, module_name, last_migration_timestamp, last_migration_name, updated_at)
        VALUES ($1, $2, $3, $4, now())
        ON CONFLICT (schema_name, module_name)
        DO UPDATE SET
          last_migration_timestamp = EXCLUDED.last_migration_timestamp,
          last_migration_name = EXCLUDED.last_migration_name,
          updated_at = now()`,
        [schemaName, moduleName, null, null],
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.any(String),
        [schemaName, moduleName, null, null],
      );
    });
  });

  describe("main - sync-tenant-schemas orchestration", () => {
    it("initializes AppDataSource if not already initialized", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const mockInit = vi.mocked(AppDataSource.initialize);

      (AppDataSource as any).isInitialized = false;
      mockQuery.mockResolvedValue([]);
      mockInit.mockResolvedValueOnce(undefined);

      await AppDataSource.initialize();

      expect(mockInit).toHaveBeenCalled();
    });

    it("processes all escritorios and runs migrations", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const mockRunTenant = vi.mocked(runTenantMigrations);
      const mockGetRepository = vi.mocked(AppDataSource.getRepository);

      const mockRepository = {
        find: vi
          .fn()
          .mockResolvedValueOnce([
            { id: "escritorio-1" },
            { id: "escritorio-2" },
          ]),
      };

      mockGetRepository.mockReturnValueOnce(mockRepository as any);
      mockQuery.mockResolvedValue([]);
      mockRunTenant.mockResolvedValue(undefined);

      const escritorios = await AppDataSource.getRepository("Escritorio").find({
        select: { id: true },
      });

      expect(escritorios).toHaveLength(2);
      expect(escritorios[0].id).toBe("escritorio-1");
    });

    it("creates schema for each escritorio if not exists", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const id = "test-id-123";
      const expectedSchemaName = buildEscritorioSchemaName(id);

      mockQuery.mockResolvedValueOnce(undefined);

      await AppDataSource.query(
        `CREATE SCHEMA IF NOT EXISTS "${expectedSchemaName}"`,
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("CREATE SCHEMA IF NOT EXISTS"),
      );
      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("escritorio_test_id_123"),
      );
    });

    it("respects --module flag when provided", async () => {
      const mockRunModule = vi.mocked(runModuleMigrations);
      mockRunModule.mockResolvedValue(undefined);

      const targetModule = "tenant";
      if (targetModule && ["tenant"].includes(targetModule)) {
        await runModuleMigrations("escritorio_test", {});
      }

      expect(mockRunModule).toHaveBeenCalledWith("escritorio_test", {});
    });

    it("runs all modules when --module flag not provided", async () => {
      const mockRunTenant = vi.mocked(runTenantMigrations);
      mockRunTenant.mockResolvedValue(undefined);

      await runTenantMigrations("escritorio_test");

      expect(mockRunTenant).toHaveBeenCalledWith("escritorio_test");
    });

    it("persists migration state after processing each schema", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValue(undefined);

      const schemaName = "escritorio_state_test";
      await AppDataSource.query(
        `INSERT INTO public."tenant_migration_state"
          (schema_name, module_name, last_migration_timestamp, last_migration_name, updated_at)
        VALUES ($1, $2, $3, $4, now())`,
        [schemaName, "tenant", 1234567890, "test_migration"],
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("INSERT INTO public"),
        expect.arrayContaining([schemaName, "tenant"]),
      );
    });
  });

  describe("quoteIdentifier utility", () => {
    it("wraps identifier in quotes", () => {
      const quoteIdentifier = (value: string) =>
        `"${value.replace(/"/g, '""')}"`;
      const result = quoteIdentifier("schema_name");

      expect(result).toBe('"schema_name"');
    });

    it("escapes double quotes in identifier", () => {
      const quoteIdentifier = (value: string) =>
        `"${value.replace(/"/g, '""')}"`;
      const result = quoteIdentifier('schema"name');

      expect(result).toBe('"schema""name"');
    });
  });
});
