import { describe, expect, it } from "vitest";
import { REGRAS_NCM_REVISADAS } from "../modules/public/migrations/dados/regras-ncm-revisadas-20260916.js";

const resolver = (codigo: string) => [...REGRAS_NCM_REVISADAS]
  .filter(r => codigo.startsWith(r.codigo)).sort((a, b) => b.codigo.length - a.codigo.length)[0];

describe("catálogo NCM revisado conforme LC 214/2025", () => {
  it("não possui códigos repetidos ou fatores inválidos", () => {
    expect(new Set(REGRAS_NCM_REVISADAS.map(r => r.codigo)).size).toBe(REGRAS_NCM_REVISADAS.length);
    for (const r of REGRAS_NCM_REVISADAS) {
      expect(r.codigo).toMatch(/^\d{2,8}$/);
      expect([0, 0.4, 1]).toContain(r.fator);
      if (!r.automatica) expect(r.condicoes).toBeTruthy();
    }
  });

  it.each(["07141000", "02011000", "02071400", "02061000", "11010010", "17019900"])(
    "%s permanece com alíquota zero no escopo legal", codigo => {
      expect(resolver(codigo)).toMatchObject({ fator: 0, automatica: true });
    },
  );

  it.each(["15079011", "07132090", "10061092", "11010020"])(
    "%s não herda zero de um prefixo excessivo", codigo => {
      expect(resolver(codigo)).toMatchObject({ fator: 0.4, automatica: false });
    },
  );

  it.each(["04029900", "17019100", "19024000", "19053100", "33062000", "87149990", "21061000"])(
    "%s não recebe benefício genérico sem previsão", codigo => expect(resolver(codigo)).toBeUndefined(),
  );

  it.each(["03025100", "03036300", "03044100", "03047100", "02074300"])(
    "%s exige conferir espécie/apresentação e eventual regime in natura", codigo => {
      expect(resolver(codigo)).toMatchObject({ automatica: false });
    },
  );

  it("não zera fraldas nem preparações genéricas automaticamente pelo NCM compartilhado", () => {
    expect(resolver("96190000")).toMatchObject({ automatica: false });
    expect(resolver("96190000")?.condicoes).toContain("Fraldas");
    for (const c of ["21069090", "19019090", "19059090"]) expect(resolver(c)?.automatica).toBe(false);
  });

  it.each(["96032100", "48181000", "33061000"])("%s recebe a redução correta de higiene", codigo => {
    expect(resolver(codigo)).toMatchObject({ fator: 0.4, automatica: true });
  });

  it.each(["87131000", "87142000", "90189010"])("%s sugere zero condicionado à norma aplicável", codigo => {
    expect(resolver(codigo)).toMatchObject({ fator: 0, automatica: false });
  });
});
