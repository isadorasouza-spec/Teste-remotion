import { describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { CreateCatalogoSimples1789800000000 } from "../modules/public/migrations/1789800000000-create-catalogo-simples.js";
import { AddRbt12Folha12mSimulacoes1789800000001 } from "../modules/tenant/migrations/1789800000001-add-rbt12-folha-12m-simulacoes.js";
import { AddDestinoIpiSemIncidenciaSimulacoes1789800000002 } from "../modules/tenant/migrations/1789800000002-add-destino-ipi-sem-incidencia-simulacoes.js";
import { CompletarCatalogoSimplesCnaes1789800000003 } from "../modules/public/migrations/1789800000003-completar-catalogo-simples-cnaes.js";
import { AddSituacaoSimplesCnaes1789800000004 } from "../modules/public/migrations/1789800000004-add-situacao-simples-cnaes.js";
import { CompletarCatalogoSimplesServicos1789800000005 } from "../modules/public/migrations/1789800000005-completar-catalogo-simples-servicos.js";
import { SIMPLES_CNAES_SEED } from "../modules/public/migrations/dados/simples-cnaes.js";
import { SIMPLES_ANEXOS_SEED } from "../modules/public/migrations/dados/simples-anexos.js";

describe("migrations do DAS automático", () => {
  it("registra as três entidades em todos os DataSources públicos", () => {
    for (const arquivo of ["../data-source.ts", "../migration-data-source.ts", "../migration-data-source-runtime.ts"]) {
      const fonte = readFileSync(new URL(arquivo, import.meta.url), "utf8");
      expect(fonte).toContain("SimplesCnae");
      expect(fonte).toContain("SimplesAnexo");
      expect(fonte).toContain("SimplesAnexoReparticao");
    }
  });

  it("cria os três catálogos públicos com checks, UUIDv7 e todo o seed", async () => {
    const query = vi.fn(async () => []);
    await new CreateCatalogoSimples1789800000000().up({ query } as never);
    const sql = query.mock.calls.map(([texto]) => String(texto)).join("\n");
    expect(sql).toContain('CREATE TABLE "simples_cnaes"');
    expect(sql).toContain('CREATE TABLE "simples_anexos"');
    expect(sql).toContain('CREATE TABLE "simples_anexo_reparticoes"');
    expect(sql).toContain("uuid_generate_v7()");
    expect(sql).toContain("CK_simples_cnaes_fator_r");
    const inserts = query.mock.calls.filter(([texto]) => String(texto).includes("INSERT INTO"));
    expect(JSON.parse(String(inserts[0][1]?.[0]))).toHaveLength(SIMPLES_CNAES_SEED.length);
    expect(JSON.parse(String(inserts[1][1]?.[0]))).toHaveLength(SIMPLES_ANEXOS_SEED.length);
    // A procedência vai linha a linha: o seed mistura o recorte curado de serviços com as subclasses
    // oficiais do IBGE, então `fonte` não pode ser constante no SQL.
    expect(String(inserts[0][0])).toContain("item.fonte");
    // Toda linha tem procedência, e ela é uma lista ou um dispositivo da LC 123/2006.
    expect(SIMPLES_CNAES_SEED.every((item) => Boolean(item.fonte))).toBe(true);
    expect(SIMPLES_CNAES_SEED.filter((item) => item.fonte === "tabela-cnae.csv")).toHaveLength(392);
    // As duas migrations que rodam antes de a coluna existir precisam filtrar, senão linha sem anexo
    // viola CK_simples_cnaes_fator_r e a criação do zero quebra em banco novo.
    expect(sql).toContain("WHERE item.situacao = 'enquadrado'");
  });

  it("adiciona campos tenant nullable com checks não negativos e sem backfill", async () => {
    const query = vi.fn(async () => []);
    await new AddRbt12Folha12mSimulacoes1789800000001().up({ query } as never);
    const sql = String(query.mock.calls[0][0]);
    expect(sql).toContain('ADD COLUMN "rbt12" numeric(14,2)');
    expect(sql).toContain('ADD COLUMN "folha_12m" numeric(14,2)');
    expect(sql).toContain("CHECK (\"rbt12\" IS NULL OR \"rbt12\" >= 0)");
    expect(sql).not.toMatch(/UPDATE|DEFAULT/i);
  });

  it("completa o catálogo de forma idempotente em banco que já rodou o seed inline", async () => {
    const query = vi.fn(async () => []);
    await new CompletarCatalogoSimplesCnaes1789800000003().up({ query } as never);
    const sql = String(query.mock.calls[0][0]);

    // Sem isto, crescer o arquivo de seed é invisível para todo banco que já aplicou 1789800000000.
    expect(sql).toContain('ON CONFLICT ("codigo") DO NOTHING');
    expect(sql).toContain("WHERE item.situacao = 'enquadrado'");
    expect(sql).not.toMatch(/UPDATE|DELETE/i);
    expect(JSON.parse(String(query.mock.calls[0][1]?.[0]))).toHaveLength(SIMPLES_CNAES_SEED.length);

    const queryDown = vi.fn(async () => []);
    await new CompletarCatalogoSimplesCnaes1789800000003().down({ query: queryDown } as never);
    // O `down` não pode levar embora o recorte curado de serviços, que veio da outra migration.
    expect(String(queryDown.mock.calls[0][0])).toContain("'ibge/cnae/subclasses'");
  });

  it("relaxa o CHECK de anexo antes de inserir vedado e não-optante", async () => {
    const query = vi.fn(async () => []);
    await new AddSituacaoSimplesCnaes1789800000004().up({ query } as never);
    const sql = query.mock.calls.map(([texto]) => String(texto)).join("\n");

    expect(sql).toContain('ADD COLUMN "situacao" varchar(20) NOT NULL DEFAULT \'enquadrado\'');
    expect(sql).toContain("IN ('enquadrado', 'vedado', 'nao_optante')");
    // A ordem importa: o CHECK antigo exige anexo em linha sem Fator R, então tem de cair ANTES do
    // INSERT das linhas sem anexo.
    const posDrop = sql.indexOf('DROP CONSTRAINT "CK_simples_cnaes_fator_r"');
    const posInsert = sql.indexOf("INSERT INTO");
    expect(posDrop).toBeGreaterThan(-1);
    expect(posInsert).toBeGreaterThan(posDrop);
    expect(sql).toContain('ON CONFLICT ("codigo") DO NOTHING');
    // O CHECK novo só exige anexo dentro de `enquadrado`.
    expect(sql).toMatch(/CASE WHEN "situacao" = 'enquadrado'/);
  });

  it("traz os serviços do residual sem depender de a migration anterior ter rodado", async () => {
    const query = vi.fn(async () => []);
    await new CompletarCatalogoSimplesServicos1789800000005().up({ query } as never);
    const sql = String(query.mock.calls[0][0]);

    // Migration própria, e não crescimento do seed lido pela anterior: aquela roda uma vez só.
    expect(sql).toContain('ON CONFLICT ("codigo") DO NOTHING');
    expect(sql).toContain('"situacao"');
    expect(sql).not.toMatch(/UPDATE/i);
    expect(JSON.parse(String(query.mock.calls[0][1]?.[0]))).toHaveLength(SIMPLES_CNAES_SEED.length);
  });

  it("adiciona a premissa de destino do IPI com default neutro em deploy", async () => {
    const query = vi.fn(async () => []);
    await new AddDestinoIpiSemIncidenciaSimulacoes1789800000002().up({ query } as never);
    const sql = String(query.mock.calls[0][0]);

    expect(sql).toContain('ADD COLUMN "destino_ipi_sem_incidencia" varchar(20) NOT NULL');
    // `receita` é o comportamento histórico do motor: nenhum cenário existente muda de número.
    expect(sql).toContain("DEFAULT 'receita'");
    expect(sql).toContain("IN ('receita', 'reducao_preco')");
    expect(sql).not.toMatch(/UPDATE/i);
  });
});
