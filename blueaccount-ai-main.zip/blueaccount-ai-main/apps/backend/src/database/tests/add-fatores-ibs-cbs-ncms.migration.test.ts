import { describe, expect, it, vi } from "vitest";
import { AddFatoresIbsCbsNcms1787800000000 } from "../modules/public/migrations/1787800000000-add-fatores-ibs-cbs-ncms.js";

describe("AddFatoresIbsCbsNcms1787800000000", () => {
  it("cria fatores globais limitados e carrega um manifesto sem códigos duplicados", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddFatoresIbsCbsNcms1787800000000().up({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('ADD COLUMN IF NOT EXISTS "fator_ibs" decimal(7,6) NOT NULL DEFAULT 1');
    expect(sql).toContain('ADD COLUMN IF NOT EXISTS "fator_cbs" decimal(7,6) NOT NULL DEFAULT 1');
    expect(sql).toContain('CHECK ("fator_ibs" BETWEEN 0 AND 1)');
    expect(sql).toContain("ON CONFLICT (\"codigo\") DO UPDATE");
    const codigos = query.mock.calls
      .filter(([, parametros]) => Array.isArray(parametros))
      .map(([, parametros]) => (parametros as unknown[])[0]);
    expect(codigos.length).toBeGreaterThan(30);
    expect(new Set(codigos).size).toBe(codigos.length);
    const cargas = query.mock.calls.filter(([, parametros]) => Array.isArray(parametros)).map(([, parametros]) => parametros as unknown[]);
    expect(cargas.find(([codigo]) => codigo === "04090000")).toEqual(expect.arrayContaining(["04090000", expect.any(String), expect.any(String), 0.4, true]));
    expect(cargas.find(([codigo]) => codigo === "3306")?.[4]).toBe(false);
    expect(cargas.find(([codigo]) => codigo === "02074300")).toEqual(expect.arrayContaining(["02074300", expect.any(String), expect.any(String), 1, true]));
  });

  it("remove somente linhas criadas pelo manifesto antes de retirar a configuração", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddFatoresIbsCbsNcms1787800000000().down({ query } as never);

    const [deleteSql, alterSql] = query.mock.calls.map(([statement]) => statement as string);
    expect(deleteSql).toContain("resposta_brasilapi\"->>'origem' = 'migration:LC214-227-2026'");
    expect(deleteSql).not.toContain("TRUNCATE");
    expect(alterSql).toContain('DROP COLUMN "fator_ibs"');
  });
});
