import { afterEach, expect, it, vi } from "vitest";
import { reconciliarPrivilegiosWorkerFiscal, grantTenantRoleToRuntimeRoles } from "../tenant-privileges.js";
afterEach(() => vi.unstubAllEnvs());
it.each([undefined, { rolsuper: true }, { rolbypassrls: true }, { rolinherit: true }])("recusa role ausente ou privilegiada: %j", async (role) => {
  vi.stubEnv("DOCUMENTOS_FISCAIS_DB_USERNAME", "fiscal");
  const query = vi.fn().mockResolvedValue(role ? [role] : []);
  await expect(reconciliarPrivilegiosWorkerFiscal({ query })).rejects.toThrow("NOSUPERUSER");
  expect(query).toHaveBeenCalledTimes(1);
});
it("repara grants das duas filas após migration sem username", async () => {
  vi.stubEnv("DOCUMENTOS_FISCAIS_DB_USERNAME", "fiscal");
  const query = vi.fn().mockResolvedValue([])
    .mockResolvedValueOnce([{ rolsuper: false, rolbypassrls: false, rolinherit: false }])
    .mockResolvedValueOnce([{ relname: "ingestoes_fiscais_fila" }, { relname: "distribuicoes_dfe_fila" }]);
  await reconciliarPrivilegiosWorkerFiscal({ query });
  expect(query).toHaveBeenCalledWith('GRANT SELECT,UPDATE ON public."ingestoes_fiscais_fila" TO "fiscal"');
  expect(query).toHaveBeenCalledWith('GRANT SELECT,UPDATE ON public."distribuicoes_dfe_fila" TO "fiscal"');
});
it("falha ao provisionar novo escritório se a role fiscal configurada não existe", async () => {
  vi.stubEnv("DOCUMENTOS_FISCAIS_DB_USERNAME", "fiscal");
  await expect(grantTenantRoleToRuntimeRoles({ query: vi.fn().mockResolvedValue([]) }, "user_escritorio_teste", ["fiscal"]))
    .rejects.toThrow("deve existir");
});
