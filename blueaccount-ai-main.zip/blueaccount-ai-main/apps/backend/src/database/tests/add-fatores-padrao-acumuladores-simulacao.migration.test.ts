import { describe, expect, it, vi } from "vitest";
import { AddFatoresPadraoAcumuladoresSimulacao1787700000000 } from "../modules/tenant/migrations/1787700000000-add-fatores-padrao-acumuladores-simulacao.js";

describe("AddFatoresPadraoAcumuladoresSimulacao1787700000000", () => {
  it("adiciona defaults nullable com limites sem atualizar registros existentes", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new AddFatoresPadraoAcumuladoresSimulacao1787700000000().up({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('ADD COLUMN "fator_ibs_padrao" numeric(7,6)');
    expect(sql).toContain('ADD COLUMN "fator_cbs_padrao" numeric(7,6)');
    expect(sql).toContain('"fator_ibs_padrao" BETWEEN 0 AND 1');
    expect(sql).toContain('"fator_cbs_padrao" BETWEEN 0 AND 1');
    expect(sql).not.toMatch(/\bUPDATE\b/i);
  });

  it("remove constraints e colunas na reversão", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new AddFatoresPadraoAcumuladoresSimulacao1787700000000().down({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('DROP CONSTRAINT "CK_acumuladores_simulacao_fator_ibs_padrao"');
    expect(sql).toContain('DROP CONSTRAINT "CK_acumuladores_simulacao_fator_cbs_padrao"');
    expect(sql).toContain('DROP COLUMN "fator_ibs_padrao"');
    expect(sql).toContain('DROP COLUMN "fator_cbs_padrao"');
  });
});
