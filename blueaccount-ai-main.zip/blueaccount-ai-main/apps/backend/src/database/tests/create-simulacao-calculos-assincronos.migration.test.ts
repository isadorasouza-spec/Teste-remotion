import { describe, expect, it, vi } from "vitest";
import { CreateSimulacaoCalculosFila1791000000000 } from "../modules/public/migrations/1791000000000-create-simulacao-calculos-fila.js";
import { CreateSimulacaoCalculosAssincronos1791000000000 } from "../modules/tenant/migrations/1791000000000-create-simulacao-calculos-assincronos.js";

describe("migrations dos cálculos assíncronos", () => {
  it("cria fila durável, controle global e funções transacionais", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new CreateSimulacaoCalculosFila1791000000000().up({ query } as never);
    const sql = query.mock.calls.map(([texto]) => String(texto)).join("\n");

    expect(sql).toContain('CREATE TABLE "simulacao_calculos_fila"');
    expect(sql).toContain('UNIQUE ("escritorio_id", "simulacao_id")');
    expect(sql).toContain('CREATE TABLE "simulacao_fila_controle"');
    expect(sql).toContain('SECURITY DEFINER');
    expect(sql).toContain('enfileirar_calculos_simulacao');
  });

  it("cria o artefato logged com cascade e recupera o cache anterior", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new CreateSimulacaoCalculosAssincronos1791000000000().up({ query } as never);
    const sql = query.mock.calls.map(([texto]) => String(texto)).join("\n");

    expect(sql).toContain('ADD COLUMN "status_calculo"');
    expect(sql).toContain('CREATE TABLE "simulacao_calculos"');
    expect(sql).toContain('ON DELETE CASCADE');
    expect(sql).toContain('FROM "simulacao_resultados_cache"');
    expect(sql).not.toContain("UNLOGGED");
  });

  it("remove primeiro os objetos dependentes no rollback", async () => {
    const publicQuery = vi.fn().mockResolvedValue(undefined);
    const tenantQuery = vi.fn().mockResolvedValue(undefined);
    await new CreateSimulacaoCalculosFila1791000000000().down({ query: publicQuery } as never);
    await new CreateSimulacaoCalculosAssincronos1791000000000().down({ query: tenantQuery } as never);

    expect(String(publicQuery.mock.calls[0][0])).toContain("remover_calculo_simulacao_fila");
    expect(String(publicQuery.mock.calls.at(-1)?.[0])).toContain('DROP TABLE "simulacao_calculos_fila"');
    expect(String(tenantQuery.mock.calls[0][0])).toContain('DROP TABLE "simulacao_calculos"');
    expect(tenantQuery.mock.calls.map(([texto]) => String(texto)).join("\n")).toContain('DROP COLUMN "status_calculo"');
  });
});
