import { DataSource, Table, TableColumn } from "typeorm";
import { expect, it, vi } from "vitest";
import { AdicionarOrigemLoteFiscal1791400000000 } from "../modules/tenant/migrations/1791400000000-adicionar-origem-lote-fiscal.js";

it("gera alteração aditiva com default compatível para lotes antigos", async () => {
  const runner = new DataSource({ type: "postgres" }).createQueryRunner();
  runner.enableSqlMemory();
  await runner.addColumn(new Table({ name: "lotes_ingestao_documentos_fiscais", columns: [] }),
    new TableColumn({ name: "origem", type: "varchar", length: "20", isNullable: false, default: "'upload_manual'" }));
  const query = vi.fn();
  const migration = new AdicionarOrigemLoteFiscal1791400000000();
  await migration.up({ query } as never);
  expect(query.mock.calls.map(([sql]) => sql)).toEqual(runner.getMemorySql().upQueries.map((q) => q.query));
  query.mockClear();
  await migration.down({ query } as never);
  expect(query.mock.calls.map(([sql]) => sql)).toEqual(runner.getMemorySql().downQueries.map((q) => q.query));
});
