import { afterEach, describe, expect, it, vi } from "vitest";
import { AppDataSource, RlsDataSource, encerrarConexoesBanco } from "../data-source.js";

afterEach(() => {
  Object.assign(AppDataSource, { isInitialized: false });
  Object.assign(RlsDataSource, { isInitialized: false });
  vi.restoreAllMocks();
});

describe("encerrarConexoesBanco", () => {
  it.each([[true, true], [true, false], [false, true], [false, false]])(
    "fecha apenas pools inicializados (owner=%s, RLS=%s)", async (owner, rls) => {
      Object.assign(AppDataSource, { isInitialized: owner });
      Object.assign(RlsDataSource, { isInitialized: rls });
      const fecharOwner = vi.spyOn(AppDataSource, "destroy").mockResolvedValue();
      const fecharRls = vi.spyOn(RlsDataSource, "destroy").mockResolvedValue();
      await encerrarConexoesBanco();
      expect(fecharOwner).toHaveBeenCalledTimes(Number(owner));
      expect(fecharRls).toHaveBeenCalledTimes(Number(rls));
    },
  );
  it("tenta fechar ambos e propaga falha ao ciclo de shutdown", async () => {
    Object.assign(AppDataSource, { isInitialized: true });
    Object.assign(RlsDataSource, { isInitialized: true });
    vi.spyOn(AppDataSource, "destroy").mockRejectedValue(new Error("falha no fechamento"));
    const fecharRls = vi.spyOn(RlsDataSource, "destroy").mockResolvedValue();
    await expect(encerrarConexoesBanco()).rejects.toThrow("falha no fechamento");
    expect(fecharRls).toHaveBeenCalledOnce();
  });
});
