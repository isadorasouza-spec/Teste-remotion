import { describe, it, expect, beforeEach, vi } from "vitest";
import { AppDataSource } from "../data-source.js";

// Mock AppDataSource
vi.mock("../data-source.js", () => ({
  AppDataSource: {
    isInitialized: false,
    initialize: vi.fn().mockResolvedValue(undefined),
    destroy: vi.fn().mockResolvedValue(undefined),
    query: vi.fn(),
    transaction: vi.fn(),
  },
}));

vi.mock("../tenant-naming.js", () => ({
  buildEscritorioRoleName: (id: string) => `user_escritorio_${id.replace(/-/g, "_")}`,
}));

vi.mock("../escritorio-schema.js", () => ({
  provisionEscritorioSchema: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("node:fs/promises", () => ({
  readFile: vi.fn().mockResolvedValue("-- SQL content from file"),
}));

import { buildEscritorioRoleName } from "../tenant-naming.js";
import { provisionEscritorioSchema } from "../escritorio-schema.js";

describe("create-tenant-schemas", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DB_AI_USERNAME = undefined;
    process.env.DB_USERNAME = undefined;
  });

  describe("resolveRuntimeRoles", () => {
    it("returns both runtime roles when both are set", () => {
      process.env.DB_AI_USERNAME = "app_ai";
      process.env.DB_USERNAME = "app_user";

      const uniqueValues = (values: Array<string | null | undefined>): string[] =>
        [...new Set(values.filter((value): value is string => Boolean(value && value.trim())))].map((value) =>
          value.trim(),
        );

      const runtimeRoles = uniqueValues([
        process.env.DB_AI_USERNAME,
        process.env.DB_USERNAME,
      ]);

      expect(runtimeRoles).toContain("app_ai");
      expect(runtimeRoles).toContain("app_user");
      expect(runtimeRoles).toHaveLength(2);
    });

    it("filters out undefined roles", () => {
      process.env.DB_AI_USERNAME = "app_ai";
      delete process.env.DB_USERNAME;

      const uniqueValues = (values: Array<string | null | undefined>): string[] =>
        [...new Set(values.filter((value): value is string => Boolean(value && value.trim())))].map((value) =>
          value.trim(),
        );

      const runtimeRoles = uniqueValues([
        process.env.DB_AI_USERNAME,
        process.env.DB_USERNAME,
      ]);

      expect(runtimeRoles).toEqual(["app_ai"]);
    });

    it("deduplicates roles", () => {
      process.env.DB_AI_USERNAME = "app_user";
      process.env.DB_USERNAME = "app_user";

      const uniqueValues = (values: Array<string | null | undefined>): string[] =>
        [...new Set(values.filter((value): value is string => Boolean(value && value.trim())))].map((value) =>
          value.trim(),
        );

      const runtimeRoles = uniqueValues([
        process.env.DB_AI_USERNAME,
        process.env.DB_USERNAME,
      ]);

      expect(runtimeRoles).toHaveLength(1);
      expect(runtimeRoles[0]).toBe("app_user");
    });

    it("trims whitespace from roles", () => {
      process.env.DB_AI_USERNAME = "  app_ai  ";
      process.env.DB_USERNAME = "app_user";

      const uniqueValues = (values: Array<string | null | undefined>): string[] =>
        [...new Set(values.filter((value): value is string => Boolean(value && value.trim())))].map((value) =>
          value.trim(),
        );

      const runtimeRoles = uniqueValues([
        process.env.DB_AI_USERNAME,
        process.env.DB_USERNAME,
      ]);

      expect(runtimeRoles).toEqual(["app_ai", "app_user"]);
    });
  });

  describe("grantTenantRoleMemberships", () => {
    it("fetches all escritorios from database", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce([
        { id: "escritorio-1" },
        { id: "escritorio-2" },
      ]);
      mockQuery.mockResolvedValueOnce([]); // pg_roles query

      await AppDataSource.query("SELECT id FROM public.escritorios ORDER BY id ASC");

      expect(mockQuery).toHaveBeenCalledWith(
        "SELECT id FROM public.escritorios ORDER BY id ASC",
      );
    });

    it("queries for existing runtime roles", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      process.env.DB_AI_USERNAME = "app_ai";

      mockQuery.mockResolvedValueOnce([]); // escritorios query
      mockQuery.mockResolvedValueOnce([{ rolname: "app_ai" }]); // pg_roles query

      const runtimeRoles = ["app_ai"];
      await AppDataSource.query(
        "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
        [runtimeRoles],
      );

      expect(mockQuery).toHaveBeenCalledWith(
        "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
        [runtimeRoles],
      );
    });

    it("grants tenant role to runtime role", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const escritorioId = "test-123";
      const roleName = buildEscritorioRoleName(escritorioId);
      const runtimeRole = "app_user";

      mockQuery.mockResolvedValueOnce(undefined);

      await AppDataSource.query(
        `GRANT ${`"${roleName.replace(/"/g, '""')}"` } TO ${`"${runtimeRole.replace(/"/g, '""')}"` }`,
      );

      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("GRANT"),
      );
      expect(mockQuery).toHaveBeenCalledWith(
        expect.stringContaining("user_escritorio_test_123"),
      );
    });

    it("skips granting if runtime role does not exist", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce([]); // escritorios
      mockQuery.mockResolvedValueOnce([]); // pg_roles empty

      process.env.DB_AI_USERNAME = "nonexistent_role";
      const runtimeRoles = ["nonexistent_role"];

      await AppDataSource.query(
        "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
        [runtimeRoles],
      );

      const grantedRoles = new Set(
        Array.isArray([]) ? [].map((row: any) => String(row.rolname)) : [],
      );

      expect(grantedRoles.size).toBe(0);
    });
  });

  describe("reconcileTenantProvisioning", () => {
    it("fetches all escritorios ordered by created_at", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValueOnce([
        { id: "escritorio-1" },
        { id: "escritorio-2" },
      ]);

      await AppDataSource.query(
        "SELECT id FROM public.escritorios ORDER BY created_at ASC",
      );

      expect(mockQuery).toHaveBeenCalledWith(
        "SELECT id FROM public.escritorios ORDER BY created_at ASC",
      );
    });

    it("provisions each escritorio in transaction", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const mockTransaction = vi.mocked(AppDataSource.transaction);

      const testCallback = vi.fn().mockResolvedValue(undefined);
      mockTransaction.mockImplementation(async (callback: any) => {
        return callback({});
      });

      mockQuery.mockResolvedValueOnce([{ id: "test-escritorio" }]);

      await AppDataSource.transaction(testCallback);

      expect(mockTransaction).toHaveBeenCalled();
      expect(testCallback).toHaveBeenCalled();
    });

    it("calls provisionEscritorioSchema for each escritorio", async () => {
      const mockProvision = vi.mocked(provisionEscritorioSchema);
      const mockTransaction = vi.mocked(AppDataSource.transaction);

      const escritorioId = "provision-test-123";
      const manager = {} as any;

      mockTransaction.mockImplementation(async (callback: any) => {
        return callback(manager);
      });

      await AppDataSource.transaction(async (mgr) => {
        await provisionEscritorioSchema(mgr, escritorioId);
      });

      expect(mockProvision).toHaveBeenCalledWith(manager, escritorioId);
    });

    it("continues processing if one escritorio fails", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const mockTransaction = vi.mocked(AppDataSource.transaction);

      mockQuery.mockResolvedValueOnce([
        { id: "escritorio-1" },
        { id: "escritorio-2" },
      ]);

      let transactionCount = 0;
      mockTransaction.mockImplementation(async (callback: any) => {
        transactionCount++;
        if (transactionCount === 1) {
          throw new Error("First transaction failed");
        }
        return callback({});
      });

      // Simulate processing with error handling
      const escritorios = [{ id: "escritorio-1" }, { id: "escritorio-2" }];
      let processedCount = 0;

      for (const escritorio of escritorios) {
        try {
          await AppDataSource.transaction(async () => {
            processedCount++;
          });
        } catch (error) {
          // Continue processing
        }
      }

      expect(processedCount).toBeGreaterThan(0);
    });
  });

  describe("main - create-tenant-schemas orchestration", () => {
    it("reads SQL file from scripts directory", async () => {
      const { readFile } = await import("node:fs/promises");
      const mockReadFile = vi.mocked(readFile);

      mockReadFile.mockResolvedValueOnce("-- SQL content");

      const sql = await readFile("/path/to/file", "utf8");

      expect(mockReadFile).toHaveBeenCalled();
      expect(typeof sql).toBe("string");
    });

    it("initializes AppDataSource if not already initialized", async () => {
      const mockInit = vi.mocked(AppDataSource.initialize);
      (AppDataSource as any).isInitialized = false;

      await AppDataSource.initialize();

      expect(mockInit).toHaveBeenCalled();
    });

    it("executes SQL from file", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const sqlContent = "CREATE TABLE test (id int)";

      mockQuery.mockResolvedValueOnce(undefined);

      await AppDataSource.query(sqlContent);

      expect(mockQuery).toHaveBeenCalledWith(sqlContent);
    });

    it("calls grantTenantRoleMemberships after SQL execution", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      mockQuery.mockResolvedValue([]);

      // Simulate the workflow
      await AppDataSource.query("-- SQL");
      await AppDataSource.query(
        "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
        [[]],
      );

      expect(mockQuery).toHaveBeenCalledTimes(2);
    });

    it("calls reconcileTenantProvisioning after granting roles", async () => {
      const mockQuery = vi.mocked(AppDataSource.query);
      const mockTransaction = vi.mocked(AppDataSource.transaction);

      mockQuery.mockResolvedValue([]);
      mockTransaction.mockResolvedValue(undefined);

      // Simulate the complete workflow
      await AppDataSource.query("-- SQL");
      await AppDataSource.transaction(async () => {});

      expect(mockQuery).toHaveBeenCalled();
      expect(mockTransaction).toHaveBeenCalled();
    });

    it("destroys AppDataSource on completion", async () => {
      const mockDestroy = vi.mocked(AppDataSource.destroy);
      (AppDataSource as any).isInitialized = true;

      await AppDataSource.destroy();

      expect(mockDestroy).toHaveBeenCalled();
    });

    it("destroys AppDataSource even on error", async () => {
      const mockDestroy = vi.mocked(AppDataSource.destroy);
      (AppDataSource as any).isInitialized = true;

      let errorThrown = false;
      try {
        throw new Error("Simulated error");
      } catch {
        errorThrown = true;
      } finally {
        await AppDataSource.destroy();
      }

      expect(errorThrown).toBe(true);
      expect(mockDestroy).toHaveBeenCalled();
    });
  });

  describe("quoteIdentifier utility", () => {
    it("wraps identifier in quotes", () => {
      const quoteIdentifier = (value: string) =>
        `"${value.replace(/"/g, '""')}"`;
      const result = quoteIdentifier("role_name");

      expect(result).toBe('"role_name"');
    });

    it("escapes internal double quotes", () => {
      const quoteIdentifier = (value: string) =>
        `"${value.replace(/"/g, '""')}"`;
      const result = quoteIdentifier('role"name');

      expect(result).toBe('"role""name"');
    });
  });
});
