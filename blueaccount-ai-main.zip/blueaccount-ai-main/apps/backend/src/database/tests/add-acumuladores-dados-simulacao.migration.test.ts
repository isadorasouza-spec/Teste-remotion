import { describe, expect, it, vi } from "vitest";
import { AddAcumuladoresDadosSimulacao1787600000000 } from "../modules/tenant/migrations/1787600000000-add-acumuladores-dados-simulacao.js";

describe("AddAcumuladoresDadosSimulacao1787600000000", () => {
  it("cria o catálogo vazio, sem copiar códigos entre escritórios", async () => {
    const query = vi.fn().mockResolvedValue(undefined);

    await new AddAcumuladoresDadosSimulacao1787600000000().up({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('CREATE TABLE "acumuladores_simulacao"');
    expect(sql).not.toMatch(/\bINSERT\b/i);
    expect(sql).not.toMatch(/\bUPDATE\s+"acumuladores_simulacao"\b/i);
  });
});
