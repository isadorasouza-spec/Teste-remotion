# Integration Tests — Setup & GitHub Actions

Guia para executar testes de integração localmente e configurar CI/CD.

---

## Quick Start

### Rodar testes localmente (one-shot)

```bash
./scripts/test-integration.sh all
```

Isso:
1. ✅ Limpa dados de testes anteriores
2. ✅ Inicia postgres via docker-compose
3. ✅ Roda testes
4. ✅ Limpa tudo ao final

### Rodar em modo desenvolvimento

```bash
# Terminal 1: Manter banco rodando
./scripts/test-integration.sh up

# Terminal 2: Rodar testes em watch mode
npm run test:integration:watch

# Quando terminar:
./scripts/test-integration.sh down
```

---

## Arquivos Adicionados

| Arquivo | Função |
|---------|--------|
| `docker-compose.test.yml` | Compose com postgres para testes |
| `.env.test` | Environment variables para testes |
| `vitest.integration.config.ts` | Config do Vitest para integration tests |
| `src/database/test-data-source.ts` | DataSource para testes contra DB real |
| `src/database/tests/escritorio-schema.integration.test.ts` | 7 testes do fluxo de provisioning |
| `src/database/tests/INTEGRATION.md` | Documentação detalhada |
| `scripts/test-integration.sh` | Script bash para orquestração |

---

## Scripts NPM Adicionados

```bash
npm run test:integration          # Roda uma vez
npm run test:integration:watch    # Watch mode
```

---

## GitHub Actions Workflow

### Criar `.github/workflows/integration-tests.yml`

```yaml
name: Integration Tests

on:
  push:
    branches: [main, develop, feature/**]
  pull_request:
    branches: [main, develop]

jobs:
  integration-tests:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: testuser
          POSTGRES_PASSWORD: testpass
          POSTGRES_DB: testdb
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
      - uses: actions/checkout@v4
      
      - uses: actions/setup-node@v4
        with:
          node-version: 22
          cache: npm

      - name: Install dependencies
        run: npm ci

      - name: Build
        run: npm run build

      - name: Run unit tests
        run: npm run test

      - name: Run integration tests
        env:
          DB_HOST: localhost
          DB_PORT: 5432
          DB_USERNAME: testuser
          DB_PASSWORD: testpass
          DB_DATABASE: testdb
        run: npm run test:integration

      - name: Upload coverage
        if: always()
        uses: codecov/codecov-action@v3
        with:
          files: ./coverage/coverage-final.json
```

### Alternative: Docker Compose Approach

Se preferir usar `docker-compose.test.yml` em GitHub Actions:

```yaml
steps:
  - uses: actions/checkout@v4
  
  - uses: actions/setup-node@v4
    with:
      node-version: 22
      cache: npm

  - name: Install dependencies
    run: npm ci

  - name: Build
    run: npm run build

  - name: Start test database
    run: docker-compose -f docker-compose.test.yml up -d

  - name: Wait for database
    run: |
      npx wait-on tcp:5432 --timeout 30000

  - name: Run unit tests
    run: npm run test

  - name: Run integration tests
    run: npm run test:integration

  - name: Cleanup
    if: always()
    run: docker-compose -f docker-compose.test.yml down -v
```

---

## Recomendação

**Usar GitHub Actions Services** (primeira opção):
- ✅ Mais rápido (sem docker-compose overhead)
- ✅ Melhor integração nativa com Actions
- ✅ Menos recursos

---

## Próximas Fases

### Phase 2: CLI Tests Unitários

Adicionar testes unitários para:
- `sync-tenant-schemas.ts`
- `create-tenant-schemas.ts`

Arquivo: `src/database/tests/sync-tenant-schemas.test.ts` + `create-tenant-schemas.test.ts`

Estimativa: 2-3 horas

### Phase 3: Cobertura Total

```bash
# Gerar coverage report
npm run test -- --coverage

# Verificar mínimo 80% em src/database/
```

---

## Troubleshooting

### Testes falham localmente mas passam no Actions

Verifique:
```bash
# Usar mesma versão do Node
node --version  # Deve ser 22.x

# Usar mesmas env vars
cat .env.test

# Testar com docker-compose explicitamente
docker-compose -f docker-compose.test.yml up -d
npm run test:integration
docker-compose -f docker-compose.test.yml down
```

### Port 5432 em uso

```bash
# Matar processo existente
lsof -i :5432 | grep LISTEN | awk '{print $2}' | xargs kill -9

# Ou usar port diferente em docker-compose.test.yml
```

### Postgres takes long to start

Aumentar `healthcheck.start_period` em `docker-compose.test.yml`:
```yaml
healthcheck:
  start_period: 10s  # aumentado de 5s
```
