import { describe, expect, it, vi } from "vitest";
import { RemoveExtractionEngineColumns1784900000000 } from "../modules/public/migrations/1784900000000-remove_extraction_engine_columns.js";

describe("RemoveExtractionEngineColumns1784900000000", () => {
  it("remove as duas escolhas técnicas no up", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new RemoveExtractionEngineColumns1784900000000().up({ query } as never);

    expect(query.mock.calls.map(([sql]) => sql)).toEqual([
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "contract_extraction_engine"`,
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_extraction_engine"`,
    ]);
  });

  it("restaura ambas em AgentCore no down", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new RemoveExtractionEngineColumns1784900000000().down({ query } as never);

    expect(query.mock.calls.map(([sql]) => sql)).toEqual([
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "contract_extraction_engine" text NOT NULL DEFAULT 'agent'`,
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_extraction_engine" text NOT NULL DEFAULT 'agent'`,
    ]);
  });
});
