import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  buildTenantPrivilegeTarget,
  grantTenantRoleToRuntimeRoles,
  reconcileTenantPrivileges,
  resolveTenantObjectOwnerRole,
  resolveRuntimeRoles,
  revokePublicTablePrivilegesFromTenantRole,
} from "../tenant-privileges.js";

describe("tenant privileges", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    delete process.env.DOCUMENTOS_FISCAIS_DB_USERNAME;
    delete process.env.DB_AI_USERNAME;
    delete process.env.DB_USERNAME;
  });

  it("builds schema and role names from escritorio id", () => {
    expect(buildTenantPrivilegeTarget("550e8400-e29b-41d4-a716-446655440000")).toEqual({
      schemaName: "escritorio_550e8400_e29b_41d4_a716_446655440000",
      roleName: "user_escritorio_550e8400_e29b_41d4_a716_446655440000",
    });
  });

  it("uses DB_USERNAME as the default privilege owner because tenant migrations run with it", () => {
    process.env.DB_AI_USERNAME = "app_ai";
    process.env.DB_USERNAME = "app_user";

    expect(resolveTenantObjectOwnerRole()).toBe("app_user");
  });

  it("inclui a credencial fiscal no provisionamento e sincronização de escritórios", () => {
    process.env.DOCUMENTOS_FISCAIS_DB_USERNAME = "fiscal_piloto";
    expect(resolveRuntimeRoles()).toEqual(["fiscal_piloto"]);
  });

  it("deduplicates runtime roles", () => {
    process.env.DB_AI_USERNAME = " app_user ";
    process.env.DB_USERNAME = "app_user";

    expect(resolveRuntimeRoles()).toEqual(["app_user"]);
  });

  it("grants current and future tenant table and sequence privileges", async () => {
    const query = vi.fn().mockResolvedValue([]);

    await reconcileTenantPrivileges(
      { query },
      { schemaName: "escritorio_office_1", roleName: "user_escritorio_office_1" },
      "app_owner",
    );

    expect(query).toHaveBeenCalledWith(
      "SELECT 1 FROM pg_roles WHERE rolname = $1 LIMIT 1",
      ["user_escritorio_office_1"],
    );
    expect(query).toHaveBeenCalledWith(
      'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA "escritorio_office_1" TO "user_escritorio_office_1"',
    );
    expect(query).toHaveBeenCalledWith(
      'GRANT USAGE ON ALL SEQUENCES IN SCHEMA "escritorio_office_1" TO "user_escritorio_office_1"',
    );
    expect(query).toHaveBeenCalledWith(
      'ALTER DEFAULT PRIVILEGES FOR ROLE "app_owner" IN SCHEMA "escritorio_office_1" GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO "user_escritorio_office_1"',
    );
    expect(query).toHaveBeenCalledWith(
      'ALTER DEFAULT PRIVILEGES FOR ROLE "app_owner" IN SCHEMA "escritorio_office_1" GRANT USAGE ON SEQUENCES TO "user_escritorio_office_1"',
    );
  });

  it("grants tenant role membership only to existing runtime roles", async () => {
    const query = vi.fn().mockResolvedValueOnce([{ rolname: "app_user" }]);

    await grantTenantRoleToRuntimeRoles(
      { query },
      "user_escritorio_office_1",
      ["app_user", "missing_role"],
    );

    expect(query).toHaveBeenCalledWith(
      "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
      [["app_user", "missing_role"]],
    );
    expect(query).toHaveBeenCalledWith('GRANT "user_escritorio_office_1" TO "app_user"');
    expect(query).not.toHaveBeenCalledWith('GRANT "user_escritorio_office_1" TO "missing_role"');
  });

  it("revokes access to public tables from tenant role", async () => {
    const query = vi.fn().mockResolvedValue([]);

    await revokePublicTablePrivilegesFromTenantRole({ query }, "user_escritorio_office_1");

    expect(query).toHaveBeenCalledWith(
      'REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM "user_escritorio_office_1"',
    );
  });
});
