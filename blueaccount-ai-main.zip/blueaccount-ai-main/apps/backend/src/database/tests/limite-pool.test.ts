import { afterEach, describe, expect, it, vi } from "vitest";
import { resolverLimitePool } from "../limite-pool.js";
import { Settings } from "../../settings.js";

afterEach(() => vi.unstubAllEnvs());
describe("limites e configuração de bootstrap", () => {
  it.each(["", "0", "-1", "1.5", "Infinity", "abc", "10001"])("preserva padrão para %s", (valor) => {
    expect(resolverLimitePool(valor)).toBe(10);
  });
  it("aceita inteiros positivos", () => expect(resolverLimitePool(" 5 ")).toBe(5));
  it("sincronização é habilitada por padrão sem env", () => {
    vi.stubEnv("DB_SYNC_TENANTS_ON_BOOT", undefined);
    expect(new Settings("/arquivo-inexistente-para-teste").DB_SYNC_TENANTS_ON_BOOT).toBe(true);
  });
  it("aplica o limite aos dois pools reais e mantém migrations limitadas", async () => {
    vi.stubEnv("DB_POOL_MAX", "5");
    const { AppDataSource, RlsDataSource } = await import("../data-source.js");
    const { default: publico } = await import("../migration-data-source-runtime.js");
    const { createTenantDataSource } = await import("../tenant-datasource-factory.js");
    expect(AppDataSource.options.poolSize).toBe(5);
    expect(RlsDataSource.options.poolSize).toBe(5);
    expect(publico.options.poolSize).toBe(2);
    const tenant = createTenantDataSource({ schemaName: "teste", entities: [], migrationsDir: "vazio" });
    expect(tenant.options.poolSize).toBe(2);
    expect(tenant.options.extra.options).toContain("lock_timeout=");
    expect(AppDataSource.isInitialized).toBe(false);
  });
});
