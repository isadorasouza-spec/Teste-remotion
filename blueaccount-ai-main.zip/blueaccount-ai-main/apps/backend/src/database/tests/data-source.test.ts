import { beforeEach, describe, expect, it, vi } from "vitest";

const dataSourceMocks = vi.hoisted(() => {
  const managerQuery = vi.fn();
  const transactionManager = {
    query: managerQuery,
    getRepository: vi.fn(),
  };

  class MockDataSource {
    isInitialized = false;
    getRepository = vi.fn();
    initialize = vi.fn(async () => {
      this.isInitialized = true;
      return this;
    });
    transaction = vi.fn(async <T>(callback: (manager: typeof transactionManager) => Promise<T>) => callback(transactionManager));
  }

  const decorator = () => () => undefined;

  return {
    managerQuery,
    transactionManager,
    MockDataSource,
    decorator,
  };
});

vi.mock("typeorm", () => ({
  DataSource: dataSourceMocks.MockDataSource,
  Entity: dataSourceMocks.decorator,
  ForeignKey: dataSourceMocks.decorator,
  PrimaryGeneratedColumn: dataSourceMocks.decorator,
  PrimaryColumn: dataSourceMocks.decorator,
  Column: dataSourceMocks.decorator,
  CreateDateColumn: dataSourceMocks.decorator,
  UpdateDateColumn: dataSourceMocks.decorator,
  ManyToOne: dataSourceMocks.decorator,
  OneToMany: dataSourceMocks.decorator,
  ManyToMany: dataSourceMocks.decorator,
  JoinColumn: dataSourceMocks.decorator,
  JoinTable: dataSourceMocks.decorator,
  Index: dataSourceMocks.decorator,
  Unique: dataSourceMocks.decorator,
  Check: dataSourceMocks.decorator,
}));

const { buildEscritorioSchemaName } = await import("../tenant-naming.js");
const { AppDataSource, RlsDataSource, runQueryWithRls } = await import("../data-source.js");
const { Escritorio } = await import("../modules/public/entities/escritorio.entity.js");
const { Cliente } = await import("../modules/tenant/entities/cliente.entity.js");

describe("database rls helpers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    dataSourceMocks.managerQuery.mockImplementation(async (query: string) => {
      if (query === "SELECT current_schema() = $1 AS schema_matches") {
        return [{ schema_matches: true }];
      }
      return [];
    });
    (RlsDataSource as unknown as { isInitialized: boolean }).isInitialized = false;
  });

  it("derives the schema name from the escritorio id", () => {
    expect(buildEscritorioSchemaName("office-1")).toBe("escritorio_office_1");
  });

  it("applies search_path and escritorio_id before executing rls queries", async () => {
    const result = await runQueryWithRls({ escritorio_id: "office-1" }, async (manager) => {
      manager.getRepository(Cliente);
      expect(dataSourceMocks.transactionManager.getRepository).toHaveBeenCalledWith(Cliente);
      return "ok";
    });

    expect(result).toBe("ok");
    expect(RlsDataSource.initialize).toHaveBeenCalledTimes(1);
    expect(RlsDataSource.transaction).toHaveBeenCalledTimes(1);
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      1,
      'SET LOCAL ROLE "user_escritorio_office_1"',
    );
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      2,
      "SELECT set_config('search_path', $1, true)",
      ["escritorio_office_1, public"],
    );
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      3,
      "SELECT current_schema() = $1 AS schema_matches",
      ["escritorio_office_1"],
    );
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      4,
      "SELECT set_config('app.escritorio_id', $1, true)",
      ["office-1"],
    );
  });

  it("uses an explicit schema name when provided", async () => {
    await runQueryWithRls({ escritorio_id: "office-1", schema_name: "escritorio_custom" }, async () => null);

    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      1,
      'SET LOCAL ROLE "user_escritorio_office_1"',
    );
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      2,
      "SELECT set_config('search_path', $1, true)",
      ["escritorio_custom, public"],
    );
    expect(dataSourceMocks.managerQuery).toHaveBeenNthCalledWith(
      3,
      "SELECT current_schema() = $1 AS schema_matches",
      ["escritorio_custom"],
    );
  });

  it("rejects getRepository for public-schema entities inside runQueryWithRls", async () => {
    await expect(
      runQueryWithRls({ escritorio_id: "office-1" }, async (manager) => {
        manager.getRepository(Escritorio);
      }),
    ).rejects.toThrow(/Escritorio.*schema public/);
  });

  it("rejects AppDataSource.getRepository for tenant entities", () => {
    expect(() => AppDataSource.getRepository(Cliente)).toThrow(/Cliente.*ignora isolamento RLS/);
  });

  it("allows AppDataSource.getRepository for public entities", () => {
    expect(() => AppDataSource.getRepository(Escritorio)).not.toThrow();
  });
});
