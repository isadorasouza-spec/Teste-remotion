import { afterEach, expect, it, vi } from "vitest";
import type { QueryRunner } from "typeorm";
import { ConcederRolesWorkerFiscal1791800000000 } from "../modules/public/migrations/1791800000000-conceder-roles-worker-fiscal.js";
afterEach(() => vi.unstubAllEnvs());
it("concede somente roles descobertas e escapa identificadores", async () => {
  vi.stubEnv("DOCUMENTOS_FISCAIS_DB_USERNAME", 'fiscal"local');
  const query = vi.fn().mockResolvedValueOnce([{rolsuper:false,rolbypassrls:false,rolinherit:false}])
    .mockResolvedValueOnce([{rolname:"user_escritorio_teste"}]).mockResolvedValue([]);
  await new ConcederRolesWorkerFiscal1791800000000().up({query} as unknown as QueryRunner);
  expect(query).toHaveBeenLastCalledWith('GRANT "user_escritorio_teste" TO "fiscal""local"');
});
it.each([[],[{rolsuper:true}],[{rolbypassrls:true}],[{rolinherit:true}]])("recusa role ausente ou insegura %j", async (...rows) => {
  vi.stubEnv("DOCUMENTOS_FISCAIS_DB_USERNAME", "fiscal");
  const query=vi.fn().mockResolvedValue(rows);
  await expect(new ConcederRolesWorkerFiscal1791800000000().up({query} as unknown as QueryRunner)).rejects.toThrow();
  expect(query).toHaveBeenCalledTimes(1);
});
