import { expect, it, vi } from "vitest";
import { AmpliarChaveNfseNacional1791300000000 } from "../modules/tenant/migrations/1791300000000-ampliar-chave-nfse-nacional.js";

it("amplia a chave preservando coluna, dados e índice único", async () => {
  const query = vi.fn().mockResolvedValue([]);
  await new AmpliarChaveNfseNacional1791300000000().up({ query } as never);
  const sql = query.mock.calls.map(([s]) => s).join(" ");
  expect(sql).toContain('ALTER COLUMN "chave" TYPE varchar(50)');
  expect(sql).not.toMatch(/DROP COLUMN|DROP INDEX|DELETE|TRUNCATE/);
});

it.each([true, undefined])("impede rollback destrutivo ou sem confirmação: %s", async (bloqueado) => {
  const query = vi.fn().mockResolvedValueOnce([]).mockResolvedValueOnce([{ bloqueado }]);
  await expect(new AmpliarChaveNfseNacional1791300000000().down({ query } as never)).rejects.toThrow("sem truncar");
  expect(query.mock.calls.flat().join(" ")).not.toContain("ALTER COLUMN");
});

it("permite rollback sem notas nacionais, sob lock", async () => {
  const query = vi.fn().mockResolvedValueOnce([]).mockResolvedValueOnce([{ bloqueado: false }]);
  await new AmpliarChaveNfseNacional1791300000000().down({ query } as never);
  expect(query.mock.calls[0][0]).toContain("ACCESS EXCLUSIVE");
  expect(query.mock.calls[2][0]).toContain("varchar(44)");
  expect(query.mock.calls[3][0]).toContain("SET NOT NULL");
});
