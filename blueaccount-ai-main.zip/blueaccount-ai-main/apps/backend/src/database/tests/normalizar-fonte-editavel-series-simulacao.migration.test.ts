import { describe, expect, it, vi } from "vitest";
import { NormalizarFonteEditavelSeriesSimulacao1788500000000 } from "../modules/tenant/migrations/1788500000000-normalizar-fonte-editavel-series-simulacao.js";

describe("NormalizarFonteEditavelSeriesSimulacao1788500000000", () => {
  it("torna a cópia do ano-base editável e redireciona os outros anos para ela", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new NormalizarFonteEditavelSeriesSimulacao1788500000000().up({ query } as never);

    const statements = query.mock.calls.map(([statement]) => statement as string);
    const sql = statements.join(" ");

    expect(statements).toHaveLength(5);
    expect(sql).toContain('fonte_externa."ano" = copia_base."ano"');
    expect(sql).toContain('item_fonte."simulacao_id" = fonte_externa."id"');
    expect(statements[1]).toContain('SET "fonte_seed" = entrada_base."id"');
    expect(statements[2]).toContain('SET "simulacao_origem_id" = normalizacao."copia_base_id"');
    expect(statements[3]).toContain('SET "fonte_seed" = NULL');
    expect(statements[4]).toContain('SET "simulacao_origem_id" = NULL');
  });
});
