import { describe, expect, it, vi } from "vitest";
import { AddImportacaoDominioDocumentos1790000000000 } from "../modules/tenant/migrations/1790000000000-add-importacao-dominio-documentos.js";

describe("AddImportacaoDominioDocumentos1790000000000", () => {
  it("adiciona metadados estáveis e unicidade parcial por lote", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddImportacaoDominioDocumentos1790000000000().up({ query } as never);
    const sql = query.mock.calls.map(([texto]) => texto).join("\n");
    expect(sql).toContain('ADD COLUMN "chave_importacao" text');
    expect(sql).toContain('ADD COLUMN "dados_simulacao_output_key" text');
    expect(sql).toContain('"simulacao_id", "chave_importacao"');
    expect(sql).toContain('WHERE "chave_importacao" IS NOT NULL');
  });
});
