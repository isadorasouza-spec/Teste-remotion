import { describe, expect, it, vi } from "vitest";
import { AddPoliticasAcumuladoresCliente1790200000000 } from "../modules/tenant/migrations/1790200000000-add-politicas-acumuladores-cliente.js";

describe("AddPoliticasAcumuladoresCliente1790200000000", () => {
  it("cria estruturas aditivas, UUIDv7 compatível e modos numéricos explícitos sem backfill", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddPoliticasAcumuladoresCliente1790200000000().up({ query } as never);
    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('CREATE TABLE "acumuladores_simulacao_cliente"');
    expect(sql).toContain('CREATE TABLE "simulacao_entradas_excluidas"');
    expect(sql.match(/uuid_generate_v7\(\)/g)).toHaveLength(2);
    expect(sql).toContain("'herdar','limpar','valor'");
    expect(sql).toContain('UNIQUE ("simulacao_id","documento_origem_referencia","ordem_origem")');
    expect(sql).toContain('REFERENCES "documentos"("id") ON DELETE SET NULL');
    expect(sql).not.toMatch(/\bUPDATE\b/i);
  });
});
