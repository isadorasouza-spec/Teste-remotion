import type { EntityManager } from "typeorm";
import { AppDataSource } from "./data-source.js";
import { buildEscritorioSchemaName } from "./tenant-naming.js";

/**
 * Transação que enxerga o schema do tenant E as tabelas públicas ao mesmo tempo.
 *
 * Usa `AppDataSource` (role dona do schema), e não `runQueryWithRls`, porque os finalizadores de
 * fila precisam mover a linha da fila em `public` e a linha do tenant **na mesma transação** — se as
 * duas commitassem separado, um crash no meio deixaria a fila dizendo `concluido` com a simulação
 * ainda em `processando`. A role do tenant não alcança `public` (ver `tenant-privileges.ts`, que
 * revoga), então a única forma de ter as duas na mesma transação é a role dona.
 *
 * O isolamento aqui é por `search_path` mais o `escritorio_id` no WHERE de toda query, não por RLS.
 * Quem escrever query sob esta transação mantém o filtro por `escritorio_id` explícito: sem ele, o
 * schema certo com id errado atravessa tenant sem nenhuma barreira do banco.
 *
 * Mora em `src/database` e não no domínio porque é helper de fronteira RLS, irmão de
 * `runQueryWithRls` — e porque as três filas do produto (cálculo de simulação, projeção de documento
 * fiscal, consulta de chave fiscal) precisam do mesmo mecanismo.
 *
 * rls-guard-ok: fila pública + linha do tenant precisam de atomicidade; isolamento por search_path
 * e por escritorio_id explícito em cada query.
 */
export async function transacaoFilaTenant<T>(
  escritorioId: string,
  callback: (manager: EntityManager) => Promise<T>,
): Promise<T> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  const schema = buildEscritorioSchemaName(escritorioId);
  return AppDataSource.transaction(async (manager) => {
    await manager.query("SELECT set_config('search_path', $1, true)", [`${schema}, public`]);
    return callback(manager);
  });
}
