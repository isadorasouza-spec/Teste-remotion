import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSeedRuns1782300000000 implements MigrationInterface {
  name = "CreateSeedRuns1782300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "seed_runs" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "escritorio_id" uuid NOT NULL,
        "name" text NOT NULL,
        "description" text,
        "status" text NOT NULL DEFAULT 'active',
        "capture_mcp_calls" boolean NOT NULL DEFAULT true,
        "disable_agents_during_seed" boolean NOT NULL DEFAULT true,
        "started_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "completed_at" TIMESTAMP WITH TIME ZONE,
        "created_by_admin_id" text,
        "metadata" jsonb,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_seed_runs" PRIMARY KEY ("id"),
        CONSTRAINT "FK_seed_runs_escritorios" FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE RESTRICT ON UPDATE NO ACTION
      )
    `);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_runs_escritorio_id" ON "seed_runs" ("escritorio_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_runs_status" ON "seed_runs" ("status")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_runs_started_at" ON "seed_runs" ("started_at")`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "IDX_seed_runs_one_active_per_escritorio"
      ON "seed_runs" ("escritorio_id")
      WHERE "status" = 'active'
    `);

    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "seed_run_api_calls" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "seed_run_id" uuid NOT NULL,
        "api_log_id" uuid,
        "sequence" integer NOT NULL,
        "method" text NOT NULL,
        "path" text NOT NULL,
        "query" jsonb,
        "request_body" jsonb,
        "response_status" integer,
        "response_body" jsonb,
        "completed_at" TIMESTAMP WITH TIME ZONE,
        "source" text NOT NULL DEFAULT 'mcp',
        "redaction_applied" boolean NOT NULL DEFAULT true,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_seed_run_api_calls" PRIMARY KEY ("id"),
        CONSTRAINT "FK_seed_run_api_calls_seed_run" FOREIGN KEY ("seed_run_id") REFERENCES "seed_runs"("id") ON DELETE CASCADE ON UPDATE NO ACTION,
        CONSTRAINT "FK_seed_run_api_calls_contexto" FOREIGN KEY ("api_log_id") REFERENCES "contexto"("id") ON DELETE SET NULL ON UPDATE NO ACTION
      )
    `);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_run_api_calls_seed_run_id" ON "seed_run_api_calls" ("seed_run_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_run_api_calls_api_log_id" ON "seed_run_api_calls" ("api_log_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_seed_run_api_calls_created_at" ON "seed_run_api_calls" ("created_at")`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "IDX_seed_run_api_calls_seed_sequence"
      ON "seed_run_api_calls" ("seed_run_id", "sequence")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_run_api_calls_seed_sequence"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_run_api_calls_created_at"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_run_api_calls_api_log_id"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_run_api_calls_seed_run_id"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "seed_run_api_calls"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_runs_one_active_per_escritorio"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_runs_started_at"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_runs_status"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_seed_runs_escritorio_id"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "seed_runs"`);
  }
}
