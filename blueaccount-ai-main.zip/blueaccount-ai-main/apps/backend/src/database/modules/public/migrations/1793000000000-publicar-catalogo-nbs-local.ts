import type { MigrationInterface, QueryRunner } from "typeorm";
import { CATALOGO_NBS } from "./dados/nbs-catalogo-20260917.js";
import { METADADOS_CATALOGO_NBS } from "./dados/nbs-metadados-20260917.js";

/** Publicação integral; arquivo anterior e carga participam da transação da migration. */
export class PublicarCatalogoNbsLocal1793000000000 implements MigrationInterface {
  name = "PublicarCatalogoNbsLocal1793000000000";
  async up(q: QueryRunner): Promise<void> {
    await q.query(`LOCK TABLE public.nbs_referencia IN ACCESS EXCLUSIVE MODE`);
    await q.query(`CREATE TABLE public.nbs_arquivo_20260917 AS SELECT * FROM public.nbs_referencia`);
    await q.query(`ALTER TABLE public.nbs_referencia ADD versao_catalogo varchar(40), ADD capitulo text, ADD categoria text, ADD fonte_linha integer`);
    await q.query(`DROP INDEX public."IDX_nbs_referencia_fatores_configurados_codigo"`);
    await q.query(`DELETE FROM public.nbs_referencia WHERE NOT (codigo = ANY($1::varchar[]))`, [CATALOGO_NBS.map(r => r.codigo)]);
    for (let inicio = 0; inicio < CATALOGO_NBS.length; inicio += 500) {
      await q.query(`INSERT INTO public.nbs_referencia (codigo, descricao, fator_ibs, fator_cbs,
        fatores_configurados, aplicacao_automatica, gera_credito_adquirente, regime_especifico,
        fundamento_legal_fatores, condicoes_aplicacao_fatores, origem_configuracao_fatores,
        descricoes_hierarquia, versao_catalogo, capitulo, categoria, fonte_linha)
        SELECT codigo, descricao, fator, fator, true, true, true, NULL, fundamento, observacao, $2,
          ARRAY[]::text[], $2, capitulo, categoria, linha
        FROM jsonb_to_recordset($1::jsonb) AS r(codigo text, descricao text, fator numeric,
          fundamento text, observacao text, capitulo text, categoria text, linha integer)
        ON CONFLICT (codigo) DO UPDATE SET descricao = EXCLUDED.descricao,
          fator_ibs = EXCLUDED.fator_ibs, fator_cbs = EXCLUDED.fator_cbs,
          fatores_configurados = true, aplicacao_automatica = true, gera_credito_adquirente = true,
          regime_especifico = NULL, fundamento_legal_fatores = EXCLUDED.fundamento_legal_fatores,
          condicoes_aplicacao_fatores = EXCLUDED.condicoes_aplicacao_fatores,
          origem_configuracao_fatores = EXCLUDED.origem_configuracao_fatores,
          descricoes_hierarquia = ARRAY[]::text[], versao_catalogo = EXCLUDED.versao_catalogo,
          capitulo = EXCLUDED.capitulo, categoria = EXCLUDED.categoria,
          fonte_linha = EXCLUDED.fonte_linha, atualizado_em = now()`,
      [JSON.stringify(CATALOGO_NBS.slice(inicio, inicio + 500)), METADADOS_CATALOGO_NBS.versao]);
    }
    await q.query(`ALTER TABLE public.nbs_referencia ADD CONSTRAINT "CHK_nbs_catalogo_local"
      CHECK (codigo ~ '^[0-9]{9}$' AND versao_catalogo IS NOT NULL AND capitulo IS NOT NULL
        AND categoria IS NOT NULL AND fonte_linha IS NOT NULL AND fonte_linha >= 2
        AND fatores_configurados AND aplicacao_automatica AND gera_credito_adquirente
        AND regime_especifico IS NULL AND fator_ibs = fator_cbs)`);
    const [contagem] = await q.query(`SELECT count(*)::integer AS total FROM public.nbs_referencia`);
    if (contagem.total !== METADADOS_CATALOGO_NBS.total) throw new Error("Carga NBS incompleta.");
    await q.query(`CREATE TABLE public.nbs_catalogo_versoes (
      versao varchar(40) PRIMARY KEY, metadados jsonb NOT NULL, publicado_em timestamptz NOT NULL DEFAULT now())`);
    await q.query(`INSERT INTO public.nbs_catalogo_versoes (versao, metadados) VALUES ($1, $2::jsonb)`,
      [METADADOS_CATALOGO_NBS.versao, JSON.stringify(METADADOS_CATALOGO_NBS)]);
  }
  async down(): Promise<void> {
    throw new Error("Revisar public.nbs_arquivo_20260917 e publicar correção versionada; não restaurar regras antigas automaticamente.");
  }
}
