import type { MigrationInterface, QueryRunner } from "typeorm";
import { METADADOS_CATALOGO_NCM } from "./dados/ncm-metadados-20260916.js";
import { carregarCatalogoNcm, registrarVersaoCatalogoNcm } from "./dados/carga-catalogo-ncm.js";

/**
 * A publicação anterior semeou o catálogo direto da planilha, que se declara material de apoio lido
 * em espelhos comunitários. A reconciliação com a revisão do texto da LC 214/2025 mudou a situação de
 * 1.606 códigos e o fator de parte deles, então o manifesto virou uma versão nova — e o runtime
 * filtra por `versao_catalogo`. Sem esta republicação, um banco que já publicou a versão de fonte
 * única resolve **todo** NCM como `fora_catalogo` com fator 1.
 *
 * É no-op em banco novo: ali a migration anterior já semeia esta versão, porque ambas leem o mesmo
 * manifesto. Não altera simulação, resultado, cache nem fila; só a base global de referência.
 */
export class RepublicarCatalogoNcmReconciliado1792900001000 implements MigrationInterface {
  name = "RepublicarCatalogoNcmReconciliado1792900001000";

  async up(q: QueryRunner): Promise<void> {
    const [jaPublicada] = await q.query(`SELECT 1 AS ok FROM public.ncm_catalogo_versoes WHERE versao = $1`, [METADADOS_CATALOGO_NCM.versao]);
    if (jaPublicada) return;
    await q.query(`LOCK TABLE public.ncms_referencia IN ACCESS EXCLUSIVE MODE`);
    // Fator fiscal não é trocado sem cópia do estado anterior, mesmo sendo derivado do mesmo arquivo.
    await q.query(`CREATE TABLE IF NOT EXISTS public.ncms_arquivo_reconciliacao_20260917 AS SELECT * FROM public.ncms_referencia`);
    await carregarCatalogoNcm(q);
    await registrarVersaoCatalogoNcm(q);
  }

  async down(): Promise<void> {
    throw new Error("Consultar public.ncms_arquivo_reconciliacao_20260917 e publicar correção versionada sem alterar simulações históricas.");
  }
}
