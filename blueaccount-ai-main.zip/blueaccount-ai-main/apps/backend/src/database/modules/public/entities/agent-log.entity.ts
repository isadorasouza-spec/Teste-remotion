import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";

@Entity("agent_logs")
export class AgentLog {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Escritorio, { nullable: false })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio>;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Index()
  @Column({ type: "text" })
  agent_name!: string;

  @Column({ type: "text" })
  level!: string;

  @Column({ type: "text" })
  event!: string;

  @Column({ type: "jsonb", nullable: true })
  context!: Record<string, unknown> | null;

  @Column({ type: "text", nullable: true })
  prompt!: string | null;

  // ── Execution tracking (nullable — present when known) ───────────────

  @Index()
  @Column({ type: "text", nullable: true })
  status!: string | null;

  // Runtime/resource ARN being invoked (AgentCore runtime ARN, Step Functions
  // execution ARN, etc.) — not necessarily a Lambda.
  @Column({ type: "text", nullable: true })
  execution_arn!: string | null;

  // Per-invocation handle (AgentCore runtimeSessionId / pipeline trace id).
  @Index()
  @Column({ type: "text", nullable: true })
  trace_id!: string | null;

  // ── LLM usage (nullable — only present for model calls) ──────────────

  @Column({ type: "text", nullable: true })
  model_id!: string | null;

  @Column({ type: "int", nullable: true })
  input_tokens!: number | null;

  @Column({ type: "int", nullable: true })
  output_tokens!: number | null;

  @Column({ type: "int", nullable: true })
  total_tokens!: number | null;

  @Column({ type: "int", nullable: true })
  latency_ms!: number | null;

  @Index()
  @CreateDateColumn()
  created_at!: Date;
}
