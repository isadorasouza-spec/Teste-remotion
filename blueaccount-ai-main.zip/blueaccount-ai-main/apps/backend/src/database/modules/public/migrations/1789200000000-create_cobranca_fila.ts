import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Fila de geração de cobrança em Postgres. A tabela é a fila **e** o registro de
 * lease: `status = 'processando'` significa "ocupando uma das vagas do limite
 * global". O limite vem de env (`COBRANCA_CONCORRENCIA_LIMITE`) e é comparado
 * com a contagem de linhas, então mudar de 6 para 8 não exige migration.
 *
 * O job pg_cron é só um piso de garantia para quando **nenhuma** State Machine
 * está rodando (fila vazia com uma linha travada em `processando` que ninguém
 * vai reapear). O reap oportunista dentro do pop é quem conserta o VAC, porque
 * só ele tem contexto de tenant.
 */
export class CreateCobrancaFila1789200000000 implements MigrationInterface {
  name = "CreateCobrancaFila1789200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "cobranca_fila" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "escritorio_id" uuid NOT NULL,
        "valores_a_cobrar_id" uuid NOT NULL,
        "competencia" varchar(7) NOT NULL,
        "cliente_id" uuid NOT NULL,
        "grupo_id" uuid,
        "payload" jsonb NOT NULL,
        "status" varchar(20) NOT NULL,
        "tentativas" smallint NOT NULL DEFAULT 0,
        "erro" text,
        "execution_arn" text,
        "lock_adquirido_em" TIMESTAMP WITH TIME ZONE,
        "criado_em" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "atualizado_em" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        CONSTRAINT "PK_cobranca_fila" PRIMARY KEY ("id"),
        CONSTRAINT "CHK_cobranca_fila_status" CHECK (
          "status" IN ('pendente', 'processando', 'concluido', 'erro')
        ),
        CONSTRAINT "CHK_cobranca_fila_lock" CHECK (
          ("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL)
        )
      )
    `);

    // Substitui o MessageDeduplicationId da antiga fila FIFO: um VAC só pode ter
    // um item em voo por vez.
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_cobranca_fila_vac_em_voo"
      ON "cobranca_fila" ("valores_a_cobrar_id")
      WHERE "status" IN ('pendente', 'processando')
    `);
    await queryRunner.query(`
      CREATE INDEX "IDX_cobranca_fila_pendentes"
      ON "cobranca_fila" ("status", "criado_em")
    `);
    await queryRunner.query(`
      CREATE INDEX "IDX_cobranca_fila_processando"
      ON "cobranca_fila" ("status", "lock_adquirido_em")
      WHERE "status" = 'processando'
    `);

    await queryRunner.query(`
      CREATE OR REPLACE FUNCTION public.reenfileirar_cobrancas_travadas(ttl_segundos integer, max_tentativas integer)
      RETURNS integer
      LANGUAGE plpgsql
      SECURITY DEFINER
      SET search_path = pg_catalog, public
      AS $$
      DECLARE
        afetadas integer;
      BEGIN
        WITH expiradas AS (
          SELECT "id", "tentativas"
          FROM public.cobranca_fila
          WHERE "status" = 'processando'
            AND "lock_adquirido_em" < now() - make_interval(secs => ttl_segundos)
          FOR UPDATE SKIP LOCKED
        )
        UPDATE public.cobranca_fila AS fila
        SET "tentativas" = expiradas."tentativas" + 1,
            "status" = CASE
              WHEN expiradas."tentativas" + 1 >= max_tentativas THEN 'erro'
              ELSE 'pendente'
            END,
            "erro" = CASE
              WHEN expiradas."tentativas" + 1 >= max_tentativas
                THEN 'A execução que detinha a vaga expirou sem concluir e as tentativas se esgotaram.'
              ELSE fila."erro"
            END,
            "execution_arn" = NULL,
            "lock_adquirido_em" = NULL,
            "atualizado_em" = now()
        FROM expiradas
        WHERE fila."id" = expiradas."id";
        GET DIAGNOSTICS afetadas = ROW_COUNT;
        RETURN afetadas;
      END;
      $$;
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF current_setting('shared_preload_libraries', true) LIKE '%pg_cron%' THEN
          CREATE EXTENSION IF NOT EXISTS pg_cron;
          PERFORM cron.schedule(
            'reenfileirar-cobrancas-travadas',
            '*/1 * * * *',
            $q$SELECT public.reenfileirar_cobrancas_travadas(420, 3)$q$
          );
        ELSE
          RAISE NOTICE 'pg_cron não carregado; reap de piso da fila de cobrança não agendado.';
        END IF;
      EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'pg_cron indisponível para o reap da fila de cobrança (%).', SQLERRM;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
          PERFORM cron.unschedule(jobid)
          FROM cron.job
          WHERE jobname = 'reenfileirar-cobrancas-travadas';
        END IF;
      END $$;
    `);
    await queryRunner.query(`DROP FUNCTION IF EXISTS public.reenfileirar_cobrancas_travadas(integer, integer);`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_cobranca_fila_processando"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_cobranca_fila_pendentes"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."UQ_cobranca_fila_vac_em_voo"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "cobranca_fila"`);
  }
}
