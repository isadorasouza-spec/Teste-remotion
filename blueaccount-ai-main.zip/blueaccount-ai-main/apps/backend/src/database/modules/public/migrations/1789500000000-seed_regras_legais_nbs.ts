import type { MigrationInterface, QueryRunner } from "typeorm";
import { REGRAS_LEGAIS_NBS } from "./dados/regras-legais-nbs.js";

/**
 * Aplica o manifesto curado `REGRAS_LEGAIS_NBS` (`dados/regras-legais-nbs.ts`, 39 regras) sobre o
 * catálogo já semeado por `seed_nbs_referencia_catalogo`. Diferente daquela migration, esta faz
 * `UPDATE`: os prefixos já existem como linhas do catálogo (validado no próprio manifesto — nenhum
 * prefixo duplicado, todos existentes na NBS 2.0), então não há `INSERT` aqui.
 *
 * `down()` reverte apenas as linhas que este manifesto marcou (`origem_configuracao_fatores = 'lc214'`),
 * de volta ao default do catálogo — nunca uma linha que um admin da plataforma tenha editado depois
 * (`origem_configuracao_fatores = 'admin-plataforma'` já não bate no `WHERE`).
 */
export class SeedRegrasLegaisNbs1789500000000 implements MigrationInterface {
  name = "SeedRegrasLegaisNbs1789500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    for (const regra of REGRAS_LEGAIS_NBS) {
      await queryRunner.query(
        `UPDATE "nbs_referencia"
         SET "fator_ibs" = $2,
             "fator_cbs" = $2,
             "fatores_configurados" = true,
             "aplicacao_automatica" = $3,
             "gera_credito_adquirente" = $4,
             "regime_especifico" = $5,
             "fundamento_legal_fatores" = $6,
             "condicoes_aplicacao_fatores" = $7,
             "origem_configuracao_fatores" = 'lc214'
         WHERE "codigo" = $1`,
        [
          regra.codigo,
          regra.fator,
          regra.aplicacao_automatica,
          regra.gera_credito_adquirente,
          regra.regime_especifico,
          regra.fundamento,
          regra.condicoes,
        ],
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const codigos = REGRAS_LEGAIS_NBS.map((regra) => regra.codigo);
    await queryRunner.query(
      `UPDATE "nbs_referencia"
       SET "fator_ibs" = 1,
           "fator_cbs" = 1,
           "fatores_configurados" = false,
           "aplicacao_automatica" = true,
           "gera_credito_adquirente" = true,
           "regime_especifico" = NULL,
           "fundamento_legal_fatores" = NULL,
           "condicoes_aplicacao_fatores" = NULL,
           "origem_configuracao_fatores" = 'nbs-2.0-anexo-b'
       WHERE "codigo" = ANY($1::varchar[])
         AND "origem_configuracao_fatores" = 'lc214'`,
      [codigos],
    );
  }
}
