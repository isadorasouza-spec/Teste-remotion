import { MigrationInterface, QueryRunner } from "typeorm";

/** AgentCore é o único motor de extração; a escolha por escritório deixou de existir. */
export class RemoveExtractionEngineColumns1784900000000 implements MigrationInterface {
  name = "RemoveExtractionEngineColumns1784900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "contract_extraction_engine"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_extraction_engine"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "contract_extraction_engine" text NOT NULL DEFAULT 'agent'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_extraction_engine" text NOT NULL DEFAULT 'agent'`);
  }
}
