# `src/database/modules/public`

Schema compartilhado da plataforma BlueAccount. Sem isolamento por escritório.

## Entidades

| Tabela | Entidade | Função |
|--------|----------|--------|
| `escritorios` | `Escritorio` | Cada instituição/empresa na plataforma |
| `usuarios` | `Usuario` | Usuários da plataforma (admin ou regulares) |
| `sessoes` | `Sessao` | Sessões autenticadas (bearer tokens) |
| `admin_sessions` | `AdminSession` | Contexto de login admin local (não-Cognito) |
| `fatores_mfa_usuario` | `FatorMfaUsuario` | Um fator TOTP ativo por usuário, segredo cifrado e último passo aceito |
| `fator_mfa_admin_plataforma` | `FatorMfaAdminPlataforma` | Fator TOTP singleton do admin de plataforma |
| `desafios_mfa` | `DesafioMfa` | Tabela `UNLOGGED` de desafios pré-auth expirantes; token somente em hash e enrollment cifrado |
| `eventos_auditoria_seguranca` | `EventoAuditoriaSeguranca` | Trilha administrativa retida de setup, verificação, reset e break-glass MFA, sem material do fator |
| `agent_logs` | `AgentLog` | Logs de processamento (pipelines, workers); inclui `status`, `execution_arn` (ARN do runtime/recurso invocado) e `trace_id` (handle da invocação) |
| `contexto` | `Contexto` | Contexto de processamento (KV store) |
| `seed_runs` | `SeedRun` | Execuções administrativas de captura MCP para gerar seeds reproduzíveis em escritórios de teste |
| `seed_run_api_calls` | `SeedRunApiCall` | Snapshots redigidos das chamadas capturadas durante uma Seed Run |
| `oauth_refresh_tokens` | `OAuthRefreshToken` | Refresh tokens OAuth rotativos, armazenados apenas como hash e vinculados à família de credenciais |
| `ingestao_controle_concorrencia` | `IngestaoControleConcorrencia` | Linha singleton bloqueada com `SELECT ... FOR UPDATE` para serializar admissões de ingestão |
| `ingestao_permissoes_processamento` | `IngestaoPermissaoProcessamento` | Lease por execução top-level, com módulo, documento, aquisição, liberação e status terminal |
| `cobranca_fila` | `CobrancaFila` | Fila de geração de cobrança e registro de lease: item pendente/processando/concluído/erro, payload do pedido, tentativas e a execução que detém a vaga |
| `simulacao_calculos_fila` | `SimulacaoCalculoFila` | Fila durável coalescida por tenant/simulação, com geração, retry, cancelamento e lease do worker |
| `simulacao_fila_controle` | `SimulacaoFilaControle` | Singleton de pausa global das novas aquisições de cálculo |
| `indices_inflacao` | `IndiceInflacao` | Séries mensais IPCA, INPC e IGP-M coletadas do BCB/SGS para reajustes contratuais auditáveis |
| `cnaes_referencia` | `CnaeReferencia` | Cache compartilhado da classificação IBGE: subclasse, hierarquia, atividades, observações e snapshot integral da resposta |
| `ncms_referencia` | `NcmReferencia` | Catálogo NCM local versionado, exato e somente leitura. Fatores da fonte separados dos automáticos, condições/conflitos, categoria, observação e proveniência. Publicação arquiva registros anteriores; sem API ou hierarquia em runtime. |
| `nbs_referencia` | `NbsReferencia` | Catálogo exato e somente leitura da planilha NBS versionada: fator, capítulo, categoria, fundamento, observação e proveniência. Publicação arquiva e substitui o legado. |
| `simples_cnaes` | `SimplesCnae` | Mapeamento normalizado de CNAE para anexo e incidência de Fator R usado pelo DAS automático, com `situacao` separando enquadrado de vedado e de não-optante |
| `simples_anexos` | `SimplesAnexo` | Faixas versionadas por vigência, anexo e RBT12, com alíquota nominal e parcela a deduzir |
| `simples_anexo_reparticoes` | `SimplesAnexoReparticao` | Percentuais versionados de IBS/CBS por faixa necessários ao DAS residual do regime regular |

O gate de ingestão usa somente o schema público. Aquisição e liberação acontecem sob o mesmo
lock da linha singleton; ambas são idempotentes por `execution_arn`. O índice parcial
`IDX_ingestao_permissoes_ativas_modulo` cobre apenas leases com `liberada_em IS NULL`. Leases não
expiram automaticamente, pois expirar durante OCR/extração poderia exceder o limite real.

A fila de cobrança usa o mesmo perfil: só schema público, sem RLS, porque a visão admin é
cross-tenant. A serialização do acquire é feita com `pg_advisory_xact_lock(hashtext('cobranca_fila'))`
(liberação automática no fim da transação, sem linha singleton). O índice único parcial
`UQ_cobranca_fila_vac_em_voo` impede enfileirar o mesmo VAC duas vezes enquanto ele estiver
`pendente` ou `processando`, substituindo o `MessageDeduplicationId` da antiga fila FIFO. Diferente
das leases de ingestão, a lease da fila de cobrança **expira**: `COBRANCA_FILA_LOCK_TTL_MS` devolve
para `pendente` (ou `erro`, ao esgotar `COBRANCA_FILA_MAX_TENTATIVAS`) itens cuja State Machine
morreu com a vaga na mão, tanto no reap oportunista do pop quanto no job pg_cron de piso.

## Migrations

Migrations TypeORM padrão em `migrations/`:

- `1787800000000-add-fatores-ibs-cbs-ncms.ts` adiciona os fatores globais e carrega o manifesto
  legal auditável da LC 214/2025 consolidada pela LC 227/2026. O rollback remove somente linhas
  criadas pela carga (identificadas também no JSON de origem), preservando NCMs previamente cacheados.
- `1788900000000-automatizar-posicoes-carnes-anexo-i.ts` torna automáticas as posições de carnes
  integralmente relacionadas no item 19; exceções filhas continuam vencendo pelo maior prefixo.
- `1789100000000-enforce-heranca-fatores-ncm.ts` torna automática toda regra configurada e trava no
  banco o contrato raiz herdada → exceção filha com fator integral.
- `1789300000000-create_nbs_referencia.ts` cria a tabela `nbs_referencia`.
- `1789400000000-seed_nbs_referencia_catalogo.ts` semeia o catálogo (~1.200 códigos, gerado por
  `scripts/gerar-catalogo-nbs.mjs` a partir do Anexo B da NFS-e Nacional) em lotes com `ON CONFLICT`;
  o rollback apaga só os códigos do manifesto.
- `1789500000000-seed_regras_legais_nbs.ts` aplica o manifesto curado de 39 regras legais (Anexos II
  e III, arts. 57, 127, 157, 285, 286 da LC 214/2025) por `UPDATE`, sem `INSERT`; o rollback reverte
  só as linhas cuja origem ainda é `lc214` (uma edição administrativa posterior não é desfeita).
- `1789600000000-create-mfa.ts` cria fatores MFA persistentes e desafios `UNLOGGED`, com
  unicidade por identidade, limites de tentativa e constraints de finalidade/estado.
- `1789800000000-create-catalogo-simples.ts` cria o catálogo do DAS automático e semeia 895 CNAEs
  normalizados mais as faixas/repartições legais versionadas. O manifesto CNAE é regenerável por
  `scripts/gerar-catalogo-simples-cnaes.mjs` e combina DUAS fontes, registradas linha a linha na
  coluna `fonte`: `tabela-cnae.csv` traz os 392 códigos de serviço (Anexos III, IV e V e a marcação de
  Fator R, que não são dedutíveis do código) e as subclasses oficiais do IBGE completam os 503
  restantes de comércio e indústria, cujo anexo decorre da natureza da atividade — divisões 10 a 32
  → Anexo II, divisões 45 a 47 → Anexo I (LC 123/2006, art. 18, §4º, I e II). O CSV sempre vence, o
  que preserva os bolsões de serviço dentro dessas divisões (grupo 461, 452, 4543, 4751202,
  3250706/3250709) sem precisar de lista de exceções.
- `1789800000003-completar-catalogo-simples-cnaes.ts` insere o seed com `ON CONFLICT (codigo) DO
  NOTHING`. É a migration que faz o catálogo crescer em banco que **já** aplicou `1789800000000`:
  aquela semeia inline, então engordar o arquivo de seed não muda nada num banco onde ela já consta
  como executada. **Todo crescimento futuro do catálogo precisa de uma migration própria como esta, e
  não de uma edição no seed original.** É neutra nas duas direções — em banco novo não sobra nada para
  inserir. O `down` remove só as linhas com `fonte = 'ibge/cnae/subclasses'`.
- `1789800000004-add-situacao-simples-cnaes.ts` adiciona `situacao` (`enquadrado`, `vedado`,
  `nao_optante`, default `enquadrado`), **relaxa** `CK_simples_cnaes_fator_r` para exigir anexo só
  dentro de `enquadrado`, e só então insere as linhas sem anexo. A ordem é obrigatória: o CHECK
  original exige anexo em toda linha sem Fator R.

  Consequência que vale conhecer: como o seed é uma constante compartilhada e mutável, `1789800000000`
  e `1789800000003` precisam filtrar `WHERE item.situacao = 'enquadrado'`. Sem o filtro, crescer o
  arquivo de seed quebra a criação do zero em banco novo, mesmo sem ninguém tocar naquelas migrations.
  Há teste travando os três filtros e a ordem do `DROP CONSTRAINT` antes do `INSERT`.
- `1789800000005-completar-catalogo-simples-servicos.ts` traz 52 códigos de serviço: o residual do art.
  18, §5º-F (Anexo III), os de previsão expressa (§5º-C, §5º-B XIV, locação de bens móveis, fornecimento
  de alimentação) e as vedações do art. 17 que casam literalmente com um inciso. Idempotente, e o `down`
  apaga por prefixo de `fonte`, que identifica a procedência linha a linha.
- `1789800000006-completar-catalogo-simples-agro-extrativa.ts` traz os 164 códigos de agropecuária,
  produção florestal, pesca e extrativa no Anexo I, pela mesma regra de natureza da atividade das
  divisões de comércio e indústria. Não há coluna de presunção: a classificação oficial já separa
  produção própria in natura (divisões 01 a 09) de industrialização dela (10 a 32).
- `1789800000007-completar-catalogo-simples-construcao.ts` traz os 31 códigos das divisões 41 a 43: 19 no
  Anexo IV pelo §5º-C, I, 11 no Anexo III pelo residual do §5º-F por não serem obra, e a incorporação
  imobiliária como vedada pelo art. 17, XIV.
- `1789800000008-completar-catalogo-simples-transportes.ts` traz os 81 códigos de transporte,
  armazenagem, correio e telecomunicações: 77 no Anexo III pelo residual do §5º-F e 4 vedados pelo art.
  17, VI. Eles esperavam o híbrido do §5º-E, que foi revogado.

```bash
npm run migration:run              # Aplica pendentes
npm run migration:generate --name=X  # Gera a partir de diff de entidades
npm run migration:revert          # Reverte última
```

## Nomenclatura

- Tabelas e colunas: `snake_case`
- Entidades TypeORM: `PascalCase`
- Arquivo de entidade: `kebab-case.entity.ts`

## RLS (Row Level Security)

As entidades públicas **não usam RLS** — são compartilhadas. O isolamento é por schema de tenant.

### Worker de distribuição DFe

`1792100000000-conceder-fila-distribuicao-worker` concede SELECT/UPDATE de
`distribuicoes_dfe_fila` à `DOCUMENTOS_FISCAIS_DB_USERNAME`, validando
NOSUPERUSER/NOBYPASSRLS/NOINHERIT. Nenhum INSERT/DELETE direto é concedido; enqueue continua pela
função pública existente. O worker Python assume a role tenant para certificado, cursor e ledger.
A credencial precisa estar configurada na aplicação da migration; se omitida com a integração
desligada, a concessão posterior deve ser feita explicitamente pelo owner.

## Controle CRM

Migration `1792500000000` define tabelas SQL de controle `crm_configuracao`, `crm_vinculos`,
`crm_eventos`, `crm_historico`, `crm_entregas`, `crm_usuarios`. O repositório parametrizado em
`domain/integracoes-crm` mantém leases, transações e tombstones. Sem grants tenant. Ciphertext de
setup tem validade de 24h e purga por worker/pg_cron; nunca aparece em projeções administrativas.

CRM: `1792600000000-reforcar-operacao-crm` acrescenta ator/contexto ao histórico (vínculo opcional
para auditoria de configuração global), prioridade da fila e índice para reconciliação limitada.
Aplicar antes de publicar a nova API/imagem CRM. Registros antigos recebem autoria legada explícita.

CRM: `1792700000000-definir-corte-provisionamento-crm` adiciona o marco fixo
`crm_configuracao.provisionar_criados_apos=2026-09-15T15:52:34Z` e `crm_vinculos.negocio_criado_em`.
Executar antes da nova API/imagem SAM. Não recalcular o default com `now()` nem alterar por JSON
na configuração: ele protege contra onboarding automático do pipeline histórico.
