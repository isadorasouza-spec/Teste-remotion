import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddReportAgentInstructionsToEscritorios1783500000000 implements MigrationInterface {
  name = "AddReportAgentInstructionsToEscritorios1783500000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_agent_instructions" text`,
    );
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_agent_instructions"`,
    );
  }
}
