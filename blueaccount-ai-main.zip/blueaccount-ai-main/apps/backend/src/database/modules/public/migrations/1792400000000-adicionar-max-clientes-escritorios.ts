import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Teto de clientes por escritório.
 *
 * `NULL` (o valor de todo escritório existente) significa ilimitado, então a
 * coluna entra sem default e sem NOT NULL: nenhum escritório atual passa a ter
 * limite por causa desta migration. Diferente das colunas `trial_*`, este limite
 * não é gateado por `is_trial` — vale para qualquer escritório.
 */
export class AdicionarMaxClientesEscritorios1792400000000 implements MigrationInterface {
  name = "AdicionarMaxClientesEscritorios1792400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "max_clientes" integer NULL`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "max_clientes"`);
  }
}
