import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn, type Relation } from "typeorm";
import { SimplesAnexo } from "./simples-anexo.entity.js";

export type ComponenteSimples = "IBS" | "CBS";

@Index("UQ_simples_anexo_reparticoes_componente", ["simples_anexo_id", "componente"], { unique: true })
@Entity("simples_anexo_reparticoes")
export class SimplesAnexoReparticao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  simples_anexo_id!: string;

  @ManyToOne(() => SimplesAnexo, (faixa) => faixa.reparticoes, { onDelete: "CASCADE" })
  @JoinColumn({ name: "simples_anexo_id" })
  faixa_anexo!: Relation<SimplesAnexo>;

  @Column({ type: "varchar", length: 3 })
  componente!: ComponenteSimples;

  /** Fração do DAS da faixa destinada ao componente (0,155 = 15,5%). */
  @Column({ type: "decimal", precision: 8, scale: 6 })
  percentual!: number;
}
