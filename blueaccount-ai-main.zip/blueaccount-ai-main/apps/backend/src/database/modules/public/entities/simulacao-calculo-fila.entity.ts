import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type StatusSimulacaoCalculoFila = "pendente" | "processando" | "concluido" | "erro" | "cancelado";

@Entity("simulacao_calculos_fila")
@Index("UQ_simulacao_calculos_fila_alvo", ["escritorio_id", "simulacao_id"], { unique: true })
@Index("IDX_simulacao_calculos_fila_disponivel", ["status", "disponivel_em", "atualizado_em"])
@Index("IDX_simulacao_calculos_fila_lease", ["status", "lock_adquirido_em"], {
  where: `"status" = 'processando'`,
})
@Check("CHK_simulacao_calculos_fila_status", `"status" IN ('pendente', 'processando', 'concluido', 'erro', 'cancelado')`)
@Check(
  "CHK_simulacao_calculos_fila_lease",
  `("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL AND "versao_processando" IS NOT NULL)`,
)
export class SimulacaoCalculoFila {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) simulacao_id!: string;
  @Column({ type: "varchar", length: 20 }) status!: StatusSimulacaoCalculoFila;
  @Column({ type: "bigint", default: 1 }) versao_solicitada!: string;
  @Column({ type: "bigint", nullable: true }) versao_processando!: string | null;
  @Column({ type: "smallint", default: 0 }) tentativas!: number;
  @Column({ type: "timestamptz", default: () => "now()" }) disponivel_em!: Date;
  @Column({ type: "text", nullable: true }) erro!: string | null;
  @Column({ type: "uuid", nullable: true }) lease_token!: string | null;
  @Column({ type: "timestamptz", nullable: true }) lock_adquirido_em!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) cancelamento_solicitado_em!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) concluido_em!: Date | null;
  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
