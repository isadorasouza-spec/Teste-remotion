import type { MigrationInterface, QueryRunner } from "typeorm";

/** Descarta a fila e o histórico do coletor de consulta pública aposentado. */
export class RemoverConsultasChavesFiscaisFila1792200000000 implements MigrationInterface {
  async up(q: QueryRunner): Promise<void> {
    await q.query(`DROP FUNCTION IF EXISTS public.enfileirar_consulta_chave_fiscal(uuid,uuid,varchar,varchar)`);
    await q.query(`DROP TABLE IF EXISTS public.consultas_chaves_fiscais_fila`);
  }
  async down(): Promise<void> {
    throw new Error("Recriar uma fila vazia não restaura os dados da consulta pública");
  }
}
