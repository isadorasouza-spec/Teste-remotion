import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  type Relation,
} from "typeorm";
import { Usuario } from "./usuario.entity.js";

@Index("UQ_fatores_mfa_usuario_usuario_id", ["usuario_id"], { unique: true })
@Entity({ name: "fatores_mfa_usuario", schema: "public" })
export class FatorMfaUsuario {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Usuario, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "usuario_id" })
  usuario!: Relation<Usuario>;

  @Column({ type: "uuid" })
  usuario_id!: string;

  @Column({ type: "text" })
  segredo_encrypted!: string;

  @Column({ type: "text" })
  segredo_iv!: string;

  @Column({ type: "text" })
  segredo_tag!: string;

  @Column({ type: "bigint", nullable: true })
  ultimo_passo_aceito!: string | null;

  @Column({ type: "timestamp" })
  ativado_em!: Date;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
