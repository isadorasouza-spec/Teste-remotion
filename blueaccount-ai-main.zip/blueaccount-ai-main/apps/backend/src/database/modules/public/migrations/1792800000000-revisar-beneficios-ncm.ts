import type { MigrationInterface, QueryRunner } from "typeorm";
import { REGRAS_NCM_REVISADAS } from "./dados/regras-ncm-revisadas-20260916.js";

/** Correção do catálogo com evidência anterior persistida; não altera fatores de entradas. */
export class RevisarBeneficiosNcm1792800000000 implements MigrationInterface {
  name = "RevisarBeneficiosNcm1792800000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    // Snapshot somente de referências fiscais públicas, sem dados de contribuintes.
    await queryRunner.query(`CREATE TABLE IF NOT EXISTS public.ncms_revisao_20260916 (
      codigo varchar(8) PRIMARY KEY, anterior jsonb, revisado_em timestamptz NOT NULL DEFAULT now()
    )`);
    await queryRunner.query(`INSERT INTO public.ncms_revisao_20260916 (codigo, anterior)
      SELECT codigo, to_jsonb(n) FROM public.ncms_referencia n
      WHERE fatores_configurados = true OR codigo = ANY($1::varchar[])
      ON CONFLICT (codigo) DO NOTHING`, [REGRAS_NCM_REVISADAS.map(r => r.codigo)]);
    await queryRunner.query(`ALTER TABLE public.ncms_referencia
      DROP CONSTRAINT IF EXISTS "CHK_ncms_regra_configurada_automatica"`);
    // Remover apenas o manifesto substituído. Configurações administrativas fora da auditoria
    // permanecem; as duas divergências locais revisadas são reconciliadas abaixo.
    await queryRunner.query(`UPDATE public.ncms_referencia SET fatores_configurados = false,
      fator_ibs = 1, fator_cbs = 1, aplicacao_automatica = true,
      fundamento_legal_fatores = NULL, condicoes_aplicacao_fatores = NULL,
      origem_configuracao_fatores = 'revisao-NCM-20260916:retirada'
      WHERE origem_configuracao_fatores LIKE 'LC214-227-2026%'`);
    for (const regra of REGRAS_NCM_REVISADAS) {
      await queryRunner.query(`INSERT INTO public.ncms_referencia (
        codigo, descricao, resposta_brasilapi, fator_ibs, fator_cbs, fatores_configurados,
        aplicacao_automatica, fundamento_legal_fatores, condicoes_aplicacao_fatores, origem_configuracao_fatores
      ) VALUES ($1, $2, $3::jsonb, $4, $4, true, $5, $6, $7, 'revisao-NCM-20260916')
      ON CONFLICT (codigo) DO UPDATE SET
        fator_ibs = EXCLUDED.fator_ibs, fator_cbs = EXCLUDED.fator_cbs,
        fatores_configurados = true, aplicacao_automatica = EXCLUDED.aplicacao_automatica,
        fundamento_legal_fatores = EXCLUDED.fundamento_legal_fatores,
        condicoes_aplicacao_fatores = EXCLUDED.condicoes_aplicacao_fatores,
        origem_configuracao_fatores = EXCLUDED.origem_configuracao_fatores
      WHERE ncms_referencia.origem_configuracao_fatores IS DISTINCT FROM 'admin-plataforma'
        OR ncms_referencia.codigo IN ('0302', '07141000')`, [
        regra.codigo, regra.descricao, JSON.stringify({ origem: "revisao-NCM-20260916" }),
        regra.fator, regra.automatica, regra.fundamento, regra.condicoes,
      ]);
    }
  }

  async down(): Promise<void> {
    throw new Error("Reversão fiscal exige revisão do snapshot public.ncms_revisao_20260916 e das simulações afetadas; não restaurar benefícios incorretos automaticamente.");
  }
}
