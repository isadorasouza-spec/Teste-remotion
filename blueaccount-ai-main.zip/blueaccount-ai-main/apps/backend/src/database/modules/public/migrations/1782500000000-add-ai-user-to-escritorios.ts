import { MigrationInterface, QueryRunner } from "typeorm";

export class AddAiUserToEscritorios1782500000000 implements MigrationInterface {
  name = "AddAiUserToEscritorios1782500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "ai_user_id" uuid`);

    await queryRunner.query(`
      INSERT INTO "usuarios" ("escritorio_id", "nome", "email", "cognito_sub", "admin_escritorio", "ativo")
      SELECT
        e."id",
        'Kontiva AI',
        'ai+' || e."id"::text || '@internal.kontiva.ai',
        NULL,
        false,
        true
      FROM "escritorios" e
      WHERE NOT EXISTS (
        SELECT 1
        FROM "usuarios" u
        WHERE u."email" = 'ai+' || e."id"::text || '@internal.kontiva.ai'
      )
    `);

    await queryRunner.query(`
      UPDATE "escritorios" e
      SET "ai_user_id" = u."id"
      FROM "usuarios" u
      WHERE
        u."email" = 'ai+' || e."id"::text || '@internal.kontiva.ai'
        AND e."ai_user_id" IS NULL
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1
          FROM "pg_constraint"
          WHERE "conname" = 'FK_escritorios_ai_user_id'
        ) THEN
          ALTER TABLE "escritorios"
          ADD CONSTRAINT "FK_escritorios_ai_user_id"
          FOREIGN KEY ("ai_user_id")
          REFERENCES "usuarios"("id")
          ON DELETE SET NULL
          ON UPDATE NO ACTION;
        END IF;
      END $$;
    `);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_escritorios_ai_user_id" ON "escritorios" ("ai_user_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_escritorios_ai_user_id"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP CONSTRAINT IF EXISTS "FK_escritorios_ai_user_id"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "ai_user_id"`);
    await queryRunner.query(`
      DELETE FROM "sessoes"
      WHERE "usuario_id" IN (
        SELECT "id"
        FROM "usuarios"
        WHERE "email" LIKE 'ai+%@internal.kontiva.ai'
      )
    `);
    await queryRunner.query(`DELETE FROM "usuarios" WHERE "email" LIKE 'ai+%@internal.kontiva.ai'`);
  }
}
