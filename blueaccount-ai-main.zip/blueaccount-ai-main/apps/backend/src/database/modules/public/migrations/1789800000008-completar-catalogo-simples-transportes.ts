import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Transporte, armazenagem, correio e telecomunicações: 81 códigos.
 *
 * 77 no Anexo III pelo residual do art. 18, §5º-F e 4 vedados pelo art. 17, VI (transporte
 * intermunicipal e interestadual de passageiros).
 *
 * Estes códigos ficaram fora do catálogo por vários ciclos esperando o híbrido do art. 18, §5º-E, que
 * mandava aplicar o Anexo III deduzida a parcela do ISS e acrescida a do ICMS do Anexo I. **O §5º-E foi
 * revogado**, então não existe composição a modelar: eles caem no residual comum. O trabalho de
 * estender `simples_anexo_reparticoes` para carregar ICMS e ISS deixou de ser pré-requisito daqui.
 *
 * Transporte de CARGA nunca foi vedado - o art. 17, VI alcança só passageiros, e com três exceções
 * (fluvial, característica urbana ou metropolitana, e fretamento contínuo metropolitano de estudantes
 * ou trabalhadores) que tiram do alcance da vedação boa parte dos códigos de passageiros.
 */
export class CompletarCatalogoSimplesTransportes1789800000008 implements MigrationInterface {
  name = "CompletarCatalogoSimplesTransportes1789800000008";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte", "situacao")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte, item.situacao
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes"
        WHERE (left("codigo", 2) IN ('49', '50', '51', '52', '53') OR left("codigo", 2) = '61')
          AND "fonte" <> 'tabela-cnae.csv'`,
    );
  }
}
