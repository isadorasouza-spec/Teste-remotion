import type { MigrationInterface, QueryRunner } from "typeorm";

export class SetSessoesUnlogged1784112210638 implements MigrationInterface {
  name = "SetSessoesUnlogged1784112210638";

  // Sessões são efêmeras (workaround para não depender de Redis): em parada suja
  // (crash/reboot/patch do RDS) o Postgres trunca tabelas UNLOGGED, e o único efeito
  // é o usuário/admin reautenticar. Em troca, escrita não gera WAL — alivia o hot
  // path de `sessoes` (UPDATE de last_seen_at a cada request).
  //
  // Postgres proíbe FK entre persistências diferentes (unlogged↔logged), então antes
  // de converter é preciso derrubar as FKs que tocam `sessoes`, nas duas direções:
  //   - sessoes.usuario_id → usuarios        (sessoes é filho)
  //   - sessoes.escritorio_id → escritorios  (sessoes é filho)
  //   - contexto.sessao_id → sessoes         (contexto é filho; telemetria)
  // As relações ORM viram `createForeignKeyConstraints: false` para o migration:generate
  // não recriar essas FKs. Integridade referencial some, aceitável: linhas de sessão são
  // descartáveis e a limpeza é feita por job (pg_cron) + truncate em restart.
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DO $$
      DECLARE r record;
      BEGIN
        FOR r IN
          SELECT conname, conrelid::regclass AS tbl
          FROM pg_constraint
          WHERE contype = 'f'
            AND (conrelid = 'public.sessoes'::regclass OR confrelid = 'public.sessoes'::regclass)
        LOOP
          EXECUTE format('ALTER TABLE %s DROP CONSTRAINT %I', r.tbl, r.conname);
        END LOOP;
      END $$;
    `);
    await queryRunner.query(`ALTER TABLE "sessoes" SET UNLOGGED`);
    await queryRunner.query(`ALTER TABLE "admin_session" SET UNLOGGED`);

    // Sem FK, o crescimento das tabelas é contido por pg_cron: purga sessões
    // expiradas/revogadas a cada 15 min. O agendamento só roda onde pg_cron está
    // carregado (prod, após reboot com shared_preload_libraries=pg_cron); em
    // local/CI o guard pula sem erro. IMPORTANTE: em prod, rodar esta migration
    // DEPOIS do reboot do RDS, senão o agendamento é pulado e não se repete.
    await queryRunner.query(`
      DO $$
      BEGIN
        IF current_setting('shared_preload_libraries', true) LIKE '%pg_cron%' THEN
          CREATE EXTENSION IF NOT EXISTS pg_cron;
          PERFORM cron.schedule(
            'purge-sessoes', '*/15 * * * *',
            $q$DELETE FROM public.sessoes WHERE expires_at < now() OR revoked_at IS NOT NULL$q$
          );
          PERFORM cron.schedule(
            'purge-admin-session', '*/15 * * * *',
            $q$DELETE FROM public.admin_session WHERE expires_at < now() OR revoked_at IS NOT NULL$q$
          );
        ELSE
          RAISE NOTICE 'pg_cron não carregado; purge de sessões não agendado.';
        END IF;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
          PERFORM cron.unschedule(jobname)
          FROM cron.job
          WHERE jobname IN ('purge-sessoes', 'purge-admin-session');
        END IF;
      END $$;
    `);
    await queryRunner.query(`ALTER TABLE "admin_session" SET LOGGED`);
    await queryRunner.query(`ALTER TABLE "sessoes" SET LOGGED`);
    await queryRunner.query(`
      ALTER TABLE "sessoes"
      ADD CONSTRAINT "FK_61dbcb4cfdf4aaca8067f368128"
      FOREIGN KEY ("usuario_id") REFERENCES "usuarios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
      ALTER TABLE "sessoes"
      ADD CONSTRAINT "FK_bf95fdd714ce01e7e9bdf12ff6b"
      FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION
    `);
    await queryRunner.query(`
      ALTER TABLE "contexto"
      ADD CONSTRAINT "FK_contexto_sessao_id"
      FOREIGN KEY ("sessao_id") REFERENCES "sessoes"("id") ON DELETE SET NULL ON UPDATE NO ACTION
    `);
  }
}
