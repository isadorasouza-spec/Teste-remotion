import type { QueryRunner } from "typeorm";
import { CATALOGO_NCM } from "./ncm-catalogo-20260916.js";
import { METADADOS_CATALOGO_NCM } from "./ncm-metadados-20260916.js";

/**
 * Carga do manifesto reconciliado, compartilhada pela publicação inicial e pela republicação.
 * Mora aqui, junto dos dados, porque o SQL e o formato do manifesto mudam juntos: duas cópias
 * divergiriam em silêncio e publicariam catálogos diferentes conforme a ordem das migrations.
 *
 * Remove os códigos fora da fonte (inclusive prefixos e overrides administrativos) e semeia todos os
 * registros da versão corrente. Não toca em simulação, resultado, cache ou fila: a arquivagem do
 * estado anterior é responsabilidade de quem chama, antes de invocar esta função.
 */
export async function carregarCatalogoNcm(q: QueryRunner): Promise<void> {
  await q.query(`DELETE FROM public.ncms_referencia WHERE NOT (codigo = ANY($1::varchar[]))`, [CATALOGO_NCM.map(r => r.codigo)]);
  for (let inicio = 0; inicio < CATALOGO_NCM.length; inicio += 500) {
    await q.query(`INSERT INTO public.ncms_referencia (
      codigo, descricao, fator_ibs, fator_cbs, fatores_configurados, aplicacao_automatica,
      fundamento_legal_fatores, condicoes_aplicacao_fatores, origem_configuracao_fatores,
      versao_catalogo, categoria, observacao, fonte_linha, situacao_revisao, motivos_revisao, evidencias_revisao,
      resposta_brasilapi, descricoes_hierarquia
    ) SELECT codigo, descricao, fator, fator, true, situacao = 'automatica', fundamento, condicoes, $2,
      $2, categoria, observacao, linha, situacao, motivos, evidencias, '{}'::jsonb, ARRAY[]::text[]
    FROM jsonb_to_recordset($1::jsonb) AS r(codigo text, descricao text, fator numeric, fundamento text,
      condicoes text, categoria text, observacao text, linha int, situacao text, motivos jsonb, evidencias jsonb)
    ON CONFLICT (codigo) DO UPDATE SET
      descricao = EXCLUDED.descricao, fator_ibs = EXCLUDED.fator_ibs, fator_cbs = EXCLUDED.fator_cbs,
      fatores_configurados = true, aplicacao_automatica = EXCLUDED.aplicacao_automatica,
      fundamento_legal_fatores = EXCLUDED.fundamento_legal_fatores, condicoes_aplicacao_fatores = EXCLUDED.condicoes_aplicacao_fatores,
      origem_configuracao_fatores = EXCLUDED.origem_configuracao_fatores, versao_catalogo = EXCLUDED.versao_catalogo,
      categoria = EXCLUDED.categoria, observacao = EXCLUDED.observacao, fonte_linha = EXCLUDED.fonte_linha,
      situacao_revisao = EXCLUDED.situacao_revisao, motivos_revisao = EXCLUDED.motivos_revisao, evidencias_revisao = EXCLUDED.evidencias_revisao,
      resposta_brasilapi = '{}'::jsonb, resposta_arvore_brasilapi = NULL, descricoes_hierarquia = ARRAY[]::text[],
      data_inicio = NULL, data_fim = NULL, tipo_ato = NULL, numero_ato = NULL, ano_ato = NULL, atualizado_em = now()`,
    [JSON.stringify(CATALOGO_NCM.slice(inicio, inicio + 500)), METADADOS_CATALOGO_NCM.versao]);
  }
}

/** Registra a publicação e recusa a transação inteira se a carga não bateu com o manifesto. */
export async function registrarVersaoCatalogoNcm(q: QueryRunner): Promise<void> {
  const [contagem] = await q.query(`SELECT count(*)::int AS total FROM public.ncms_referencia WHERE versao_catalogo = $1`, [METADADOS_CATALOGO_NCM.versao]);
  if (contagem.total !== METADADOS_CATALOGO_NCM.total) throw new Error("Carga NCM incompleta.");
  await q.query(`INSERT INTO public.ncm_catalogo_versoes (versao, metadados) VALUES ($1, $2::jsonb)`,
    [METADADOS_CATALOGO_NCM.versao, JSON.stringify(METADADOS_CATALOGO_NCM)]);
}
