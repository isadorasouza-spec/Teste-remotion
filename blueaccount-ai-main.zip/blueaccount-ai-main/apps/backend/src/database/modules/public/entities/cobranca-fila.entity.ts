import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/**
 * Estado de um item na fila de cobrança. `processando` é o único estado que
 * ocupa uma vaga do lock global — a contagem de vagas ativas é
 * `COUNT(*) WHERE status = 'processando'`.
 */
export type StatusCobrancaFila = "pendente" | "processando" | "concluido" | "erro";

/**
 * Fila de geração de cobrança em Postgres. A tabela é a fila **e** o registro de
 * lease: o backend só enfileira e dispara a State Machine, e a SM descobre o
 * alvo depois de ganhar uma vaga (`POST /api/internal/cobranca/fila/proximo`).
 *
 * Vive em `public` e sem RLS de propósito: a visão admin é cross-tenant e não
 * itera schemas de escritório. Mesmo perfil LGPD de
 * `ingestao_permissoes_processamento` — só ids, competência e o payload técnico
 * que já trafegava pela fila SQS.
 */
@Entity("cobranca_fila")
@Index("IDX_cobranca_fila_pendentes", ["status", "criado_em"])
@Index("IDX_cobranca_fila_processando", ["status", "lock_adquirido_em"], {
  where: `"status" = 'processando'`,
})
@Index("UQ_cobranca_fila_vac_em_voo", ["valores_a_cobrar_id"], {
  unique: true,
  where: `"status" IN ('pendente', 'processando')`,
})
@Check("CHK_cobranca_fila_status", `"status" IN ('pendente', 'processando', 'concluido', 'erro')`)
@Check(
  "CHK_cobranca_fila_lock",
  `("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL)`,
)
export class CobrancaFila {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "uuid" })
  valores_a_cobrar_id!: string;

  @Column({ type: "varchar", length: 7 })
  competencia!: string;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "uuid", nullable: true })
  grupo_id!: string | null;

  /** `PayloadCobrancaAssincrona` v1 inteiro, como era enviado à fila FIFO. */
  @Column({ type: "jsonb" })
  payload!: Record<string, unknown>;

  @Column({ type: "varchar", length: 20 })
  status!: StatusCobrancaFila;

  @Column({ type: "smallint", default: 0 })
  tentativas!: number;

  @Column({ type: "text", nullable: true })
  erro!: string | null;

  /** Execução da State Machine que detém a vaga enquanto `status = 'processando'`. */
  @Column({ type: "text", nullable: true })
  execution_arn!: string | null;

  @Column({ type: "timestamptz", nullable: true })
  lock_adquirido_em!: Date | null;

  @CreateDateColumn({ type: "timestamptz", name: "criado_em" })
  criado_em!: Date;

  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" })
  atualizado_em!: Date;
}
