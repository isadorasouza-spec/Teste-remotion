import { Check, Column, CreateDateColumn, Entity, PrimaryColumn, UpdateDateColumn } from "typeorm";

@Check("CK_fator_mfa_admin_username", `"username" = 'admin'`)
@Entity({ name: "fator_mfa_admin_plataforma", schema: "public" })
export class FatorMfaAdminPlataforma {
  @PrimaryColumn({ type: "text" })
  username!: "admin";

  @Column({ type: "text" })
  segredo_encrypted!: string;

  @Column({ type: "text" })
  segredo_iv!: string;

  @Column({ type: "text" })
  segredo_tag!: string;

  @Column({ type: "bigint", nullable: true })
  ultimo_passo_aceito!: string | null;

  @Column({ type: "timestamp" })
  ativado_em!: Date;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
