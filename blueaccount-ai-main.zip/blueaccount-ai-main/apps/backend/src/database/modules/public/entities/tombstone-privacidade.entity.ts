import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type EscopoTombstonePrivacidade = "documento" | "escritorio" | "titular";

@Entity("tombstones_privacidade")
@Index("UQ_tombstones_privacidade_escopo_hash", ["escopo", "identificador_hash"], { unique: true })
@Index("IDX_tombstones_privacidade_pendente", ["concluido_em", "proxima_tentativa_em"])
export class TombstonePrivacidade {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "text" }) escopo!: EscopoTombstonePrivacidade;
  @Column({ type: "text" }) identificador_hash!: string;
  @Column({ type: "uuid", nullable: true }) escritorio_id!: string | null;
  @Column({ type: "jsonb", default: {} }) manifesto!: Record<string, unknown>;
  @Column({ type: "text" }) motivo!: string;
  @Column({ type: "int", default: 0 }) tentativas!: number;
  @Column({ type: "text", nullable: true }) ultimo_erro!: string | null;
  @Column({ type: "timestamp with time zone", nullable: true }) proxima_tentativa_em!: Date | null;
  @Column({ type: "timestamp with time zone", nullable: true }) concluido_em!: Date | null;
  @CreateDateColumn({ type: "timestamp with time zone" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamp with time zone" }) updated_at!: Date;
}
