/** Gerado por scripts/gerar-catalogo-ncm.mjs. Não editar: publicar nova versão. */
export const METADADOS_CATALOGO_NCM = {
  "versao": "ncm-20260916-v2",
  "arquivo": "NCM_Fator_IVA_IBS_CBS.xlsx",
  "sha256": "e94d49f04bec010bf1fa5dea04ec283d63f03a768422f0a5ba2d694950f9fddb",
  "data_fonte": "2026-09-16",
  "aba": "NCM x Fator IVA",
  "total": 10938,
  "cobertura": "parcial",
  "reconciliacao": {
    "arquivo": "apps/backend/src/database/modules/public/migrations/dados/regras-ncm-revisadas-20260916.ts",
    "sha256": "954033e0f4d38b89aa5d1dd1b1a5213987c5367aca6bbe241813428de666fa25",
    "regras": 201,
    "situacoes": {
      "automatica": 9332,
      "condicional": 1261,
      "conflito": 345
    },
    "beneficio_automatico": 316
  },
  "categorias": [
    "Alimentos para Consumo Humano (reducao 60%)",
    "Cesta Basica Nacional de Alimentos",
    "Dispositivos Medicos (essenciais)",
    "Dispositivos Medicos (reducao 60%)",
    "Dispositivos de Acessibilidade PCD (essenciais)",
    "Dispositivos de Acessibilidade PCD (reducao 60%)",
    "Higiene Pessoal e Limpeza (baixa renda)",
    "Insumos Agropecuarios e Aquicolas (reducao 60%)",
    "Medicamentos - criterio nao e por NCM (ver observacao)",
    "Nutricao Enteral/Parenteral e Formulas Especiais",
    "Padrao",
    "Produtos Horticolas, Frutas e Ovos"
  ],
  "metodologia": [
    "NCM x Fator de IVA (IBS/CBS) — Reforma Tributária",
    "Gerado em 16/09/2026. Total de códigos NCM cobertos: 10938.",
    "O que é o \"Fator\"",
    "O Fator IVA (%) representa o percentual da alíquota cheia do IBS/CBS (o IVA dual criado pela Reforma Tributária — EC 132/2023, regulamentada pela LC 214/2025) que efetivamente incide sobre aquele NCM. Fator 100% = alíquota padrão, sem redução. Fator 40% = redução de 60% (produto paga 40% da alíquota cheia). Fator 0% = alíquota zero / isenção (cesta básica, por exemplo). Esse é o mesmo conceito usado internamente na Kontiva (campo fator_ibs/fator_cbs, derivado da classificação NCM de cada lançamento).",
    "Distribuição por categoria",
    "• 9326 NCM — Padrao",
    "• 423 NCM — Medicamentos - criterio nao e por NCM (ver observacao)",
    "• 362 NCM — Insumos Agropecuarios e Aquicolas (reducao 60%)",
    "• 264 NCM — Cesta Basica Nacional de Alimentos",
    "• 200 NCM — Alimentos para Consumo Humano (reducao 60%)",
    "• 126 NCM — Produtos Horticolas, Frutas e Ovos",
    "• 95 NCM — Dispositivos Medicos (reducao 60%)",
    "• 62 NCM — Nutricao Enteral/Parenteral e Formulas Especiais",
    "• 45 NCM — Dispositivos Medicos (essenciais)",
    "• 21 NCM — Dispositivos de Acessibilidade PCD (reducao 60%)",
    "• 7 NCM — Higiene Pessoal e Limpeza (baixa renda)",
    "• 7 NCM — Dispositivos de Acessibilidade PCD (essenciais)",
    "Fontes utilizadas",
    "Tabela base de NCM: cruzamento entre a API pública do MDIC/Comex Stat (api-comexstat.mdic.gov.br) e mirrors comunitários de dados abertos do governo (repositórios públicos no GitHub: jansenfelipe/ncm e felipemotabr/NCM). Os domínios oficiais gov.br (Receita Federal, Siscomex, Planalto, CGIBS) estavam bloqueados por política de rede deste ambiente e não puderam ser acessados diretamente — os números abaixo refletem essa limitação.",
    "Anexos de redução (LC 214/2025, com as alterações da LC 227/2026): cruzamento entre buscadorncm.com.br/reforma, leicomplementar214.com.br, taxradar.app e bananasoft.ai/dados/aliquotas-reduzidas-reforma. Não foi possível ler o texto literal e completo dos Anexos diretamente no site do Planalto (o documento é extenso e a ferramenta de leitura usada trunca antes de alcançar a seção de Anexos).",
    "⚠ Limitações — leia antes de usar em produção",
    "1) COBERTURA PARCIAL: esta tabela cobre aproximadamente 79% dos ~13.700 NCM vigentes hoje (faltam principalmente códigos mais recentes, pós-2022, em capítulos como 29, 30, 39, 84 e 85). Um NCM que não aparecer aqui não significa que ele não exista ou que tenha fator 100% — significa apenas que não foi possível confirmá-lo nas fontes acessíveis deste ambiente.",
    "2) MEDICAMENTOS (Capítulo 30 / NCM iniciando em \"30\"): o critério legal (LC 214/2025 art. 133 e art. 146, na redação da LC 227/2026) NÃO é definido pelo NCM, e sim pela finalidade terapêutica do registro na ANVISA e por compromisso do fabricante com a CMED/Comitê Gestor do IBS. As 423 linhas afetadas foram marcadas na coluna Categoria/Observação em vez de receberem um fator fixo — o fator real depende de uma lista dinâmica publicada a cada 120 dias. NÃO use o valor desta planilha para medicamentos sem confirmar o enquadramento do produto específico.",
    "3) ANEXOS NÃO INCLUÍDOS: Anexos da LC 214/2025 relativos a serviços (NBS) — saúde, educação, transporte público, produção cultural, profissões regulamentadas — não estão nesta planilha, que cobre apenas NCM (bens/mercadorias). A tabela também não inclui alguns Anexos secundários de baixo impacto (cultura, segurança, referenciais).",
    "4) FONTE DE VERDADE: para qualquer NCM específico usado em cobrança ou nota fiscal real, confirme o fator com a própria ferramenta da Kontiva (consulta de NCM por simulação) ou com o texto oficial da LC 214/2025 e da LC 227/2026 no Planalto — esta planilha é um material de apoio, não substitui essa confirmação.",
    "Legenda de cores (aba \"NCM x Fator IVA\", coluna Fator IVA)",
    "Verde: fator 0% (alíquota zero / isenção). Amarelo: fator reduzido, mas diferente de zero (ex.: 40%, 70%). Sem cor: fator 100% (alíquota padrão)."
  ]
} as const;
