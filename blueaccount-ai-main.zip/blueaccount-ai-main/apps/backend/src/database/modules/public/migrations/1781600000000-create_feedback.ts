import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateFeedback1781600000000 implements MigrationInterface {
  name = "CreateFeedback1781600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "feedback" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"escritorio_id" uuid, ` +
        `"usuario_id" uuid, ` +
        `"email" text, ` +
        `"mensagem" text NOT NULL, ` +
        `"pagina" text, ` +
        `"status" text NOT NULL DEFAULT 'aberto', ` +
        `"created_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_feedback" PRIMARY KEY ("id"), ` +
        `CONSTRAINT "FK_feedback_escritorio" FOREIGN KEY ("escritorio_id") ` +
        `REFERENCES "escritorios"("id") ON DELETE SET NULL, ` +
        `CONSTRAINT "FK_feedback_usuario" FOREIGN KEY ("usuario_id") ` +
        `REFERENCES "usuarios"("id") ON DELETE SET NULL)`,
    );

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_feedback_escritorio_id" ON "feedback" ("escritorio_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_feedback_usuario_id" ON "feedback" ("usuario_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_feedback_status" ON "feedback" ("status")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_feedback_created_at" ON "feedback" ("created_at")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_feedback_created_at"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_feedback_status"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_feedback_usuario_id"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_feedback_escritorio_id"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "feedback"`);
  }
}
