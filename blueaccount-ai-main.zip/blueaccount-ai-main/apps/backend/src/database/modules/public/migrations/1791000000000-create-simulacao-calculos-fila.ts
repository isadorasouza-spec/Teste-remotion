import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSimulacaoCalculosFila1791000000000 implements MigrationInterface {
  name = "CreateSimulacaoCalculosFila1791000000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "simulacao_calculos_fila" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "simulacao_id" uuid NOT NULL,
      "status" varchar(20) NOT NULL DEFAULT 'pendente',
      "versao_solicitada" bigint NOT NULL DEFAULT 1,
      "versao_processando" bigint,
      "tentativas" smallint NOT NULL DEFAULT 0,
      "disponivel_em" timestamptz NOT NULL DEFAULT now(),
      "erro" text,
      "lease_token" uuid,
      "lock_adquirido_em" timestamptz,
      "cancelamento_solicitado_em" timestamptz,
      "concluido_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_simulacao_calculos_fila" PRIMARY KEY ("id"),
      CONSTRAINT "UQ_simulacao_calculos_fila_alvo" UNIQUE ("escritorio_id", "simulacao_id"),
      CONSTRAINT "CHK_simulacao_calculos_fila_status" CHECK ("status" IN ('pendente', 'processando', 'concluido', 'erro', 'cancelado')),
      CONSTRAINT "CHK_simulacao_calculos_fila_lease" CHECK (
        ("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL AND "versao_processando" IS NOT NULL)
      )
    )`);
    await q.query(`CREATE INDEX "IDX_simulacao_calculos_fila_disponivel" ON "simulacao_calculos_fila" ("status", "disponivel_em", "atualizado_em")`);
    await q.query(`CREATE INDEX "IDX_simulacao_calculos_fila_lease" ON "simulacao_calculos_fila" ("status", "lock_adquirido_em") WHERE "status" = 'processando'`);
    await q.query(`CREATE TABLE "simulacao_fila_controle" (
      "id" smallint NOT NULL DEFAULT 1,
      "pausada" boolean NOT NULL DEFAULT false,
      "motivo" text,
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_simulacao_fila_controle" PRIMARY KEY ("id"),
      CONSTRAINT "CHK_simulacao_fila_controle_singleton" CHECK ("id" = 1)
    )`);
    await q.query(`INSERT INTO "simulacao_fila_controle" ("id", "pausada") VALUES (1, false)`);
    await q.query(`CREATE FUNCTION "public"."enfileirar_calculos_simulacao"(
      p_escritorio_id uuid, p_simulacao_ids uuid[], p_incrementar boolean DEFAULT true
    ) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path = pg_catalog, public
    AS $$
    BEGIN
      IF current_setting('app.escritorio_id', true) IS NULL
         OR current_setting('app.escritorio_id', true)::uuid IS DISTINCT FROM p_escritorio_id THEN
        RAISE EXCEPTION 'Contexto de escritório inválido para enfileirar cálculo.';
      END IF;
      INSERT INTO public.simulacao_calculos_fila
        (escritorio_id, simulacao_id, status, versao_solicitada, disponivel_em)
      SELECT p_escritorio_id, alvo, 'pendente', 1, now() FROM unnest(p_simulacao_ids) alvo
      ON CONFLICT (escritorio_id, simulacao_id) DO UPDATE SET
        versao_solicitada = CASE WHEN p_incrementar
          THEN simulacao_calculos_fila.versao_solicitada + 1 ELSE simulacao_calculos_fila.versao_solicitada END,
        status = CASE WHEN simulacao_calculos_fila.status = 'processando' THEN 'processando' ELSE 'pendente' END,
        tentativas = CASE WHEN simulacao_calculos_fila.status = 'processando' THEN simulacao_calculos_fila.tentativas ELSE 0 END,
        disponivel_em = CASE WHEN simulacao_calculos_fila.status = 'processando' THEN simulacao_calculos_fila.disponivel_em ELSE now() END,
        erro = NULL, cancelamento_solicitado_em = NULL, concluido_em = NULL, atualizado_em = now();
    END $$`);
    // Os roles tenant são criados dinamicamente. A função valida o escritorio_id contra a variável
    // transacional aplicada por runQueryWithRls antes de tocar a fila pública.
    await q.query(`GRANT EXECUTE ON FUNCTION "public"."enfileirar_calculos_simulacao"(uuid, uuid[], boolean) TO PUBLIC`);
    await q.query(`CREATE FUNCTION "public"."remover_calculo_simulacao_fila"(
      p_escritorio_id uuid, p_simulacao_id uuid
    ) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
    BEGIN
      IF current_setting('app.escritorio_id', true) IS NULL
         OR current_setting('app.escritorio_id', true)::uuid IS DISTINCT FROM p_escritorio_id THEN
        RAISE EXCEPTION 'Contexto de escritório inválido para remover cálculo.';
      END IF;
      DELETE FROM public.simulacao_calculos_fila
       WHERE escritorio_id = p_escritorio_id AND simulacao_id = p_simulacao_id;
    END $$`);
    await q.query(`GRANT EXECUTE ON FUNCTION "public"."remover_calculo_simulacao_fila"(uuid, uuid) TO PUBLIC`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP FUNCTION "public"."remover_calculo_simulacao_fila"(uuid, uuid)`);
    await q.query(`DROP FUNCTION "public"."enfileirar_calculos_simulacao"(uuid, uuid[], boolean)`);
    await q.query(`DROP TABLE "simulacao_fila_controle"`);
    await q.query(`DROP TABLE "simulacao_calculos_fila"`);
  }
}
