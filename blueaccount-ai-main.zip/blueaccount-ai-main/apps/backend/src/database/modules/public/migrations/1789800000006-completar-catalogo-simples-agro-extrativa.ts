import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Agropecuária, produção florestal, pesca e extrativa: 164 códigos no Anexo I.
 *
 * Venda de produção própria em estado natural não é industrialização, então Anexo I. **Não é
 * presunção:** o CNAE já separa os dois casos em divisões distintas - `0151201` é criação de bovinos,
 * `1011201` é o frigorífico que abate. Quem industrializa a produção própria exerce atividade de
 * divisão 10 a 32, que a regra por natureza já manda para o Anexo II.
 *
 * Se o contador não informar CNAE na linha de receita, vale o do cliente. O motor não tenta descobrir
 * qual das atividades cadastradas gerou aquela receita: calcula o que foi declarado.
 */
export class CompletarCatalogoSimplesAgroExtrativa1789800000006 implements MigrationInterface {
  name = "CompletarCatalogoSimplesAgroExtrativa1789800000006";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte", "situacao")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte, item.situacao
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  /** Só as divisões desta leva. As outras fontes respondem pelas suas. */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes"
        WHERE "fonte" = 'ibge/cnae/subclasses'
          AND left("codigo", 2) IN ('01', '02', '03', '05', '06', '07', '08', '09')`,
    );
  }
}
