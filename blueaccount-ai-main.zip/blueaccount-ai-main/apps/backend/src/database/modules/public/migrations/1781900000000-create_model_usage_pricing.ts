import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateModelUsagePricing1781900000000 implements MigrationInterface {
  name = "CreateModelUsagePricing1781900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "model_usage_pricing" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"model_id" text NOT NULL, ` +
        `"label" text, ` +
        `"price_per_1k_input_tokens" numeric NOT NULL DEFAULT 0, ` +
        `"price_per_1k_output_tokens" numeric NOT NULL DEFAULT 0, ` +
        `"ativo" boolean NOT NULL DEFAULT true, ` +
        `"created_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_model_usage_pricing" PRIMARY KEY ("id"), ` +
        `CONSTRAINT "UQ_model_usage_pricing_model_id" UNIQUE ("model_id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "model_usage_pricing"`);
  }
}
