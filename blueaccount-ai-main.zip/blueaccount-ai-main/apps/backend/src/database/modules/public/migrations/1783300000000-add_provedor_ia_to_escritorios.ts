import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona `provedor_ia` em `escritorios`: o provedor de IA externo do
 * escritório (`'chatgpt' | 'claude'`), usado pelo atalho "Perguntar ao
 * ChatGPT/Claude" da aplicação. Default `'chatgpt'` preserva o comportamento
 * para todas as linhas existentes. Espelha o estilo de
 * `1783200000000-add_report_agent_input_mode_to_escritorios`.
 */
export class AddProvedorIaToEscritorios1783300000000 implements MigrationInterface {
  name = "AddProvedorIaToEscritorios1783300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "provedor_ia" text NOT NULL DEFAULT 'chatgpt'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "provedor_ia"`,
    );
  }
}
