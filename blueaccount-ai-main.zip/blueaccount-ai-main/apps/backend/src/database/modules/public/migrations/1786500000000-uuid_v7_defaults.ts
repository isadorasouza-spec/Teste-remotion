import type { MigrationInterface, QueryRunner } from "typeorm";
import {
  SQL_CRIAR_FUNCAO_UUID_V7,
  SQL_VERIFICAR_FUNCAO_UUID_V7,
  sqlTrocarDefaultsUuid,
} from "../../../uuid-v7.js";

/**
 * Passa as chaves primárias do schema público a gerar UUIDv7 (ordenado por tempo) em vez de v4.
 *
 * Só troca o DEFAULT das colunas: nenhuma linha existente é reescrita, então as tabelas passam a
 * conter uma mistura de ids v4 (antigos) e v7 (novos). `ALTER COLUMN ... SET DEFAULT` mexe apenas
 * no catálogo — sem rewrite de tabela, seguro em produção.
 *
 * Cria também a função `public.uuid_generate_v7()`, usada pelas migrations de tenant. A ordem de
 * deploy já garante público antes de tenant (`migration:run` → `migration:sync-tenants`), mas a
 * migration de tenant repete o `CREATE OR REPLACE` para não depender disso.
 *
 * Detalhes de projeto (nome da função em inglês, ausência de `uuidv7()` nativo, DEFAULT sem
 * qualificação de schema): ver `src/database/uuid-v7.ts`.
 */
export class UuidV7Defaults1786500000000 implements MigrationInterface {
  name = "UuidV7Defaults1786500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(SQL_CRIAR_FUNCAO_UUID_V7);
    await queryRunner.query(SQL_VERIFICAR_FUNCAO_UUID_V7);
    await queryRunner.query(sqlTrocarDefaultsUuid("uuid_generate_v7"));
  }

  /**
   * Reverte os DEFAULTs para `gen_random_uuid()` — inclusive nas tabelas que originalmente usavam
   * `uuid_generate_v4()`. A assimetria é intencional: `gen_random_uuid()` é core desde o PG13,
   * enquanto `uuid_generate_v4()` depende da extensão `uuid-ossp`, que nenhuma migration cria.
   *
   * A função NÃO é derrubada. Schemas de tenant podem continuar com DEFAULTs que dependem dela, e
   * o `DROP` falharia (ou, com CASCADE, apagaria esses DEFAULTs). Uma função órfã é inofensiva.
   */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(sqlTrocarDefaultsUuid("gen_random_uuid"));
  }
}
