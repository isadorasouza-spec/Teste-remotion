import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";
import { Usuario } from "./usuario.entity.js";
import { Sessao } from "./sessao.entity.js";

export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

@Index("IDX_contexto_trace_id", ["trace_id"])
@Index("IDX_contexto_escritorio_id", ["escritorio_id"])
@Index("IDX_contexto_usuario_id", ["usuario_id"])
@Index("IDX_contexto_sessao_id", ["sessao_id"])
@Index("IDX_contexto_rota", ["rota"])
@Index("IDX_contexto_metodo", ["metodo"])
@Index("IDX_contexto_pagina", ["pagina"])
@Index("IDX_contexto_sucesso", ["sucesso"])
@Index("IDX_contexto_created_at", ["created_at"])
@Entity("contexto")
export class Contexto {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  trace_id!: string;

  @ManyToOne(() => Escritorio, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio> | null;

  @Column({ type: "uuid", nullable: true })
  escritorio_id!: string | null;

  @ManyToOne(() => Usuario, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "usuario_id" })
  usuario!: Relation<Usuario> | null;

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  // createForeignKeyConstraints: false — `sessoes` é UNLOGGED (migration
  // 1784112210638); tabela LOGGED não pode referenciar UNLOGGED. Mantém a relação
  // ORM; sessao_id vira referência solta (sessão some no truncate/purge).
  @ManyToOne(() => Sessao, { nullable: true, createForeignKeyConstraints: false })
  @JoinColumn({ name: "sessao_id" })
  sessao!: Relation<Sessao> | null;

  @Column({ type: "uuid", nullable: true })
  sessao_id!: string | null;

  @Column({ type: "text" })
  rota!: string;

  @Column({ type: "text" })
  metodo!: string;

  @Column({ type: "text", nullable: true })
  pagina!: string | null;

  @Column({ type: "int", nullable: true })
  status_code!: number | null;

  @Column({ type: "boolean", default: false })
  sucesso!: boolean;

  @Column({ type: "jsonb", nullable: true })
  request_payload!: JsonValue | null;

  @Column({ type: "jsonb", nullable: true })
  response_payload!: JsonValue | null;

  @Column({ type: "jsonb", nullable: true })
  error_payload!: JsonValue | null;

  @Column({ type: "int", nullable: true })
  latency_ms!: number | null;

  @CreateDateColumn()
  created_at!: Date;
}
