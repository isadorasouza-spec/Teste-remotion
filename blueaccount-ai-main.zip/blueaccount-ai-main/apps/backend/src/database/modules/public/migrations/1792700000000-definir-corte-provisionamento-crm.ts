import type { MigrationInterface, QueryRunner } from "typeorm";

export class DefinirCorteProvisionamentoCrm1792700000000 implements MigrationInterface {
  async up(q: QueryRunner): Promise<void> {
    // Marco aprovado em 15/09/2026 às 12:52:34 America/Sao_Paulo. Nunca usar now() aqui.
    await q.query(`ALTER TABLE public.crm_configuracao ADD COLUMN provisionar_criados_apos timestamptz
      NOT NULL DEFAULT TIMESTAMPTZ '2026-09-15 15:52:34+00'`);
    await q.query(`ALTER TABLE public.crm_vinculos ADD COLUMN negocio_criado_em timestamptz`);
  }
  async down(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE public.crm_vinculos DROP COLUMN negocio_criado_em`);
    await q.query(`ALTER TABLE public.crm_configuracao DROP COLUMN provisionar_criados_apos`);
  }
}
