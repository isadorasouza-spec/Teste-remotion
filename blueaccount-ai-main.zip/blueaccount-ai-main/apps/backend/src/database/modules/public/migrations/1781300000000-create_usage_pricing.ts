import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateUsagePricing1781300000000 implements MigrationInterface {
  name = "CreateUsagePricing1781300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "usage_pricing" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"price_per_ocr_page" numeric NOT NULL, ` +
        `"price_per_1k_input_tokens" numeric NOT NULL, ` +
        `"price_per_1k_output_tokens" numeric NOT NULL, ` +
        `"platform_monthly_fee" numeric NOT NULL, ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_usage_pricing" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "usage_pricing"`);
  }
}
