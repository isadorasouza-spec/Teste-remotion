import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona `locale` em `escritorios`: o idioma preferido do escritório
 * (`'pt' | 'en'`), base da internacionalização da plataforma. Default `'pt'`
 * preserva o comportamento para todas as linhas existentes. Primeiro consumidor:
 * o idioma da `explicacao` do CobrancaAgent. Espelha o estilo de
 * `1783300000000-add_provedor_ia_to_escritorios`.
 */
export class AddLocaleToEscritorios1784400000000 implements MigrationInterface {
  name = "AddLocaleToEscritorios1784400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "locale" text NOT NULL DEFAULT 'pt'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "locale"`,
    );
  }
}
