import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/** Catálogo compartilhado, versionado e somente leitura; NCM exato de oito dígitos. */
@Index("UQ_ncms_referencia_codigo", ["codigo"], { unique: true })
@Entity("ncms_referencia")
export class NcmReferencia {
  @Column({ type: "varchar", length: 40, nullable: true })
  versao_catalogo!: string | null;

  @Column({ type: "text", nullable: true })
  categoria!: string | null;

  @Column({ type: "text", nullable: true })
  observacao!: string | null;

  @Column({ type: "integer", nullable: true })
  fonte_linha!: number | null;

  @Column({ type: "varchar", length: 20, nullable: true })
  situacao_revisao!: "automatica" | "condicional" | "conflito" | null;

  @Column({ type: "jsonb", default: () => "'[]'::jsonb" })
  motivos_revisao!: string[];

  @Column({ type: "jsonb", default: () => "'[]'::jsonb" })
  evidencias_revisao!: Array<{ codigo: string; descricao: string; fator: number; fundamento: string; condicoes: string | null; automatica: boolean; fonte: string }>;
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /** Código NCM exato de oito dígitos, sem pontuação. */
  @Column({ type: "varchar", length: 8 })
  codigo!: string;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_ibs!: number;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_cbs!: number;

  /** Distingue uma regra explícita do default de 100% aplicado a todo NCM apenas cacheado. */
  @Column({ type: "boolean", default: false })
  fatores_configurados!: boolean;

  /** False quando o benefício exige confirmar produto, finalidade, registro ou adquirente. */
  @Column({ type: "boolean", default: true })
  aplicacao_automatica!: boolean;

  @Column({ type: "text", nullable: true })
  fundamento_legal_fatores!: string | null;

  @Column({ type: "text", nullable: true })
  condicoes_aplicacao_fatores!: string | null;

  @Column({ type: "varchar", length: 80, nullable: true })
  origem_configuracao_fatores!: string | null;

  @Column({ type: "text" })
  descricao!: string;

  /** Legado de armazenamento: catálogo local mantém array vazio. */
  @Column({ type: "text", array: true, nullable: true })
  descricoes_hierarquia!: string[] | null;

  @Column({ type: "date", nullable: true })
  data_inicio!: string | null;

  @Column({ type: "date", nullable: true })
  data_fim!: string | null;

  @Column({ type: "text", nullable: true })
  tipo_ato!: string | null;

  @Column({ type: "varchar", length: 20, nullable: true })
  numero_ato!: string | null;

  @Column({ type: "varchar", length: 4, nullable: true })
  ano_ato!: string | null;

  /** Legado de armazenamento: catálogo local mantém objeto vazio; origem anterior está no arquivo histórico. */
  @Column({ type: "jsonb" })
  resposta_brasilapi!: Record<string, unknown>;

  /** Legado de armazenamento, sempre nulo no catálogo local. */
  @Column({ type: "jsonb", nullable: true })
  resposta_arvore_brasilapi!: Record<string, unknown>[] | null;

  @UpdateDateColumn({ type: "timestamptz" })
  atualizado_em!: Date;
}
