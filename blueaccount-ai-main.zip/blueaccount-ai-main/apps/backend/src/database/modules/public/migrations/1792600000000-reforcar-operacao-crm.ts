import type { MigrationInterface, QueryRunner } from "typeorm";

export class ReforcarOperacaoCrm1792600000000 implements MigrationInterface {
  async up(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE public.crm_historico ALTER COLUMN vinculo_id DROP NOT NULL,
      ADD COLUMN ator text NOT NULL DEFAULT 'sistema:legado',
      ADD COLUMN contexto jsonb NOT NULL DEFAULT '{}'::jsonb`);
    await q.query(`ALTER TABLE public.crm_historico ALTER COLUMN ator SET DEFAULT 'sistema:hubspot'`);
    await q.query(`ALTER TABLE public.crm_vinculos ADD COLUMN motivo_fila text NOT NULL DEFAULT 'evento'
      CHECK (motivo_fila IN ('evento','reconciliacao'))`);
    await q.query(`CREATE INDEX crm_reconciliacao_idx ON public.crm_vinculos(sincronizado_em,id)
      WHERE status='concluido' AND NOT excluido`);
  }
  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP INDEX public.crm_reconciliacao_idx`);
    await q.query(`ALTER TABLE public.crm_vinculos DROP COLUMN motivo_fila`);
    await q.query(`DELETE FROM public.crm_historico WHERE vinculo_id IS NULL`);
    await q.query(`ALTER TABLE public.crm_historico DROP COLUMN ator, DROP COLUMN contexto,
      ALTER COLUMN vinculo_id SET NOT NULL`);
  }
}
