import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Construção civil, divisões 41 a 43: 31 códigos.
 *
 * 19 no Anexo IV pelo art. 18, §5º-C, I (construção de imóveis e obras de engenharia em geral,
 * inclusive sob a forma de subempreitada), 11 no Anexo III pelo residual do §5º-F por não serem obra
 * (preparação, demolição, sondagem, instalação, pintura, revestimento, administração) e 1 vedado pelo
 * art. 17, XIV, que é a incorporação de empreendimentos imobiliários.
 *
 * O Anexo IV **exclui a CPP** do recolhimento unificado (§5º-C, caput, e art. 13, VI). Isso não afeta o
 * valor do DAS, que já sai da tabela do anexo, mas significa que o encargo previdenciário patronal fica
 * fora do cálculo - e o motor não modela folha. Ver a nota em `domain/simulacoes/README.md`.
 */
export class CompletarCatalogoSimplesConstrucao1789800000007 implements MigrationInterface {
  name = "CompletarCatalogoSimplesConstrucao1789800000007";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte", "situacao")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte, item.situacao
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes"
        WHERE left("codigo", 2) IN ('41', '42', '43')
          AND "fonte" <> 'tabela-cnae.csv'`,
    );
  }
}
