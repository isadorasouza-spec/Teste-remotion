import type { MigrationInterface, QueryRunner } from "typeorm";

/** O worker assume roles tenant para documentos; sua role técnica só lê/atualiza a fila. */
export class ConcederFilaDistribuicaoWorker1792100000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    const credencial = process.env.DOCUMENTOS_FISCAIS_DB_USERNAME?.trim();
    if (!credencial) {
      if (process.env.DISTRIBUICAO_DFE_HABILITADA === "true") {
        throw new Error("DOCUMENTOS_FISCAIS_DB_USERNAME obrigatório para distribuição DFe");
      }
      return;
    }
    const [role] = await queryRunner.query(
      "SELECT rolsuper, rolbypassrls, rolinherit FROM pg_catalog.pg_roles WHERE rolname=$1", [credencial],
    );
    if (!role || role.rolsuper || role.rolbypassrls || role.rolinherit) {
      throw new Error("Worker DFe exige role existente NOSUPERUSER NOBYPASSRLS NOINHERIT");
    }
    const identificador = '"' + credencial.replace(/"/g, '""') + '"';
    await queryRunner.query(`GRANT SELECT, UPDATE ON public.distribuicoes_dfe_fila TO ${identificador}`);
  }

  async down(): Promise<void> {
    throw new Error("Reversão exige revisão dos grants preexistentes do worker DFe");
  }
}
