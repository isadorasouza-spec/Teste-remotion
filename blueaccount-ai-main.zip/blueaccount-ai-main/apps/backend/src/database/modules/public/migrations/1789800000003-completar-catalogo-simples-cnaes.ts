import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Completa `simples_cnaes` com os códigos de comércio e indústria derivados das subclasses oficiais do
 * IBGE.
 *
 * Existe porque `1789800000000` semeia INLINE: num banco que já a aplicou, crescer o arquivo de seed
 * não muda nada — a migration está registrada como executada e nunca roda de novo. Todo crescimento
 * futuro do catálogo precisa de uma migration própria como esta, e não de uma edição no seed original.
 *
 * `ON CONFLICT (codigo) DO NOTHING` deixa a operação idempotente e neutra nas duas direções: em banco
 * novo `1789800000000` já inseriu tudo e aqui não sobra nada para inserir; em banco já migrado entram
 * só os códigos que faltavam. Não há UPDATE de propósito — os códigos vindos do recorte curado de
 * serviços são autoritativos e não devem ser sobrescritos pela regra por divisão.
 */
export class CompletarCatalogoSimplesCnaes1789800000003 implements MigrationInterface {
  name = "CompletarCatalogoSimplesCnaes1789800000003";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       -- Só os enquadrados. Vedado e não-optante não têm anexo, e nesta altura o CHECK
       -- CK_simples_cnaes_fator_r ainda exige anexo para linha sem Fator R: eles entram em
       -- 1789800000004, depois que a coluna situacao existe e o CHECK é relaxado.
       WHERE item.situacao = 'enquadrado'
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  /**
   * Remove só o que veio da derivação por divisão. O recorte curado de serviços permanece: ele foi
   * inserido por `1789800000000` e é o `down` daquela migration que responde por ele.
   */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes" WHERE "fonte" = 'ibge/cnae/subclasses'`,
    );
  }
}
