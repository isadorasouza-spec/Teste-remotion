import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Fila pública durável das varreduras do `NFeDistribuicaoDFe`.
 *
 * `UQ_distribuicoes_dfe_em_curso` é single-flight por cliente: dois scans concorrentes do mesmo
 * CNPJ andariam o NSU fora de ordem, o que a SEFAZ pune com bloqueio de 1h (`cStat 656`).
 */
export class CreateDistribuicoesDfeFila1792000000000 implements MigrationInterface {
  name = "CreateDistribuicoesDfeFila1792000000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "distribuicoes_dfe_fila" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "certificado_id" uuid NOT NULL,
      "ambiente" varchar(12) NOT NULL DEFAULT 'producao',
      "cuf_autor" varchar(2) NOT NULL,
      "periodo_inicio" date NOT NULL,
      "periodo_fim" date NOT NULL,
      "status" varchar(20) NOT NULL DEFAULT 'pendente',
      "tentativas" smallint NOT NULL DEFAULT 0,
      "disponivel_em" timestamptz NOT NULL DEFAULT now(),
      "lease_token" uuid,
      "lock_adquirido_em" timestamptz,
      "documentos_completos" integer NOT NULL DEFAULT 0,
      "documentos_resumo" integer NOT NULL DEFAULT 0,
      "documentos_evento" integer NOT NULL DEFAULT 0,
      "documentos_duplicados" integer NOT NULL DEFAULT 0,
      "codigo_erro" varchar(80),
      "detalhe_erro" text,
      "concluido_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_distribuicoes_dfe_fila" PRIMARY KEY ("id"),
      CONSTRAINT "CHK_distribuicoes_dfe_status" CHECK ("status" IN ('pendente','processando','concluido','erro','cancelado')),
      CONSTRAINT "CHK_distribuicoes_dfe_lease" CHECK (("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL)),
      CONSTRAINT "CHK_distribuicoes_dfe_tentativas" CHECK ("tentativas" >= 0),
      CONSTRAINT "CHK_distribuicoes_dfe_ambiente" CHECK ("ambiente" IN ('producao','homologacao')),
      CONSTRAINT "CHK_distribuicoes_dfe_cuf" CHECK ("cuf_autor" ~ '^[0-9]{2}$'),
      CONSTRAINT "CHK_distribuicoes_dfe_periodo" CHECK ("periodo_fim" >= "periodo_inicio"),
      CONSTRAINT "CHK_distribuicoes_dfe_contadores" CHECK (
        "documentos_completos" >= 0 AND "documentos_resumo" >= 0
        AND "documentos_evento" >= 0 AND "documentos_duplicados" >= 0
      )
    )`);
    await q.query(`CREATE INDEX "IDX_distribuicoes_dfe_disponivel" ON "distribuicoes_dfe_fila" ("status", "disponivel_em")`);
    await q.query(`CREATE INDEX "IDX_distribuicoes_dfe_lease_token" ON "distribuicoes_dfe_fila" ("lease_token") WHERE "lease_token" IS NOT NULL`);
    await q.query(`CREATE INDEX "IDX_distribuicoes_dfe_cliente" ON "distribuicoes_dfe_fila" ("escritorio_id", "cliente_id", "criado_em")`);
    await q.query(`CREATE UNIQUE INDEX "UQ_distribuicoes_dfe_em_curso" ON "distribuicoes_dfe_fila" ("escritorio_id", "cliente_id", "ambiente") WHERE "status" IN ('pendente','processando')`);

    await q.query(`CREATE FUNCTION "public"."enfileirar_distribuicao_dfe"(
      p_escritorio_id uuid, p_cliente_id uuid, p_certificado_id uuid,
      p_ambiente varchar(12), p_cuf_autor varchar(2),
      p_periodo_inicio date, p_periodo_fim date
    ) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
    DECLARE
      v_id uuid;
    BEGIN
      IF current_setting('app.escritorio_id', true) IS NULL
         OR current_setting('app.escritorio_id', true)::uuid IS DISTINCT FROM p_escritorio_id THEN
        RAISE EXCEPTION 'Contexto de escritório inválido para enfileirar varredura DFe.';
      END IF;
      INSERT INTO public.distribuicoes_dfe_fila (
        escritorio_id, cliente_id, certificado_id, ambiente, cuf_autor,
        periodo_inicio, periodo_fim, status, disponivel_em
      ) VALUES (
        p_escritorio_id, p_cliente_id, p_certificado_id, p_ambiente, p_cuf_autor,
        p_periodo_inicio, p_periodo_fim, 'pendente', now()
      ) RETURNING id INTO v_id;
      RETURN v_id;
    END $$`);
    await q.query(`GRANT EXECUTE ON FUNCTION "public"."enfileirar_distribuicao_dfe"(uuid,uuid,uuid,varchar,varchar,date,date) TO PUBLIC`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP FUNCTION "public"."enfileirar_distribuicao_dfe"(uuid,uuid,uuid,varchar,varchar,date,date)`);
    await q.query(`DROP TABLE "distribuicoes_dfe_fila"`);
  }
}
