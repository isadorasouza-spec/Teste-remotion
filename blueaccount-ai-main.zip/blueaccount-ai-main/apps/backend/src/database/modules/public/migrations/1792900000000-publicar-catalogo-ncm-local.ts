import type { MigrationInterface, QueryRunner } from "typeorm";
import { carregarCatalogoNcm, registrarVersaoCatalogoNcm } from "./dados/carga-catalogo-ncm.js";

/** DDL gerado com TypeORM e revisado; carga e arquivo histórico na mesma transação. */
export class PublicarCatalogoNcmLocal1792900000000 implements MigrationInterface {
  name = "PublicarCatalogoNcmLocal1792900000000";
  async up(q: QueryRunner): Promise<void> {
    await q.query(`LOCK TABLE public.ncms_referencia IN ACCESS EXCLUSIVE MODE`);
    await q.query(`CREATE TABLE public.ncms_arquivo_20260916 AS SELECT * FROM public.ncms_referencia`);
    await q.query(`ALTER TABLE public.ncms_referencia
      ADD versao_catalogo varchar(40), ADD categoria text, ADD observacao text,
      ADD fonte_linha integer, ADD situacao_revisao varchar(20),
      ADD motivos_revisao jsonb NOT NULL DEFAULT '[]'::jsonb,
      ADD evidencias_revisao jsonb NOT NULL DEFAULT '[]'::jsonb`);
    await q.query(`DROP INDEX IF EXISTS public."IDX_ncms_referencia_fatores_configurados_codigo"`);
    await q.query(`CREATE TABLE public.ncm_catalogo_versoes (
      versao varchar(40) PRIMARY KEY, metadados jsonb NOT NULL, publicado_em timestamptz NOT NULL DEFAULT now()
    )`);
    await carregarCatalogoNcm(q);
    await q.query(`ALTER TABLE public.ncms_referencia ADD CONSTRAINT "CHK_ncm_catalogo_local"
      CHECK (codigo ~ '^[0-9]{8}$' AND versao_catalogo IS NOT NULL AND categoria IS NOT NULL
        AND fonte_linha IS NOT NULL AND fonte_linha >= 2 AND situacao_revisao IS NOT NULL AND situacao_revisao IN ('automatica', 'condicional', 'conflito')
        AND aplicacao_automatica = (situacao_revisao = 'automatica'))`);
    await registrarVersaoCatalogoNcm(q);
  }
  async down(): Promise<void> {
    throw new Error("Revisar public.ncms_arquivo_20260916 e publicar correção versionada sem alterar simulações históricas.");
  }
}
