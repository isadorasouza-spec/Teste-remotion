import type { MigrationInterface, QueryRunner } from "typeorm";

/** Fila WAL-durável. O enqueue participa da transação do ledger tenant. */
export class CriarFilaIngestaoFiscal1792300000000 implements MigrationInterface {
  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE public.ingestoes_fiscais_fila (
      id uuid PRIMARY KEY DEFAULT public.uuid_generate_v7(),
      escritorio_id uuid NOT NULL, cliente_id uuid NOT NULL, lote_id uuid NOT NULL,
      tentativa integer NOT NULL CHECK (tentativa >= 0), payload jsonb NOT NULL,
      status varchar(20) NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente','processando','concluido','erro')),
      tentativas integer NOT NULL DEFAULT 0 CHECK (tentativas >= 0),
      disponivel_em timestamptz NOT NULL DEFAULT now(),
      lease_token uuid, lock_adquirido_em timestamptz, codigo_erro varchar(80),
      criado_em timestamptz NOT NULL DEFAULT now(), atualizado_em timestamptz NOT NULL DEFAULT now(),
      UNIQUE (escritorio_id,lote_id,tentativa),
      CHECK ((status='processando') = (lease_token IS NOT NULL AND lock_adquirido_em IS NOT NULL))
    )`);
    await q.query(`CREATE INDEX ON public.ingestoes_fiscais_fila(status,disponivel_em)`);
    await q.query(`REVOKE ALL ON public.ingestoes_fiscais_fila FROM PUBLIC`);
    await q.query(`CREATE FUNCTION public.enfileirar_ingestao_fiscal(
      p_escritorio uuid,p_cliente uuid,p_lote uuid,p_tentativa integer,p_payload jsonb
    ) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,public AS $$
    DECLARE v_id uuid; v_valido boolean;
    BEGIN
      IF current_setting('app.escritorio_id',true)::uuid IS DISTINCT FROM p_escritorio THEN
        RAISE EXCEPTION 'Contexto de escritório inválido';
      END IF;
      EXECUTE format('SELECT EXISTS(SELECT 1 FROM %I.lotes_ingestao_documentos_fiscais WHERE id=$1 AND cliente_id=$2 AND escritorio_id=$3)',
        'escritorio_' || replace(p_escritorio::text,'-','_')) INTO v_valido USING p_lote,p_cliente,p_escritorio;
      IF NOT v_valido OR p_payload->>'escritorio_id' IS DISTINCT FROM p_escritorio::text
        OR p_payload->>'cliente_id' IS DISTINCT FROM p_cliente::text
        OR p_payload->>'lote_id' IS DISTINCT FROM p_lote::text THEN
        RAISE EXCEPTION 'Payload fora do ledger autenticado';
      END IF;
      INSERT INTO public.ingestoes_fiscais_fila(escritorio_id,cliente_id,lote_id,tentativa,payload)
      VALUES(p_escritorio,p_cliente,p_lote,p_tentativa,p_payload)
      ON CONFLICT(escritorio_id,lote_id,tentativa) DO UPDATE SET lote_id=EXCLUDED.lote_id
      RETURNING id INTO v_id;
      RETURN v_id;
    END $$`);
    const usuario = process.env.DOCUMENTOS_FISCAIS_DB_USERNAME?.trim();
    if (!usuario && process.env.DOCUMENTOS_FISCAIS_PROCESSADOR === "worker") {
      throw new Error("DOCUMENTOS_FISCAIS_DB_USERNAME obrigatório para a fila fiscal");
    }
    if (usuario) {
      const [role] = await q.query("SELECT rolsuper,rolbypassrls,rolinherit FROM pg_roles WHERE rolname=$1", [usuario]);
      if (!role || role.rolsuper || role.rolbypassrls || role.rolinherit) throw new Error("Worker exige NOSUPERUSER NOBYPASSRLS NOINHERIT");
      // A migration DFe antiga pode ter passado sem username; reparar o grant aqui também.
      await q.query(`GRANT SELECT,UPDATE ON public.ingestoes_fiscais_fila,public.distribuicoes_dfe_fila TO "${usuario.replace(/"/g, '""')}"`);
    }
  }
  async down(): Promise<void> {
    throw new Error("Remover a fila fiscal exige dreno e revisão dos trabalhos persistidos");
  }
}
