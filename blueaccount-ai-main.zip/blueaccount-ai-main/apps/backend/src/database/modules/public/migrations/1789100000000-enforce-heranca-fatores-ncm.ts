import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Toda regra configurada é uma regra hierárquica efetiva. Descendentes herdam o fator do prefixo
 * mais específico; alíquota cheia só pode ser representada por uma exceção filha com fator 1.
 */
export class EnforceHerancaFatoresNcm1789100000000 implements MigrationInterface {
  name = "EnforceHerancaFatoresNcm1789100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE "ncms_referencia"
      SET "aplicacao_automatica" = true
      WHERE "fatores_configurados" = true
    `);
    await queryRunner.query(`
      ALTER TABLE "ncms_referencia"
      ADD CONSTRAINT "CHK_ncms_regra_configurada_automatica"
      CHECK (NOT "fatores_configurados" OR "aplicacao_automatica")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "ncms_referencia"
      DROP CONSTRAINT "CHK_ncms_regra_configurada_automatica"
    `);
  }
}
