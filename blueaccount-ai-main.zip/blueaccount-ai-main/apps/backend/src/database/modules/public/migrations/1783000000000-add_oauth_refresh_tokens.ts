import { MigrationInterface, QueryRunner } from "typeorm";

export class AddOauthRefreshTokens1783000000000 implements MigrationInterface {
  name = "AddOauthRefreshTokens1783000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "oauth_access_tokens" ADD "family_id" uuid`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_access_tokens_family_id" ON "oauth_access_tokens" ("family_id")`);

    await queryRunner.query(`
      CREATE TABLE "oauth_refresh_tokens" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "token_hash" text NOT NULL,
        "family_id" uuid NOT NULL,
        "client_id" text NOT NULL,
        "usuario_id" uuid NOT NULL,
        "escritorio_id" uuid NOT NULL,
        "session_id_hash" text NOT NULL,
        "scope" text,
        "resource" text,
        "expires_at" TIMESTAMP NOT NULL,
        "revoked_at" TIMESTAMP,
        "last_seen_at" TIMESTAMP,
        "rotated_from_id" uuid,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_oauth_refresh_tokens_id" PRIMARY KEY ("id")
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_oauth_refresh_tokens_token_hash" ON "oauth_refresh_tokens" ("token_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_refresh_tokens_client_id" ON "oauth_refresh_tokens" ("client_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_refresh_tokens_session_id_hash" ON "oauth_refresh_tokens" ("session_id_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_refresh_tokens_family_id" ON "oauth_refresh_tokens" ("family_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_refresh_tokens_expires_at" ON "oauth_refresh_tokens" ("expires_at")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_refresh_tokens_expires_at"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_refresh_tokens_family_id"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_refresh_tokens_session_id_hash"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_refresh_tokens_client_id"`);
    await queryRunner.query(`DROP INDEX "public"."UQ_oauth_refresh_tokens_token_hash"`);
    await queryRunner.query(`DROP TABLE "oauth_refresh_tokens"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_access_tokens_family_id"`);
    await queryRunner.query(`ALTER TABLE "oauth_access_tokens" DROP COLUMN "family_id"`);
  }
}
