import { MigrationInterface, QueryRunner } from "typeorm";

export class AdicionarModoPlataforma1791300000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "public"."escritorios" ADD "modo_plataforma" text NOT NULL DEFAULT 'escritorio'`);
    await queryRunner.query(`ALTER TABLE "public"."escritorios" ADD CONSTRAINT "CHK_escritorios_modo_plataforma" CHECK ("modo_plataforma" IN ('escritorio', 'empresa'))`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "public"."escritorios" DROP CONSTRAINT "CHK_escritorios_modo_plataforma"`);
    await queryRunner.query(`ALTER TABLE "public"."escritorios" DROP COLUMN "modo_plataforma"`);
  }
}
