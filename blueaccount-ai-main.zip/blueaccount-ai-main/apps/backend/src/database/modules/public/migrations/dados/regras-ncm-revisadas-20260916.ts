/** Revisão de 16/09/2026. Fonte: LC 214/2025 consolidada pela LC 227/2026.
 * https://www2.camara.leg.br/legin/fed/leicom/2025/leicomplementar-214-16-janeiro-2025-796905-normaatualizada-pl.pdf
 * Regras condicionais são sugestões, nunca conclusões a partir da descrição livre.
 * Escopos não incluídos continuam no padrão; este catálogo não certifica todas as hipóteses legais.
 */
export type RegraNcmRevisada = { codigo: string; descricao: string; fator: number; fundamento: string; condicoes: string | null; automatica: boolean };
export const REGRAS_NCM_REVISADAS: readonly RegraNcmRevisada[] = [
  {
    "codigo": "0201",
    "descricao": "Carnes bovinas frescas ou refrigeradas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Carne ou produto animal expressamente abrangido, exceto exclusões legais.",
    "automatica": true
  },
  {
    "codigo": "0202",
    "descricao": "Carnes bovinas congeladas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Carne ou produto animal expressamente abrangido, exceto exclusões legais.",
    "automatica": true
  },
  {
    "codigo": "0203",
    "descricao": "Carnes suínas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Carne ou produto animal expressamente abrangido, exceto exclusões legais.",
    "automatica": true
  },
  {
    "codigo": "0204",
    "descricao": "Carnes ovinas ou caprinas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Carne ou produto animal expressamente abrangido, exceto exclusões legais.",
    "automatica": true
  },
  {
    "codigo": "02061000",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02062",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02063000",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02064",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02068000",
    "descricao": "Carne caprina ou miudezas ovinas/caprinas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": "Somente carne caprina ou miudezas comestíveis de ovinos/caprinos conforme o código.",
    "automatica": false
  },
  {
    "codigo": "02069000",
    "descricao": "Carne caprina ou miudezas ovinas/caprinas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": "Somente carne caprina ou miudezas comestíveis de ovinos/caprinos conforme o código.",
    "automatica": false
  },
  {
    "codigo": "0207",
    "descricao": "Carnes e miudezas de aves",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Carne ou produto animal expressamente abrangido, exceto os códigos 0207.43.00 e 0207.53.00.",
    "automatica": true
  },
  {
    "codigo": "02074300",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "02075300",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "020910",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02099000",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02101",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02102000",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "0210991",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02109920",
    "descricao": "Carnes, miudezas e produtos animais abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "02109990",
    "descricao": "Carne caprina ou miudezas ovinas/caprinas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 19",
    "condicoes": "Somente carne caprina ou miudezas comestíveis de ovinos/caprinos conforme o código.",
    "automatica": false
  },
  {
    "codigo": "0302",
    "descricao": "Peixes frescos ou refrigerados abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.",
    "automatica": true
  },
  {
    "codigo": "03021",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03023",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03025100",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03025200",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03025300",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03029",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "0303",
    "descricao": "Peixes congelados abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.",
    "automatica": true
  },
  {
    "codigo": "03031",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03034",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03036300",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03036400",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03036500",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "03039",
    "descricao": "Produtos excluídos da cesta básica",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo I, itens 19 e 20, exclusões; art. 137",
    "condicoes": "Não possui zero da cesta básica. Fator 0,4 somente mediante confirmação dos requisitos de produto in natura do art. 137 ou outra base legal aplicável.",
    "automatica": false
  },
  {
    "codigo": "0304",
    "descricao": "Filés e outras carnes de peixes abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.",
    "automatica": true
  },
  {
    "codigo": "03044",
    "descricao": "Filés e carnes de peixes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 20",
    "condicoes": "Zero somente para espécies abrangidas: excluídos salmonídeos, atuns, bacalhaus, hadoque e saithe. Confirmar espécie; exclusão pode exigir avaliar art. 137.",
    "automatica": false
  },
  {
    "codigo": "03045",
    "descricao": "Filés e carnes de peixes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 20",
    "condicoes": "Zero somente para espécies abrangidas: excluídos salmonídeos, atuns, bacalhaus, hadoque e saithe. Confirmar espécie; exclusão pode exigir avaliar art. 137.",
    "automatica": false
  },
  {
    "codigo": "03047",
    "descricao": "Filés e carnes de peixes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 20",
    "condicoes": "Zero somente para espécies abrangidas: excluídos salmonídeos, atuns, bacalhaus, hadoque e saithe. Confirmar espécie; exclusão pode exigir avaliar art. 137.",
    "automatica": false
  },
  {
    "codigo": "03048",
    "descricao": "Filés e carnes de peixes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 20",
    "condicoes": "Zero somente para espécies abrangidas: excluídos salmonídeos, atuns, bacalhaus, hadoque e saithe. Confirmar espécie; exclusão pode exigir avaliar art. 137.",
    "automatica": false
  },
  {
    "codigo": "03049",
    "descricao": "Filés e carnes de peixes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 20",
    "condicoes": "Zero somente para espécies abrangidas: excluídos salmonídeos, atuns, bacalhaus, hadoque e saithe. Confirmar espécie; exclusão pode exigir avaliar art. 137.",
    "automatica": false
  },
  {
    "codigo": "03061",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "030611",
    "descricao": "Crustáceos excluídos do Anexo VII",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo VII, item 1, exclusões; art. 137",
    "condicoes": "Redução somente se comprovada hipótese própria, como produto in natura do art. 137.",
    "automatica": false
  },
  {
    "codigo": "03061500",
    "descricao": "Crustáceos excluídos do Anexo VII",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo VII, item 1, exclusões; art. 137",
    "condicoes": "Redução somente se comprovada hipótese própria, como produto in natura do art. 137.",
    "automatica": false
  },
  {
    "codigo": "03063",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03063100",
    "descricao": "Crustáceos excluídos do Anexo VII",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo VII, item 1, exclusões; art. 137",
    "condicoes": "Redução somente se comprovada hipótese própria, como produto in natura do art. 137.",
    "automatica": false
  },
  {
    "codigo": "03063400",
    "descricao": "Crustáceos excluídos do Anexo VII",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo VII, item 1, exclusões; art. 137",
    "condicoes": "Redução somente se comprovada hipótese própria, como produto in natura do art. 137.",
    "automatica": false
  },
  {
    "codigo": "03063910",
    "descricao": "Crustáceos excluídos do Anexo VII",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo VII, item 1, exclusões; art. 137",
    "condicoes": "Redução somente se comprovada hipótese própria, como produto in natura do art. 137.",
    "automatica": false
  },
  {
    "codigo": "03073100",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03073200",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03074200",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "030743",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03075100",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03075200",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03079100",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "03079200",
    "descricao": "Crustáceos e moluscos abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "04011010",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04011090",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04012010",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04012090",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04014010",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04015010",
    "descricao": "Leite para consumo direto",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 2",
    "condicoes": "Atender aos requisitos legais de leite para consumo direto.",
    "automatica": false
  },
  {
    "codigo": "04021010",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04021090",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04022110",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04022120",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04022910",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04022920",
    "descricao": "Leite em pó",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 3",
    "condicoes": "Atender aos requisitos legais de leite em pó.",
    "automatica": false
  },
  {
    "codigo": "04032000",
    "descricao": "Leite fermentado",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026",
    "condicoes": "Atender à descrição e aos requisitos da legislação específica; conferir eventual enquadramento mais benéfico.",
    "automatica": false
  },
  {
    "codigo": "04039000",
    "descricao": "Outros leites fermentados e compostos lácteos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026",
    "condicoes": "Atender à descrição e aos requisitos da legislação específica; conferir eventual enquadramento mais benéfico.",
    "automatica": false
  },
  {
    "codigo": "04051000",
    "descricao": "Manteiga",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "04061010",
    "descricao": "Queijo muçarela",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipo de queijo expressamente abrangido.",
    "automatica": false
  },
  {
    "codigo": "04061090",
    "descricao": "Outros queijos frescos abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipos de queijo expressamente abrangidos.",
    "automatica": false
  },
  {
    "codigo": "04062000",
    "descricao": "Queijos ralados ou em pó",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipos de queijo expressamente abrangidos.",
    "automatica": false
  },
  {
    "codigo": "04069010",
    "descricao": "Outros queijos abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipos de queijo expressamente abrangidos.",
    "automatica": false
  },
  {
    "codigo": "04069020",
    "descricao": "Outros queijos abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipos de queijo expressamente abrangidos.",
    "automatica": false
  },
  {
    "codigo": "04069030",
    "descricao": "Outros queijos abrangidos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente tipos de queijo expressamente abrangidos.",
    "automatica": false
  },
  {
    "codigo": "04072",
    "descricao": "Ovos de aves, exceto para incubação",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 1",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "04090000",
    "descricao": "Mel natural",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "06",
    "descricao": "Plantas e produtos de floricultura",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 4",
    "condicoes": "Relativos à horticultura e cultivados para fins alimentares, ornamentais ou medicinais.",
    "automatica": false
  },
  {
    "codigo": "07",
    "descricao": "Produtos vegetais abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 14",
    "condicoes": "Confirmar ausência de açúcar/edulcorantes e exclusões de frutas de casca rija não regionais e dos Anexos I e XV.",
    "automatica": false
  },
  {
    "codigo": "0701",
    "descricao": "Batatas frescas ou refrigeradas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0702",
    "descricao": "Tomates frescos ou refrigerados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0703",
    "descricao": "Cebolas, alhos e produtos hortícolas semelhantes",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0704",
    "descricao": "Couves, couve-flor e produtos semelhantes",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0705",
    "descricao": "Alfaces e chicórias",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0706",
    "descricao": "Cenouras, nabos e raízes semelhantes",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0707",
    "descricao": "Pepinos e pepininhos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0708",
    "descricao": "Legumes de vagem frescos ou refrigerados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola no estado descrito na lei.",
    "automatica": true
  },
  {
    "codigo": "0709",
    "descricao": "Outros produtos hortícolas frescos ou refrigerados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 2",
    "condicoes": "Produto hortícola abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "07095",
    "descricao": "Exceção ao zero de hortícolas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo XV, item 2; art. 135, Anexo VII, item 14",
    "condicoes": "Confirmar descrição: excluído do zero do Anexo XV; redução conforme requisitos do Anexo VII.",
    "automatica": false
  },
  {
    "codigo": "0710",
    "descricao": "Hortícolas congelados; raízes e tubérculos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, itens 2 e 5",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "07108000",
    "descricao": "Exceção ao zero de hortícolas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, Anexo XV, item 2; art. 135, Anexo VII, item 14",
    "condicoes": "Confirmar descrição: excluído do zero do Anexo XV; redução conforme requisitos do Anexo VII.",
    "automatica": false
  },
  {
    "codigo": "0711",
    "descricao": "Produtos excluídos da redução alimentar",
    "fator": 1,
    "fundamento": "LC 214/2025, Anexo VII, item 14, exclusões",
    "condicoes": "Excluído do Anexo VII; verificar outro enquadramento específico.",
    "automatica": false
  },
  {
    "codigo": "07133319",
    "descricao": "Feijões comuns, outros",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Feijão abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "07133329",
    "descricao": "Feijão-preto, outros",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Feijão abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "07133399",
    "descricao": "Outros feijões",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Feijão abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "07133590",
    "descricao": "Feijão-fradinho, outros",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Feijão abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "0714",
    "descricao": "Hortícolas congelados; raízes e tubérculos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, itens 2 e 5",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "07141000",
    "descricao": "Raízes de mandioca",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 5",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "08",
    "descricao": "Produtos vegetais abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 14",
    "condicoes": "Confirmar ausência de açúcar/edulcorantes e exclusões de frutas de casca rija não regionais e dos Anexos I e XV.",
    "automatica": false
  },
  {
    "codigo": "08011",
    "descricao": "Cocos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 6",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "0803",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0804",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0805",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0806",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0807",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0808",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0809",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0810",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0811",
    "descricao": "Frutas frescas, refrigeradas ou congeladas",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 148, Anexo XV, item 3",
    "condicoes": "Confirmar apresentação abrangida; congeladas sem açúcar ou edulcorantes. Não aplicar automaticamente a frutas secas.",
    "automatica": false
  },
  {
    "codigo": "0812",
    "descricao": "Produtos excluídos da redução alimentar",
    "fator": 1,
    "fundamento": "LC 214/2025, Anexo VII, item 14, exclusões",
    "condicoes": "Excluído do Anexo VII; verificar outro enquadramento específico.",
    "automatica": false
  },
  {
    "codigo": "08140000",
    "descricao": "Produtos excluídos da redução alimentar",
    "fator": 1,
    "fundamento": "LC 214/2025, Anexo VII, item 14, exclusões",
    "condicoes": "Excluído do Anexo VII; verificar outro enquadramento específico.",
    "automatica": false
  },
  {
    "codigo": "0901",
    "descricao": "Café",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Café abrangido pela apresentação e descrição legal.",
    "automatica": true
  },
  {
    "codigo": "0903",
    "descricao": "Mate",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Mate abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "10",
    "descricao": "Cereais, sementes e frutos oleaginosos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 15",
    "condicoes": "Confirmar produto destinado ao consumo humano; prevalecem as exceções da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "100620",
    "descricao": "Arroz descascado",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "100630",
    "descricao": "Arroz semibranqueado ou branqueado",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "10064000",
    "descricao": "Arroz quebrado",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "1101",
    "descricao": "Farinhas destinadas ao consumo humano",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 4",
    "condicoes": "Confirmar produto e destinação ao consumo humano.",
    "automatica": false
  },
  {
    "codigo": "11010010",
    "descricao": "Farinha de trigo",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 13",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "1102",
    "descricao": "Farinhas destinadas ao consumo humano",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 4",
    "condicoes": "Confirmar produto e destinação ao consumo humano.",
    "automatica": false
  },
  {
    "codigo": "11022000",
    "descricao": "Farinha de milho",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "11029000",
    "descricao": "Outras farinhas de cereais",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente farinha de aveia abrangida pela descrição legal.",
    "automatica": false
  },
  {
    "codigo": "11031100",
    "descricao": "Grumos, sêmolas e grãos de cereais",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, itens 5 e 6",
    "condicoes": "Destinação ao consumo humano; prevalecem itens da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "11031300",
    "descricao": "Grumos e sêmolas de milho",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "11031900",
    "descricao": "Grumos, sêmolas e grãos de cereais",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, itens 5 e 6",
    "condicoes": "Destinação ao consumo humano; prevalecem itens da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "11041",
    "descricao": "Grumos, sêmolas e grãos de cereais",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, itens 5 e 6",
    "condicoes": "Destinação ao consumo humano; prevalecem itens da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "11041200",
    "descricao": "Grãos de aveia esmagados ou em flocos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "11041900",
    "descricao": "Outros grãos de cereais trabalhados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente grãos de milho abrangidos pela descrição legal.",
    "automatica": false
  },
  {
    "codigo": "11042",
    "descricao": "Grumos, sêmolas e grãos de cereais",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, itens 5 e 6",
    "condicoes": "Destinação ao consumo humano; prevalecem itens da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "11042200",
    "descricao": "Outros grãos de aveia trabalhados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "11042300",
    "descricao": "Outros grãos de milho trabalhados",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "1105",
    "descricao": "Farinhas destinadas ao consumo humano",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 4",
    "condicoes": "Confirmar produto e destinação ao consumo humano.",
    "automatica": false
  },
  {
    "codigo": "1106",
    "descricao": "Farinhas destinadas ao consumo humano",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 4",
    "condicoes": "Confirmar produto e destinação ao consumo humano.",
    "automatica": false
  },
  {
    "codigo": "11062000",
    "descricao": "Farinha de mandioca",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": false
  },
  {
    "codigo": "11081200",
    "descricao": "Amido de milho",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "12",
    "descricao": "Cereais, sementes e frutos oleaginosos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 15",
    "condicoes": "Confirmar produto destinado ao consumo humano; prevalecem as exceções da cesta básica.",
    "automatica": false
  },
  {
    "codigo": "1208",
    "descricao": "Farinhas destinadas ao consumo humano",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 4",
    "condicoes": "Confirmar produto e destinação ao consumo humano.",
    "automatica": false
  },
  {
    "codigo": "150790",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "1508",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "1511",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "1512",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "1513",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "15132120",
    "descricao": "Óleo de babaçu",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Atender à legislação específica para consumo como alimento.",
    "automatica": false
  },
  {
    "codigo": "1514",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "1515",
    "descricao": "Óleos vegetais alimentares",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 8",
    "condicoes": "Confirmar requisitos para consumo como alimento; babaçu abrangido tem regra específica.",
    "automatica": false
  },
  {
    "codigo": "15171000",
    "descricao": "Margarina",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "17011400",
    "descricao": "Açúcar abrangido pela cesta básica",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 14",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "17019900",
    "descricao": "Açúcar abrangido pela cesta básica",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 125, Anexo I, item 14",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "19011010",
    "descricao": "Fórmulas infantis acondicionadas para venda a retalho",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Fórmula infantil conforme os requisitos da legislação específica.",
    "automatica": false
  },
  {
    "codigo": "19011090",
    "descricao": "Outras fórmulas infantis",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Fórmula infantil conforme os requisitos da legislação específica.",
    "automatica": false
  },
  {
    "codigo": "19012010",
    "descricao": "Pré-mistura para pão francês",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente pré-mistura ou massa destinada ao pão francês descrito na lei.",
    "automatica": false
  },
  {
    "codigo": "19012090",
    "descricao": "Massa para pão francês",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente pré-mistura ou massa destinada ao pão francês descrito na lei.",
    "automatica": false
  },
  {
    "codigo": "19019090",
    "descricao": "Farinha com baixo teor de proteína",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente produto destinado às condições metabólicas descritas na lei.",
    "automatica": false
  },
  {
    "codigo": "19021",
    "descricao": "Massas alimentícias não cozidas nem recheadas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto abrangido pela descrição legal; conferir fórmula especial quando aplicável.",
    "automatica": true
  },
  {
    "codigo": "19021900",
    "descricao": "Massa com baixo teor de proteína",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente produto destinado às condições metabólicas descritas na lei.",
    "automatica": true
  },
  {
    "codigo": "19022000",
    "descricao": "Massas alimentícias recheadas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "19023000",
    "descricao": "Outras massas alimentícias",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "19030000",
    "descricao": "Tapioca e seus sucedâneos",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto destinado à alimentação humana conforme a descrição legal.",
    "automatica": true
  },
  {
    "codigo": "19059010",
    "descricao": "Pão de forma",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "19059090",
    "descricao": "Pão francês",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente pão francês com formato, composição e requisitos descritos na lei.",
    "automatica": false
  },
  {
    "codigo": "20021000",
    "descricao": "Hortícolas preparados abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 16",
    "condicoes": "Apenas pré-cozidos ou cozidos em água/vapor, sem sal ou outras substâncias.",
    "automatica": false
  },
  {
    "codigo": "20029000",
    "descricao": "Extrato de tomate",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "2004",
    "descricao": "Hortícolas preparados abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 16",
    "condicoes": "Apenas pré-cozidos ou cozidos em água/vapor, sem sal ou outras substâncias.",
    "automatica": false
  },
  {
    "codigo": "2005",
    "descricao": "Hortícolas preparados abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, item 16",
    "condicoes": "Apenas pré-cozidos ou cozidos em água/vapor, sem sal ou outras substâncias.",
    "automatica": false
  },
  {
    "codigo": "2008",
    "descricao": "Polpas, frutas e sementes abrangidas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135, Anexo VII, itens 11 e 17",
    "condicoes": "Somente polpas sem açúcar/edulcorantes e conservantes ou produtos do item 17 apenas torrados/cozidos, sem sal e outras substâncias.",
    "automatica": false
  },
  {
    "codigo": "2009",
    "descricao": "Sucos de frutas ou produtos hortícolas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 135 e Anexo VII",
    "condicoes": "Natural, sem adição de açúcar, edulcorantes ou conservantes, conforme a descrição legal.",
    "automatica": false
  },
  {
    "codigo": "21011",
    "descricao": "Extratos, essências e concentrados de café",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Produto de café abrangido pela descrição legal.",
    "automatica": true
  },
  {
    "codigo": "21069090",
    "descricao": "Fórmulas infantis ou dietoterápicas abrangidas",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Somente fórmula infantil ou dietoterápica para erro inato do metabolismo expressamente abrangida.",
    "automatica": false
  },
  {
    "codigo": "22029900",
    "descricao": "Bebidas e compostos lácteos ou fórmulas específicas",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026",
    "condicoes": "Anexo VII, item 2: bebidas e compostos lácteos, conforme legislação; Anexo VI: apenas fórmulas expressamente relacionadas. Não estender a todas as bebidas vegetais.",
    "automatica": false
  },
  {
    "codigo": "25010020",
    "descricao": "Sal para consumo humano",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Atender ao teor de iodo e demais requisitos da legislação específica.",
    "automatica": false
  },
  {
    "codigo": "25010090",
    "descricao": "Outro sal para consumo humano",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 125 e Anexo I",
    "condicoes": "Atender ao teor de iodo e demais requisitos da legislação específica.",
    "automatica": false
  },
  {
    "codigo": "3003",
    "descricao": "Medicamentos não acondicionados para venda a retalho",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 133",
    "condicoes": "Medicamento registrado na Anvisa ou produzido por farmácia de manipulação; conferir hipóteses de alíquota zero do art. 146.",
    "automatica": false
  },
  {
    "codigo": "3004",
    "descricao": "Medicamentos acondicionados para venda a retalho",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 133",
    "condicoes": "Medicamento registrado na Anvisa ou produzido por farmácia de manipulação; conferir hipóteses de alíquota zero do art. 146.",
    "automatica": false
  },
  {
    "codigo": "31",
    "descricao": "Fertilizantes",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 138, Anexo IX, itens 1 e 2",
    "condicoes": "Confirmar descrição e registro como insumo agropecuário/aquícola quando exigido; avaliar diferimento da operação.",
    "automatica": false
  },
  {
    "codigo": "33061000",
    "descricao": "Produtos de higiene e limpeza abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "34011190",
    "descricao": "Produtos de higiene e limpeza abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "34011900",
    "descricao": "Produtos de higiene e limpeza abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "3808",
    "descricao": "Inseticidas e produtos semelhantes",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 138, Anexo IX",
    "condicoes": "Somente insumo agropecuário ou aquícola registrado e na finalidade prevista em lei.",
    "automatica": false
  },
  {
    "codigo": "38089419",
    "descricao": "Água sanitária",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII, item 5",
    "condicoes": "Somente água sanitária, não todos os desinfetantes do código.",
    "automatica": false
  },
  {
    "codigo": "48181000",
    "descricao": "Produtos de higiene e limpeza abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "4901",
    "descricao": "Livros, brochuras e impressos semelhantes",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 9º, IV",
    "condicoes": "Imunidade para livros abrangidos; confirmar natureza do impresso. Não confundir imunidade com alíquota zero.",
    "automatica": false
  },
  {
    "codigo": "83024100",
    "descricao": "Dispositivos de acessibilidade abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII",
    "condicoes": "Confirmar descrição exata do Anexo XIII e requisitos do órgão competente; 83024100 apenas barras de apoio e 90219019 apenas implantes cocleares.",
    "automatica": false
  },
  {
    "codigo": "8713",
    "descricao": "Cadeiras de rodas e veículos para pessoas com deficiência",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII, item 2",
    "condicoes": "Atender aos requisitos da norma do órgão competente.",
    "automatica": false
  },
  {
    "codigo": "87142000",
    "descricao": "Dispositivos de acessibilidade abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII",
    "condicoes": "Confirmar descrição exata do Anexo XIII e requisitos do órgão competente; 83024100 apenas barras de apoio e 90219019 apenas implantes cocleares.",
    "automatica": false
  },
  {
    "codigo": "9018",
    "descricao": "Instrumentos e aparelhos para medicina, cirurgia e odontologia",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 131 e 144 e Anexos IV e XII",
    "condicoes": "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.",
    "automatica": false
  },
  {
    "codigo": "901812",
    "descricao": "Dispositivos médicos abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 144, Anexo XII, itens 13 a 17",
    "condicoes": "Confirmar descrição específica do Anexo XII e requisitos Anvisa; não basta o código compartilhado.",
    "automatica": false
  },
  {
    "codigo": "90181300",
    "descricao": "Dispositivos médicos abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 144, Anexo XII, itens 13 a 17",
    "condicoes": "Confirmar descrição específica do Anexo XII e requisitos Anvisa; não basta o código compartilhado.",
    "automatica": false
  },
  {
    "codigo": "90181980",
    "descricao": "Dispositivos médicos abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 144, Anexo XII, itens 13 a 17",
    "condicoes": "Confirmar descrição específica do Anexo XII e requisitos Anvisa; não basta o código compartilhado.",
    "automatica": false
  },
  {
    "codigo": "90189010",
    "descricao": "Dispositivos médicos abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 144, Anexo XII, itens 13 a 17",
    "condicoes": "Confirmar descrição específica do Anexo XII e requisitos Anvisa; não basta o código compartilhado.",
    "automatica": false
  },
  {
    "codigo": "9019",
    "descricao": "Aparelhos de mecanoterapia, massagem e terapia respiratória",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 131 e 144 e Anexos IV e XII",
    "condicoes": "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.",
    "automatica": false
  },
  {
    "codigo": "90192040",
    "descricao": "Dispositivos médicos abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 144, Anexo XII, itens 13 a 17",
    "condicoes": "Confirmar descrição específica do Anexo XII e requisitos Anvisa; não basta o código compartilhado.",
    "automatica": false
  },
  {
    "codigo": "9020",
    "descricao": "Outros aparelhos respiratórios e máscaras contra gases",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 131 e 144 e Anexos IV e XII",
    "condicoes": "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.",
    "automatica": false
  },
  {
    "codigo": "9021",
    "descricao": "Dispositivos ortopédicos e de acessibilidade",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128, 131 e 132 e Anexos IV e V",
    "condicoes": "Dispositivo listado e regularizado perante a Anvisa ou órgão competente; observar adquirente e finalidade quando exigidos.",
    "automatica": false
  },
  {
    "codigo": "90214000",
    "descricao": "Dispositivos de acessibilidade abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII",
    "condicoes": "Confirmar descrição exata do Anexo XIII e requisitos do órgão competente; 83024100 apenas barras de apoio e 90219019 apenas implantes cocleares.",
    "automatica": false
  },
  {
    "codigo": "90219019",
    "descricao": "Dispositivos de acessibilidade abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII",
    "condicoes": "Confirmar descrição exata do Anexo XIII e requisitos do órgão competente; 83024100 apenas barras de apoio e 90219019 apenas implantes cocleares.",
    "automatica": false
  },
  {
    "codigo": "90219092",
    "descricao": "Dispositivos de acessibilidade abrangidos",
    "fator": 0,
    "fundamento": "LC 214/2025, art. 145, Anexo XIII",
    "condicoes": "Confirmar descrição exata do Anexo XIII e requisitos do órgão competente; 83024100 apenas barras de apoio e 90219019 apenas implantes cocleares.",
    "automatica": false
  },
  {
    "codigo": "9022",
    "descricao": "Aparelhos de raios X e outros dispositivos médicos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 128 e 131 e Anexo IV",
    "condicoes": "Dispositivo listado e regularizado perante a Anvisa.",
    "automatica": false
  },
  {
    "codigo": "9402",
    "descricao": "Mobiliário médico, cirúrgico, odontológico ou veterinário",
    "fator": 0.4,
    "fundamento": "LC 214/2025, arts. 131 e 144 e Anexos IV e XII",
    "condicoes": "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.",
    "automatica": false
  },
  {
    "codigo": "96032100",
    "descricao": "Produtos de higiene e limpeza abrangidos",
    "fator": 0.4,
    "fundamento": "LC 214/2025, art. 136, Anexo VIII",
    "condicoes": null,
    "automatica": true
  },
  {
    "codigo": "96190000",
    "descricao": "Absorventes, tampões, calcinhas absorventes e coletores menstruais",
    "fator": 0.0,
    "fundamento": "LC 214/2025, art. 147",
    "condicoes": "Saúde menstrual do art. 147 e requisitos Anvisa: fator 0. Fraldas e semelhantes do Anexo VIII, item 7: fator 0,4. Confirmar produto e informar o fator correto na entrada.",
    "automatica": false
  }
];
