import type { MigrationInterface, QueryRunner } from "typeorm";

/** Fila pública durável do worker que consulta NFC-e por chave de acesso no portal da SEFAZ. */
export class CreateConsultasChavesFiscaisFila1791500000000 implements MigrationInterface {
  name = "CreateConsultasChavesFiscaisFila1791500000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "consultas_chaves_fiscais_fila" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "chave_acesso" varchar(44) NOT NULL,
      "uf" varchar(2) NOT NULL,
      "status" varchar(20) NOT NULL DEFAULT 'pendente',
      "tentativas" smallint NOT NULL DEFAULT 0,
      "disponivel_em" timestamptz NOT NULL DEFAULT now(),
      "lease_token" uuid,
      "lock_adquirido_em" timestamptz,
      "lote_id" uuid,
      "codigo_erro" varchar(80),
      "detalhe_erro" text,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_consultas_chaves_fiscais_fila" PRIMARY KEY ("id"),
      CONSTRAINT "UQ_consultas_chaves_fiscais_alvo" UNIQUE ("escritorio_id", "cliente_id", "chave_acesso"),
      CONSTRAINT "CHK_consultas_chaves_fiscais_status" CHECK ("status" IN ('pendente','processando','concluido','erro','cancelado')),
      CONSTRAINT "CHK_consultas_chaves_fiscais_lease" CHECK (("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL)),
      CONSTRAINT "CHK_consultas_chaves_fiscais_tentativas" CHECK ("tentativas" >= 0),
      CONSTRAINT "CHK_consultas_chaves_fiscais_chave" CHECK ("chave_acesso" ~ '^[0-9]{44}$')
    )`);
    await q.query(`CREATE INDEX "IDX_consultas_chaves_fiscais_disponivel" ON "consultas_chaves_fiscais_fila" ("status", "disponivel_em")`);
    await q.query(`CREATE INDEX "IDX_consultas_chaves_fiscais_lease_token" ON "consultas_chaves_fiscais_fila" ("lease_token") WHERE "lease_token" IS NOT NULL`);

    await q.query(`CREATE FUNCTION "public"."enfileirar_consulta_chave_fiscal"(
      p_escritorio_id uuid, p_cliente_id uuid, p_chave_acesso varchar(44), p_uf varchar(2)
    ) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
    DECLARE
      v_id uuid;
    BEGIN
      IF current_setting('app.escritorio_id', true) IS NULL
         OR current_setting('app.escritorio_id', true)::uuid IS DISTINCT FROM p_escritorio_id THEN
        RAISE EXCEPTION 'Contexto de escritório inválido para enfileirar consulta de chave fiscal.';
      END IF;
      INSERT INTO public.consultas_chaves_fiscais_fila (
        escritorio_id, cliente_id, chave_acesso, uf, status, disponivel_em
      ) VALUES (
        p_escritorio_id, p_cliente_id, p_chave_acesso, p_uf, 'pendente', now()
      ) ON CONFLICT (escritorio_id, cliente_id, chave_acesso) DO UPDATE SET
        uf = EXCLUDED.uf,
        status = CASE WHEN consultas_chaves_fiscais_fila.status = 'processando' THEN 'processando' ELSE 'pendente' END,
        tentativas = CASE WHEN consultas_chaves_fiscais_fila.status = 'processando' THEN consultas_chaves_fiscais_fila.tentativas ELSE 0 END,
        disponivel_em = CASE WHEN consultas_chaves_fiscais_fila.status = 'processando' THEN consultas_chaves_fiscais_fila.disponivel_em ELSE now() END,
        codigo_erro = NULL, detalhe_erro = NULL, atualizado_em = now()
      RETURNING id INTO v_id;
      RETURN v_id;
    END $$`);
    await q.query(`GRANT EXECUTE ON FUNCTION "public"."enfileirar_consulta_chave_fiscal"(uuid,uuid,varchar,varchar) TO PUBLIC`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP FUNCTION "public"."enfileirar_consulta_chave_fiscal"(uuid,uuid,varchar,varchar)`);
    await q.query(`DROP TABLE "consultas_chaves_fiscais_fila"`);
  }
}
