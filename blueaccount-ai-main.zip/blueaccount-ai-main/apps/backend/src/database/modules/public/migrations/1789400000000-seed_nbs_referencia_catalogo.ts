import type { MigrationInterface, QueryRunner } from "typeorm";
import { CATALOGO_NBS, type ItemCatalogoNbs } from "./dados/nbs-catalogo-2.0.js";

const TAMANHO_LOTE = 200;

/**
 * Semeia o catálogo local da NBS 2.0 (`dados/nbs-catalogo-2.0.ts`, ~1200 códigos gerados do Anexo B
 * da NFS-e Nacional — ver `scripts/gerar-catalogo-nbs.mjs`). Diferente do cache de NCM (lazy, via
 * BrasilAPI), este catálogo nasce cheio: não existe fonte pública gratuita equivalente para NBS.
 *
 * `fatores_configurados` nasce `false` para toda linha — a migration seguinte
 * (`seed_regras_legais_nbs`) marca `true` apenas nos prefixos com regra legal curada. O `ON CONFLICT`
 * atualiza somente descrição/hierarquia, nunca as colunas de fator/regra: reexecutar este seed (ex.:
 * reimportar uma planilha mais nova) não pode reverter uma regra legal já aplicada.
 */
export class SeedNbsReferenciaCatalogo1789400000000 implements MigrationInterface {
  name = "SeedNbsReferenciaCatalogo1789400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    for (let inicio = 0; inicio < CATALOGO_NBS.length; inicio += TAMANHO_LOTE) {
      const lote = CATALOGO_NBS.slice(inicio, inicio + TAMANHO_LOTE);
      await inserirLote(queryRunner, lote);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const codigos = CATALOGO_NBS.map((item) => item.codigo);
    for (let inicio = 0; inicio < codigos.length; inicio += TAMANHO_LOTE) {
      const lote = codigos.slice(inicio, inicio + TAMANHO_LOTE);
      await queryRunner.query(
        `DELETE FROM "nbs_referencia" WHERE "codigo" = ANY($1::varchar[])`,
        [lote],
      );
    }
  }
}

async function inserirLote(queryRunner: QueryRunner, lote: ItemCatalogoNbs[]): Promise<void> {
  const parametros: unknown[] = [];
  const linhas = lote.map((item, indice) => {
    const base = indice * 4;
    parametros.push(item.codigo, item.descricao, item.hierarquia, "nbs-2.0-anexo-b");
    return `($${base + 1}, $${base + 2}, $${base + 3}::text[], $${base + 4})`;
  });
  await queryRunner.query(
    `INSERT INTO "nbs_referencia" ("codigo", "descricao", "descricoes_hierarquia", "origem_configuracao_fatores")
     VALUES ${linhas.join(", ")}
     ON CONFLICT ("codigo") DO UPDATE SET
       "descricao" = EXCLUDED."descricao",
       "descricoes_hierarquia" = EXCLUDED."descricoes_hierarquia"`,
    parametros,
  );
}
