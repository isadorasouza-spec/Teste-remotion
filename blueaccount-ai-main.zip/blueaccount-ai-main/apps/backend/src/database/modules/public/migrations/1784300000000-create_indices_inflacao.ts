import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateIndicesInflacao1784300000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS indices_inflacao (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        indice VARCHAR(20) NOT NULL,
        competencia VARCHAR(7) NOT NULL,
        percentual_mensal NUMERIC(10,6) NOT NULL,
        fonte TEXT NOT NULL DEFAULT 'BCB/SGS',
        coletado_em TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT UQ_indices_inflacao_indice_competencia UNIQUE (indice, competencia)
      );
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS indices_inflacao;`);
  }
}
