import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Migration separada para que bancos que executaram a primeira versão da
 * migration de MFA também recebam a trilha de auditoria retida.
 */
export class CreateEventosAuditoriaSeguranca1789600000001 implements MigrationInterface {
  name = "CreateEventosAuditoriaSeguranca1789600000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "eventos_auditoria_seguranca" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "evento" text NOT NULL,
        "identidade_tipo" text NOT NULL,
        "usuario_id" uuid,
        "resultado" text NOT NULL,
        "metadados" jsonb,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_eventos_auditoria_seguranca" PRIMARY KEY ("id"),
        CONSTRAINT "CK_eventos_auditoria_identidade" CHECK ("identidade_tipo" IN ('usuario', 'admin_plataforma')),
        CONSTRAINT "CK_eventos_auditoria_resultado" CHECK ("resultado" IN ('sucesso', 'falha'))
      )
    `);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_eventos_auditoria_seguranca_evento" ON "eventos_auditoria_seguranca" ("evento")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_eventos_auditoria_seguranca_created_at" ON "eventos_auditoria_seguranca" ("created_at")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "eventos_auditoria_seguranca"`);
  }
}
