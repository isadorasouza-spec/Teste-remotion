// Gerado por scripts/gerar-catalogo-simples-cnaes.mjs. Não editar manualmente.
// Serviços (Anexos III/IV/V e Fator R) vêm de tabela-cnae.csv; comércio (divisões 45-47, Anexo I) e
// indústria de transformação (divisões 10-32, Anexo II) são derivados das subclasses oficiais do
// IBGE pela natureza da atividade (LC 123/2006, art. 18, §4º, I e II). A coluna `fonte` registra
// a procedência de cada linha.
export const SIMPLES_CNAES_SEED = [
  {
    "codigo": "0111301",
    "descricao": "CULTIVO DE ARROZ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0111302",
    "descricao": "CULTIVO DE MILHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0111303",
    "descricao": "CULTIVO DE TRIGO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0111399",
    "descricao": "CULTIVO DE OUTROS CEREAIS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0112101",
    "descricao": "CULTIVO DE ALGODÃO HERBÁCEO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0112102",
    "descricao": "CULTIVO DE JUTA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0112199",
    "descricao": "CULTIVO DE OUTRAS FIBRAS DE LAVOURA TEMPORÁRIA NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0113000",
    "descricao": "CULTIVO DE CANA DE AÇÚCAR",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0114800",
    "descricao": "CULTIVO DE FUMO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0115600",
    "descricao": "CULTIVO DE SOJA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0116401",
    "descricao": "CULTIVO DE AMENDOIM",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0116402",
    "descricao": "CULTIVO DE GIRASSOL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0116403",
    "descricao": "CULTIVO DE MAMONA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0116499",
    "descricao": "CULTIVO DE OUTRAS OLEAGINOSAS DE LAVOURA TEMPORÁRIA NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119901",
    "descricao": "CULTIVO DE ABACAXI",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119902",
    "descricao": "CULTIVO DE ALHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119903",
    "descricao": "CULTIVO DE BATATA INGLESA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119904",
    "descricao": "CULTIVO DE CEBOLA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119905",
    "descricao": "CULTIVO DE FEIJÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119906",
    "descricao": "CULTIVO DE MANDIOCA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119907",
    "descricao": "CULTIVO DE MELÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119908",
    "descricao": "CULTIVO DE MELANCIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119909",
    "descricao": "CULTIVO DE TOMATE RASTEIRO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0119999",
    "descricao": "CULTIVO DE OUTRAS PLANTAS DE LAVOURA TEMPORÁRIA NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0121101",
    "descricao": "HORTICULTURA, EXCETO MORANGO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0121102",
    "descricao": "CULTIVO DE MORANGO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0122900",
    "descricao": "CULTIVO DE FLORES E PLANTAS ORNAMENTAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0131800",
    "descricao": "CULTIVO DE LARANJA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0132600",
    "descricao": "CULTIVO DE UVA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133401",
    "descricao": "CULTIVO DE AÇAÍ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133402",
    "descricao": "CULTIVO DE BANANA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133403",
    "descricao": "CULTIVO DE CAJU",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133404",
    "descricao": "CULTIVO DE CÍTRICOS, EXCETO LARANJA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133405",
    "descricao": "CULTIVO DE COCO DA BAÍA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133406",
    "descricao": "CULTIVO DE GUARANÁ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133407",
    "descricao": "CULTIVO DE MAÇÃ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133408",
    "descricao": "CULTIVO DE MAMÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133409",
    "descricao": "CULTIVO DE MARACUJÁ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133410",
    "descricao": "CULTIVO DE MANGA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133411",
    "descricao": "CULTIVO DE PÊSSEGO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0133499",
    "descricao": "CULTIVO DE FRUTAS DE LAVOURA PERMANENTE NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0134200",
    "descricao": "CULTIVO DE CAFÉ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0135100",
    "descricao": "CULTIVO DE CACAU",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139301",
    "descricao": "CULTIVO DE CHÁ DA ÍNDIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139302",
    "descricao": "CULTIVO DE ERVA MATE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139303",
    "descricao": "CULTIVO DE PIMENTA DO REINO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139304",
    "descricao": "CULTIVO DE PLANTAS PARA CONDIMENTO, EXCETO PIMENTA DO REINO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139305",
    "descricao": "CULTIVO DE DENDÊ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139306",
    "descricao": "CULTIVO DE SERINGUEIRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0139399",
    "descricao": "CULTIVO DE OUTRAS PLANTAS DE LAVOURA PERMANENTE NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0141501",
    "descricao": "PRODUÇÃO DE SEMENTES CERTIFICADAS, EXCETO DE FORRAGEIRAS PARA PASTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0141502",
    "descricao": "PRODUÇÃO DE SEMENTES CERTIFICADAS DE FORRAGEIRAS PARA FORMAÇÃO DE PASTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0142300",
    "descricao": "PRODUÇÃO DE MUDAS E OUTRAS FORMAS DE PROPAGAÇÃO VEGETAL, CERTIFICADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0151201",
    "descricao": "CRIAÇÃO DE BOVINOS PARA CORTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0151202",
    "descricao": "CRIAÇÃO DE BOVINOS PARA LEITE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0151203",
    "descricao": "CRIAÇÃO DE BOVINOS, EXCETO PARA CORTE E LEITE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0152101",
    "descricao": "CRIAÇÃO DE BUFALINOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0152102",
    "descricao": "CRIAÇÃO DE EQÜINOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0152103",
    "descricao": "CRIAÇÃO DE ASININOS E MUARES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0153901",
    "descricao": "CRIAÇÃO DE CAPRINOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0153902",
    "descricao": "CRIAÇÃO DE OVINOS, INCLUSIVE PARA PRODUÇÃO DE LÃ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0154700",
    "descricao": "CRIAÇÃO DE SUÍNOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0155501",
    "descricao": "CRIAÇÃO DE FRANGOS PARA CORTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0155502",
    "descricao": "PRODUÇÃO DE PINTOS DE UM DIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0155503",
    "descricao": "CRIAÇÃO DE OUTROS GALINÁCEOS, EXCETO PARA CORTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0155504",
    "descricao": "CRIAÇÃO DE AVES, EXCETO GALINÁCEOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0155505",
    "descricao": "PRODUÇÃO DE OVOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0159801",
    "descricao": "APICULTURA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0159802",
    "descricao": "CRIAÇÃO DE ANIMAIS DE ESTIMAÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0159803",
    "descricao": "CRIAÇÃO DE ESCARGÔ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0159804",
    "descricao": "CRIAÇÃO DE BICHO DA SEDA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0159899",
    "descricao": "CRIAÇÃO DE OUTROS ANIMAIS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0161001",
    "descricao": "SERVIÇO DE PULVERIZAÇÃO E CONTROLE DE PRAGAS AGRÍCOLAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0161002",
    "descricao": "SERVIÇO DE PODA DE ÁRVORES PARA LAVOURAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0161003",
    "descricao": "Serviço de preparação de terreno, cultivo e colheita",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0161099",
    "descricao": "ATIVIDADES DE APOIO À AGRICULTURA NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0162801",
    "descricao": "SERVIÇO DE INSEMINAÇÃO ARTIFICIAL DE ANIMAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0162802",
    "descricao": "SERVIÇO DE TOSQUIAMENTO DE OVINOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0162803",
    "descricao": "Serviço de manejo de animais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0162899",
    "descricao": "ATIVIDADES DE APOIO À PECUÁRIA NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0163600",
    "descricao": "ATIVIDADES DE PÓS COLHEITA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0170900",
    "descricao": "CAÇA E SERVIÇOS RELACIONADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210101",
    "descricao": "CULTIVO DE EUCALIPTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210102",
    "descricao": "CULTIVO DE ACÁCIA NEGRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210103",
    "descricao": "CULTIVO DE PINUS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210104",
    "descricao": "CULTIVO DE TECA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210105",
    "descricao": "CULTIVO DE ESPÉCIES MADEIREIRAS, EXCETO EUCALIPTO, ACÁCIA NEGRA, PINUS E TECA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210106",
    "descricao": "CULTIVO DE MUDAS EM VIVEIROS FLORESTAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210107",
    "descricao": "EXTRAÇÃO DE MADEIRA EM FLORESTAS PLANTADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210108",
    "descricao": "PRODUÇÃO DE CARVÃO VEGETAL - FLORESTAS PLANTADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210109",
    "descricao": "PRODUÇÃO DE CASCA DE ACÁCIA NEGRA - FLORESTAS PLANTADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0210199",
    "descricao": "PRODUÇÃO DE PRODUTOS NÃO MADEIREIROS NÃO ESPECIFICADOS ANTERIORMENTE EM FLORESTAS PLANTADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220901",
    "descricao": "EXTRAÇÃO DE MADEIRA EM FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220902",
    "descricao": "PRODUÇÃO DE CARVÃO VEGETAL - FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220903",
    "descricao": "COLETA DE CASTANHA DO PARÁ EM FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220904",
    "descricao": "COLETA DE LÁTEX EM FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220905",
    "descricao": "COLETA DE PALMITO EM FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220906",
    "descricao": "CONSERVAÇÃO DE FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0220999",
    "descricao": "COLETA DE PRODUTOS NÃO MADEIREIROS NÃO ESPECIFICADOS ANTERIORMENTE EM FLORESTAS NATIVAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0230600",
    "descricao": "ATIVIDADES DE APOIO À PRODUÇÃO FLORESTAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0311601",
    "descricao": "PESCA DE PEIXES EM ÁGUA SALGADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0311602",
    "descricao": "PESCA DE CRUSTÁCEOS E MOLUSCOS EM ÁGUA SALGADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0311603",
    "descricao": "COLETA DE OUTROS PRODUTOS MARINHOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0311604",
    "descricao": "ATIVIDADES DE APOIO À PESCA EM ÁGUA SALGADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0312401",
    "descricao": "PESCA DE PEIXES EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0312402",
    "descricao": "PESCA DE CRUSTÁCEOS E MOLUSCOS EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0312403",
    "descricao": "COLETA DE OUTROS PRODUTOS AQUÁTICOS DE ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0312404",
    "descricao": "ATIVIDADES DE APOIO À PESCA EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321301",
    "descricao": "CRIAÇÃO DE PEIXES EM ÁGUA SALGADA E SALOBRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321302",
    "descricao": "CRIAÇÃO DE CAMARÕES EM ÁGUA SALGADA E SALOBRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321303",
    "descricao": "CRIAÇÃO DE OSTRAS E MEXILHÕES EM ÁGUA SALGADA E SALOBRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321304",
    "descricao": "CRIAÇÃO DE PEIXES ORNAMENTAIS EM ÁGUA SALGADA E SALOBRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321305",
    "descricao": "ATIVIDADES DE APOIO À AQÜICULTURA EM ÁGUA SALGADA E SALOBRA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0321399",
    "descricao": "CULTIVOS E SEMICULTIVOS DA AQÜICULTURA EM ÁGUA SALGADA E SALOBRA NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322101",
    "descricao": "CRIAÇÃO DE PEIXES EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322102",
    "descricao": "CRIAÇÃO DE CAMARÕES EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322103",
    "descricao": "CRIAÇÃO DE OSTRAS E MEXILHÕES EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322104",
    "descricao": "CRIAÇÃO DE PEIXES ORNAMENTAIS EM ÁGUA DOCE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322105",
    "descricao": "RANICULTURA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322106",
    "descricao": "CRIAÇÃO DE JACARÉ",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322107",
    "descricao": "Atividades de apoio à aqüicultura em água doce",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0322199",
    "descricao": "CULTIVOS E SEMICULTIVOS DA AQÜICULTURA EM ÁGUA DOCE NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0500301",
    "descricao": "EXTRAÇÃO DE CARVÃO MINERAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0500302",
    "descricao": "BENEFICIAMENTO DE CARVÃO MINERAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0600001",
    "descricao": "EXTRAÇÃO DE PETRÓLEO E GÁS NATURAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0600002",
    "descricao": "EXTRAÇÃO E BENEFICIAMENTO DE XISTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0600003",
    "descricao": "EXTRAÇÃO E BENEFICIAMENTO DE AREIAS BETUMINOSAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0710301",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE FERRO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0710302",
    "descricao": "PELOTIZAÇÃO, SINTERIZAÇÃO E OUTROS BENEFICIAMENTOS DE MINÉRIO DE FERRO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0721901",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE ALUMÍNIO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0721902",
    "descricao": "BENEFICIAMENTO DE MINÉRIO DE ALUMÍNIO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0722701",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE ESTANHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0722702",
    "descricao": "BENEFICIAMENTO DE MINÉRIO DE ESTANHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0723501",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE MANGANÊS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0723502",
    "descricao": "BENEFICIAMENTO DE MINÉRIO DE MANGANÊS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0724301",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE METAIS PRECIOSOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0724302",
    "descricao": "BENEFICIAMENTO DE MINÉRIO DE METAIS PRECIOSOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0725100",
    "descricao": "EXTRAÇÃO DE MINERAIS RADIOATIVOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0729401",
    "descricao": "EXTRAÇÃO DE MINÉRIOS DE NIÓBIO E TITÂNIO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0729402",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE TUNGSTÊNIO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0729403",
    "descricao": "EXTRAÇÃO DE MINÉRIO DE NÍQUEL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0729404",
    "descricao": "EXTRAÇÃO DE MINÉRIOS DE COBRE, CHUMBO, ZINCO E OUTROS MINERAIS METÁLICOS NÃO FERROSOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0729405",
    "descricao": "BENEFICIAMENTO DE MINÉRIOS DE COBRE, CHUMBO, ZINCO E OUTROS MINERAIS METÁLICOS NÃO FERROSOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810001",
    "descricao": "EXTRAÇÃO DE ARDÓSIA E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810002",
    "descricao": "EXTRAÇÃO DE GRANITO E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810003",
    "descricao": "EXTRAÇÃO DE MÁRMORE E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810004",
    "descricao": "EXTRAÇÃO DE CALCÁRIO E DOLOMITA E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810005",
    "descricao": "EXTRAÇÃO DE GESSO E CAULIM",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810006",
    "descricao": "EXTRAÇÃO DE AREIA, CASCALHO OU PEDREGULHO E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810007",
    "descricao": "EXTRAÇÃO DE ARGILA E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810008",
    "descricao": "EXTRAÇÃO DE SAIBRO E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810009",
    "descricao": "EXTRAÇÃO DE BASALTO E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810010",
    "descricao": "BENEFICIAMENTO DE GESSO E CAULIM ASSOCIADO À EXTRAÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0810099",
    "descricao": "EXTRAÇÃO E BRITAMENTO DE PEDRAS E OUTROS MATERIAIS PARA CONSTRUÇÃO E BENEFICIAMENTO ASSOCIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0891600",
    "descricao": "EXTRAÇÃO DE MINERAIS PARA FABRICAÇÃO DE ADUBOS, FERTILIZANTES E OUTROS PRODUTOS QUÍMICOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0892401",
    "descricao": "EXTRAÇÃO DE SAL MARINHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0892402",
    "descricao": "EXTRAÇÃO DE SAL GEMA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0892403",
    "descricao": "REFINO E OUTROS TRATAMENTOS DO SAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0893200",
    "descricao": "EXTRAÇÃO DE GEMAS (PEDRAS PRECIOSAS E SEMIPRECIOSAS)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0899101",
    "descricao": "EXTRAÇÃO DE GRAFITA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0899102",
    "descricao": "EXTRAÇÃO DE QUARTZO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0899103",
    "descricao": "EXTRAÇÃO DE AMIANTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0899199",
    "descricao": "EXTRAÇÃO DE OUTROS MINERAIS NÃO METÁLICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0910600",
    "descricao": "ATIVIDADES DE APOIO À EXTRAÇÃO DE PETRÓLEO E GÁS NATURAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0990401",
    "descricao": "ATIVIDADES DE APOIO À EXTRAÇÃO DE MINÉRIO DE FERRO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0990402",
    "descricao": "ATIVIDADES DE APOIO À EXTRAÇÃO DE MINERAIS METÁLICOS NÃO FERROSOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "0990403",
    "descricao": "ATIVIDADES DE APOIO À EXTRAÇÃO DE MINERAIS NÃO METÁLICOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1011201",
    "descricao": "FRIGORÍFICO - ABATE DE BOVINOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1011202",
    "descricao": "FRIGORÍFICO - ABATE DE EQÜINOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1011203",
    "descricao": "FRIGORÍFICO - ABATE DE OVINOS E CAPRINOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1011204",
    "descricao": "FRIGORÍFICO - ABATE DE BUFALINOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1011205",
    "descricao": "MATADOURO - ABATE DE RESES SOB CONTRATO - EXCETO ABATE DE SUÍNOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1012101",
    "descricao": "ABATE DE AVES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1012102",
    "descricao": "ABATE DE PEQUENOS ANIMAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1012103",
    "descricao": "FRIGORÍFICO - ABATE DE SUÍNOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1012104",
    "descricao": "MATADOURO - ABATE DE SUÍNOS SOB CONTRATO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1013901",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE CARNE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1013902",
    "descricao": "PREPARAÇÃO DE SUBPRODUTOS DO ABATE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1020101",
    "descricao": "PRESERVAÇÃO DE PEIXES, CRUSTÁCEOS E MOLUSCOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1020102",
    "descricao": "FABRICAÇÃO DE CONSERVAS DE PEIXES, CRUSTÁCEOS E MOLUSCOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1031700",
    "descricao": "FABRICAÇÃO DE CONSERVAS DE FRUTAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1032501",
    "descricao": "FABRICAÇÃO DE CONSERVAS DE PALMITO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1032599",
    "descricao": "FABRICAÇÃO DE CONSERVAS DE LEGUMES E OUTROS VEGETAIS, EXCETO PALMITO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1033301",
    "descricao": "FABRICAÇÃO DE SUCOS CONCENTRADOS DE FRUTAS, HORTALIÇAS E LEGUMES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1033302",
    "descricao": "FABRICAÇÃO DE SUCOS DE FRUTAS, HORTALIÇAS E LEGUMES, EXCETO CONCENTRADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1041400",
    "descricao": "FABRICAÇÃO DE ÓLEOS VEGETAIS EM BRUTO, EXCETO ÓLEO DE MILHO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1042200",
    "descricao": "FABRICAÇÃO DE ÓLEOS VEGETAIS REFINADOS, EXCETO ÓLEO DE MILHO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1043100",
    "descricao": "FABRICAÇÃO DE MARGARINA E OUTRAS GORDURAS VEGETAIS E DE ÓLEOS NÃO COMESTÍVEIS DE ANIMAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1051100",
    "descricao": "PREPARAÇÃO DO LEITE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1052000",
    "descricao": "FABRICAÇÃO DE LATICÍNIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1053800",
    "descricao": "FABRICAÇÃO DE SORVETES E OUTROS GELADOS COMESTÍVEIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1061901",
    "descricao": "BENEFICIAMENTO DE ARROZ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1061902",
    "descricao": "FABRICAÇÃO DE PRODUTOS DO ARROZ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1062700",
    "descricao": "MOAGEM DE TRIGO E FABRICAÇÃO DE DERIVADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1063500",
    "descricao": "FABRICAÇÃO DE FARINHA DE MANDIOCA E DERIVADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1064300",
    "descricao": "FABRICAÇÃO DE FARINHA DE MILHO E DERIVADOS, EXCETO ÓLEOS DE MILHO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1065101",
    "descricao": "FABRICAÇÃO DE AMIDOS E FÉCULAS DE VEGETAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1065102",
    "descricao": "FABRICAÇÃO DE ÓLEO DE MILHO EM BRUTO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1065103",
    "descricao": "FABRICAÇÃO DE ÓLEO DE MILHO REFINADO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1066000",
    "descricao": "FABRICAÇÃO DE ALIMENTOS PARA ANIMAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1069400",
    "descricao": "MOAGEM E FABRICAÇÃO DE PRODUTOS DE ORIGEM VEGETAL NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1071600",
    "descricao": "FABRICAÇÃO DE AÇÚCAR EM BRUTO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1072401",
    "descricao": "FABRICAÇÃO DE AÇÚCAR DE CANA REFINADO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1072402",
    "descricao": "FABRICAÇÃO DE AÇÚCAR DE CEREAIS (DEXTROSE) E DE BETERRABA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1081301",
    "descricao": "BENEFICIAMENTO DE CAFÉ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1081302",
    "descricao": "TORREFAÇÃO E MOAGEM DE CAFÉ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1082100",
    "descricao": "FABRICAÇÃO DE PRODUTOS À BASE DE CAFÉ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1091101",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE PANIFICAÇÃO INDUSTRIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1091102",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE PADARIA E CONFEITARIA COM PREDOMINÂNCIA DE PRODUÇÃO PRÓPRIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1092900",
    "descricao": "FABRICAÇÃO DE BISCOITOS E BOLACHAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1093701",
    "descricao": "FABRICAÇÃO DE PRODUTOS DERIVADOS DO CACAU E DE CHOCOLATES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1093702",
    "descricao": "FABRICAÇÃO DE FRUTAS CRISTALIZADAS, BALAS E SEMELHANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1094500",
    "descricao": "FABRICAÇÃO DE MASSAS ALIMENTÍCIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1095300",
    "descricao": "FABRICAÇÃO DE ESPECIARIAS, MOLHOS, TEMPEROS E CONDIMENTOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1096100",
    "descricao": "FABRICAÇÃO DE ALIMENTOS E PRATOS PRONTOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099601",
    "descricao": "FABRICAÇÃO DE VINAGRES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099602",
    "descricao": "FABRICAÇÃO DE PÓS ALIMENTÍCIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099603",
    "descricao": "FABRICAÇÃO DE FERMENTOS E LEVEDURAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099604",
    "descricao": "Fabricação de gelo comum",
    "anexo": "II",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099605",
    "descricao": "FABRICAÇÃO DE PRODUTOS PARA INFUSÃO (CHÁ, MATE, ETC.)",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099606",
    "descricao": "FABRICAÇÃO DE ADOÇANTES NATURAIS E ARTIFICIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099607",
    "descricao": "FABRICAÇÃO DE ALIMENTOS DIETÉTICOS E COMPLEMENTOS ALIMENTARES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1099699",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS ALIMENTÍCIOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1111901",
    "descricao": "FABRICAÇÃO DE AGUARDENTE DE CANA DE AÇÚCAR",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1111902",
    "descricao": "FABRICAÇÃO DE OUTRAS AGUARDENTES E BEBIDAS DESTILADAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1112700",
    "descricao": "FABRICAÇÃO DE VINHO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1113501",
    "descricao": "FABRICAÇÃO DE MALTE, INCLUSIVE MALTE UÍSQUE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1113502",
    "descricao": "FABRICAÇÃO DE CERVEJAS E CHOPES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1121600",
    "descricao": "FABRICAÇÃO DE ÁGUAS ENVASADAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1122401",
    "descricao": "FABRICAÇÃO DE REFRIGERANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1122402",
    "descricao": "FABRICAÇÃO DE CHÁ MATE E OUTROS CHÁS PRONTOS PARA CONSUMO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1122403",
    "descricao": "FABRICAÇÃO DE REFRESCOS, XAROPES E PÓS PARA REFRESCOS, EXCETO REFRESCOS DE FRUTAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1122404",
    "descricao": "FABRICAÇÃO DE BEBIDAS ISOTÔNICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1122499",
    "descricao": "FABRICAÇÃO DE OUTRAS BEBIDAS NÃO ALCOÓLICAS NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1210700",
    "descricao": "PROCESSAMENTO INDUSTRIAL DO FUMO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1220401",
    "descricao": "FABRICAÇÃO DE CIGARROS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1220402",
    "descricao": "FABRICAÇÃO DE CIGARRILHAS E CHARUTOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1220403",
    "descricao": "FABRICAÇÃO DE FILTROS PARA CIGARROS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1220499",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS DO FUMO, EXCETO CIGARROS, CIGARRILHAS E CHARUTOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1311100",
    "descricao": "PREPARAÇÃO E FIAÇÃO DE FIBRAS DE ALGODÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1312000",
    "descricao": "PREPARAÇÃO E FIAÇÃO DE FIBRAS TÊXTEIS NATURAIS, EXCETO ALGODÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1313800",
    "descricao": "FIAÇÃO DE FIBRAS ARTIFICIAIS E SINTÉTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1314600",
    "descricao": "FABRICAÇÃO DE LINHAS PARA COSTURAR E BORDAR",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1321900",
    "descricao": "TECELAGEM DE FIOS DE ALGODÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1322700",
    "descricao": "TECELAGEM DE FIOS DE FIBRAS TÊXTEIS NATURAIS, EXCETO ALGODÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1323500",
    "descricao": "TECELAGEM DE FIOS DE FIBRAS ARTIFICIAIS E SINTÉTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1330800",
    "descricao": "FABRICAÇÃO DE TECIDOS DE MALHA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1340501",
    "descricao": "ESTAMPARIA E TEXTURIZAÇÃO EM FIOS, TECIDOS, ARTEFATOS TÊXTEIS E PEÇAS DO VESTUÁRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1340502",
    "descricao": "ALVEJAMENTO, TINGIMENTO E TORÇÃO EM FIOS, TECIDOS, ARTEFATOS TÊXTEIS E PEÇAS DO VESTUÁRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1340599",
    "descricao": "OUTROS SERVIÇOS DE ACABAMENTO EM FIOS, TECIDOS, ARTEFATOS TÊXTEIS E PEÇAS DO VESTUÁRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1351100",
    "descricao": "FABRICAÇÃO DE ARTEFATOS TÊXTEIS PARA USO DOMÉSTICO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1352900",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE TAPEÇARIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1353700",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE CORDOARIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1354500",
    "descricao": "FABRICAÇÃO DE TECIDOS ESPECIAIS, INCLUSIVE ARTEFATOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1359600",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS TÊXTEIS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1411801",
    "descricao": "CONFECÇÃO DE ROUPAS ÍNTIMAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1411802",
    "descricao": "FACÇÃO DE ROUPAS ÍNTIMAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1412601",
    "descricao": "CONFECÇÃO DE PEÇAS DE VESTUÁRIO, EXCETO ROUPAS ÍNTIMAS E AS CONFECCIONADAS SOB MEDIDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1412602",
    "descricao": "CONFECÇÃO, SOB MEDIDA, DE PEÇAS DO VESTUÁRIO, EXCETO ROUPAS ÍNTIMAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1412603",
    "descricao": "FACÇÃO DE PEÇAS DO VESTUÁRIO, EXCETO ROUPAS ÍNTIMAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1413401",
    "descricao": "CONFECÇÃO DE ROUPAS PROFISSIONAIS, EXCETO SOB MEDIDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1413402",
    "descricao": "CONFECÇÃO, SOB MEDIDA, DE ROUPAS PROFISSIONAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1413403",
    "descricao": "FACÇÃO DE ROUPAS PROFISSIONAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1414200",
    "descricao": "FABRICAÇÃO DE ACESSÓRIOS DO VESTUÁRIO, EXCETO PARA SEGURANÇA E PROTEÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1421500",
    "descricao": "FABRICAÇÃO DE MEIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1422300",
    "descricao": "FABRICAÇÃO DE ARTIGOS DO VESTUÁRIO, PRODUZIDOS EM MALHARIAS E TRICOTAGENS, EXCETO MEIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1510600",
    "descricao": "CURTIMENTO E OUTRAS PREPARAÇÕES DE COURO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1521100",
    "descricao": "FABRICAÇÃO DE ARTIGOS PARA VIAGEM, BOLSAS E SEMELHANTES DE QUALQUER MATERIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1529700",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE COURO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1531901",
    "descricao": "FABRICAÇÃO DE CALÇADOS DE COURO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1531902",
    "descricao": "ACABAMENTO DE CALÇADOS DE COURO SOB CONTRATO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1532700",
    "descricao": "FABRICAÇÃO DE TÊNIS DE QUALQUER MATERIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1533500",
    "descricao": "FABRICAÇÃO DE CALÇADOS DE MATERIAL SINTÉTICO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1539400",
    "descricao": "FABRICAÇÃO DE CALÇADOS DE MATERIAIS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1540800",
    "descricao": "FABRICAÇÃO DE PARTES PARA CALÇADOS, DE QUALQUER MATERIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1610203",
    "descricao": "SERRARIAS COM DESDOBRAMENTO DE MADEIRA EM BRUTO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1610204",
    "descricao": "SERRARIAS SEM DESDOBRAMENTO DE MADEIRA EM BRUTO - RESSERRAGEM",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1610205",
    "descricao": "SERVIÇO DE TRATAMENTO DE MADEIRA REALIZADO SOB CONTRATO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1621800",
    "descricao": "FABRICAÇÃO DE MADEIRA LAMINADA E DE CHAPAS DE MADEIRA COMPENSADA, PRENSADA E AGLOMERADA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1622601",
    "descricao": "FABRICAÇÃO DE CASAS DE MADEIRA PRÉ FABRICADAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1622602",
    "descricao": "FABRICAÇÃO DE ESQUADRIAS DE MADEIRA E DE PEÇAS DE MADEIRA PARA INSTALAÇÕES INDUSTRIAIS E COMERCIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1622699",
    "descricao": "FABRICAÇÃO DE OUTROS ARTIGOS DE CARPINTARIA PARA CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1623400",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE TANOARIA E DE EMBALAGENS DE MADEIRA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1629301",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DIVERSOS DE MADEIRA, EXCETO MÓVEIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1629302",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DIVERSOS DE CORTIÇA, BAMBU, PALHA, VIME E OUTROS MATERIAIS TRANÇADOS, EXCETO MÓVEIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1710900",
    "descricao": "FABRICAÇÃO DE CELULOSE E OUTRAS PASTAS PARA A FABRICAÇÃO DE PAPEL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1721400",
    "descricao": "FABRICAÇÃO DE PAPEL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1722200",
    "descricao": "FABRICAÇÃO DE CARTOLINA E PAPEL CARTÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1731100",
    "descricao": "FABRICAÇÃO DE EMBALAGENS DE PAPEL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1732000",
    "descricao": "FABRICAÇÃO DE EMBALAGENS DE CARTOLINA E PAPEL CARTÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1733800",
    "descricao": "FABRICAÇÃO DE CHAPAS E DE EMBALAGENS DE PAPELÃO ONDULADO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1741901",
    "descricao": "FABRICAÇÃO DE FORMULÁRIOS CONTÍNUOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1741902",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE PAPEL, CARTOLINA, PAPEL CARTÃO E PAPELÃO ONDULADO PARA USO COMERCIAL E DE ESCRITÓRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1742701",
    "descricao": "FABRICAÇÃO DE FRALDAS DESCARTÁVEIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1742702",
    "descricao": "FABRICAÇÃO DE ABSORVENTES HIGIÊNICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1742799",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE PAPEL PARA USO DOMÉSTICO E HIGIÊNICO SANITÁRIO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1749400",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE PASTAS CELULÓSICAS, PAPEL, CARTOLINA, PAPEL CARTÃO E PAPELÃO ONDULADO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1811301",
    "descricao": "IMPRESSÃO DE JORNAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1811302",
    "descricao": "IMPRESSÃO DE LIVROS, REVISTAS E OUTRAS PUBLICAÇÕES PERIÓDICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1812100",
    "descricao": "IMPRESSÃO DE MATERIAL DE SEGURANÇA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1813001",
    "descricao": "IMPRESSÃO DE MATERIAL PARA USO PUBLICITÁRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1813099",
    "descricao": "IMPRESSÃO DE MATERIAL PARA OUTROS USOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1821100",
    "descricao": "SERVIÇOS DE PRÉ IMPRESSÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1822901",
    "descricao": "SERVIÇOS DE ENCADERNAÇÃO E PLASTIFICAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1822999",
    "descricao": "SERVIÇOS DE ACABAMENTOS GRÁFICOS, EXCETO ENCADERNAÇÃO E PLASTIFICAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1830001",
    "descricao": "REPRODUÇÃO DE SOM EM QUALQUER SUPORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1830002",
    "descricao": "REPRODUÇÃO DE VÍDEO EM QUALQUER SUPORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1830003",
    "descricao": "REPRODUÇÃO DE SOFTWARE EM QUALQUER SUPORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1910100",
    "descricao": "COQUERIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1921700",
    "descricao": "FABRICAÇÃO DE PRODUTOS DO REFINO DE PETRÓLEO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1922501",
    "descricao": "FORMULAÇÃO DE COMBUSTÍVEIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1922502",
    "descricao": "RERREFINO DE ÓLEOS LUBRIFICANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1922599",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS DERIVADOS DO PETRÓLEO, EXCETO PRODUTOS DO REFINO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1931400",
    "descricao": "FABRICAÇÃO DE ÁLCOOL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "1932200",
    "descricao": "FABRICAÇÃO DE BIOCOMBUSTÍVEIS, EXCETO ÁLCOOL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2011800",
    "descricao": "FABRICAÇÃO DE CLORO E ÁLCALIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2012600",
    "descricao": "FABRICAÇÃO DE INTERMEDIÁRIOS PARA FERTILIZANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2013401",
    "descricao": "FABRICAÇÃO DE ADUBOS E FERTILIZANTES ORGANOMINERAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2013402",
    "descricao": "FABRICAÇÃO DE ADUBOS E FERTILIZANTES, EXCETO ORGANOMINERAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2014200",
    "descricao": "FABRICAÇÃO DE GASES INDUSTRIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2019301",
    "descricao": "ELABORAÇÃO DE COMBUSTÍVEIS NUCLEARES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2019399",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS QUÍMICOS INORGÂNICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2021500",
    "descricao": "FABRICAÇÃO DE PRODUTOS PETROQUÍMICOS BÁSICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2022300",
    "descricao": "FABRICAÇÃO DE INTERMEDIÁRIOS PARA PLASTIFICANTES, RESINAS E FIBRAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2029100",
    "descricao": "FABRICAÇÃO DE PRODUTOS QUÍMICOS ORGÂNICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2031200",
    "descricao": "FABRICAÇÃO DE RESINAS TERMOPLÁSTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2032100",
    "descricao": "FABRICAÇÃO DE RESINAS TERMOFIXAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2033900",
    "descricao": "FABRICAÇÃO DE ELASTÔMEROS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2040100",
    "descricao": "FABRICAÇÃO DE FIBRAS ARTIFICIAIS E SINTÉTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2051700",
    "descricao": "FABRICAÇÃO DE DEFENSIVOS AGRÍCOLAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2052500",
    "descricao": "FABRICAÇÃO DE DESINFESTANTES DOMISSANITÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2061400",
    "descricao": "FABRICAÇÃO DE SABÕES E DETERGENTES SINTÉTICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2062200",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE LIMPEZA E POLIMENTO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2063100",
    "descricao": "FABRICAÇÃO DE COSMÉTICOS, PRODUTOS DE PERFUMARIA E DE HIGIENE PESSOAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2071100",
    "descricao": "FABRICAÇÃO DE TINTAS, VERNIZES, ESMALTES E LACAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2072000",
    "descricao": "FABRICAÇÃO DE TINTAS DE IMPRESSÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2073800",
    "descricao": "FABRICAÇÃO DE IMPERMEABILIZANTES, SOLVENTES E PRODUTOS AFINS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2091600",
    "descricao": "FABRICAÇÃO DE ADESIVOS E SELANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2092401",
    "descricao": "FABRICAÇÃO DE PÓLVORAS, EXPLOSIVOS E DETONANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2092402",
    "descricao": "FABRICAÇÃO DE ARTIGOS PIROTÉCNICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2092403",
    "descricao": "FABRICAÇÃO DE FÓSFOROS DE SEGURANÇA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2093200",
    "descricao": "FABRICAÇÃO DE ADITIVOS DE USO INDUSTRIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2094100",
    "descricao": "FABRICAÇÃO DE CATALISADORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2099101",
    "descricao": "FABRICAÇÃO DE CHAPAS, FILMES, PAPÉIS E OUTROS MATERIAIS E PRODUTOS QUÍMICOS PARA FOTOGRAFIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2099199",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS QUÍMICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2110600",
    "descricao": "FABRICAÇÃO DE PRODUTOS FARMOQUÍMICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2121101",
    "descricao": "FABRICAÇÃO DE MEDICAMENTOS ALOPÁTICOS PARA USO HUMANO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2121102",
    "descricao": "FABRICAÇÃO DE MEDICAMENTOS HOMEOPÁTICOS PARA USO HUMANO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2121103",
    "descricao": "FABRICAÇÃO DE MEDICAMENTOS FITOTERÁPICOS PARA USO HUMANO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2122000",
    "descricao": "FABRICAÇÃO DE MEDICAMENTOS PARA USO VETERINÁRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2123800",
    "descricao": "FABRICAÇÃO DE PREPARAÇÕES FARMACÊUTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2211100",
    "descricao": "FABRICAÇÃO DE PNEUMÁTICOS E DE CÂMARAS DE AR",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2212900",
    "descricao": "REFORMA DE PNEUMÁTICOS USADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2219600",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE BORRACHA NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2221800",
    "descricao": "FABRICAÇÃO DE LAMINADOS PLANOS E TUBULARES DE MATERIAL PLÁSTICO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2222600",
    "descricao": "FABRICAÇÃO DE EMBALAGENS DE MATERIAL PLÁSTICO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2223400",
    "descricao": "FABRICAÇÃO DE TUBOS E ACESSÓRIOS DE MATERIAL PLÁSTICO PARA USO NA CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2229301",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE MATERIAL PLÁSTICO PARA USO PESSOAL E DOMÉSTICO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2229302",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE MATERIAL PLÁSTICO PARA USOS INDUSTRIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2229303",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE MATERIAL PLÁSTICO PARA USO NA CONSTRUÇÃO, EXCETO TUBOS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2229399",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE MATERIAL PLÁSTICO PARA OUTROS USOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2311700",
    "descricao": "FABRICAÇÃO DE VIDRO PLANO E DE SEGURANÇA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2312500",
    "descricao": "FABRICAÇÃO DE EMBALAGENS DE VIDRO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2319200",
    "descricao": "FABRICAÇÃO DE ARTIGOS DE VIDRO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2320600",
    "descricao": "FABRICAÇÃO DE CIMENTO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330301",
    "descricao": "FABRICAÇÃO DE ESTRUTURAS PRÉ MOLDADAS DE CONCRETO ARMADO, EM SÉRIE E SOB ENCOMENDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330302",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE CIMENTO PARA USO NA CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330303",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE FIBROCIMENTO PARA USO NA CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330304",
    "descricao": "FABRICAÇÃO DE CASAS PRÉ MOLDADAS DE CONCRETO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330305",
    "descricao": "PREPARAÇÃO DE MASSA DE CONCRETO E ARGAMASSA PARA CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2330399",
    "descricao": "FABRICAÇÃO DE OUTROS ARTEFATOS E PRODUTOS DE CONCRETO, CIMENTO, FIBROCIMENTO, GESSO E MATERIAIS SEMELHANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2341900",
    "descricao": "FABRICAÇÃO DE PRODUTOS CERÂMICOS REFRATÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2342701",
    "descricao": "FABRICAÇÃO DE AZULEJOS E PISOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2342702",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE CERÂMICA E BARRO COZIDO PARA USO NA CONSTRUÇÃO, EXCETO AZULEJOS E PISOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2349401",
    "descricao": "FABRICAÇÃO DE MATERIAL SANITÁRIO DE CERÂMICA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2349499",
    "descricao": "FABRICAÇÃO DE PRODUTOS CERÂMICOS NÃO REFRATÁRIOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2391501",
    "descricao": "BRITAMENTO DE PEDRAS, EXCETO ASSOCIADO À EXTRAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2391502",
    "descricao": "APARELHAMENTO DE PEDRAS PARA CONSTRUÇÃO, EXCETO ASSOCIADO À EXTRAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2391503",
    "descricao": "APARELHAMENTO DE PLACAS E EXECUÇÃO DE TRABALHOS EM MÁRMORE, GRANITO, ARDÓSIA E OUTRAS PEDRAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2392300",
    "descricao": "FABRICAÇÃO DE CAL E GESSO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2399101",
    "descricao": "DECORAÇÃO, LAPIDAÇÃO, GRAVAÇÃO, VITRIFICAÇÃO E OUTROS TRABALHOS EM CERÂMICA, LOUÇA, VIDRO E CRISTAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2399102",
    "descricao": "FABRICAÇÃO DE ABRASIVOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2399199",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS DE MINERAIS NÃO METÁLICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2411300",
    "descricao": "PRODUÇÃO DE FERRO GUSA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2412100",
    "descricao": "PRODUÇÃO DE FERROLIGAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2421100",
    "descricao": "PRODUÇÃO DE SEMI ACABADOS DE AÇO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2422901",
    "descricao": "PRODUÇÃO DE LAMINADOS PLANOS DE AÇO AO CARBONO, REVESTIDOS OU NÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2422902",
    "descricao": "PRODUÇÃO DE LAMINADOS PLANOS DE AÇOS ESPECIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2423701",
    "descricao": "PRODUÇÃO DE TUBOS DE AÇO SEM COSTURA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2423702",
    "descricao": "PRODUÇÃO DE LAMINADOS LONGOS DE AÇO, EXCETO TUBOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2424501",
    "descricao": "PRODUÇÃO DE ARAMES DE AÇO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2424502",
    "descricao": "PRODUÇÃO DE RELAMINADOS, TREFILADOS E PERFILADOS DE AÇO, EXCETO ARAMES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2431800",
    "descricao": "PRODUÇÃO DE TUBOS DE AÇO COM COSTURA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2439300",
    "descricao": "PRODUÇÃO DE OUTROS TUBOS DE FERRO E AÇO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2441501",
    "descricao": "PRODUÇÃO DE ALUMÍNIO E SUAS LIGAS EM FORMAS PRIMÁRIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2441502",
    "descricao": "PRODUÇÃO DE LAMINADOS DE ALUMÍNIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2442300",
    "descricao": "METALURGIA DOS METAIS PRECIOSOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2443100",
    "descricao": "METALURGIA DO COBRE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2449101",
    "descricao": "PRODUÇÃO DE ZINCO EM FORMAS PRIMÁRIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2449102",
    "descricao": "PRODUÇÃO DE LAMINADOS DE ZINCO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2449103",
    "descricao": "FABRICAÇÃO DE ÂNODOS PARA GALVANOPLASTIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2449199",
    "descricao": "METALURGIA DE OUTROS METAIS NÃO FERROSOS E SUAS LIGAS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2451200",
    "descricao": "FUNDIÇÃO DE FERRO E AÇO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2452100",
    "descricao": "FUNDIÇÃO DE METAIS NÃO FERROSOS E SUAS LIGAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2511000",
    "descricao": "FABRICAÇÃO DE ESTRUTURAS METÁLICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2512800",
    "descricao": "FABRICAÇÃO DE ESQUADRIAS DE METAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2513600",
    "descricao": "FABRICAÇÃO DE OBRAS DE CALDEIRARIA PESADA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2521700",
    "descricao": "FABRICAÇÃO DE TANQUES, RESERVATÓRIOS METÁLICOS E CALDEIRAS PARA AQUECIMENTO CENTRAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2522500",
    "descricao": "FABRICAÇÃO DE CALDEIRAS GERADORAS DE VAPOR, EXCETO PARA AQUECIMENTO CENTRAL E PARA VEÍCULOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2531401",
    "descricao": "PRODUÇÃO DE FORJADOS DE AÇO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2531402",
    "descricao": "PRODUÇÃO DE FORJADOS DE METAIS NÃO FERROSOS E SUAS LIGAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2532201",
    "descricao": "PRODUÇÃO DE ARTEFATOS ESTAMPADOS DE METAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2532202",
    "descricao": "METALURGIA DO PÓ",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2539001",
    "descricao": "SERVIÇOS DE USINAGEM, TORNEARIA E SOLDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2539002",
    "descricao": "SERVIÇOS DE TRATAMENTO E REVESTIMENTO EM METAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2541100",
    "descricao": "FABRICAÇÃO DE ARTIGOS DE CUTELARIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2542000",
    "descricao": "FABRICAÇÃO DE ARTIGOS DE SERRALHERIA, EXCETO ESQUADRIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2543800",
    "descricao": "FABRICAÇÃO DE FERRAMENTAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2550101",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTO BÉLICO PESADO, EXCETO VEÍCULOS MILITARES DE COMBATE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2550102",
    "descricao": "FABRICAÇÃO DE ARMAS DE FOGO, OUTRAS ARMAS E MUNIÇÕES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2591800",
    "descricao": "FABRICAÇÃO DE EMBALAGENS METÁLICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2592601",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE TREFILADOS DE METAL PADRONIZADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2592602",
    "descricao": "FABRICAÇÃO DE PRODUTOS DE TREFILADOS DE METAL, EXCETO PADRONIZADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2593400",
    "descricao": "FABRICAÇÃO DE ARTIGOS DE METAL PARA USO DOMÉSTICO E PESSOAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2599301",
    "descricao": "SERVIÇOS DE CONFECÇÃO DE ARMAÇÕES METÁLICAS PARA A CONSTRUÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2599302",
    "descricao": "SERVIÇO DE CORTE E DOBRA DE METAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2599399",
    "descricao": "FABRICAÇÃO DE OUTROS PRODUTOS DE METAL NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2610800",
    "descricao": "FABRICAÇÃO DE COMPONENTES ELETRÔNICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2621300",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS DE INFORMÁTICA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2622100",
    "descricao": "FABRICAÇÃO DE PERIFÉRICOS PARA EQUIPAMENTOS DE INFORMÁTICA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2631100",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS TRANSMISSORES DE COMUNICAÇÃO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2632900",
    "descricao": "FABRICAÇÃO DE APARELHOS TELEFÔNICOS E DE OUTROS EQUIPAMENTOS DE COMUNICAÇÃO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2640000",
    "descricao": "FABRICAÇÃO DE APARELHOS DE RECEPÇÃO, REPRODUÇÃO, GRAVAÇÃO E AMPLIFICAÇÃO DE ÁUDIO E VÍDEO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2651500",
    "descricao": "FABRICAÇÃO DE APARELHOS E EQUIPAMENTOS DE MEDIDA, TESTE E CONTROLE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2652300",
    "descricao": "FABRICAÇÃO DE CRONÔMETROS E RELÓGIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2660400",
    "descricao": "FABRICAÇÃO DE APARELHOS ELETROMÉDICOS E ELETROTERAPÊUTICOS E EQUIPAMENTOS DE IRRADIAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2670101",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS E INSTRUMENTOS ÓPTICOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2670102",
    "descricao": "FABRICAÇÃO DE APARELHOS FOTOGRÁFICOS E CINEMATOGRÁFICOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2680900",
    "descricao": "FABRICAÇÃO DE MÍDIAS VIRGENS, MAGNÉTICAS E ÓPTICAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2710401",
    "descricao": "FABRICAÇÃO DE GERADORES DE CORRENTE CONTÍNUA E ALTERNADA, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2710402",
    "descricao": "FABRICAÇÃO DE TRANSFORMADORES, INDUTORES, CONVERSORES, SINCRONIZADORES E SEMELHANTES, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2710403",
    "descricao": "FABRICAÇÃO DE MOTORES ELÉTRICOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2721000",
    "descricao": "FABRICAÇÃO DE PILHAS, BATERIAS E ACUMULADORES ELÉTRICOS, EXCETO PARA VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2722801",
    "descricao": "FABRICAÇÃO DE BATERIAS E ACUMULADORES PARA VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2722802",
    "descricao": "RECONDICIONAMENTO DE BATERIAS E ACUMULADORES PARA VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2731700",
    "descricao": "FABRICAÇÃO DE APARELHOS E EQUIPAMENTOS PARA DISTRIBUIÇÃO E CONTROLE DE ENERGIA ELÉTRICA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2732500",
    "descricao": "FABRICAÇÃO DE MATERIAL ELÉTRICO PARA INSTALAÇÕES EM CIRCUITO DE CONSUMO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2733300",
    "descricao": "FABRICAÇÃO DE FIOS, CABOS E CONDUTORES ELÉTRICOS ISOLADOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2740601",
    "descricao": "FABRICAÇÃO DE LÂMPADAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2740602",
    "descricao": "FABRICAÇÃO DE LUMINÁRIAS E OUTROS EQUIPAMENTOS DE ILUMINAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2751100",
    "descricao": "FABRICAÇÃO DE FOGÕES, REFRIGERADORES E MÁQUINAS DE LAVAR E SECAR PARA USO DOMÉSTICO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2759701",
    "descricao": "FABRICAÇÃO DE APARELHOS ELÉTRICOS DE USO PESSOAL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2759799",
    "descricao": "FABRICAÇÃO DE OUTROS APARELHOS ELETRODOMÉSTICOS NÃO ESPECIFICADOS ANTERIORMENTE, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2790201",
    "descricao": "FABRICAÇÃO DE ELETRODOS, CONTATOS E OUTROS ARTIGOS DE CARVÃO E GRAFITA PARA USO ELÉTRICO, ELETROÍMÃS E ISOLADORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2790202",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS PARA SINALIZAÇÃO E ALARME",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2790299",
    "descricao": "FABRICAÇÃO DE OUTROS EQUIPAMENTOS E APARELHOS ELÉTRICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2811900",
    "descricao": "FABRICAÇÃO DE MOTORES E TURBINAS, PEÇAS E ACESSÓRIOS, EXCETO PARA AVIÕES E VEÍCULOS RODOVIÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2812700",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS HIDRÁULICOS E PNEUMÁTICOS, PEÇAS E ACESSÓRIOS, EXCETO VÁLVULAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2813500",
    "descricao": "FABRICAÇÃO DE VÁLVULAS, REGISTROS E DISPOSITIVOS SEMELHANTES, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2814301",
    "descricao": "FABRICAÇÃO DE COMPRESSORES PARA USO INDUSTRIAL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2814302",
    "descricao": "FABRICAÇÃO DE COMPRESSORES PARA USO NÃO INDUSTRIAL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2815101",
    "descricao": "FABRICAÇÃO DE ROLAMENTOS PARA FINS INDUSTRIAIS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2815102",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS DE TRANSMISSÃO PARA FINS INDUSTRIAIS, EXCETO ROLAMENTOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2821601",
    "descricao": "FABRICAÇÃO DE FORNOS INDUSTRIAIS, APARELHOS E EQUIPAMENTOS NÃO ELÉTRICOS PARA INSTALAÇÕES TÉRMICAS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2821602",
    "descricao": "FABRICAÇÃO DE ESTUFAS E FORNOS ELÉTRICOS PARA FINS INDUSTRIAIS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2822401",
    "descricao": "FABRICAÇÃO DE MÁQUINAS, EQUIPAMENTOS E APARELHOS PARA TRANSPORTE E ELEVAÇÃO DE PESSOAS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2822402",
    "descricao": "FABRICAÇÃO DE MÁQUINAS, EQUIPAMENTOS E APARELHOS PARA TRANSPORTE E ELEVAÇÃO DE CARGAS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2823200",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E APARELHOS DE REFRIGERAÇÃO E VENTILAÇÃO PARA USO INDUSTRIAL E COMERCIAL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2824101",
    "descricao": "FABRICAÇÃO DE APARELHOS E EQUIPAMENTOS DE AR CONDICIONADO PARA USO INDUSTRIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2824102",
    "descricao": "FABRICAÇÃO DE APARELHOS E EQUIPAMENTOS DE AR CONDICIONADO PARA USO NÃO INDUSTRIAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2825900",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA SANEAMENTO BÁSICO E AMBIENTAL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2829101",
    "descricao": "FABRICAÇÃO DE MÁQUINAS DE ESCREVER, CALCULAR E OUTROS EQUIPAMENTOS NÃO ELETRÔNICOS PARA ESCRITÓRIO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2829199",
    "descricao": "FABRICAÇÃO DE OUTRAS MÁQUINAS E EQUIPAMENTOS DE USO GERAL NÃO ESPECIFICADOS ANTERIORMENTE, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2831300",
    "descricao": "FABRICAÇÃO DE TRATORES AGRÍCOLAS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2832100",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS PARA IRRIGAÇÃO AGRÍCOLA, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2833000",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA A AGRICULTURA E PECUÁRIA, PEÇAS E ACESSÓRIOS, EXCETO PARA IRRIGAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2840200",
    "descricao": "FABRICAÇÃO DE MÁQUINAS FERRAMENTA, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2851800",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA A PROSPECÇÃO E EXTRAÇÃO DE PETRÓLEO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2852600",
    "descricao": "FABRICAÇÃO DE OUTRAS MÁQUINAS E EQUIPAMENTOS PARA USO NA EXTRAÇÃO MINERAL, PEÇAS E ACESSÓRIOS, EXCETO NA EXTRAÇÃO DE PETRÓLEO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2853400",
    "descricao": "FABRICAÇÃO DE TRATORES, PEÇAS E ACESSÓRIOS, EXCETO AGRÍCOLAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2854200",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA TERRAPLENAGEM, PAVIMENTAÇÃO E CONSTRUÇÃO, PEÇAS E ACESSÓRIOS, EXCETO TRATORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2861500",
    "descricao": "FABRICAÇÃO DE MÁQUINAS PARA A INDÚSTRIA METALÚRGICA, PEÇAS E ACESSÓRIOS, EXCETO MÁQUINAS FERRAMENTA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2862300",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA AS INDÚSTRIAS DE ALIMENTOS, BEBIDAS E FUMO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2863100",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA A INDÚSTRIA TÊXTIL, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2864000",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA AS INDÚSTRIAS DO VESTUÁRIO, DO COURO E DE CALÇADOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2865800",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA AS INDÚSTRIAS DE CELULOSE, PAPEL E PAPELÃO E ARTEFATOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2866600",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA A INDÚSTRIA DO PLÁSTICO, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2869100",
    "descricao": "FABRICAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA USO INDUSTRIAL ESPECÍFICO NÃO ESPECIFICADOS ANTERIORMENTE, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2910701",
    "descricao": "FABRICAÇÃO DE AUTOMÓVEIS, CAMIONETAS E UTILITÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2910702",
    "descricao": "FABRICAÇÃO DE CHASSIS COM MOTOR PARA AUTOMÓVEIS, CAMIONETAS E UTILITÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2910703",
    "descricao": "FABRICAÇÃO DE MOTORES PARA AUTOMÓVEIS, CAMIONETAS E UTILITÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2920401",
    "descricao": "FABRICAÇÃO DE CAMINHÕES E ÔNIBUS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2920402",
    "descricao": "FABRICAÇÃO DE MOTORES PARA CAMINHÕES E ÔNIBUS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2930101",
    "descricao": "FABRICAÇÃO DE CABINES, CARROCERIAS E REBOQUES PARA CAMINHÕES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2930102",
    "descricao": "FABRICAÇÃO DE CARROCERIAS PARA ÔNIBUS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2930103",
    "descricao": "FABRICAÇÃO DE CABINES, CARROCERIAS E REBOQUES PARA OUTROS VEÍCULOS AUTOMOTORES, EXCETO CAMINHÕES E ÔNIBUS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2941700",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA O SISTEMA MOTOR DE VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2942500",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA OS SISTEMAS DE MARCHA E TRANSMISSÃO DE VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2943300",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA O SISTEMA DE FREIOS DE VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2944100",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA O SISTEMA DE DIREÇÃO E SUSPENSÃO DE VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2945000",
    "descricao": "FABRICAÇÃO DE MATERIAL ELÉTRICO E ELETRÔNICO PARA VEÍCULOS AUTOMOTORES, EXCETO BATERIAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2949201",
    "descricao": "FABRICAÇÃO DE BANCOS E ESTOFADOS PARA VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2949299",
    "descricao": "FABRICAÇÃO DE OUTRAS PEÇAS E ACESSÓRIOS PARA VEÍCULOS AUTOMOTORES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "2950600",
    "descricao": "RECONDICIONAMENTO E RECUPERAÇÃO DE MOTORES PARA VEÍCULOS AUTOMOTORES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3011301",
    "descricao": "CONSTRUÇÃO DE EMBARCAÇÕES DE GRANDE PORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3011302",
    "descricao": "CONSTRUÇÃO DE EMBARCAÇÕES PARA USO COMERCIAL E PARA USOS ESPECIAIS, EXCETO DE GRANDE PORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3012100",
    "descricao": "CONSTRUÇÃO DE EMBARCAÇÕES PARA ESPORTE E LAZER",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3031800",
    "descricao": "FABRICAÇÃO DE LOCOMOTIVAS, VAGÕES E OUTROS MATERIAIS RODANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3032600",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA VEÍCULOS FERROVIÁRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3041500",
    "descricao": "FABRICAÇÃO DE AERONAVES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3042300",
    "descricao": "FABRICAÇÃO DE TURBINAS, MOTORES E OUTROS COMPONENTES E PEÇAS PARA AERONAVES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3050400",
    "descricao": "FABRICAÇÃO DE VEÍCULOS MILITARES DE COMBATE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3091101",
    "descricao": "FABRICAÇÃO DE MOTOCICLETAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3091102",
    "descricao": "FABRICAÇÃO DE PEÇAS E ACESSÓRIOS PARA MOTOCICLETAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3092000",
    "descricao": "FABRICAÇÃO DE BICICLETAS E TRICICLOS NÃO MOTORIZADOS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3099700",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS DE TRANSPORTE NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3101200",
    "descricao": "FABRICAÇÃO DE MÓVEIS COM PREDOMINÂNCIA DE MADEIRA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3102100",
    "descricao": "FABRICAÇÃO DE MÓVEIS COM PREDOMINÂNCIA DE METAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3103900",
    "descricao": "FABRICAÇÃO DE MÓVEIS DE OUTROS MATERIAIS, EXCETO MADEIRA E METAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3104700",
    "descricao": "FABRICAÇÃO DE COLCHÕES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3211601",
    "descricao": "LAPIDAÇÃO DE GEMAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3211602",
    "descricao": "FABRICAÇÃO DE ARTEFATOS DE JOALHERIA E OURIVESARIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3211603",
    "descricao": "CUNHAGEM DE MOEDAS E MEDALHAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3212400",
    "descricao": "FABRICAÇÃO DE BIJUTERIAS E ARTEFATOS SEMELHANTES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3220500",
    "descricao": "FABRICAÇÃO DE INSTRUMENTOS MUSICAIS, PEÇAS E ACESSÓRIOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3230200",
    "descricao": "FABRICAÇÃO DE ARTEFATOS PARA PESCA E ESPORTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3240001",
    "descricao": "FABRICAÇÃO DE JOGOS ELETRÔNICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3240002",
    "descricao": "FABRICAÇÃO DE MESAS DE BILHAR, DE SINUCA E ACESSÓRIOS NÃO ASSOCIADA À LOCAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3240003",
    "descricao": "FABRICAÇÃO DE MESAS DE BILHAR, DE SINUCA E ACESSÓRIOS ASSOCIADA À LOCAÇÃO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3240099",
    "descricao": "FABRICAÇÃO DE OUTROS BRINQUEDOS E JOGOS RECREATIVOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250701",
    "descricao": "FABRICAÇÃO DE INSTRUMENTOS NÃO ELETRÔNICOS E UTENSÍLIOS PARA USO MÉDICO, CIRÚRGICO, ODONTOLÓGICO E DE LABORATÓRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250702",
    "descricao": "FABRICAÇÃO DE MOBILIÁRIO PARA USO MÉDICO, CIRÚRGICO, ODONTOLÓGICO E DE LABORATÓRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250703",
    "descricao": "FABRICAÇÃO DE APARELHOS E UTENSÍLIOS PARA CORREÇÃO DE DEFEITOS FÍSICOS E APARELHOS ORTOPÉDICOS EM GERAL SOB ENCOMENDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250704",
    "descricao": "FABRICAÇÃO DE APARELHOS E UTENSÍLIOS PARA CORREÇÃO DE DEFEITOS FÍSICOS E APARELHOS ORTOPÉDICOS EM GERAL, EXCETO SOB ENCOMENDA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250705",
    "descricao": "FABRICAÇÃO DE MATERIAIS PARA MEDICINA E ODONTOLOGIA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250706",
    "descricao": "Serviços de prótese dentária",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250707",
    "descricao": "FABRICAÇÃO DE ARTIGOS ÓPTICOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3250709",
    "descricao": "Serviço de laboratório óptico",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3291400",
    "descricao": "FABRICAÇÃO DE ESCOVAS, PINCÉIS E VASSOURAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3292201",
    "descricao": "FABRICAÇÃO DE ROUPAS DE PROTEÇÃO E SEGURANÇA E RESISTENTES A FOGO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3292202",
    "descricao": "FABRICAÇÃO DE EQUIPAMENTOS E ACESSÓRIOS PARA SEGURANÇA PESSOAL E PROFISSIONAL",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299001",
    "descricao": "FABRICAÇÃO DE GUARDA CHUVAS E SIMILARES",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299002",
    "descricao": "FABRICAÇÃO DE CANETAS, LÁPIS E OUTROS ARTIGOS PARA ESCRITÓRIO",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299003",
    "descricao": "FABRICAÇÃO DE LETRAS, LETREIROS E PLACAS DE QUALQUER MATERIAL, EXCETO LUMINOSOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299004",
    "descricao": "FABRICAÇÃO DE PAINÉIS E LETREIROS LUMINOSOS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299005",
    "descricao": "FABRICAÇÃO DE AVIAMENTOS PARA COSTURA",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299006",
    "descricao": "FABRICAÇÃO DE VELAS, INCLUSIVE DECORATIVAS",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3299099",
    "descricao": "FABRICAÇÃO DE PRODUTOS DIVERSOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "II",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3311200",
    "descricao": "MANUTENÇÃO E REPARAÇÃO DE TANQUES, RESERVATÓRIOS METÁLICOS E CALDEIRAS, EXCETO PARA VEÍCULOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3312102",
    "descricao": "Manutenção e reparação de aparelhos e instrumentos de medida, teste e controle",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3312103",
    "descricao": "Manutenção e reparação de aparelhos eletromédicos e eletroterapêuticos e equipamentos de irradiação",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3312104",
    "descricao": "Manutenção e reparação de equipamentos e instrumentos ópticos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3313901",
    "descricao": "Manutenção e reparação de geradores, transformadores e motores elétricos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3313902",
    "descricao": "Manutenção e reparação de baterias e acumuladores elétricos, exceto para veículos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3313999",
    "descricao": "Manutenção e reparação de máquinas, aparelhos e materiais elétricos não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314701",
    "descricao": "Manutenção e reparação de máquinas motrizes não-elétricas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314702",
    "descricao": "Manutenção e reparação de equipamentos hidráulicos e pneumáticos, exceto válvulas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314703",
    "descricao": "Manutenção e reparação de válvulas industriais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314704",
    "descricao": "Manutenção e reparação de compressores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314705",
    "descricao": "Manutenção e reparação de equipamentos de transmissão para fins industriais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314706",
    "descricao": "Manutenção e reparação de máquinas, aparelhos e equipamentos para instalações térmicas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314707",
    "descricao": "Manutenção e reparação de máquinas e aparelhos de refrigeração e ventilação para uso industrial e comercial",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314708",
    "descricao": "Manutenção e reparação de máquinas, equipamentos e aparelhos para transporte e elevação de cargas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314709",
    "descricao": "Manutenção e reparação de máquinas de escrever, calcular e de outros equipamentos não-eletrônicos para escritório",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314710",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para uso geral não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314711",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para agricultura e pecuária",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314712",
    "descricao": "Manutenção e reparação de tratores agrícolas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314713",
    "descricao": "Manutenção e reparação de máquinas-ferramenta",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314714",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para a prospecção e extração de petróleo",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314715",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para uso na extração mineral, exceto na extração de petróleo",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314716",
    "descricao": "Manutenção e reparação de tratores, exceto agrícolas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314717",
    "descricao": "Manutenção e reparação de máquinas e equipamentos de terraplenagem, pavimentação e construção, exceto tratores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314718",
    "descricao": "Manutenção e reparação de máquinas para a indústria metalúrgica, exceto máquinas-ferramenta",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314719",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para as indústrias de alimentos, bebidas e fumo",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314720",
    "descricao": "Manutenção e reparação de máquinas e equipamentos para a indústria têxtil, do vestuário, do couro e calçados",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314721",
    "descricao": "Manutenção e reparação de máquinas e aparelhos para a indústria de celulose, papel e papelão e artefatos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314722",
    "descricao": "Manutenção e reparação de máquinas e aparelhos para a indústria do plástico",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3314799",
    "descricao": "Manutenção e reparação de outras máquinas e equipamentos para usos industriais não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3315500",
    "descricao": "Manutenção e reparação de veículos ferroviários",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3316301",
    "descricao": "Manutenção e reparação de aeronaves, exceto a manutenção na pista",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3316302",
    "descricao": "Manutenção de aeronaves na pista",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3317101",
    "descricao": "Manutenção e reparação de embarcações e estruturas flutuantes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3317102",
    "descricao": "Manutenção e reparação de embarcações para esporte e lazer",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3319800",
    "descricao": "Manutenção e reparação de equipamentos e produtos não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3321000",
    "descricao": "Instalação de máquinas e equipamentos industriais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3329501",
    "descricao": "SERVIÇOS DE MONTAGEM DE MÓVEIS DE QUALQUER MATERIAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3329599",
    "descricao": "INSTALAÇÃO DE OUTROS EQUIPAMENTOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3511501",
    "descricao": "GERAÇÃO DE ENERGIA ELÉTRICA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VII, geradora de energia elétrica)",
    "situacao": "vedado"
  },
  {
    "codigo": "3512300",
    "descricao": "TRANSMISSÃO DE ENERGIA ELÉTRICA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VII, transmissora de energia elétrica)",
    "situacao": "vedado"
  },
  {
    "codigo": "3513100",
    "descricao": "COMÉRCIO ATACADISTA DE ENERGIA ELÉTRICA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VII, comercializadora de energia elétrica)",
    "situacao": "vedado"
  },
  {
    "codigo": "3514000",
    "descricao": "DISTRIBUIÇÃO DE ENERGIA ELÉTRICA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VII, distribuidora de energia elétrica)",
    "situacao": "vedado"
  },
  {
    "codigo": "3520402",
    "descricao": "DISTRIBUIÇÃO DE COMBUSTÍVEIS GASOSOS POR REDES URBANAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3530100",
    "descricao": "PRODUÇÃO E DISTRIBUIÇÃO DE VAPOR, ÁGUA QUENTE E AR CONDICIONADO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3600601",
    "descricao": "CAPTAÇÃO, TRATAMENTO E DISTRIBUIÇÃO DE ÁGUA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3600602",
    "descricao": "DISTRIBUIÇÃO DE ÁGUA POR CAMINHÕES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3701100",
    "descricao": "GESTÃO DE REDES DE ESGOTO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3702900",
    "descricao": "ATIVIDADES RELACIONADAS A ESGOTO, EXCETO A GESTÃO DE REDES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3811400",
    "descricao": "COLETA DE RESÍDUOS NÃO PERIGOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3812200",
    "descricao": "COLETA DE RESÍDUOS PERIGOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3821100",
    "descricao": "TRATAMENTO E DISPOSIÇÃO DE RESÍDUOS NÃO PERIGOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3822000",
    "descricao": "TRATAMENTO E DISPOSIÇÃO DE RESÍDUOS PERIGOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "3900500",
    "descricao": "DESCONTAMINAÇÃO E OUTROS SERVIÇOS DE GESTÃO DE RESÍDUOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4110700",
    "descricao": "INCORPORAÇÃO DE EMPREENDIMENTOS IMOBILIÁRIOS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (XIV, incorporação de imóveis)",
    "situacao": "vedado"
  },
  {
    "codigo": "4120400",
    "descricao": "Construção de edifícios",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4211101",
    "descricao": "CONSTRUÇÃO DE RODOVIAS E FERROVIAS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4211102",
    "descricao": "Pintura para sinalização em pistas rodoviárias e aeroportos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4212000",
    "descricao": "CONSTRUÇÃO DE OBRAS DE ARTE ESPECIAIS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4213800",
    "descricao": "OBRAS DE URBANIZAÇÃO - RUAS, PRAÇAS E CALÇADAS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4221901",
    "descricao": "CONSTRUÇÃO DE BARRAGENS E REPRESAS PARA GERAÇÃO DE ENERGIA ELÉTRICA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4221902",
    "descricao": "CONSTRUÇÃO DE ESTAÇÕES E REDES DE DISTRIBUIÇÃO DE ENERGIA ELÉTRICA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4221903",
    "descricao": "Manutenção de redes de distribuição de energia elétrica",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4221904",
    "descricao": "CONSTRUÇÃO DE ESTAÇÕES E REDES DE TELECOMUNICAÇÕES",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4221905",
    "descricao": "Manutenção de estações e redes de telecomunicações",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4222701",
    "descricao": "CONSTRUÇÃO DE REDES DE ABASTECIMENTO DE ÁGUA, COLETA DE ESGOTO E CONSTRUÇÕES CORRELATAS, EXCETO OBRAS DE IRRIGAÇÃO",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4222702",
    "descricao": "OBRAS DE IRRIGAÇÃO",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4223500",
    "descricao": "CONSTRUÇÃO DE REDES DE TRANSPORTES POR DUTOS, EXCETO PARA ÁGUA E ESGOTO",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4291000",
    "descricao": "OBRAS PORTUÁRIAS, MARÍTIMAS E FLUVIAIS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4292801",
    "descricao": "MONTAGEM DE ESTRUTURAS METÁLICAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4292802",
    "descricao": "OBRAS DE MONTAGEM INDUSTRIAL",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4299501",
    "descricao": "CONSTRUÇÃO DE INSTALAÇÕES ESPORTIVAS E RECREATIVAS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4299599",
    "descricao": "OUTRAS OBRAS DE ENGENHARIA CIVIL NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4311801",
    "descricao": "DEMOLIÇÃO DE EDIFÍCIOS E OUTRAS ESTRUTURAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4311802",
    "descricao": "PREPARAÇÃO DE CANTEIRO E LIMPEZA DE TERRENO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4312600",
    "descricao": "PERFURAÇÕES E SONDAGENS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4313400",
    "descricao": "Obras de terraplenagem",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4319300",
    "descricao": "SERVIÇOS DE PREPARAÇÃO DO TERRENO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4321500",
    "descricao": "Instalação e manutenção elétrica",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4322301",
    "descricao": "Instalações hidráulicas, sanitárias e de gás",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4322302",
    "descricao": "Instalação e manutenção de sistemas centrais de ar condicionado, de ventilação e refrigeração",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4322303",
    "descricao": "Instalações de sistema de prevenção contra incêndio",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329101",
    "descricao": "Instalação de painéis publicitários",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329102",
    "descricao": "Instalação de equipamentos para orientação à navegação marítima, fluvial e lacustre",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329103",
    "descricao": "Instalação, manutenção e reparação de elevadores, escadas e esteiras rolantes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329104",
    "descricao": "Montagem e instalação de sistemas e equipamentos de iluminação e sinalização em vias públicas, portos e aeroportos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329105",
    "descricao": "Tratamentos térmicos, acústicos ou de vibração",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4329199",
    "descricao": "OUTRAS OBRAS DE INSTALAÇÕES EM CONSTRUÇÕES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330401",
    "descricao": "IMPERMEABILIZAÇÃO EM OBRAS DE ENGENHARIA CIVIL",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330402",
    "descricao": "INSTALAÇÃO DE PORTAS, JANELAS, TETOS, DIVISÓRIAS E ARMÁRIOS EMBUTIDOS DE QUALQUER MATERIAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330403",
    "descricao": "OBRAS DE ACABAMENTO EM GESSO E ESTUQUE",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330404",
    "descricao": "SERVIÇOS DE PINTURA DE EDIFÍCIOS EM GERAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330405",
    "descricao": "APLICAÇÃO DE REVESTIMENTOS E DE RESINAS EM INTERIORES E EXTERIORES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4330499",
    "descricao": "OUTRAS OBRAS DE ACABAMENTO DA CONSTRUÇÃO",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4391600",
    "descricao": "OBRAS DE FUNDAÇÕES",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399101",
    "descricao": "Administração de obras",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399102",
    "descricao": "Montagem e desmontagem de andaimes e outras estruturas temporárias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399103",
    "descricao": "OBRAS DE ALVENARIA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399104",
    "descricao": "SERVIÇOS DE OPERAÇÃO E FORNECIMENTO DE EQUIPAMENTOS PARA TRANSPORTE E ELEVAÇÃO DE CARGAS E PESSOAS PARA USO EM OBRAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399105",
    "descricao": "PERFURAÇÃO E CONSTRUÇÃO DE POÇOS DE ÁGUA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C, I",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4399199",
    "descricao": "SERVIÇOS ESPECIALIZADOS PARA CONSTRUÇÃO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511101",
    "descricao": "Comércio a varejo de automóveis, camionetas e utilitários novos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511102",
    "descricao": "COMÉRCIO A VAREJO DE AUTOMÓVEIS, CAMIONETAS E UTILITÁRIOS USADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511103",
    "descricao": "COMÉRCIO POR ATACADO DE AUTOMÓVEIS, CAMIONETAS E UTILITÁRIOS NOVOS E USADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511104",
    "descricao": "COMÉRCIO POR ATACADO DE CAMINHÕES NOVOS E USADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511105",
    "descricao": "COMÉRCIO POR ATACADO DE REBOQUES E SEMI REBOQUES NOVOS E USADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4511106",
    "descricao": "COMÉRCIO POR ATACADO DE ÔNIBUS E MICROÔNIBUS NOVOS E USADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4512901",
    "descricao": "Representantes comerciais e agentes do comércio de veículos automotores",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4512902",
    "descricao": "COMÉRCIO SOB CONSIGNAÇÃO DE VEÍCULOS AUTOMOTORES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520001",
    "descricao": "Serviços de manutenção e reparação mecânica de veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520002",
    "descricao": "Serviços de lanternagem ou funilaria e pintura de veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520003",
    "descricao": "Serviços de manutenção e reparação elétrica de veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520004",
    "descricao": "Serviços de alinhamento e balanceamento de veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520005",
    "descricao": "Serviços de lavagem, lubrificação e polimento de veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520006",
    "descricao": "Serviços de borracharia para veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520007",
    "descricao": "Serviços de instalação, manutenção e reparação de acessórios para veículos automotores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4520008",
    "descricao": "Serviços de capotaria",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530701",
    "descricao": "Comércio por atacado de peças e acessórios novos para veículos automotores",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530702",
    "descricao": "Comércio por atacado de pneumáticos e câmaras-de-ar",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530703",
    "descricao": "Comércio a varejo de peças e acessórios novos para veículos automotores",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530704",
    "descricao": "Comércio a varejo de peças e acessórios usados para veículos automotores",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530705",
    "descricao": "Comércio a varejo de pneumáticos e câmaras-de-ar",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4530706",
    "descricao": "Representantes comerciais e agentes do comércio de peças e acessórios novos e usados para veículos automotores",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541201",
    "descricao": "COMÉRCIO POR ATACADO DE MOTOCICLETAS E MOTONETAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541202",
    "descricao": "Comércio por atacado de peças e acessórios para motocicletas e motonetas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541203",
    "descricao": "Comércio a varejo de motocicletas e motonetas novas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541204",
    "descricao": "Comércio a varejo de motocicletas e motonetas usadas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541206",
    "descricao": "Comércio a varejo de peças e acessórios novos para motocicletas e motonetas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4541207",
    "descricao": "Comércio a varejo de peças e acessórios usados para motocicletas e motonetas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4542101",
    "descricao": "Representantes comerciais e agentes do comércio de motocicletas e motonetas, peças e acessórios",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4542102",
    "descricao": "COMÉRCIO SOB CONSIGNAÇÃO DE MOTOCICLETAS E MOTONETAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4543900",
    "descricao": "Manutenção e reparação de motocicletas e motonetas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4611700",
    "descricao": "Representantes comerciais e agentes do comércio de matérias-primas agrícolas e animais vivos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4612500",
    "descricao": "Representantes comerciais e agentes do comércio de combustíveis, minerais, produtos siderúrgicos e químicos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4613300",
    "descricao": "Representantes comerciais e agentes do comércio de madeira, material de construção e ferragens",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4614100",
    "descricao": "Representantes comerciais e agentes do comércio de máquinas, equipamentos, embarcações e aeronaves",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4615000",
    "descricao": "Representantes comerciais e agentes do comércio de eletrodomésticos, móveis e artigos de uso doméstico",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4616800",
    "descricao": "Representantes comerciais e agentes do comércio de têxteis, vestuário, calçados e artigos de viagem",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4617600",
    "descricao": "Representantes comerciais e agentes do comércio de produtos alimentícios, bebidas e fumo",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4618401",
    "descricao": "Representantes comerciais e agentes do comércio de medicamentos, cosméticos e produtos de perfumaria",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4618402",
    "descricao": "Representantes comerciais e agentes do comércio de instrumentos e materiais odonto-médico-hospitalares",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4618403",
    "descricao": "Representantes comerciais e agentes do comércio de jornais, revistas e outras publicações",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4618499",
    "descricao": "Outros representantes comerciais e agentes do comércio especializado em produtos não especificados anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4619200",
    "descricao": "Representantes comerciais e agentes do comércio de mercadorias em geral não especializado",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4621400",
    "descricao": "COMÉRCIO ATACADISTA DE CAFÉ EM GRÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4622200",
    "descricao": "COMÉRCIO ATACADISTA DE SOJA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623101",
    "descricao": "COMÉRCIO ATACADISTA DE ANIMAIS VIVOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623102",
    "descricao": "COMÉRCIO ATACADISTA DE COUROS, LÃS, PELES E OUTROS SUBPRODUTOS NÃO COMESTÍVEIS DE ORIGEM ANIMAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623103",
    "descricao": "COMÉRCIO ATACADISTA DE ALGODÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623104",
    "descricao": "COMÉRCIO ATACADISTA DE FUMO EM FOLHA NÃO BENEFICIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623105",
    "descricao": "COMÉRCIO ATACADISTA DE CACAU",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623106",
    "descricao": "COMÉRCIO ATACADISTA DE SEMENTES, FLORES, PLANTAS E GRAMAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623107",
    "descricao": "COMÉRCIO ATACADISTA DE SISAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623108",
    "descricao": "COMÉRCIO ATACADISTA DE MATÉRIAS PRIMAS AGRÍCOLAS COM ATIVIDADE DE FRACIONAMENTO E ACONDICIONAMENTO ASSOCIADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623109",
    "descricao": "COMÉRCIO ATACADISTA DE ALIMENTOS PARA ANIMAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4623199",
    "descricao": "COMÉRCIO ATACADISTA DE MATÉRIAS PRIMAS AGRÍCOLAS NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4631100",
    "descricao": "COMÉRCIO ATACADISTA DE LEITE E LATICÍNIOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4632001",
    "descricao": "COMÉRCIO ATACADISTA DE CEREAIS E LEGUMINOSAS BENEFICIADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4632002",
    "descricao": "COMÉRCIO ATACADISTA DE FARINHAS, AMIDOS E FÉCULAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4632003",
    "descricao": "COMÉRCIO ATACADISTA DE CEREAIS E LEGUMINOSAS BENEFICIADOS, FARINHAS, AMIDOS E FÉCULAS, COM ATIVIDADE DE FRACIONAMENTO E ACONDICIONAMENTO ASSOCIADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4633801",
    "descricao": "COMÉRCIO ATACADISTA DE FRUTAS, VERDURAS, RAÍZES, TUBÉRCULOS, HORTALIÇAS E LEGUMES FRESCOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4633802",
    "descricao": "COMÉRCIO ATACADISTA DE AVES VIVAS E OVOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4633803",
    "descricao": "COMÉRCIO ATACADISTA DE COELHOS E OUTROS PEQUENOS ANIMAIS VIVOS PARA ALIMENTAÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4634601",
    "descricao": "COMÉRCIO ATACADISTA DE CARNES BOVINAS E SUÍNAS E DERIVADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4634602",
    "descricao": "COMÉRCIO ATACADISTA DE AVES ABATIDAS E DERIVADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4634603",
    "descricao": "COMÉRCIO ATACADISTA DE PESCADOS E FRUTOS DO MAR",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4634699",
    "descricao": "COMÉRCIO ATACADISTA DE CARNES E DERIVADOS DE OUTROS ANIMAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4635401",
    "descricao": "COMÉRCIO ATACADISTA DE ÁGUA MINERAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4635402",
    "descricao": "COMÉRCIO ATACADISTA DE CERVEJA, CHOPE E REFRIGERANTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4635403",
    "descricao": "COMÉRCIO ATACADISTA DE BEBIDAS COM ATIVIDADE DE FRACIONAMENTO E ACONDICIONAMENTO ASSOCIADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4635499",
    "descricao": "COMÉRCIO ATACADISTA DE BEBIDAS NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4636201",
    "descricao": "COMÉRCIO ATACADISTA DE FUMO BENEFICIADO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4636202",
    "descricao": "COMÉRCIO ATACADISTA DE CIGARROS, CIGARRILHAS E CHARUTOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637101",
    "descricao": "COMÉRCIO ATACADISTA DE CAFÉ TORRADO, MOÍDO E SOLÚVEL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637102",
    "descricao": "COMÉRCIO ATACADISTA DE AÇÚCAR",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637103",
    "descricao": "COMÉRCIO ATACADISTA DE ÓLEOS E GORDURAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637104",
    "descricao": "COMÉRCIO ATACADISTA DE PÃES, BOLOS, BISCOITOS E SIMILARES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637105",
    "descricao": "COMÉRCIO ATACADISTA DE MASSAS ALIMENTÍCIAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637106",
    "descricao": "COMÉRCIO ATACADISTA DE SORVETES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637107",
    "descricao": "COMÉRCIO ATACADISTA DE CHOCOLATES, CONFEITOS, BALAS, BOMBONS E SEMELHANTES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4637199",
    "descricao": "COMÉRCIO ATACADISTA ESPECIALIZADO EM OUTROS PRODUTOS ALIMENTÍCIOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4639701",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS ALIMENTÍCIOS EM GERAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4639702",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS ALIMENTÍCIOS EM GERAL, COM ATIVIDADE DE FRACIONAMENTO E ACONDICIONAMENTO ASSOCIADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4641901",
    "descricao": "COMÉRCIO ATACADISTA DE TECIDOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4641902",
    "descricao": "COMÉRCIO ATACADISTA DE ARTIGOS DE CAMA, MESA E BANHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4641903",
    "descricao": "COMÉRCIO ATACADISTA DE ARTIGOS DE ARMARINHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4642701",
    "descricao": "COMÉRCIO ATACADISTA DE ARTIGOS DO VESTUÁRIO E ACESSÓRIOS, EXCETO PROFISSIONAIS E DE SEGURANÇA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4642702",
    "descricao": "COMÉRCIO ATACADISTA DE ROUPAS E ACESSÓRIOS PARA USO PROFISSIONAL E DE SEGURANÇA DO TRABALHO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4643501",
    "descricao": "COMÉRCIO ATACADISTA DE CALÇADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4643502",
    "descricao": "COMÉRCIO ATACADISTA DE BOLSAS, MALAS E ARTIGOS DE VIAGEM",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4644301",
    "descricao": "COMÉRCIO ATACADISTA DE MEDICAMENTOS E DROGAS DE USO HUMANO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4644302",
    "descricao": "COMÉRCIO ATACADISTA DE MEDICAMENTOS E DROGAS DE USO VETERINÁRIO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4645101",
    "descricao": "COMÉRCIO ATACADISTA DE INSTRUMENTOS E MATERIAIS PARA USO MÉDICO, CIRÚRGICO, HOSPITALAR E DE LABORATÓRIOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4645102",
    "descricao": "COMÉRCIO ATACADISTA DE PRÓTESES E ARTIGOS DE ORTOPEDIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4645103",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS ODONTOLÓGICOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4646001",
    "descricao": "COMÉRCIO ATACADISTA DE COSMÉTICOS E PRODUTOS DE PERFUMARIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4646002",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS DE HIGIENE PESSOAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4647801",
    "descricao": "COMÉRCIO ATACADISTA DE ARTIGOS DE ESCRITÓRIO E DE PAPELARIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4647802",
    "descricao": "COMÉRCIO ATACADISTA DE LIVROS, JORNAIS E OUTRAS PUBLICAÇÕES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649401",
    "descricao": "COMÉRCIO ATACADISTA DE EQUIPAMENTOS ELÉTRICOS DE USO PESSOAL E DOMÉSTICO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649402",
    "descricao": "COMÉRCIO ATACADISTA DE APARELHOS ELETRÔNICOS DE USO PESSOAL E DOMÉSTICO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649403",
    "descricao": "COMÉRCIO ATACADISTA DE BICICLETAS, TRICICLOS E OUTROS VEÍCULOS RECREATIVOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649404",
    "descricao": "COMÉRCIO ATACADISTA DE MÓVEIS E ARTIGOS DE COLCHOARIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649405",
    "descricao": "COMÉRCIO ATACADISTA DE ARTIGOS DE TAPEÇARIA; PERSIANAS E CORTINAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649406",
    "descricao": "COMÉRCIO ATACADISTA DE LUSTRES, LUMINÁRIAS E ABAJURES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649407",
    "descricao": "COMÉRCIO ATACADISTA DE FILMES, CDS, DVDS, FITAS E DISCOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649408",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS DE HIGIENE, LIMPEZA E CONSERVAÇÃO DOMICILIAR",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649409",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS DE HIGIENE, LIMPEZA E CONSERVAÇÃO DOMICILIAR, COM ATIVIDADE DE FRACIONAMENTO E ACONDICIONAMENTO ASSOCIADA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649410",
    "descricao": "COMÉRCIO ATACADISTA DE JÓIAS, RELÓGIOS E BIJUTERIAS, INCLUSIVE PEDRAS PRECIOSAS E SEMIPRECIOSAS LAPIDADAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4649499",
    "descricao": "COMÉRCIO ATACADISTA DE OUTROS EQUIPAMENTOS E ARTIGOS DE USO PESSOAL E DOMÉSTICO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4651601",
    "descricao": "COMÉRCIO ATACADISTA DE EQUIPAMENTOS DE INFORMÁTICA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4651602",
    "descricao": "COMÉRCIO ATACADISTA DE SUPRIMENTOS PARA INFORMÁTICA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4652400",
    "descricao": "COMÉRCIO ATACADISTA DE COMPONENTES ELETRÔNICOS E EQUIPAMENTOS DE TELEFONIA E COMUNICAÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4661300",
    "descricao": "COMÉRCIO ATACADISTA DE MÁQUINAS, APARELHOS E EQUIPAMENTOS PARA USO AGROPECUÁRIO; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4662100",
    "descricao": "COMÉRCIO ATACADISTA DE MÁQUINAS, EQUIPAMENTOS PARA TERRAPLENAGEM, MINERAÇÃO E CONSTRUÇÃO; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4663000",
    "descricao": "COMÉRCIO ATACADISTA DE MÁQUINAS E EQUIPAMENTOS PARA USO INDUSTRIAL; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4664800",
    "descricao": "COMÉRCIO ATACADISTA DE MÁQUINAS, APARELHOS E EQUIPAMENTOS PARA USO ODONTO MÉDICO HOSPITALAR; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4665600",
    "descricao": "COMÉRCIO ATACADISTA DE MÁQUINAS E EQUIPAMENTOS PARA USO COMERCIAL; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4669901",
    "descricao": "COMÉRCIO ATACADISTA DE BOMBAS E COMPRESSORES; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4669999",
    "descricao": "COMÉRCIO ATACADISTA DE OUTRAS MÁQUINAS E EQUIPAMENTOS NÃO ESPECIFICADOS ANTERIORMENTE; PARTES E PEÇAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4671100",
    "descricao": "COMÉRCIO ATACADISTA DE MADEIRA E PRODUTOS DERIVADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4672900",
    "descricao": "COMÉRCIO ATACADISTA DE FERRAGENS E FERRAMENTAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4673700",
    "descricao": "COMÉRCIO ATACADISTA DE MATERIAL ELÉTRICO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4674500",
    "descricao": "COMÉRCIO ATACADISTA DE CIMENTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4679601",
    "descricao": "COMÉRCIO ATACADISTA DE TINTAS, VERNIZES E SIMILARES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4679602",
    "descricao": "COMÉRCIO ATACADISTA DE MÁRMORES E GRANITOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4679603",
    "descricao": "COMÉRCIO ATACADISTA DE VIDROS, ESPELHOS E VITRAIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4679604",
    "descricao": "COMÉRCIO ATACADISTA ESPECIALIZADO DE MATERIAIS DE CONSTRUÇÃO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4679699",
    "descricao": "COMÉRCIO ATACADISTA DE MATERIAIS DE CONSTRUÇÃO EM GERAL",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4681801",
    "descricao": "COMÉRCIO ATACADISTA DE ÁLCOOL CARBURANTE, BIODIESEL, GASOLINA E DEMAIS DERIVADOS DE PETRÓLEO, EXCETO LUBRIFICANTES, NÃO REALIZADO POR TRANSPORTADOR RETALHISTA (T.R.R.)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4681802",
    "descricao": "COMÉRCIO ATACADISTA DE COMBUSTÍVEIS REALIZADO POR TRANSPORTADOR RETALHISTA (T.R.R.)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4681803",
    "descricao": "COMÉRCIO ATACADISTA DE COMBUSTÍVEIS DE ORIGEM VEGETAL, EXCETO ÁLCOOL CARBURANTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4681804",
    "descricao": "COMÉRCIO ATACADISTA DE COMBUSTÍVEIS DE ORIGEM MINERAL EM BRUTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4681805",
    "descricao": "COMÉRCIO ATACADISTA DE LUBRIFICANTES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4682600",
    "descricao": "COMÉRCIO ATACADISTA DE GÁS LIQÜEFEITO DE PETRÓLEO (GLP)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4683400",
    "descricao": "COMÉRCIO ATACADISTA DE DEFENSIVOS AGRÍCOLAS, ADUBOS, FERTILIZANTES E CORRETIVOS DO SOLO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4684201",
    "descricao": "COMÉRCIO ATACADISTA DE RESINAS E ELASTÔMEROS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4684202",
    "descricao": "COMÉRCIO ATACADISTA DE SOLVENTES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4684299",
    "descricao": "COMÉRCIO ATACADISTA DE OUTROS PRODUTOS QUÍMICOS E PETROQUÍMICOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4685100",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS SIDERÚRGICOS E METALÚRGICOS, EXCETO PARA CONSTRUÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4686901",
    "descricao": "COMÉRCIO ATACADISTA DE PAPEL E PAPELÃO EM BRUTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4686902",
    "descricao": "COMÉRCIO ATACADISTA DE EMBALAGENS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4687701",
    "descricao": "COMÉRCIO ATACADISTA DE RESÍDUOS DE PAPEL E PAPELÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4687702",
    "descricao": "COMÉRCIO ATACADISTA DE RESÍDUOS E SUCATAS NÃO METÁLICOS, EXCETO DE PAPEL E PAPELÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4687703",
    "descricao": "COMÉRCIO ATACADISTA DE RESÍDUOS E SUCATAS METÁLICOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4689301",
    "descricao": "COMÉRCIO ATACADISTA DE PRODUTOS DA EXTRAÇÃO MINERAL, EXCETO COMBUSTÍVEIS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4689302",
    "descricao": "COMÉRCIO ATACADISTA DE FIOS E FIBRAS BENEFICIADOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4689399",
    "descricao": "COMÉRCIO ATACADISTA ESPECIALIZADO EM OUTROS PRODUTOS INTERMEDIÁRIOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4691500",
    "descricao": "COMÉRCIO ATACADISTA DE MERCADORIAS EM GERAL, COM PREDOMINÂNCIA DE PRODUTOS ALIMENTÍCIOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4692300",
    "descricao": "COMÉRCIO ATACADISTA DE MERCADORIAS EM GERAL, COM PREDOMINÂNCIA DE INSUMOS AGROPECUÁRIOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4693100",
    "descricao": "COMÉRCIO ATACADISTA DE MERCADORIAS EM GERAL, SEM PREDOMINÂNCIA DE ALIMENTOS OU DE INSUMOS AGROPECUÁRIOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4711301",
    "descricao": "Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios – hipermercados",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4711302",
    "descricao": "Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios – supermercados",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4712100",
    "descricao": "Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios – minimercados, mercearias e armazéns",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4713002",
    "descricao": "Lojas de variedades, exceto lojas de departamentos ou magazines",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4713004",
    "descricao": "Lojas de departamentos ou magazines, exceto lojas francas (Duty free)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4713005",
    "descricao": "LOJAS FRANCAS (DUTY FREE) DE AEROPORTOS, PORTOS E EM FRONTEIRAS TERRESTRES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4721102",
    "descricao": "Padaria e confeitaria com predominância de revenda",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4721103",
    "descricao": "Comércio varejista de laticínios e frios",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4721104",
    "descricao": "Comércio varejista de doces, balas, bombons e semelhantes",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4722901",
    "descricao": "COMÉRCIO VAREJISTA DE CARNES - AÇOUGUES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4722902",
    "descricao": "Peixaria",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4723700",
    "descricao": "Comércio varejista de bebidas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4724500",
    "descricao": "Comércio varejista de hortifrutigranjeiros",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4729601",
    "descricao": "Tabacaria",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4729602",
    "descricao": "Comércio varejista de mercadorias em lojas de conveniência",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4729699",
    "descricao": "Comércio varejista de produtos alimentícios em geral ou especializado em produtos alimentícios não especificados anteriormente",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4731800",
    "descricao": "COMÉRCIO VAREJISTA DE COMBUSTÍVEIS PARA VEÍCULOS AUTOMOTORES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4732600",
    "descricao": "COMÉRCIO VAREJISTA DE LUBRIFICANTES",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4741500",
    "descricao": "Comércio varejista de tintas e materiais para pintura",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4742300",
    "descricao": "Comércio varejista de material elétrico",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4743100",
    "descricao": "Comércio varejista de vidros",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744001",
    "descricao": "Comércio varejista de ferragens e ferramentas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744002",
    "descricao": "Comércio varejista de madeira e artefatos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744003",
    "descricao": "Comércio varejista de materiais hidráulicos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744004",
    "descricao": "Comércio varejista de cal, areia, pedra britada, tijolos e telhas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744005",
    "descricao": "Comércio varejista de materiais de construção não especificados anteriormente",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744006",
    "descricao": "Comércio varejista de pedras para revestimento",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4744099",
    "descricao": "Comércio varejista de materiais de construção em geral",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4751201",
    "descricao": "Comércio varejista especializado de equipamentos e suprimentos de informática",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4751202",
    "descricao": "Recarga de cartuchos para equipamentos de informática",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4752100",
    "descricao": "Comércio varejista especializado de equipamentos de telefonia e comunicação",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4753900",
    "descricao": "Comércio varejista especializado de eletrodomésticos e equipamentos de áudio e vídeo",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4754701",
    "descricao": "Comércio varejista de móveis",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4754702",
    "descricao": "Comércio varejista de artigos de colchoaria",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4754703",
    "descricao": "Comércio varejista de artigos de iluminação",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4755501",
    "descricao": "Comércio varejista de tecidos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4755502",
    "descricao": "Comércio varejista de artigos de armarinho",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4755503",
    "descricao": "Comércio varejista de artigos de cama, mesa e banho",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4756300",
    "descricao": "Comércio varejista especializado de instrumentos musicais e acessórios",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4757100",
    "descricao": "Comércio varejista especializado de peças e acessórios para aparelhos eletroeletrônicos para uso doméstico, exceto informática e comunicação",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4759801",
    "descricao": "Comércio varejista de artigos de tapeçaria, cortinas e persianas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4759899",
    "descricao": "Comércio varejista de outros artigos de uso doméstico não especificados anteriormente",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4761001",
    "descricao": "Comércio varejista de livros",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4761002",
    "descricao": "Comércio varejista de jornais e revistas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4761003",
    "descricao": "Comércio varejista de artigos de papelaria",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4762800",
    "descricao": "Comércio varejista de discos, CDs, DVDs e fitas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4763601",
    "descricao": "Comércio varejista de brinquedos e artigos recreativos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4763602",
    "descricao": "Comércio varejista de artigos esportivos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4763603",
    "descricao": "Comércio varejista de bicicletas e triciclos peças e acessórios",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4763604",
    "descricao": "Comércio varejista de artigos de caça, pesca e camping",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4763605",
    "descricao": "Comércio varejista de embarcações e outros veículos recreativos peças e acessórios",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4771701",
    "descricao": "COMÉRCIO VAREJISTA DE PRODUTOS FARMACÊUTICOS, SEM MANIPULAÇÃO DE FÓRMULAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4771702",
    "descricao": "COMÉRCIO VAREJISTA DE PRODUTOS FARMACÊUTICOS, COM MANIPULAÇÃO DE FÓRMULAS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4771703",
    "descricao": "COMÉRCIO VAREJISTA DE PRODUTOS FARMACÊUTICOS HOMEOPÁTICOS",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4771704",
    "descricao": "Comércio varejista de medicamentos veterinários",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4772500",
    "descricao": "Comércio varejista de cosméticos, produtos de perfumaria e de higiene pessoal",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4773300",
    "descricao": "Comércio varejista de artigos médicos e ortopédicos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4774100",
    "descricao": "Comércio varejista de artigos de óptica",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4781400",
    "descricao": "Comércio varejista de artigos do vestuário e acessórios",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4782201",
    "descricao": "Comércio varejista de calçados",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4782202",
    "descricao": "Comércio varejista de artigos de viagem",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4783101",
    "descricao": "COMÉRCIO VAREJISTA DE ARTIGOS DE JOALHERIA",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4783102",
    "descricao": "Comércio varejista de artigos de relojoaria",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4784900",
    "descricao": "COMÉRCIO VAREJISTA DE GÁS LIQÜEFEITO DE PETRÓLEO (GLP)",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4785701",
    "descricao": "Comércio varejista de antigüidades",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4785799",
    "descricao": "Comércio varejista de outros artigos usados",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789001",
    "descricao": "Comércio varejista de suvenires, bijuterias e artesanatos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789002",
    "descricao": "Comércio varejista de plantas e flores naturais",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789003",
    "descricao": "Comércio varejista de objetos de arte",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789004",
    "descricao": "COMÉRCIO VAREJISTA DE ANIMAIS VIVOS E DE ARTIGOS E ALIMENTOS PARA ANIMAIS DE ESTIMAÇÃO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "ibge/cnae/subclasses",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789005",
    "descricao": "Comércio varejista de produtos saneantes domissanitários",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789006",
    "descricao": "Comércio varejista de fogos de artifício e artigos pirotécnicos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789007",
    "descricao": "Comércio varejista de equipamentos para escritório",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789008",
    "descricao": "Comércio varejista de artigos fotográficos e para filmagem",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789009",
    "descricao": "Comércio varejista de armas e munições",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4789099",
    "descricao": "Comércio varejista de outros produtos não especificados anteriormente",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4911600",
    "descricao": "TRANSPORTE FERROVIÁRIO DE CARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4912401",
    "descricao": "TRANSPORTE FERROVIÁRIO DE PASSAGEIROS INTERMUNICIPAL E INTERESTADUAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VI, transporte ferroviário de passageiros intermunicipal e interestadual)",
    "situacao": "vedado"
  },
  {
    "codigo": "4912402",
    "descricao": "TRANSPORTE FERROVIÁRIO DE PASSAGEIROS MUNICIPAL E EM REGIÃO METROPOLITANA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4912403",
    "descricao": "TRANSPORTE METROVIÁRIO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4921301",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, COM ITINERÁRIO FIXO, MUNICIPAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4921302",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, COM ITINERÁRIO FIXO, INTERMUNICIPAL EM REGIÃO METROPOLITANA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4922101",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, COM ITINERÁRIO FIXO, INTERMUNICIPAL, EXCETO EM REGIÃO METROPOLITANA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VI, transporte rodoviário de passageiros intermunicipal)",
    "situacao": "vedado"
  },
  {
    "codigo": "4922102",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, COM ITINERÁRIO FIXO, INTERESTADUAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VI, transporte rodoviário de passageiros interestadual)",
    "situacao": "vedado"
  },
  {
    "codigo": "4922103",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, COM ITINERÁRIO FIXO, INTERNACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4923001",
    "descricao": "SERVIÇO DE TÁXI",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4923002",
    "descricao": "SERVIÇO DE TRANSPORTE DE PASSAGEIROS - LOCAÇÃO DE AUTOMÓVEIS COM MOTORISTA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4924800",
    "descricao": "TRANSPORTE ESCOLAR",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4929901",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, SOB REGIME DE FRETAMENTO, MUNICIPAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4929902",
    "descricao": "TRANSPORTE RODOVIÁRIO COLETIVO DE PASSAGEIROS, SOB REGIME DE FRETAMENTO, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (VI, fretamento de passageiros intermunicipal e interestadual)",
    "situacao": "vedado"
  },
  {
    "codigo": "4929903",
    "descricao": "ORGANIZAÇÃO DE EXCURSÕES EM VEÍCULOS RODOVIÁRIOS PRÓPRIOS, MUNICIPAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4929904",
    "descricao": "ORGANIZAÇÃO DE EXCURSÕES EM VEÍCULOS RODOVIÁRIOS PRÓPRIOS, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4929999",
    "descricao": "OUTROS TRANSPORTES RODOVIÁRIOS DE PASSAGEIROS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4930201",
    "descricao": "TRANSPORTE RODOVIÁRIO DE CARGA, EXCETO PRODUTOS PERIGOSOS E MUDANÇAS, MUNICIPAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4930202",
    "descricao": "TRANSPORTE RODOVIÁRIO DE CARGA, EXCETO PRODUTOS PERIGOSOS E MUDANÇAS, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4930203",
    "descricao": "TRANSPORTE RODOVIÁRIO DE PRODUTOS PERIGOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4930204",
    "descricao": "TRANSPORTE RODOVIÁRIO DE MUDANÇAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4940000",
    "descricao": "TRANSPORTE DUTOVIÁRIO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "4950700",
    "descricao": "TRENS TURÍSTICOS, TELEFÉRICOS E SIMILARES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5011401",
    "descricao": "TRANSPORTE MARÍTIMO DE CABOTAGEM - CARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5011402",
    "descricao": "TRANSPORTE MARÍTIMO DE CABOTAGEM - PASSAGEIROS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5012201",
    "descricao": "TRANSPORTE MARÍTIMO DE LONGO CURSO - CARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5012202",
    "descricao": "TRANSPORTE MARÍTIMO DE LONGO CURSO - PASSAGEIROS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5021101",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO INTERIOR DE CARGA, MUNICIPAL, EXCETO TRAVESSIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5021102",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO INTERIOR DE CARGA, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL, EXCETO TRAVESSIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5022001",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO INTERIOR DE PASSAGEIROS EM LINHAS REGULARES, MUNICIPAL, EXCETO TRAVESSIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5022002",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO INTERIOR DE PASSAGEIROS EM LINHAS REGULARES, INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL, EXCETO TRAVESSIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5030101",
    "descricao": "NAVEGAÇÃO DE APOIO MARÍTIMO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5030102",
    "descricao": "NAVEGAÇÃO DE APOIO PORTUÁRIO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5030103",
    "descricao": "SERVIÇO DE REBOCADORES E EMPURRADORES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5091201",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO DE TRAVESSIA, MUNICIPAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5091202",
    "descricao": "TRANSPORTE POR NAVEGAÇÃO DE TRAVESSIA INTERMUNICIPAL, INTERESTADUAL E INTERNACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5099801",
    "descricao": "TRANSPORTE AQUAVIÁRIO PARA PASSEIOS TURÍSTICOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5099899",
    "descricao": "OUTROS TRANSPORTES AQUAVIÁRIOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5111100",
    "descricao": "TRANSPORTE AÉREO DE PASSAGEIROS REGULAR",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5112901",
    "descricao": "SERVIÇO DE TÁXI AÉREO E LOCAÇÃO DE AERONAVES COM TRIPULAÇÃO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5112999",
    "descricao": "OUTROS SERVIÇOS DE TRANSPORTE AÉREO DE PASSAGEIROS NÃO REGULAR",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5120000",
    "descricao": "TRANSPORTE AÉREO DE CARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5130700",
    "descricao": "TRANSPORTE ESPACIAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5211701",
    "descricao": "ARMAZÉNS GERAIS - EMISSÃO DE WARRANT",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5211702",
    "descricao": "Guarda-móveis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5211799",
    "descricao": "DEPÓSITOS DE MERCADORIAS PARA TERCEIROS, EXCETO ARMAZÉNS GERAIS E GUARDA MÓVEIS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5212500",
    "descricao": "CARGA E DESCARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5221400",
    "descricao": "CONCESSIONÁRIAS DE RODOVIAS, PONTES, TÚNEIS E SERVIÇOS RELACIONADOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5222200",
    "descricao": "TERMINAIS RODOVIÁRIOS E FERROVIÁRIOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5223100",
    "descricao": "ESTACIONAMENTO DE VEÍCULOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5229001",
    "descricao": "SERVIÇOS DE APOIO AO TRANSPORTE POR TÁXI, INCLUSIVE CENTRAIS DE CHAMADA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5229002",
    "descricao": "SERVIÇOS DE REBOQUE DE VEÍCULOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5229099",
    "descricao": "OUTRAS ATIVIDADES AUXILIARES DOS TRANSPORTES TERRESTRES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5231101",
    "descricao": "ADMINISTRAÇÃO DA INFRAESTRUTURA PORTUÁRIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5231102",
    "descricao": "ATIVIDADES DO OPERADOR PORTUÁRIO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5231103",
    "descricao": "GESTÃO DE TERMINAIS AQUAVIÁRIOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5232000",
    "descricao": "ATIVIDADES DE AGENCIAMENTO MARÍTIMO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5239701",
    "descricao": "SERVIÇOS DE PRATICAGEM",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5239799",
    "descricao": "ATIVIDADES AUXILIARES DOS TRANSPORTES AQUAVIÁRIOS NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5240101",
    "descricao": "OPERAÇÃO DOS AEROPORTOS E CAMPOS DE ATERRISSAGEM",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5240199",
    "descricao": "ATIVIDADES AUXILIARES DOS TRANSPORTES AÉREOS, EXCETO OPERAÇÃO DOS AEROPORTOS E CAMPOS DE ATERRISSAGEM",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5250801",
    "descricao": "COMISSARIA DE DESPACHOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5250802",
    "descricao": "ATIVIDADES DE DESPACHANTES ADUANEIROS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5250803",
    "descricao": "AGENCIAMENTO DE CARGAS, EXCETO PARA O TRANSPORTE MARÍTIMO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5250804",
    "descricao": "ORGANIZAÇÃO LOGÍSTICA DO TRANSPORTE DE CARGA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5250805",
    "descricao": "OPERADOR DE TRANSPORTE MULTIMODAL - OTM",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5310501",
    "descricao": "ATIVIDADES DO CORREIO NACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5310502",
    "descricao": "ATIVIDADES DE FRANQUEADAS DO CORREIO NACIONAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5320201",
    "descricao": "Serviços de malote não realizados pelo Correio Nacional",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5320202",
    "descricao": "Serviços de entrega rápida",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5510801",
    "descricao": "Hotéis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5510802",
    "descricao": "Apart-hotéis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5510803",
    "descricao": "Motéis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5590601",
    "descricao": "Albergues, exceto assistenciais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5590602",
    "descricao": "Campings",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5590603",
    "descricao": "Pensões (alojamento)",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5590699",
    "descricao": "Outros alojamentos não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5611201",
    "descricao": "Restaurantes e similares",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5611203",
    "descricao": "Lanchonetes, casas de chá, de sucos e similares",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5611204",
    "descricao": "Bares e outros estabelecimentos especializados em servir bebidas, sem entretenimento",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5611205",
    "descricao": "BARES E OUTROS ESTABELECIMENTOS ESPECIALIZADOS EM SERVIR BEBIDAS, COM ENTRETENIMENTO",
    "anexo": "I",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §4º, I (revenda de mercadorias)",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5620101",
    "descricao": "Fornecimento de alimentos preparados preponderantemente para empresas",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5620102",
    "descricao": "Serviços de alimentação para eventos e recepções – bufê",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5620103",
    "descricao": "Cantinas – serviços de alimentação privativos",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5620104",
    "descricao": "Fornecimento de alimentos preparados preponderantemente para consumo domiciliar",
    "anexo": "I",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5811500",
    "descricao": "Edição de livros",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5812301",
    "descricao": "Edição de jornais diários",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5812302",
    "descricao": "Edição de jornais não diários",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5813100",
    "descricao": "Edição de revistas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5819100",
    "descricao": "Edição de cadastros, listas e outros produtos gráficos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5911101",
    "descricao": "Estúdios cinematográficos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5911102",
    "descricao": "Produção de filmes para publicidade",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5911199",
    "descricao": "Atividades de produção cinematográfica, de vídeos e de programas de televisão não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5912001",
    "descricao": "Serviços de dublagem",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5912002",
    "descricao": "Serviços de mixagem sonora em produção audiovisual",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5912099",
    "descricao": "Atividades de pós-produção cinematográfica, de vídeos e de programas de televisão não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5913800",
    "descricao": "Distribuição cinematográfica, de vídeo e de programas de televisão",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5914600",
    "descricao": "Atividades de exibição cinematográfica",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "5920100",
    "descricao": "Atividades de gravação de som e de edição de música",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6110801",
    "descricao": "SERVIÇOS DE TELEFONIA FIXA COMUTADA - STFC",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6110802",
    "descricao": "SERVIÇOS DE REDES DE TRANSPORTES DE TELECOMUNICAÇÕES - SRTT",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6110803",
    "descricao": "SERVIÇOS DE COMUNICAÇÃO MULTIMÍDIA - SCM",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6110899",
    "descricao": "SERVIÇOS DE TELECOMUNICAÇÕES POR FIO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6120501",
    "descricao": "TELEFONIA MÓVEL CELULAR",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6120502",
    "descricao": "SERVIÇO MÓVEL ESPECIALIZADO - SME",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6120599",
    "descricao": "SERVIÇOS DE TELECOMUNICAÇÕES SEM FIO NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6130200",
    "descricao": "TELECOMUNICAÇÕES POR SATÉLITE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6141800",
    "descricao": "OPERADORAS DE TELEVISÃO POR ASSINATURA POR CABO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6142600",
    "descricao": "OPERADORAS DE TELEVISÃO POR ASSINATURA POR MICROONDAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6143400",
    "descricao": "OPERADORAS DE TELEVISÃO POR ASSINATURA POR SATÉLITE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6190601",
    "descricao": "PROVEDORES DE ACESSO ÀS REDES DE COMUNICAÇÕES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6190602",
    "descricao": "PROVEDORES DE VOZ SOBRE PROTOCOLO INTERNET - VOIP",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6190699",
    "descricao": "OUTRAS ATIVIDADES DE TELECOMUNICAÇÕES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6201501",
    "descricao": "Desenvolvimento de programas de computador sob encomenda",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6201502",
    "descricao": "Web design",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6202300",
    "descricao": "Desenvolvimento e licenciamento de programas de computador customizáveis",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6203100",
    "descricao": "Desenvolvimento e licenciamento de programas de computador não-customizáveis",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6204000",
    "descricao": "Consultoria em tecnologia da informação",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6209100",
    "descricao": "Suporte técnico, manutenção e outros serviços em tecnologia da informação",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6311900",
    "descricao": "Tratamento de dados, provedores de serviços de aplicação e serviços de hospedagem na internet",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6319400",
    "descricao": "Portais, provedores de conteúdo e outros serviços de informação na internet",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6391700",
    "descricao": "Agências de notícias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6399200",
    "descricao": "Outras atividades de prestação de serviços de informação não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6410700",
    "descricao": "BANCO CENTRAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "6421200",
    "descricao": "BANCOS COMERCIAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (banco comercial)",
    "situacao": "vedado"
  },
  {
    "codigo": "6422100",
    "descricao": "BANCOS MÚLTIPLOS, COM CARTEIRA COMERCIAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (banco comercial)",
    "situacao": "vedado"
  },
  {
    "codigo": "6423900",
    "descricao": "CAIXAS ECONÔMICAS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (caixa econômica)",
    "situacao": "vedado"
  },
  {
    "codigo": "6431000",
    "descricao": "BANCOS MÚLTIPLOS, SEM CARTEIRA COMERCIAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (banco de investimentos ou de desenvolvimento)",
    "situacao": "vedado"
  },
  {
    "codigo": "6432800",
    "descricao": "BANCOS DE INVESTIMENTO",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (banco de investimentos)",
    "situacao": "vedado"
  },
  {
    "codigo": "6433600",
    "descricao": "BANCOS DE DESENVOLVIMENTO",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (banco de desenvolvimento)",
    "situacao": "vedado"
  },
  {
    "codigo": "6435201",
    "descricao": "SOCIEDADES DE CRÉDITO IMOBILIÁRIO",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (sociedade de crédito imobiliário)",
    "situacao": "vedado"
  },
  {
    "codigo": "6436100",
    "descricao": "SOCIEDADES DE CRÉDITO, FINANCIAMENTO E INVESTIMENTO - FINANCEIRAS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (sociedade de crédito, financiamento e investimento)",
    "situacao": "vedado"
  },
  {
    "codigo": "6440900",
    "descricao": "ARRENDAMENTO MERCANTIL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (arrendamento mercantil)",
    "situacao": "vedado"
  },
  {
    "codigo": "6450600",
    "descricao": "SOCIEDADES DE CAPITALIZAÇÃO",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (capitalização)",
    "situacao": "vedado"
  },
  {
    "codigo": "6511101",
    "descricao": "SOCIEDADE SEGURADORA DE SEGUROS VIDA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (seguros privados)",
    "situacao": "vedado"
  },
  {
    "codigo": "6512000",
    "descricao": "SOCIEDADE SEGURADORA DE SEGUROS NÃO VIDA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (seguros privados)",
    "situacao": "vedado"
  },
  {
    "codigo": "6520100",
    "descricao": "SOCIEDADE SEGURADORA DE SEGUROS SAÚDE",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (seguros privados)",
    "situacao": "vedado"
  },
  {
    "codigo": "6541300",
    "descricao": "PREVIDÊNCIA COMPLEMENTAR FECHADA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (previdência complementar)",
    "situacao": "vedado"
  },
  {
    "codigo": "6542100",
    "descricao": "PREVIDÊNCIA COMPLEMENTAR ABERTA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, §4º, VIII (previdência complementar)",
    "situacao": "vedado"
  },
  {
    "codigo": "6612605",
    "descricao": "Agentes de investimentos em aplicações financeiras",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6619302",
    "descricao": "Correspondentes de instituições financeiras",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6621501",
    "descricao": "Peritos e avaliadores de seguros",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6621502",
    "descricao": "Auditoria e consultoria atuarial",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6622300",
    "descricao": "Corretores e agentes de seguros, de planos de previdência complementar e de saúde",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6629100",
    "descricao": "Atividades auxiliares dos seguros, da previdência complementar e dos planos de saúde não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6810203",
    "descricao": "LOTEAMENTO DE IMÓVEIS PRÓPRIOS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (XIV, loteamento de imóveis)",
    "situacao": "vedado"
  },
  {
    "codigo": "6821801",
    "descricao": "Corretagem na compra e venda e avaliação de imóveis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6821802",
    "descricao": "Corretagem no aluguel de imóveis",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6822600",
    "descricao": "Gestão e administração da propriedade imobiliária",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6911701",
    "descricao": "Serviços advocatícios",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6911702",
    "descricao": "Atividades auxiliares da justiça",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6911703",
    "descricao": "Agente de propriedade industrial",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6920601",
    "descricao": "ATIVIDADES DE CONTABILIDADE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-B, XIV",
    "situacao": "enquadrado"
  },
  {
    "codigo": "6920602",
    "descricao": "ATIVIDADES DE CONSULTORIA E AUDITORIA CONTÁBIL E TRIBUTÁRIA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-B, XIV",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7020400",
    "descricao": "Atividades de consultoria em gestão empresarial, exceto consultoria técnica específica",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7111100",
    "descricao": "Serviços de arquitetura",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7112000",
    "descricao": "Serviços de engenharia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7119701",
    "descricao": "Serviços de cartografia, topografia e geodésia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7119702",
    "descricao": "Atividades de estudos geológicos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7119703",
    "descricao": "Serviços de desenho técnico relacionados à arquitetura e engenharia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7119704",
    "descricao": "Serviços de perícia técnica relacionados à segurança do trabalho",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7119799",
    "descricao": "Atividades técnicas relacionadas à engenharia e arquitetura não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7120100",
    "descricao": "Testes e análises técnicas",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7210000",
    "descricao": "Pesquisa e desenvolvimento experimental em ciências físicas e naturais",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7220700",
    "descricao": "Pesquisa e desenvolvimento experimental em ciências sociais e humanas",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7311400",
    "descricao": "Agências de publicidade",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7312200",
    "descricao": "Agenciamento de espaços para publicidade exceto em veículos de comunicação",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7319001",
    "descricao": "Criação de estandes para feiras e exposições",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7319002",
    "descricao": "Promoção de vendas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7319003",
    "descricao": "Marketing direto",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7319004",
    "descricao": "Consultoria em publicidade",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7319099",
    "descricao": "Outras atividades de publicidade não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7320300",
    "descricao": "Pesquisas de mercado e de opinião pública",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7410202",
    "descricao": "Design de interiores",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7410203",
    "descricao": "Design de produto",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7410299",
    "descricao": "Atividades de design não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7420001",
    "descricao": "Atividades de produção de fotografias, exceto aérea e submarina",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7420002",
    "descricao": "Atividades de produção de fotografias aéreas e submarinas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7420003",
    "descricao": "Laboratórios fotográficos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7420004",
    "descricao": "Filmagem de festas e eventos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7420005",
    "descricao": "Serviços de microfilmagem",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490101",
    "descricao": "Serviços de tradução, interpretação e similares",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490102",
    "descricao": "Escafandria e mergulho",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490103",
    "descricao": "Serviços de agronomia e de consultoria às atividades agrícolas e pecuárias",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490104",
    "descricao": "Atividades de intermediação e agenciamento de serviços e negócios em geral, exceto imobiliários",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490105",
    "descricao": "Agenciamento de profissionais para atividades esportivas, culturais e artísticas",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7490199",
    "descricao": "Outras atividades profissionais, científicas e técnicas não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7500100",
    "descricao": "Atividades veterinárias",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7711000",
    "descricao": "Locação de automóveis sem condutor",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7721700",
    "descricao": "Aluguel de equipamentos recreativos e esportivos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7722500",
    "descricao": "Aluguel de fitas de vídeo, DVDs e similares",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7723300",
    "descricao": "Aluguel de objetos do vestuário, jóias e acessórios",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7729201",
    "descricao": "Aluguel de aparelhos de jogos eletrônicos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7729202",
    "descricao": "Aluguel de móveis, utensílios e aparelhos de uso doméstico e pessoal; instrumentos musicais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7729203",
    "descricao": "Aluguel de material médico",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7729299",
    "descricao": "Aluguel de outros objetos pessoais e domésticos não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7731400",
    "descricao": "Aluguel de máquinas e equipamentos agrícolas sem operador",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7732201",
    "descricao": "Aluguel de máquinas e equipamentos para construção sem operador, exceto andaimes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7732202",
    "descricao": "Aluguel de andaimes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7733100",
    "descricao": "Aluguel de máquinas e equipamentos para escritório",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7739001",
    "descricao": "Aluguel de máquinas e equipamentos para extração de minérios e petróleo, sem operador",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7739002",
    "descricao": "Aluguel de equipamentos científicos, médicos e hospitalares, sem operador",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7739003",
    "descricao": "Aluguel de palcos, coberturas e outras estruturas de uso temporário, exceto andaimes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7739099",
    "descricao": "Aluguel de outras máquinas e equipamentos comerciais e industriais não especificados anteriormente, sem operador",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7740300",
    "descricao": "Gestão de ativos intangíveis não-financeiros",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7810800",
    "descricao": "SELEÇÃO E AGENCIAMENTO DE MÃO DE OBRA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7820500",
    "descricao": "LOCAÇÃO DE MÃO DE OBRA TEMPORÁRIA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 17 (XII, locação de mão-de-obra)",
    "situacao": "vedado"
  },
  {
    "codigo": "7911200",
    "descricao": "Agências de viagens",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7912100",
    "descricao": "Operadores turísticos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "7990200",
    "descricao": "Serviços de reservas e outros serviços de turismo não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8011101",
    "descricao": "ATIVIDADES DE VIGILÂNCIA E SEGURANÇA PRIVADA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C (vigilância)",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8011102",
    "descricao": "Serviços de adestramento de cães de guarda",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8020001",
    "descricao": "Atividades de monitoramento de sistemas de segurança eletrônico",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8020002",
    "descricao": "OUTRAS ATIVIDADES DE SERVIÇOS DE SEGURANÇA",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C (vigilância)",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8030700",
    "descricao": "Atividades de investigação particular",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8111700",
    "descricao": "SERVIÇOS COMBINADOS PARA APOIO A EDIFÍCIOS, EXCETO CONDOMÍNIOS PREDIAIS",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-C (conservação)",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8121400",
    "descricao": "Limpeza em prédios e em domicílios",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8122200",
    "descricao": "Imunização e controle de pragas urbanas",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8129000",
    "descricao": "Atividades de limpeza não especificadas anteriormente",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8130300",
    "descricao": "Atividades paisagísticas",
    "anexo": "IV",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8211300",
    "descricao": "Serviços combinados de escritório e apoio administrativo",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8219901",
    "descricao": "Fotocópias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8219999",
    "descricao": "Preparação de documentos e serviços especializados de apoio administrativo não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8220200",
    "descricao": "Atividades de teleatendimento",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8230001",
    "descricao": "Serviços de organização de feiras, congressos, exposições e festas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8230002",
    "descricao": "Casas de festas e eventos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8291100",
    "descricao": "Atividades de cobrança e informações cadastrais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8292000",
    "descricao": "ENVASAMENTO E EMPACOTAMENTO SOB CONTRATO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8299701",
    "descricao": "Medição de consumo de energia elétrica, gás e água",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8299703",
    "descricao": "Serviços de gravação de carimbos, exceto confecção",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8299707",
    "descricao": "Salas de acesso à internet",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8299799",
    "descricao": "Outras atividades de serviços prestados principalmente às empresas não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8411600",
    "descricao": "ADMINISTRAÇÃO PÚBLICA EM GERAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8412400",
    "descricao": "REGULAÇÃO DAS ATIVIDADES DE SAÚDE, EDUCAÇÃO, SERVIÇOS CULTURAIS E OUTROS SERVIÇOS SOCIAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8413200",
    "descricao": "REGULAÇÃO DAS ATIVIDADES ECONÔMICAS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8421300",
    "descricao": "RELAÇÕES EXTERIORES",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8422100",
    "descricao": "DEFESA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8423000",
    "descricao": "JUSTIÇA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8424800",
    "descricao": "SEGURANÇA E ORDEM PÚBLICA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8425600",
    "descricao": "DEFESA CIVIL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8430200",
    "descricao": "SEGURIDADE SOCIAL OBRIGATÓRIA",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "8511200",
    "descricao": "Educação infantil – creche",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8512100",
    "descricao": "Educação infantil – pré-escola",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8513900",
    "descricao": "Ensino fundamental",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8520100",
    "descricao": "Ensino médio",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8531700",
    "descricao": "Educação superior – graduação",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8532500",
    "descricao": "Educação superior – graduação e pós-graduação",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8533300",
    "descricao": "Educação superior – pós-graduação e extensão",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8541400",
    "descricao": "Educação profissional de nível técnico",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8542200",
    "descricao": "Educação profissional de nível tecnológico",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8550302",
    "descricao": "Atividades de apoio à educação, exceto caixas escolares",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8591100",
    "descricao": "Ensino de esportes",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8592901",
    "descricao": "Ensino de dança",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8592902",
    "descricao": "Ensino de artes cênicas, exceto dança",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8592903",
    "descricao": "Ensino de música",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8592999",
    "descricao": "Ensino de arte e cultura não especificado anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8593700",
    "descricao": "Ensino de idiomas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599601",
    "descricao": "Formação de condutores",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599602",
    "descricao": "Cursos de pilotagem",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599603",
    "descricao": "Treinamento em informática",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599604",
    "descricao": "Treinamento em desenvolvimento profissional e gerencial",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599605",
    "descricao": "Cursos preparatórios para concursos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8599699",
    "descricao": "Outras atividades de ensino não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8610101",
    "descricao": "Atividades de atendimento hospitalar, exceto pronto-socorro e unidades para atendimento a urgências",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8610102",
    "descricao": "Atividades de atendimento em pronto-socorro e unidades hospitalares para atendimento a urgências",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8621601",
    "descricao": "UTI móvel",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8621602",
    "descricao": "Serviços móveis de atendimento a urgências, exceto por UTI móvel",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8622400",
    "descricao": "Serviços de remoção de pacientes, exceto os serviços móveis de atendimento a urgências",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630501",
    "descricao": "Atividade médica ambulatorial com recursos para realização de procedimentos cirúrgicos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630502",
    "descricao": "Atividade médica ambulatorial com recursos para realização de exames complementares",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630503",
    "descricao": "Atividade médica ambulatorial restrita a consultas",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630504",
    "descricao": "Atividade odontológica",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630506",
    "descricao": "Serviços de vacinação e imunização humana",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630507",
    "descricao": "Atividades de reprodução humana assistida",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8630599",
    "descricao": "Atividades de atenção ambulatorial não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640201",
    "descricao": "Laboratórios de anatomia patológica e citológica",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640202",
    "descricao": "Laboratórios clínicos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640203",
    "descricao": "Serviços de diálise e nefrologia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640204",
    "descricao": "Serviços de tomografia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640205",
    "descricao": "Serviços de diagnóstico por imagem com uso de radiação ionizante, exceto tomografia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640206",
    "descricao": "Serviços de ressonância magnética",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640207",
    "descricao": "Serviços de diagnóstico por imagem sem uso de radiação ionizante, exceto ressonância magnética",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640208",
    "descricao": "Serviços de diagnóstico por registro gráfico – ECG, EEG e outros exames análogos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640209",
    "descricao": "Serviços de diagnóstico por métodos ópticos – endoscopia e outros exames análogos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640210",
    "descricao": "Serviços de quimioterapia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640211",
    "descricao": "Serviços de radioterapia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640212",
    "descricao": "Serviços de hemoterapia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640213",
    "descricao": "Serviços de litotripsia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640214",
    "descricao": "Serviços de bancos de células e tecidos humanos",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8640299",
    "descricao": "Atividades de serviços de complementação diagnóstica e terapêutica não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650001",
    "descricao": "Atividades de enfermagem",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650002",
    "descricao": "Atividades de profissionais da nutrição",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650003",
    "descricao": "Atividades de psicologia e psicanálise",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650004",
    "descricao": "Atividades de fisioterapia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650005",
    "descricao": "Atividades de terapia ocupacional",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650006",
    "descricao": "Atividades de fonoaudiologia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650007",
    "descricao": "Atividades de terapia de nutrição enteral e parenteral",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8650099",
    "descricao": "Atividades de profissionais da área de saúde não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8660700",
    "descricao": "Atividades de apoio à gestão de saúde",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8690901",
    "descricao": "Atividades de práticas integrativas e complementares em saúde humana",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8690902",
    "descricao": "Atividades de banco de leite humano",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8690903",
    "descricao": "Atividades de acupuntura",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8690904",
    "descricao": "Atividades de podologia",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8690999",
    "descricao": "Outras atividades de atenção à saúde humana não especificadas anteriormente",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8711501",
    "descricao": "Clínicas e residências geriátricas",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8711502",
    "descricao": "Instituições de longa permanência para idosos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8711503",
    "descricao": "ATIVIDADES DE ASSISTÊNCIA A DEFICIENTES FÍSICOS, IMUNODEPRIMIDOS E CONVALESCENTES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8711504",
    "descricao": "CENTROS DE APOIO A PACIENTES COM CÂNCER E COM AIDS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8711505",
    "descricao": "CONDOMÍNIOS RESIDENCIAIS PARA IDOSOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8712300",
    "descricao": "Atividades de fornecimento de infra-estrutura de apoio e assistência a paciente no domicílio",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8720401",
    "descricao": "ATIVIDADES DE CENTROS DE ASSISTÊNCIA PSICOSSOCIAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8720499",
    "descricao": "ATIVIDADES DE ASSISTÊNCIA PSICOSSOCIAL E À SAÚDE A PORTADORES DE DISTÚRBIOS PSÍQUICOS, DEFICIÊNCIA MENTAL E DEPENDÊNCIA QUÍMICA E GRUPOS SIMILARES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8730101",
    "descricao": "ORFANATOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8730102",
    "descricao": "ALBERGUES ASSISTENCIAIS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8730199",
    "descricao": "ATIVIDADES DE ASSISTÊNCIA SOCIAL PRESTADAS EM RESIDÊNCIAS COLETIVAS E PARTICULARES NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "8800600",
    "descricao": "SERVIÇOS DE ASSISTÊNCIA SOCIAL SEM ALOJAMENTO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001901",
    "descricao": "Produção teatral",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001902",
    "descricao": "Produção musical",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001903",
    "descricao": "Produção de espetáculos de dança",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001904",
    "descricao": "Produção de espetáculos circenses, de marionetes e similares",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001905",
    "descricao": "Produção de espetáculos de rodeios, vaquejadas e similares",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001906",
    "descricao": "Atividades de sonorização e de iluminação",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9001999",
    "descricao": "Artes cênicas, espetáculos e atividades complementares não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9002701",
    "descricao": "Atividades de artistas plásticos, jornalistas independentes e escritores",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9002702",
    "descricao": "Restauração de obras de arte",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9003500",
    "descricao": "Gestão de espaços para artes cênicas, espetáculos e outras atividades artísticas",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9101500",
    "descricao": "Atividades de bibliotecas e arquivos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9102301",
    "descricao": "Atividades de museus e de exploração de lugares e prédios históricos e atrações similares",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9102302",
    "descricao": "Restauração e conservação de lugares e prédios históricos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9103100",
    "descricao": "ATIVIDADES DE JARDINS BOTÂNICOS, ZOOLÓGICOS, PARQUES NACIONAIS, RESERVAS ECOLÓGICAS E ÁREAS DE PROTEÇÃO AMBIENTAL",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9311500",
    "descricao": "Gestão de instalações de esportes",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9312300",
    "descricao": "CLUBES SOCIAIS, ESPORTIVOS E SIMILARES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9313100",
    "descricao": "Atividades de condicionamento físico",
    "anexo": null,
    "fator_r": true,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9319101",
    "descricao": "Produção e promoção de eventos esportivos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9319199",
    "descricao": "Outras atividades esportivas não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9321200",
    "descricao": "PARQUES DE DIVERSÃO E PARQUES TEMÁTICOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9329801",
    "descricao": "DISCOTECAS, DANCETERIAS, SALÕES DE DANÇA E SIMILARES",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9329802",
    "descricao": "Exploração de boliches",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9329803",
    "descricao": "Exploração de jogos de sinuca, bilhar e similares",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9329804",
    "descricao": "Exploração de jogos eletrônicos recreativos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9329899",
    "descricao": "Outras atividades de recreação e lazer não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9411100",
    "descricao": "ATIVIDADES DE ORGANIZAÇÕES ASSOCIATIVAS PATRONAIS E EMPRESARIAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9412001",
    "descricao": "ATIVIDADES DE FISCALIZAÇÃO PROFISSIONAL",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9412099",
    "descricao": "OUTRAS ATIVIDADES ASSOCIATIVAS PROFISSIONAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9420100",
    "descricao": "ATIVIDADES DE ORGANIZAÇÕES SINDICAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9430800",
    "descricao": "ATIVIDADES DE ASSOCIAÇÕES DE DEFESA DE DIREITOS SOCIAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9491000",
    "descricao": "ATIVIDADES DE ORGANIZAÇÕES RELIGIOSAS OU FILOSÓFICAS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9492800",
    "descricao": "ATIVIDADES DE ORGANIZAÇÕES POLÍTICAS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9493600",
    "descricao": "ATIVIDADES DE ORGANIZAÇÕES ASSOCIATIVAS LIGADAS À CULTURA E À ARTE",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9499500",
    "descricao": "ATIVIDADES ASSOCIATIVAS NÃO ESPECIFICADAS ANTERIORMENTE",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9511800",
    "descricao": "Reparação e manutenção de computadores e de equipamentos periféricos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9512600",
    "descricao": "Reparação e manutenção de equipamentos de comunicação",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9521500",
    "descricao": "Reparação e manutenção de equipamentos eletroeletrônicos de uso pessoal e doméstico",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529101",
    "descricao": "Reparação de calçados, bolsas e artigos de viagem",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529102",
    "descricao": "Chaveiros",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529103",
    "descricao": "Reparação de relógios",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529104",
    "descricao": "Reparação de bicicletas, triciclos e outros veículos não-motorizados",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529105",
    "descricao": "Reparação de artigos do mobiliário",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529106",
    "descricao": "Reparação de jóias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9529199",
    "descricao": "Reparação e manutenção de outros objetos e equipamentos pessoais e domésticos não especificados anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9601701",
    "descricao": "Lavanderias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9601702",
    "descricao": "Tinturarias",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9601703",
    "descricao": "Toalheiros",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9602501",
    "descricao": "Cabeleireiros, manicure e pedicure",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9602502",
    "descricao": "Atividades de Estética e outros serviços de cuidados com a beleza",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603301",
    "descricao": "GESTÃO E MANUTENÇÃO DE CEMITÉRIOS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603302",
    "descricao": "SERVIÇOS DE CREMAÇÃO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603303",
    "descricao": "SERVIÇOS DE SEPULTAMENTO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603304",
    "descricao": "SERVIÇOS DE FUNERÁRIAS",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603305",
    "descricao": "SERVIÇOS DE SOMATOCONSERVAÇÃO",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9603399",
    "descricao": "ATIVIDADES FUNERÁRIAS E SERVIÇOS RELACIONADOS NÃO ESPECIFICADOS ANTERIORMENTE",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609202",
    "descricao": "Agências matrimoniais",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609204",
    "descricao": "EXPLORAÇÃO DE MÁQUINAS DE SERVIÇOS PESSOAIS ACIONADAS POR MOEDA",
    "anexo": "III",
    "fator_r": false,
    "fonte": "LC 123/2006, art. 18, §5º-F",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609205",
    "descricao": "Atividades de sauna e banhos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609206",
    "descricao": "Serviços de tatuagem e colocação de piercing",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609207",
    "descricao": "Alojamento de animais domésticos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609208",
    "descricao": "Higiene e embelezamento de animais domésticos",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9609299",
    "descricao": "Outras atividades de serviços pessoais não especificadas anteriormente",
    "anexo": "III",
    "fator_r": false,
    "fonte": "tabela-cnae.csv",
    "situacao": "enquadrado"
  },
  {
    "codigo": "9700500",
    "descricao": "SERVIÇOS DOMÉSTICOS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  },
  {
    "codigo": "9900800",
    "descricao": "ORGANISMOS INTERNACIONAIS E OUTRAS INSTITUIÇÕES EXTRATERRITORIAIS",
    "anexo": null,
    "fator_r": false,
    "fonte": "LC 123/2006, art. 3º, caput",
    "situacao": "nao_optante"
  }
] as const;
