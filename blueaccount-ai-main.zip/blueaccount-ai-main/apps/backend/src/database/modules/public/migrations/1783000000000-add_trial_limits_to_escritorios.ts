import { MigrationInterface, QueryRunner } from "typeorm";

export class AddTrialLimitsToEscritorios1783000000000 implements MigrationInterface {
  name = "AddTrialLimitsToEscritorios1783000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "is_trial" boolean NOT NULL DEFAULT false`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "trial_max_documentos" integer NOT NULL DEFAULT 20`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "trial_max_cobranca_execucoes" integer NOT NULL DEFAULT 20`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "trial_max_paginas_por_documento" integer NOT NULL DEFAULT 10`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "trial_cobranca_execucoes_usadas" integer NOT NULL DEFAULT 0`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "trial_cobranca_execucoes_usadas"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "trial_max_paginas_por_documento"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "trial_max_cobranca_execucoes"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "trial_max_documentos"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "is_trial"`);
  }
}
