import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from "typeorm";

@Index("UQ_admin_session_session_id_hash", ["session_id_hash"], { unique: true })
@Index("IDX_admin_session_expires_at", ["expires_at"])
// Tabela UNLOGGED (migration 1784112210638-set_sessoes_unlogged): escrita não gera
// WAL. Trunca em parada suja (crash/reboot) → admin reautentica. TypeORM não
// gerencia LOGGED/UNLOGGED, então o estado vive só na migration.
@Entity({ name: "admin_session", schema: "public" })
export class AdminSession {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  session_id_hash!: string;

  @Column({ type: "text" })
  username!: string;

  @Column({ type: "timestamp" })
  expires_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  revoked_at!: Date | null;

  @Column({ type: "timestamp", nullable: true })
  last_seen_at!: Date | null;

  // Step-up auth do admin da plataforma: ver `reautenticado_em` em Sessao.
  @Column({ type: "timestamp", nullable: true })
  reautenticado_em!: Date | null;

  @Column({ type: "text", nullable: true })
  user_agent!: string | null;

  @Column({ type: "text", nullable: true })
  ip_address!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
