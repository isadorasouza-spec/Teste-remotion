import type { MigrationInterface, QueryRunner } from "typeorm";

/** Autoriza a credencial configurada, sem criar login, senha ou bypass de RLS. */
export class ConcederRolesWorkerFiscal1791800000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    const credencial = process.env.DOCUMENTOS_FISCAIS_DB_USERNAME?.trim();
    if (!credencial) {
      if (process.env.DOCUMENTOS_FISCAIS_PROCESSADOR === "worker") throw new Error("DOCUMENTOS_FISCAIS_DB_USERNAME obrigatório");
      return;
    }
    const [role] = await queryRunner.query(
      "SELECT rolsuper, rolbypassrls, rolinherit FROM pg_catalog.pg_roles WHERE rolname=$1", [credencial],
    );
    if (!role || role.rolsuper || role.rolbypassrls || role.rolinherit) {
      throw new Error("Worker fiscal exige role existente NOSUPERUSER NOBYPASSRLS NOINHERIT");
    }
    const escritorios = await queryRunner.query(`
      SELECT r.rolname FROM pg_catalog.pg_roles r
      JOIN pg_catalog.pg_namespace n ON r.rolname = 'user_' || n.nspname
      WHERE n.nspname ~ '^escritorio_[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}$'
      ORDER BY r.rolname
    `);
    const citar = (valor: string) => '"' + valor.replace(/"/g, '""') + '"';
    for (const escritorio of escritorios) {
      await queryRunner.query(`GRANT ${citar(escritorio.rolname)} TO ${citar(credencial)}`);
    }
  }

  async down(): Promise<void> {
    // Não é possível distinguir memberships anteriores das concedidas por esta migration.
    throw new Error("Reversão exige revisão explícita dos grants do worker fiscal; memberships anteriores são preservadas");
  }
}
