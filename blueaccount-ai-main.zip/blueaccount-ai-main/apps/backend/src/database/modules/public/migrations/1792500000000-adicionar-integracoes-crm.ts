import type { MigrationInterface, QueryRunner } from "typeorm";

export class AdicionarIntegracoesCrm1792500000000 implements MigrationInterface {
  name = "AdicionarIntegracoesCrm1792500000000";
  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE public.crm_configuracao (
      id integer PRIMARY KEY CHECK (id=1), configuracao jsonb NOT NULL, atualizado_em timestamptz NOT NULL DEFAULT now());
      INSERT INTO public.crm_configuracao(id,configuracao) VALUES(1,
      '{"habilitado":false,"email_setup":"","portal_id":"","app_id":"","pipeline_id":"","etapas":{}}');
      CREATE TABLE public.crm_vinculos (
        id uuid PRIMARY KEY, portal_id text NOT NULL, deal_id text NOT NULL,
        escritorio_id uuid UNIQUE REFERENCES public.escritorios(id) ON DELETE SET NULL,
        vinculo_manual boolean NOT NULL DEFAULT false, excluido boolean NOT NULL DEFAULT false,
        nome text, pipeline_id text, etapa_id text, etapa text, convertido boolean NOT NULL DEFAULT false,
        provisionado boolean NOT NULL DEFAULT false, reemitir boolean NOT NULL DEFAULT false,
        status text NOT NULL DEFAULT 'pendente', passo text, erro text, avisos jsonb NOT NULL DEFAULT '[]',
        geracao integer NOT NULL DEFAULT 1, geracao_processando integer NOT NULL DEFAULT 0,
        tentativas integer NOT NULL DEFAULT 0, lease_token uuid, lease_ate timestamptz,
        execucao_id text, execucao_passo integer NOT NULL DEFAULT 0,
        proxima_tentativa timestamptz NOT NULL DEFAULT now(), sincronizado_em timestamptz,
        criado_em timestamptz NOT NULL DEFAULT now(), atualizado_em timestamptz NOT NULL DEFAULT now(),
        UNIQUE(portal_id,deal_id));
      CREATE INDEX crm_vinculos_fila ON public.crm_vinculos(status,proxima_tentativa);
      CREATE TABLE public.crm_eventos (impressao text PRIMARY KEY, vinculo_id uuid NOT NULL REFERENCES public.crm_vinculos(id),
        ocorrido_em timestamptz NOT NULL, criado_em timestamptz NOT NULL DEFAULT now());
      CREATE TABLE public.crm_historico (id uuid PRIMARY KEY, vinculo_id uuid NOT NULL REFERENCES public.crm_vinculos(id),
        acao text NOT NULL, pipeline_id text, etapa_id text, etapa text, criado_em timestamptz NOT NULL DEFAULT now());
      CREATE TABLE public.crm_entregas (id uuid PRIMARY KEY, vinculo_id uuid NOT NULL UNIQUE REFERENCES public.crm_vinculos(id),
        destinatario text NOT NULL, segredo jsonb, expira_em timestamptz NOT NULL,
        status text NOT NULL DEFAULT 'preparada', tentativas integer NOT NULL DEFAULT 0, ses_message_id text,
        reemissao boolean NOT NULL DEFAULT false, senha_aplicada boolean NOT NULL DEFAULT false,
        criado_em timestamptz NOT NULL DEFAULT now(), atualizado_em timestamptz NOT NULL DEFAULT now());
      CREATE TABLE public.crm_usuarios (email text PRIMARY KEY, vinculo_id uuid NOT NULL REFERENCES public.crm_vinculos(id),
        usuario_id uuid NOT NULL UNIQUE, nome text NOT NULL, administrador boolean NOT NULL,
        cognito_sub text, criacao_iniciada boolean NOT NULL DEFAULT false, criado_em timestamptz NOT NULL DEFAULT now());
      CREATE FUNCTION public.crm_preservar_tombstone() RETURNS trigger LANGUAGE plpgsql AS $$
      BEGIN
        UPDATE public.crm_entregas SET segredo=NULL,destinatario='',status='cancelada',atualizado_em=now()
          WHERE vinculo_id IN (SELECT id FROM public.crm_vinculos WHERE escritorio_id=OLD.id);
        DELETE FROM public.crm_usuarios WHERE vinculo_id IN (SELECT id FROM public.crm_vinculos WHERE escritorio_id=OLD.id);
        UPDATE public.crm_vinculos SET nome=NULL,excluido=true,status='excluido',lease_token=NULL,lease_ate=NULL,
          atualizado_em=now() WHERE escritorio_id=OLD.id;
        RETURN OLD;
      END $$;
      CREATE TRIGGER crm_escritorio_excluido BEFORE DELETE ON public.escritorios
        FOR EACH ROW EXECUTE FUNCTION public.crm_preservar_tombstone();`);
    await q.query(`DO $$ BEGIN
      IF current_setting('shared_preload_libraries',true) LIKE '%pg_cron%' THEN
        CREATE EXTENSION IF NOT EXISTS pg_cron;
        PERFORM cron.schedule('crm-expirar-credenciais','* * * * *',
          $job$UPDATE public.crm_entregas SET segredo=NULL,status='expirada',atualizado_em=now()
            WHERE segredo IS NOT NULL AND expira_em<=now()$job$);
      END IF;
    END $$`);
    // O role tenant nunca recebe acesso a identidades CRM nem credenciais de setup.
    await q.query(`REVOKE ALL ON public.crm_configuracao, public.crm_vinculos, public.crm_eventos,
      public.crm_historico, public.crm_entregas, public.crm_usuarios FROM PUBLIC`);
  }
  async down(q: QueryRunner): Promise<void> {
    await q.query(`DO $$ BEGIN
      IF EXISTS(SELECT 1 FROM pg_extension WHERE extname='pg_cron') THEN
        PERFORM cron.unschedule(jobname) FROM cron.job WHERE jobname='crm-expirar-credenciais';
      END IF;
    END $$`);
    await q.query(`DROP TRIGGER crm_escritorio_excluido ON public.escritorios;
      DROP FUNCTION public.crm_preservar_tombstone();
      DROP TABLE public.crm_usuarios,public.crm_entregas,public.crm_historico,public.crm_eventos,public.crm_vinculos,public.crm_configuracao;`);
  }
}
