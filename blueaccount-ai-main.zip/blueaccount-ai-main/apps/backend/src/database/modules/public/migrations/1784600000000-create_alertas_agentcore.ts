import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateAlertasAgentcore1784600000000 implements MigrationInterface {
  name = "CreateAlertasAgentcore1784600000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "alertas_agentcore" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "alarm_arn" text NOT NULL,
        "alarm_name" text NOT NULL,
        "agent_name" text NOT NULL,
        "condicao" text NOT NULL,
        "ambiente" text,
        "motivo" text,
        "transition_at" TIMESTAMP WITH TIME ZONE NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_alertas_agentcore" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_alertas_agentcore_arn_transicao" UNIQUE ("alarm_arn", "transition_at")
      )
    `);
    await queryRunner.query('CREATE INDEX "IDX_alertas_agentcore_alarm_arn" ON "alertas_agentcore" ("alarm_arn")');
    await queryRunner.query('CREATE INDEX "IDX_alertas_agentcore_agent_name" ON "alertas_agentcore" ("agent_name")');
    await queryRunner.query('CREATE INDEX "IDX_alertas_agentcore_condicao" ON "alertas_agentcore" ("condicao")');
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('DROP TABLE "alertas_agentcore"');
  }
}
