import { MigrationInterface, QueryRunner } from "typeorm";

export class AddPromptToAgentLogs1779100000000 implements MigrationInterface {
  name = "AddPromptToAgentLogs1779100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "agent_logs" ADD COLUMN IF NOT EXISTS "prompt" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "agent_logs" DROP COLUMN IF EXISTS "prompt"`);
  }
}
