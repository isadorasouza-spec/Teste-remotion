import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from "typeorm";

const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/**
 * Catalogo global de complexidades de cobranca.
 *
 * Define o modelo AgentCore e o preco mensal por contrato usado no billing.
 */
@Entity("billing_complexities")
export class BillingComplexity {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "int", unique: true })
  nivel!: number;

  @Column({ type: "text" })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text", nullable: true })
  inference_profile_id!: string | null;

  @Column({ type: "numeric", transformer: numericToNumber, default: 0 })
  preco_mensal_por_contrato!: number;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
