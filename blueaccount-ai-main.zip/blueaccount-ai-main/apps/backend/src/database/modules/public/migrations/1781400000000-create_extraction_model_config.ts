import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateExtractionModelConfig1781400000000 implements MigrationInterface {
  name = "CreateExtractionModelConfig1781400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "extraction_model_config" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"contratos_inference_profile_id" text, ` +
        `"relatorios_inference_profile_id" text, ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_extraction_model_config" PRIMARY KEY ("id"))`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "extraction_model_config"`);
  }
}
