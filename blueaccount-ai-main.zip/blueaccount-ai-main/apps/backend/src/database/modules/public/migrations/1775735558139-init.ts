import { MigrationInterface, QueryRunner } from "typeorm";

function sqlLiteral(value: string): string {
    return `'${value.replace(/'/g, "''")}'`;
}

function resolveAiRoleName(): string {
    return process.env.DB_AI_USERNAME?.trim()
        || process.env.DB_USERNAME?.trim()
        || "blueaccount";
}

function resolveAiRolePassword(): string {
    return process.env.DB_AI_PASSWORD?.trim()
        || process.env.DB_PASSWORD?.trim()
        || "blueaccount";
}

export class Init1775735558139 implements MigrationInterface {
    name = 'Init1775735558139'

    public async up(queryRunner: QueryRunner): Promise<void> {
        const aiRoleName = resolveAiRoleName();
        const aiRolePassword = resolveAiRolePassword();

        await queryRunner.query(`DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = ${sqlLiteral(aiRoleName)}) THEN
    EXECUTE format('CREATE ROLE %I LOGIN PASSWORD %L', ${sqlLiteral(aiRoleName)}, ${sqlLiteral(aiRolePassword)});
  END IF;
END $$`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        const aiRoleName = resolveAiRoleName();
        await queryRunner.query(`DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = ${sqlLiteral(aiRoleName)}) THEN
    EXECUTE format('DROP ROLE %I', ${sqlLiteral(aiRoleName)});
  END IF;
END $$`);
    }

}
