export type AnexoSimplesSeed = "I" | "II" | "III" | "IV" | "V";

export type FaixaSimplesSeed = {
  anexo: AnexoSimplesSeed;
  faixa: number;
  vigencia_inicio: number;
  vigencia_fim: number | null;
  rbt12_minimo: number;
  rbt12_maximo: number;
  aliquota_nominal: number;
  parcela_deduzir: number;
  percentual_cbs: number;
  percentual_ibs: number;
};

const LIMITES = [180_000, 360_000, 720_000, 1_800_000, 3_600_000, 4_800_000];
const DEDUCOES: Record<AnexoSimplesSeed, number[]> = {
  I: [0, 5_940, 13_860, 22_500, 87_300, 378_000],
  II: [0, 5_940, 13_860, 22_500, 85_500, 720_000],
  III: [0, 9_360, 17_640, 35_640, 125_640, 648_000],
  IV: [0, 8_100, 12_420, 39_780, 183_780, 828_000],
  V: [0, 4_500, 9_900, 17_100, 62_100, 540_000],
};
const ALIQUOTAS_PADRAO: Record<AnexoSimplesSeed, number[]> = {
  I: [0.04, 0.073, 0.095, 0.107, 0.143, 0.19],
  II: [0.045, 0.078, 0.10, 0.112, 0.147, 0.30],
  III: [0.06, 0.112, 0.135, 0.16, 0.21, 0.33],
  IV: [0.045, 0.09, 0.102, 0.14, 0.22, 0.33],
  V: [0.155, 0.18, 0.195, 0.205, 0.23, 0.305],
};

type Partilha = Record<AnexoSimplesSeed, { cbs: number[]; ibs: number[] }>;
const zeros = () => [0, 0, 0, 0, 0, 0];
const PARTILHA_2026: Partilha = {
  I: { cbs: zeros(), ibs: zeros() }, II: { cbs: zeros(), ibs: zeros() },
  III: { cbs: zeros(), ibs: zeros() }, IV: { cbs: zeros(), ibs: zeros() },
  V: { cbs: zeros(), ibs: zeros() },
};
const PARTILHA_2027: Partilha = {
  I: { cbs: [15.33, 15.33, 15.33, 15.33, 15.33, 34.02], ibs: [0.17, 0.17, 0.17, 0.17, 0.17, 0] },
  II: { cbs: [13.85, 13.85, 13.85, 13.85, 13.85, 25.22], ibs: [0.15, 0.15, 0.15, 0.15, 0.15, 0] },
  III: { cbs: [15.43, 16.91, 16.42, 16.42, 15.43, 19.29], ibs: [0.17, 0.19, 0.19, 0.19, 0.17, 0] },
  IV: { cbs: [21.26, 24.73, 23.74, 22.75, 21.76, 24.70], ibs: [0.24, 0.27, 0.26, 0.25, 0.24, 0] },
  V: { cbs: [16.96, 16.96, 17.95, 18.94, 16.96, 19.78], ibs: [0.19, 0.19, 0.20, 0.21, 0.19, 0] },
};
const PARTILHA_2029: Partilha = {
  I: { cbs: [15.5, 15.5, 15.5, 15.5, 15.5, 34.4], ibs: [3.4, 3.4, 3.35, 3.35, 3.35, 0] },
  II: { cbs: [14, 14, 14, 14, 14, 25.5], ibs: [3.2, 3.2, 3.2, 3.2, 3.2, 0] },
  III: { cbs: [15.6, 17.1, 16.6, 16.6, 15.6, 19.5], ibs: [3.35, 3.2, 3.25, 3.25, 3.35, 0] },
  IV: { cbs: [21.5, 25, 24, 23, 22, 25], ibs: [4.45, 4, 4, 4, 4, 0] },
  V: { cbs: [17.15, 17.15, 18.15, 19.15, 17.15, 20], ibs: [1.4, 1.7, 1.9, 2.1, 2.35, 0] },
};

function comIbs(partilha: Partilha, ibs: Record<AnexoSimplesSeed, number[]>): Partilha {
  return Object.fromEntries((Object.keys(partilha) as AnexoSimplesSeed[]).map((anexo) => [anexo, {
    cbs: partilha[anexo].cbs,
    ibs: ibs[anexo],
  }])) as Partilha;
}

const PARTILHAS: Array<{ inicio: number; fim: number | null; dados: Partilha }> = [
  { inicio: 2026, fim: 2026, dados: PARTILHA_2026 },
  { inicio: 2027, fim: 2028, dados: PARTILHA_2027 },
  { inicio: 2029, fim: 2029, dados: PARTILHA_2029 },
  { inicio: 2030, fim: 2030, dados: comIbs(PARTILHA_2029, {
    I: [6.8, 6.8, 6.7, 6.7, 6.7, 0], II: [6.4, 6.4, 6.4, 6.4, 6.4, 0],
    III: [6.7, 6.4, 6.5, 6.5, 6.7, 0], IV: [8.9, 8, 8, 8, 8, 0],
    V: [2.8, 3.4, 3.8, 4.2, 4.7, 0],
  }) },
  { inicio: 2031, fim: 2031, dados: comIbs(PARTILHA_2029, {
    I: [10.2, 10.2, 10.05, 10.05, 10.05, 0], II: [9.6, 9.6, 9.6, 9.6, 9.6, 0],
    III: [10.05, 9.6, 9.75, 9.75, 10.05, 0], IV: [13.35, 12, 12, 12, 12, 0],
    V: [4.2, 5.1, 5.7, 6.3, 7.05, 0],
  }) },
  { inicio: 2032, fim: 2032, dados: comIbs(PARTILHA_2029, {
    I: [13.6, 13.6, 13.4, 13.4, 13.4, 0], II: [12.8, 12.8, 12.8, 12.8, 12.8, 0],
    III: [13.4, 12.8, 13, 13, 13.4, 0], IV: [17.8, 16, 16, 16, 16, 0],
    V: [5.6, 6.8, 7.6, 8.4, 9.4, 0],
  }) },
  { inicio: 2033, fim: null, dados: comIbs(PARTILHA_2029, {
    I: [34, 34, 33.5, 33.5, 33.5, 0], II: [32, 32, 32, 32, 32, 0],
    III: [33.5, 32, 32.5, 32.5, 33.5, 0], IV: [44.5, 40, 40, 40, 40, 0],
    V: [14, 17, 19, 21, 23.5, 0],
  }) },
];

export const SIMPLES_ANEXOS_SEED: FaixaSimplesSeed[] = PARTILHAS.flatMap(({ inicio, fim, dados }) =>
  (Object.keys(ALIQUOTAS_PADRAO) as AnexoSimplesSeed[]).flatMap((anexo) =>
    LIMITES.map((maximo, indice) => ({
      anexo,
      faixa: indice + 1,
      vigencia_inicio: inicio,
      vigencia_fim: fim,
      rbt12_minimo: indice === 0 ? 0 : LIMITES[indice - 1],
      rbt12_maximo: maximo,
      // A alíquota nominal é a mesma em toda a transição: a LC 214/2025 remaneja a PARTILHA dentro do
      // DAS (as colunas de IBS/CBS abaixo), não os percentuais dos Anexos I a V da LC 123/2006. Se
      // algum ano passar a ter alíquota própria, ela entra como vigência nova com fundamento legal
      // próprio, nunca como ajuste calculado sobre a tabela-base.
      aliquota_nominal: ALIQUOTAS_PADRAO[anexo][indice],
      parcela_deduzir: DEDUCOES[anexo][indice],
      percentual_cbs: dados[anexo].cbs[indice] / 100,
      percentual_ibs: dados[anexo].ibs[indice] / 100,
    })),
  ),
);

export const FUNDAMENTO_SIMPLES =
  "LC 123/2006, Anexos I a V, com redação dos Anexos XVIII a XXII da LC 214/2025";
