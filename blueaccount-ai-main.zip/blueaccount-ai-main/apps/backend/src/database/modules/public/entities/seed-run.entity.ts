import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  OneToMany,
  type Relation,
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";
import { SeedRunApiCall } from "./seed-run-api-call.entity.js";
import type { JsonValue } from "./contexto.entity.js";

export type SeedRunStatus = "active" | "completed" | "cancelled" | "failed";

@Index("IDX_seed_runs_escritorio_id", ["escritorio_id"])
@Index("IDX_seed_runs_status", ["status"])
@Index("IDX_seed_runs_started_at", ["started_at"])
@Entity("seed_runs")
export class SeedRun {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Escritorio, { nullable: false, onDelete: "RESTRICT" })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio>;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  name!: string;

  @Column({ type: "text", nullable: true })
  description!: string | null;

  @Column({ type: "text", default: "active" })
  status!: SeedRunStatus;

  @Column({ type: "boolean", default: true })
  capture_mcp_calls!: boolean;

  @Column({ type: "boolean", default: true })
  disable_agents_during_seed!: boolean;

  @Column({ type: "timestamptz", default: () => "now()" })
  started_at!: Date;

  @Column({ type: "timestamptz", nullable: true })
  completed_at!: Date | null;

  @Column({ type: "text", nullable: true })
  created_by_admin_id!: string | null;

  @Column({ type: "jsonb", nullable: true })
  metadata!: JsonValue | null;

  @OneToMany(() => SeedRunApiCall, (call) => call.seed_run)
  calls!: Relation<SeedRunApiCall[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
