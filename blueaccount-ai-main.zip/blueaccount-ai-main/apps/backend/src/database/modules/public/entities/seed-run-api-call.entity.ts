import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Contexto, type JsonValue } from "./contexto.entity.js";
import { SeedRun } from "./seed-run.entity.js";

export type SeedRunApiCallSource = "mcp" | "internal" | "platform";

@Index("IDX_seed_run_api_calls_seed_run_id", ["seed_run_id"])
@Index("IDX_seed_run_api_calls_api_log_id", ["api_log_id"])
@Index("IDX_seed_run_api_calls_created_at", ["created_at"])
@Index("IDX_seed_run_api_calls_seed_sequence", ["seed_run_id", "sequence"], { unique: true })
@Entity("seed_run_api_calls")
export class SeedRunApiCall {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => SeedRun, (seedRun) => seedRun.calls, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "seed_run_id" })
  seed_run!: Relation<SeedRun>;

  @Column({ type: "uuid" })
  seed_run_id!: string;

  @ManyToOne(() => Contexto, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "api_log_id" })
  api_log!: Relation<Contexto> | null;

  @Column({ type: "uuid", nullable: true })
  api_log_id!: string | null;

  @Column({ type: "int" })
  sequence!: number;

  @Column({ type: "text" })
  method!: string;

  @Column({ type: "text" })
  path!: string;

  @Column({ type: "jsonb", nullable: true })
  query!: JsonValue | null;

  @Column({ type: "jsonb", nullable: true })
  request_body!: JsonValue | null;

  @Column({ type: "int", nullable: true })
  response_status!: number | null;

  @Column({ type: "jsonb", nullable: true })
  response_body!: JsonValue | null;

  @Column({ type: "timestamptz", nullable: true })
  completed_at!: Date | null;

  @Column({ type: "text", default: "mcp" })
  source!: SeedRunApiCallSource;

  @Column({ type: "boolean", default: true })
  redaction_applied!: boolean;

  @CreateDateColumn()
  created_at!: Date;
}
