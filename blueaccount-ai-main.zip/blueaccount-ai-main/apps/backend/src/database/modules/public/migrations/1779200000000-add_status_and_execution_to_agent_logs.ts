import { MigrationInterface, QueryRunner } from "typeorm";

export class AddStatusAndExecutionToAgentLogs1779200000000 implements MigrationInterface {
  name = "AddStatusAndExecutionToAgentLogs1779200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "agent_logs" ADD COLUMN IF NOT EXISTS "status" text`);
    await queryRunner.query(`ALTER TABLE "agent_logs" ADD COLUMN IF NOT EXISTS "execution_arn" text`);
    await queryRunner.query(`ALTER TABLE "agent_logs" ADD COLUMN IF NOT EXISTS "trace_id" text`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_agent_logs_status" ON "agent_logs" ("status")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_agent_logs_trace_id" ON "agent_logs" ("trace_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_agent_logs_trace_id"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_agent_logs_status"`);
    await queryRunner.query(`ALTER TABLE "agent_logs" DROP COLUMN IF EXISTS "trace_id"`);
    await queryRunner.query(`ALTER TABLE "agent_logs" DROP COLUMN IF EXISTS "execution_arn"`);
    await queryRunner.query(`ALTER TABLE "agent_logs" DROP COLUMN IF EXISTS "status"`);
  }
}
