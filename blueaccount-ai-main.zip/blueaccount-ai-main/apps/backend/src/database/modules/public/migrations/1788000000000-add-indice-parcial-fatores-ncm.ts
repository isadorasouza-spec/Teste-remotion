import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `resolverFatoresPorNcm` filtra por `fatores_configurados = true` antes de aplicar o LIKE de
 * prefixo (`:ncm LIKE ncm.codigo || '%'`), que não é indexável por ser construído a partir da
 * própria coluna. Sem este índice parcial, cada chamada varre `ncms_referencia` inteira — tabela
 * que cresce sem limite como cache lazy da BrasilAPI (`consultarNcm`). O índice restringe a
 * varredura ao pequeno conjunto curado de regras legais, independente do tamanho do cache.
 */
export class AddIndiceParcialFatoresNcm1788000000000 implements MigrationInterface {
  name = "AddIndiceParcialFatoresNcm1788000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE INDEX "IDX_ncms_referencia_fatores_configurados_codigo"
      ON "ncms_referencia" ("codigo")
      WHERE "fatores_configurados" = true
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_ncms_referencia_fatores_configurados_codigo"`);
  }
}
