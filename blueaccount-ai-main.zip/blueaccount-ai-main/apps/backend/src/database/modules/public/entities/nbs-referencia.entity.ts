import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/** Catálogo NBS exato, versionado e somente leitura, transcrito da planilha fornecida. */
@Index("UQ_nbs_referencia_codigo", ["codigo"], { unique: true })
@Entity("nbs_referencia")
export class NbsReferencia {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /** Código NBS exato sem pontuação, nove dígitos. */
  @Column({ type: "varchar", length: 9 })
  codigo!: string;

  @Column({ type: "text" })
  descricao!: string;

  @Column({ type: "varchar", length: 40, nullable: true })
  versao_catalogo!: string | null;

  @Column({ type: "text", nullable: true })
  capitulo!: string | null;

  @Column({ type: "text", nullable: true })
  categoria!: string | null;

  @Column({ type: "integer", nullable: true })
  fonte_linha!: number | null;

  /** Compatibilidade de schema; o catálogo exato publica array vazio. */
  @Column({ type: "text", array: true, nullable: true })
  descricoes_hierarquia!: string[] | null;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_ibs!: number;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_cbs!: number;

  /** Sempre true nos registros publicados da planilha. */
  @Column({ type: "boolean", default: false })
  fatores_configurados!: boolean;

  /** Aplica o fator numérico da fonte, que já mantém casos condicionais em 1. */
  @Column({ type: "boolean", default: true })
  aplicacao_automatica!: boolean;

  /** Compatibilidade: a fonte atual não define veto; sempre true. */
  @Column({ type: "boolean", default: true })
  gera_credito_adquirente!: boolean;

  /** Compatibilidade: a fonte atual não define regime; sempre null. */
  @Column({ type: "varchar", length: 40, nullable: true })
  regime_especifico!: string | null;

  @Column({ type: "text", nullable: true })
  fundamento_legal_fatores!: string | null;

  @Column({ type: "text", nullable: true })
  condicoes_aplicacao_fatores!: string | null;

  @Column({ type: "varchar", length: 80, nullable: true })
  origem_configuracao_fatores!: string | null;

  @UpdateDateColumn({ type: "timestamptz" })
  atualizado_em!: Date;
}
