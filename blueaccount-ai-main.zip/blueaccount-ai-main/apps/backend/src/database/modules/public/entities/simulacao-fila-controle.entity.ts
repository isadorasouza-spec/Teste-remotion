import { Check, Column, Entity, PrimaryColumn, UpdateDateColumn } from "typeorm";

@Entity("simulacao_fila_controle")
@Check("CHK_simulacao_fila_controle_singleton", `"id" = 1`)
export class SimulacaoFilaControle {
  @PrimaryColumn({ type: "smallint", default: 1 }) id!: number;
  @Column({ type: "boolean", default: false }) pausada!: boolean;
  @Column({ type: "text", nullable: true }) motivo!: string | null;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
