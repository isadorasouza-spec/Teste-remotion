import type { MigrationInterface, QueryRunner } from "typeorm";

/** Fila pública durável do worker que projeta o fato normalizado nas simulações tenant. */
export class CreateProjecoesDocumentosFiscaisFila1791200000000 implements MigrationInterface {
  name = "CreateProjecoesDocumentosFiscaisFila1791200000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "projecoes_documentos_fiscais_fila" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "simulacao_id" uuid NOT NULL,
      "lote_id" uuid NOT NULL,
      "arquivo_id" uuid NOT NULL,
      "bucket_normalizado" varchar(255) NOT NULL,
      "chave_normalizado" varchar(1024) NOT NULL,
      "status" varchar(20) NOT NULL DEFAULT 'pendente',
      "tentativas" smallint NOT NULL DEFAULT 0,
      "disponivel_em" timestamptz NOT NULL DEFAULT now(),
      "lease_token" uuid,
      "lock_adquirido_em" timestamptz,
      "erro" text,
      "concluido_em" timestamptz,
      "reconciliado_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_projecoes_documentos_fiscais_fila" PRIMARY KEY ("id"),
      CONSTRAINT "UQ_projecoes_documentos_fiscais_alvo" UNIQUE ("escritorio_id", "simulacao_id", "arquivo_id"),
      CONSTRAINT "CHK_projecoes_documentos_fiscais_status" CHECK ("status" IN ('pendente','processando','concluido','erro','cancelado')),
      CONSTRAINT "CHK_projecoes_documentos_fiscais_lease" CHECK (("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL)),
      CONSTRAINT "CHK_projecoes_documentos_fiscais_tentativas" CHECK ("tentativas" >= 0)
    )`);
    await q.query(`CREATE INDEX "IDX_projecoes_documentos_fiscais_disponivel" ON "projecoes_documentos_fiscais_fila" ("status", "disponivel_em", "atualizado_em")`);
    await q.query(`CREATE FUNCTION "public"."enfileirar_projecao_documento_fiscal"(
      p_escritorio_id uuid, p_cliente_id uuid, p_simulacao_id uuid, p_lote_id uuid,
      p_arquivo_id uuid, p_bucket_normalizado text, p_chave_normalizado text
    ) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
    BEGIN
      IF current_setting('app.escritorio_id', true) IS NULL
         OR current_setting('app.escritorio_id', true)::uuid IS DISTINCT FROM p_escritorio_id THEN
        RAISE EXCEPTION 'Contexto de escritório inválido para enfileirar projeção fiscal.';
      END IF;
      INSERT INTO public.projecoes_documentos_fiscais_fila (
        escritorio_id, cliente_id, simulacao_id, lote_id, arquivo_id,
        bucket_normalizado, chave_normalizado, status, disponivel_em
      ) VALUES (
        p_escritorio_id, p_cliente_id, p_simulacao_id, p_lote_id, p_arquivo_id,
        p_bucket_normalizado, p_chave_normalizado, 'pendente', now()
      ) ON CONFLICT (escritorio_id, simulacao_id, arquivo_id) DO UPDATE SET
        bucket_normalizado = EXCLUDED.bucket_normalizado,
        chave_normalizado = EXCLUDED.chave_normalizado,
        status = CASE WHEN projecoes_documentos_fiscais_fila.status = 'processando' THEN 'processando' ELSE 'pendente' END,
        tentativas = CASE WHEN projecoes_documentos_fiscais_fila.status = 'processando' THEN projecoes_documentos_fiscais_fila.tentativas ELSE 0 END,
        disponivel_em = CASE WHEN projecoes_documentos_fiscais_fila.status = 'processando' THEN projecoes_documentos_fiscais_fila.disponivel_em ELSE now() END,
        erro = NULL, concluido_em = NULL, reconciliado_em = NULL, atualizado_em = now();
    END $$`);
    await q.query(`GRANT EXECUTE ON FUNCTION "public"."enfileirar_projecao_documento_fiscal"(uuid,uuid,uuid,uuid,uuid,text,text) TO PUBLIC`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP FUNCTION "public"."enfileirar_projecao_documento_fiscal"(uuid,uuid,uuid,uuid,uuid,text,text)`);
    await q.query(`DROP TABLE "projecoes_documentos_fiscais_fila"`);
  }
}
