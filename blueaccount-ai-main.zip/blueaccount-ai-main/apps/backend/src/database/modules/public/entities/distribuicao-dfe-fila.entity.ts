import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type StatusDistribuicaoDfeFila = "pendente" | "processando" | "concluido" | "erro" | "cancelado";

/**
 * Fila pública durável das varreduras do `NFeDistribuicaoDFe`. Cada linha é um pedido de scan de
 * um cliente; o worker reivindica com lease e lock de sessão.
 *
 * `UQ_distribuicoes_dfe_em_curso` garante **single-flight por cliente**: dois scans simultâneos
 * do mesmo CNPJ andariam o NSU fora de ordem e o bloqueariam por 1h.
 *
 * `periodo_inicio`/`periodo_fim` **não** filtram a ingestão: o protocolo não tem filtro por data,
 * a caminhada é por NSU e tudo que vier é persistido. O período recorta apenas a exibição.
 *
 * `cuf_autor` é o código IBGE da UF do autor. É obrigatório no schema `distDFeInt`: omiti-lo
 * devolve `cStat 215 - Falha no esquema xml` (confirmado em sondagem, 2026-09-10).
 *
 * `certificado_id` e `cliente_id` não têm FK: esta tabela é do schema `public` e as referências
 * moram nos schemas de tenant.
 */
@Entity("distribuicoes_dfe_fila")
@Index("IDX_distribuicoes_dfe_disponivel", ["status", "disponivel_em"])
@Check("CHK_distribuicoes_dfe_status", `"status" IN ('pendente','processando','concluido','erro','cancelado')`)
@Check(
  "CHK_distribuicoes_dfe_lease",
  `("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL)`,
)
@Check("CHK_distribuicoes_dfe_ambiente", `"ambiente" IN ('producao','homologacao')`)
@Check("CHK_distribuicoes_dfe_cuf", `"cuf_autor" ~ '^[0-9]{2}$'`)
@Check("CHK_distribuicoes_dfe_periodo", `"periodo_fim" >= "periodo_inicio"`)
export class DistribuicaoDfeFila {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;
  @Column({ type: "uuid" }) certificado_id!: string;
  @Column({ type: "varchar", length: 12, default: "producao" }) ambiente!: "producao" | "homologacao";
  @Column({ type: "varchar", length: 2 }) cuf_autor!: string;

  @Column({ type: "date" }) periodo_inicio!: string;
  @Column({ type: "date" }) periodo_fim!: string;

  @Column({ type: "varchar", length: 20, default: "pendente" }) status!: StatusDistribuicaoDfeFila;
  @Column({ type: "smallint", default: 0 }) tentativas!: number;
  @Column({ type: "timestamptz", default: () => "now()" }) disponivel_em!: Date;
  @Column({ type: "uuid", nullable: true }) lease_token!: string | null;
  @Column({ type: "timestamptz", nullable: true }) lock_adquirido_em!: Date | null;

  /** XML completo (`procNFe`) efetivamente ingerido. */
  @Column({ type: "integer", default: 0 }) documentos_completos!: number;
  /** Resumos (`resNFe`) recebidos sem o XML completo par. */
  @Column({ type: "integer", default: 0 }) documentos_resumo!: number;
  @Column({ type: "integer", default: 0 }) documentos_evento!: number;
  @Column({ type: "integer", default: 0 }) documentos_duplicados!: number;

  @Column({ type: "varchar", length: 80, nullable: true }) codigo_erro!: string | null;
  @Column({ type: "text", nullable: true }) detalhe_erro!: string | null;
  @Column({ type: "timestamptz", nullable: true }) concluido_em!: Date | null;

  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
