import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Promove o código IBGE do município a coluna no cache de CNPJ, como já é feito com `uf` e
 * `municipio` — todos os três existem no `payload` jsonb, mas quem consome não deveria precisar
 * saber o nome da chave da BrasilAPI.
 *
 * O backfill lê o próprio payload já gravado, então não há requisição de rede nem invalidação de
 * cache. O `~ '^[0-9]{7}$'` descarta valor ausente ou inesperado; a validação de prefixo por UF
 * fica no TS, onde é legível.
 */
export class AddCodigoMunicipioIbgeToCadastrosCnpj1784800000000 implements MigrationInterface {
  name = "AddCodigoMunicipioIbgeToCadastrosCnpj1784800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "cadastros_cnpj"
        ADD COLUMN IF NOT EXISTS "codigo_municipio_ibge" varchar(7)
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "cadastros_cnpj"."codigo_municipio_ibge" IS
        'Código IBGE do município (7 dígitos), promovido do payload. NÃO confundir com codigo_municipio (TOM/SIAFI, 4 dígitos).'
    `);

    await queryRunner.query(`
      UPDATE "cadastros_cnpj"
      SET "codigo_municipio_ibge" = regexp_replace("payload" ->> 'codigo_municipio_ibge', '\\D', '', 'g')
      WHERE "codigo_municipio_ibge" IS NULL
        AND regexp_replace(COALESCE("payload" ->> 'codigo_municipio_ibge', ''), '\\D', '', 'g') ~ '^[0-9]{7}$'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "cadastros_cnpj" DROP COLUMN IF EXISTS "codigo_municipio_ibge"`,
    );
  }
}
