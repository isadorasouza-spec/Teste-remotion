import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type StatusProjecaoDocumentoFiscalFila =
  | "pendente"
  | "processando"
  | "concluido"
  | "erro"
  | "cancelado";

@Entity("projecoes_documentos_fiscais_fila")
@Index("UQ_projecoes_documentos_fiscais_alvo", ["escritorio_id", "simulacao_id", "arquivo_id"], { unique: true })
@Index("IDX_projecoes_documentos_fiscais_disponivel", ["status", "disponivel_em", "atualizado_em"])
@Check("CHK_projecoes_documentos_fiscais_status", `"status" IN ('pendente','processando','concluido','erro','cancelado')`)
@Check(
  "CHK_projecoes_documentos_fiscais_lease",
  `("status" = 'processando') = ("lock_adquirido_em" IS NOT NULL AND "lease_token" IS NOT NULL)`,
)
export class ProjecaoDocumentoFiscalFila {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;
  @Column({ type: "uuid" }) simulacao_id!: string;
  @Column({ type: "uuid" }) lote_id!: string;
  @Column({ type: "uuid" }) arquivo_id!: string;
  @Column({ type: "varchar", length: 255 }) bucket_normalizado!: string;
  @Column({ type: "varchar", length: 1024 }) chave_normalizado!: string;
  @Column({ type: "varchar", length: 20, default: "pendente" }) status!: StatusProjecaoDocumentoFiscalFila;
  @Column({ type: "smallint", default: 0 }) tentativas!: number;
  @Column({ type: "timestamptz", default: () => "now()" }) disponivel_em!: Date;
  @Column({ type: "uuid", nullable: true }) lease_token!: string | null;
  @Column({ type: "timestamptz", nullable: true }) lock_adquirido_em!: Date | null;
  @Column({ type: "text", nullable: true }) erro!: string | null;
  @Column({ type: "timestamptz", nullable: true }) concluido_em!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) reconciliado_em!: Date | null;
  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
