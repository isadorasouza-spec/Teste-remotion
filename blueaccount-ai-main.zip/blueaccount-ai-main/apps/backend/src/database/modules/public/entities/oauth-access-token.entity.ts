import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Index("UQ_oauth_access_tokens_token_hash", ["token_hash"], { unique: true })
@Index("IDX_oauth_access_tokens_client_id", ["client_id"])
@Index("IDX_oauth_access_tokens_session_id_hash", ["session_id_hash"])
@Index("IDX_oauth_access_tokens_family_id", ["family_id"])
@Index("IDX_oauth_access_tokens_expires_at", ["expires_at"])
@Entity("oauth_access_tokens")
export class OAuthAccessToken {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  token_hash!: string;

  @Column({ type: "text" })
  client_id!: string;

  @Column({ type: "uuid" })
  usuario_id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  session_id_hash!: string;

  @Column({ type: "uuid", nullable: true })
  family_id!: string | null;

  @Column({ type: "text", nullable: true })
  scope!: string | null;

  @Column({ type: "text", nullable: true })
  resource!: string | null;

  @Column({ type: "timestamp" })
  expires_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  revoked_at!: Date | null;

  @Column({ type: "timestamp", nullable: true })
  last_seen_at!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
