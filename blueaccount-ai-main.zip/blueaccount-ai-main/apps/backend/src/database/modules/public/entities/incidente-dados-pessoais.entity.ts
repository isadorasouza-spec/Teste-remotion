import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type StatusIncidenteDadosPessoais =
  | "triagem"
  | "contencao"
  | "avaliacao_risco"
  | "comunicacao"
  | "encerrado";

@Entity("incidentes_dados_pessoais")
@Index("IDX_incidentes_dados_pessoais_status", ["status"])
@Index("IDX_incidentes_dados_pessoais_detectado_em", ["detectado_em"])
export class IncidenteDadosPessoais {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "text" }) titulo!: string;
  @Column({ type: "text", default: "triagem" }) status!: StatusIncidenteDadosPessoais;
  @Column({ type: "text" }) descricao_resumida!: string;
  @Column({ type: "text", nullable: true }) categorias_dados!: string | null;
  @Column({ type: "text", nullable: true }) titulares_afetados_estimativa!: string | null;
  @Column({ type: "text", nullable: true }) avaliacao_risco!: string | null;
  @Column({ type: "text", nullable: true }) medidas_contencao!: string | null;
  @Column({ type: "text", nullable: true }) responsavel!: string | null;
  @Column({ type: "timestamp with time zone" }) detectado_em!: Date;
  @Column({ type: "timestamp with time zone", nullable: true }) comunicado_controlador_em!: Date | null;
  @Column({ type: "timestamp with time zone", nullable: true }) comunicado_anpd_em!: Date | null;
  @Column({ type: "timestamp with time zone", nullable: true }) comunicado_titulares_em!: Date | null;
  @Column({ type: "timestamp with time zone", nullable: true }) encerrado_em!: Date | null;
  @Column({ type: "jsonb", default: [] }) evidencias!: Array<Record<string, unknown>>;
  @CreateDateColumn({ type: "timestamp with time zone" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamp with time zone" }) updated_at!: Date;
}
