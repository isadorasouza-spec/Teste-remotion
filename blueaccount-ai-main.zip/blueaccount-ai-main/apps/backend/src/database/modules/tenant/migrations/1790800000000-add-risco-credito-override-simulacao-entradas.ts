import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `risco_credito_override` em `simulacao_entradas`: risco de crédito desta linha específica, que
 * vence `fornecedores.risco_credito` (ver `1790700000000-add-risco-credito-fornecedores`).
 *
 * `NULL` = "herda do fornecedor" (não "sem risco" — a ausência de um quarto valor "esta linha não
 * tem risco apesar do fornecedor marcado" é uma limitação aceita nesta entrega, ver
 * `domain/simulacoes/README.md`). Nullable, sem default e sem backfill: nenhuma entrada existente
 * muda de crédito com este deploy. `CHECK` trava os mesmos três literais.
 */
export class AddRiscoCreditoOverrideSimulacaoEntradas1790800000000
  implements MigrationInterface
{
  name = "AddRiscoCreditoOverrideSimulacaoEntradas1790800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "risco_credito_override" varchar(10) NULL,
        ADD CONSTRAINT "CK_simulacao_entradas_risco_credito_override"
          CHECK ("risco_credito_override" IS NULL OR "risco_credito_override" IN ('alto', 'medio', 'baixo'))
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."risco_credito_override" IS
        'Risco de crédito desta linha; vence fornecedores.risco_credito. NULL = herda do fornecedor.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP CONSTRAINT IF EXISTS "CK_simulacao_entradas_risco_credito_override",
        DROP COLUMN IF EXISTS "risco_credito_override"
    `);
  }
}
