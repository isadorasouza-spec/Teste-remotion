import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddRelatorioItensMulta1781500000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE relatorios
        ADD COLUMN IF NOT EXISTS itens_multa jsonb;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE relatorios
        DROP COLUMN IF EXISTS itens_multa;
    `);
  }
}
