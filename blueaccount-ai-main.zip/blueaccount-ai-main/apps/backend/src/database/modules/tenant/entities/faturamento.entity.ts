import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";

@Index("UQ_faturamento_ativo_cliente_competencia", ["cliente_id", "competencia"], {
  unique: true,
  where: '"faturamento_ativo" = true',
})
@Entity("faturamento")
export class Faturamento {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, (c) => c.faturamentos, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "text", nullable: true })
  competencia!: string | null;

  @Column({ type: "text", nullable: true })
  razao_social!: string | null;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  valor_cobrado!: number | null;

  @Column({ type: "text", nullable: true })
  discriminacao!: string | null;

  @Column({ type: "text", nullable: true })
  arquivo_origem!: string | null;

  @Column({ type: "jsonb", nullable: true })
  extracao_bruta!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  payload_normalizado_ui!: Record<string, unknown> | null;

  @Column({ type: "boolean", default: true })
  faturamento_ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;
}
