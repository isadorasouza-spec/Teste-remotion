import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona a hipótese de composição da base do ICMS e o IPI das entradas manuais.
 *
 * O default preserva a hipótese conservadora: IBS/CBS não compõem a base do ICMS. A linha pode
 * herdar o cenário (`NULL`) ou sobrescrevê-lo. O IPI nasce nulo e só é preenchido por UI/API/MCP;
 * a importação de NF-e permanece fora desta primeira etapa.
 */
export class AddIpiComposicaoBaseIcmsSimulacoes1787300000000 implements MigrationInterface {
  name = "AddIpiComposicaoBaseIcmsSimulacoes1787300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "composicao_base_icms" varchar(20) NOT NULL DEFAULT 'sem_ibs_cbs',
        ADD CONSTRAINT "ck_simulacoes_composicao_base_icms"
          CHECK ("composicao_base_icms" IN ('sem_ibs_cbs', 'com_ibs_cbs'))
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "valor_ipi" decimal(14,2),
        ADD COLUMN "composicao_base_icms_override" varchar(20),
        ADD CONSTRAINT "ck_simulacao_entrada_valor_ipi"
          CHECK ("valor_ipi" IS NULL OR "valor_ipi" >= 0),
        ADD CONSTRAINT "ck_simulacao_entrada_composicao_base_icms"
          CHECK (
            "composicao_base_icms_override" IS NULL OR
            "composicao_base_icms_override" IN ('sem_ibs_cbs', 'com_ibs_cbs')
          )
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_composicao_base_icms"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_valor_ipi"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "composicao_base_icms_override"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "valor_ipi"`);
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP CONSTRAINT IF EXISTS "ck_simulacoes_composicao_base_icms"`);
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP COLUMN IF EXISTS "composicao_base_icms"`);
  }
}
