import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";

export type PrioridadeOportunidade = "alta" | "media" | "baixa";
export type StatusOportunidade = "aberta" | "em_tratativa" | "recuperada" | "descartada";

@Entity("oportunidades_recuperacao")
export class OportunidadeRecuperacao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "uuid", nullable: true })
  valores_a_cobrar_id?: string | null;

  @Column({ type: "text" })
  competencia!: string;

  @Column({ type: "decimal", precision: 12, scale: 2 })
  valor_delta!: number;

  @Column({ type: "text", nullable: true })
  descricao?: string | null;

  @Column({ type: "text", default: "media" })
  prioridade!: PrioridadeOportunidade;

  @Column({ type: "text", default: "aberta" })
  status!: StatusOportunidade;

  @Column({ type: "text", nullable: true })
  responsavel?: string | null;

  @Column({ type: "date", nullable: true })
  prazo?: string | null;

  @Column({ type: "text", nullable: true })
  resultado_final?: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
