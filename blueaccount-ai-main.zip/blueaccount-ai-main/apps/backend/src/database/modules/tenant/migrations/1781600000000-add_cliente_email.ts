import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddClienteEmail1781600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE clientes
        ADD COLUMN IF NOT EXISTS email TEXT;
    `);
    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_clientes_email
        ON clientes (email)
        WHERE email IS NOT NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_clientes_email;`);
    await queryRunner.query(`
      ALTER TABLE clientes
        DROP COLUMN IF EXISTS email;
    `);
  }
}
