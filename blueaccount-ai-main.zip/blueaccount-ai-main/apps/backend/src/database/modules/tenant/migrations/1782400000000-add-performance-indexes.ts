import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddPerformanceIndexes1782400000000 implements MigrationInterface {
  name = "AddPerformanceIndexes1782400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_clientes_razao_social_trgm" ON "clientes" USING gin ("razao_social" public.gin_trgm_ops)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_clientes_nome_fantasia_trgm" ON "clientes" USING gin ("nome_fantasia" public.gin_trgm_ops) WHERE "nome_fantasia" IS NOT NULL`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_clientes_cnpj_trgm" ON "clientes" USING gin ("cnpj" public.gin_trgm_ops)`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_contratos_cliente_created" ON "contratos" ("cliente_id", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_contratos_escritorio_created" ON "contratos" ("escritorio_id", "created_at" DESC)`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_relatorios_cliente_ativo_competencia" ON "relatorios" ("cliente_id", "competencia" DESC) WHERE "relatorio_ativo" = true`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_relatorios_escritorio_created" ON "relatorios" ("escritorio_id", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_relatorios_arquivo_origem" ON "relatorios" ("arquivo_origem") WHERE "arquivo_origem" IS NOT NULL`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_documentos_escritorio_created" ON "documentos" ("escritorio_id", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_documentos_escritorio_status_created" ON "documentos" ("escritorio_id", "status_extracao", "created_at" DESC)`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_faturamento_escritorio_created" ON "faturamento" ("escritorio_id", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_faturamento_arquivo_origem" ON "faturamento" ("arquivo_origem") WHERE "arquivo_origem" IS NOT NULL`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_valores_a_cobrar_escritorio_competencia" ON "valores_a_cobrar" ("escritorio_id", "competencia" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_valores_a_cobrar_escritorio_status_competencia" ON "valores_a_cobrar" ("escritorio_id", "status", "competencia" DESC)`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_cobrancas_escritorio_created" ON "cobrancas" ("escritorio_id", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_cobrancas_cliente_created" ON "cobrancas" ("cliente_id", "created_at" DESC)`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_acoes_ai_status_prioridade_created" ON "acoes_ai" ("status", "prioridade", "created_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_acoes_ai_cliente_created" ON "acoes_ai" ("cliente_id", "created_at" DESC) WHERE "cliente_id" IS NOT NULL`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_historico_acao_ai_acao_created" ON "historico_acao_ai" ("acao_id", "created_at")`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_simulacoes_escritorio_updated" ON "simulacoes" ("escritorio_id", "updated_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_simulacoes_cliente_updated" ON "simulacoes" ("cliente_id", "updated_at" DESC)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_simulacao_entradas_simulacao_ordem" ON "simulacao_entradas" ("simulacao_id", "ordem", "created_at")`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_clausulas_excedentes_contrato" ON "clausulas_excedentes" ("contrato_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    const indexes = [
      "IDX_clausulas_excedentes_contrato",
      "IDX_simulacao_entradas_simulacao_ordem",
      "IDX_simulacoes_cliente_updated",
      "IDX_simulacoes_escritorio_updated",
      "IDX_historico_acao_ai_acao_created",
      "IDX_acoes_ai_cliente_created",
      "IDX_acoes_ai_status_prioridade_created",
      "IDX_cobrancas_cliente_created",
      "IDX_cobrancas_escritorio_created",
      "IDX_valores_a_cobrar_escritorio_status_competencia",
      "IDX_valores_a_cobrar_escritorio_competencia",
      "IDX_faturamento_arquivo_origem",
      "IDX_faturamento_escritorio_created",
      "IDX_documentos_escritorio_status_created",
      "IDX_documentos_escritorio_created",
      "IDX_relatorios_arquivo_origem",
      "IDX_relatorios_escritorio_created",
      "IDX_relatorios_cliente_ativo_competencia",
      "IDX_contratos_escritorio_created",
      "IDX_contratos_cliente_created",
      "IDX_clientes_cnpj_trgm",
      "IDX_clientes_nome_fantasia_trgm",
      "IDX_clientes_razao_social_trgm",
    ];
    for (const index of indexes) {
      await queryRunner.query(`DROP INDEX IF EXISTS "${index}"`);
    }
  }
}
