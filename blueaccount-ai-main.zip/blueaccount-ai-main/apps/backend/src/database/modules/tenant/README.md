# `src/database/modules/tenant`

Schema isolado por escritório. Cada escritório recebe um schema dedicado (`escritorio_<uuid>`).

## Entidades

| Tabela | Entidade | Função |
|--------|----------|--------|
| `clientes` | `Cliente` | Clientes/empresas gerenciados pelo escritório |
| `documentos` | `Documento` | Arquivos enviados (contratos, relatórios, etc.) |
| `ocr_manifests` | `OcrManifest` | Manifestos de cada execução OCR por documento |
| `ocr_blocks` | `OcrBlock` | Blocos OCR indexados para lookup por documento/página |
| `ocr_extracted_field_sources` | `OcrExtractedFieldSource` | Liga campos extraídos aos blocos OCR citados |
| `contratos` | `Contrato` | Contratos de prestação de serviço — inclui `valores_contratados`, `excedentes` e a competência do último reajuste automático |
| `valores_a_cobrar` | `ValoresACobrar` | Cobrança consolidada por cliente e competência, incluindo flag e metadados do reajuste contratual aplicado |
| `clausulas_excedentes` | `ClausulasExcedentes` | Cláusulas de cobrança por excedente |
| `servicos_contratados` | `ServicosContratados` | Serviços inclusos em um contrato |
| `relatorios` | `Relatorio` | Relatórios gerados pelo sistema |
| `simulacoes` / `simulacao_entradas` | `Simulacao` / `SimulacaoEntrada` | Cenários tributários e linhas com tratamento explícito de ICMS |
| `acumuladores_simulacao` | `AcumuladorSimulacao` | Catálogo de códigos do Domínio, classificação e estado ativo por escritório |
| `simulacao_grupos` / `simulacao_grupo_itens` | `SimulacaoGrupo` / `SimulacaoGrupoItem` | Agrupamento N:N de simulações por cliente (escopo por `cliente_id`) |
| `conexoes_assinatura_eletronica` | `ConexaoAssinaturaEletronica` | Credenciais OAuth criptografadas e cursor da sincronização por escritório/provedor |
| `envelopes_assinatura_eletronica` | `EnvelopeAssinaturaEletronica` | Ledger do PDF/certificado sincronizado no S3 e vínculo ao documento somente após processamento explícito |
| `certificados_digitais_clientes` | `CertificadoDigitalCliente` | Custódia do certificado A1 do cliente: metadados lidos do PKCS#12, ponteiro S3 do `.pfx` e senha cifrada pelo `CryptoService`. Um ativo por cliente |
| `cursores_distribuicao_dfe` | `CursorDistribuicaoDfe` | Cursor NSU do `NFeDistribuicaoDFe` por cliente e ambiente, com bloqueio e cota horária persistidos |

## Migrations

`1787900000000-add-origem-fatores-ncm-simulacao.ts` adiciona a proveniência independente de IBS e
CBS. No backfill, todo fator histórico não nulo é marcado `manual` e todo fator nulo,
`tratamento`; os valores numéricos não são alterados. As origens permitidas são `manual`, `ncm`,
`acumulador` e `tratamento`.

`1788900000000-reconciliar-fatores-ncm-simulacoes.ts` reaplica o catálogo público por longest-prefix
somente às linhas cuja origem já é `ncm`; fatores manuais, de acumulador e de tratamento não mudam.
`1789200000000-aplicar-heranca-fatores-ncm.ts` repete essa reconciliação após a nova invariante
global: toda raiz configurada é herdada e somente uma exceção filha de fator 1 restaura alíquota cheia.
`1789000000000-add-fundamento-credito-pis-cofins.ts` adiciona o fundamento auditável dos créditos
manuais de PIS/COFINS.

`1789600000000-add_nbs_to_simulacao_entradas.ts` adiciona `nbs` (varchar(9), nullable),
`credito_ibs_cbs_vedado` (boolean, default `false`) e `regime_especifico` (varchar(40), nullable) a
`simulacao_entradas`, com `CHECK` de exclusão mútua entre `ncm` e `nbs`. Sem backfill: toda linha
existente tem `nbs` nulo, então o `CHECK` valida sem migração de dados.
`1789700000000-add_origem_fator_nbs.ts` inclui `'nbs'` no domínio de `origem_fator_ibs`/
`origem_fator_cbs` (`DROP CONSTRAINT IF EXISTS` antes do `ADD`, para ser re-executável por tenant).

`1791900000000-create-certificados-digitais-e-cursor-dfe.ts` cria as duas tabelas do cano
`NFeDistribuicaoDFe`, ambas com RLS `FORCE` por `escritorio_id`:

- `certificados_digitais_clientes` guarda **material de credencial de terceiro**, não documento. O
  binário fica em `CERTIFICADOS_DIGITAIS_BUCKET`; a coluna guarda só o ponteiro, o `sha256_pfx` e a
  senha cifrada (`senha_encrypted`/`senha_iv`/`senha_tag`, AES-256-GCM do `CryptoService`). A senha
  é **cifrada, não hasheada**: o handshake mTLS precisa dela em claro. O índice parcial
  `UQ_certificados_digitais_ativo` admite um único certificado ativo por cliente, e a FK para
  `clientes` é `ON DELETE CASCADE`.
- `cursores_distribuicao_dfe` tem PK composta `(escritorio_id, cliente_id, ambiente)` e existe
  porque os limites do protocolo são **por CNPJ e persistentes**: `ultimo_nsu` nunca pode regredir
  (NSU fora de ordem bloqueia o CNPJ por 1h), `bloqueado_ate` cobre a espera do `cStat 137` e o
  bloqueio do `656`, e `consultas_na_janela`/`janela_iniciada_em` implementam a cota de 20
  consultas/hora. Token bucket em memória não serve aqui: reinício do processo zeraria o contador e
  provocaria `656`. `primeiro_nsu_visto` registra onde a primeira varredura entrou: `distNSU=0`
  **não** começa no NSU 1, e sim no documento mais antigo ainda retido (3 meses), então o cursor
  nunca deve assumir que caminhou desde o início.

A fila que alimenta esse cano é pública (`public.distribuicoes_dfe_fila`), não tenant — ver
`../public/README.md`.

Migrations TypeORM em `migrations/`. Aplicadas automaticamente ao:

1. **Provisionar novo escritório:**
   ```bash
   POST /api/admin/escritorios/:id/schema
   ```
   Chama `provisionEscritorioSchema()` → `runTenantMigrations()` → aplica todas as migrations no novo schema.

2. **Sincronizar schemas existentes:**
   ```bash
   npm run migration:sync-tenants
   ```
   Aplica migrations pendentes em todos os schemas de tenant.

3. **Gerar nova migration:**
   ```bash
   npm run migration:generate:tenant \
     --schema=escritorio_<uuid> \
     --name=AddValorReajustado
   ```
   Gera arquivo em `migrations/` após detectar diff contra o schema.

A migration de dados `1788500000000-normalizar-fonte-editavel-series-simulacao` corrige séries
criadas durante a transição do vínculo: quando a simulação externa ficou fora do grupo e uma cópia do
mesmo ano foi incluída nele, essa cópia passa a ser a fonte editável. As simulações dos outros anos e
suas entradas são redirecionadas para a cópia-base. Séries em que a fonte já pertence ao grupo não
são alteradas, e o `down` é intencionalmente vazio porque não é seguro desfazer a autoria após novas
edições na cópia-base.

### Simulações e ICMS

- `1780400000000-add_tratamento_icms_to_entradas.ts` adiciona `tratamento_icms` às entradas do simulador.
- A migration faz backfill compatível: receitas usam `gera_debito`, despesas usam `gera_credito`, e despesas de fornecedores que anteriormente anulavam ICMS recebem `regra_credito_icms = sem_credito`.
- Novos writes definem o fallback por `tipo` no domínio; a coluna não possui default fixo no banco.

### Dados do Domínio

- `1787600000000-add-acumuladores-dados-simulacao.ts` cria o catálogo vazio em cada tenant e adiciona
  `acumulador_id`, fatores e documento de origem às entradas. Não há códigos globais ou carga inicial:
  cada escritório cadastra seus acumuladores ou permite que sua primeira importação os crie.
- `1787700000000-add-fatores-padrao-acumuladores-simulacao.ts` adiciona defaults nullable de IBS/CBS
  entre 0 e 1 ao catálogo, sem backfill nem alteração das entradas existentes.
- `documentos.simulacao_id` e `simulacao_entradas.documento_origem_id` usam cascade para que remover
  um documento de importação elimine somente seu lote. Acumuladores usam `ON DELETE RESTRICT` e não
  são apagados fisicamente.

### Índices de performance

- `1782400000000-add-performance-indexes.ts` adiciona índices compostos para as listagens e filtros
  operacionais, índices de relacionamento ausentes e índices trigram para busca parcial de clientes.
- `public.pg_trgm` é habilitado pela migration pública `1782310000000-enable-pg-trgm.ts`.
- O datasource tenant mantém `search_path=<schema>,public`, necessário para FKs públicas e
  operator classes de extensões.
- O sync processa um tenant por vez, com `lock_timeout` de 5 segundos e `statement_timeout` de
  120 segundos. Os limites podem ser ajustados por `DB_TENANT_MIGRATION_LOCK_TIMEOUT_MS` e
  `DB_TENANT_MIGRATION_STATEMENT_TIMEOUT_MS`.
- Antes de adicionar novos índices, valide o padrão de consulta com `EXPLAIN (ANALYZE, BUFFERS)` e
  verifique redundância em `pg_stat_user_indexes`.

## Isolamento

- Cada schema é independente: `escritorio_<uuid>`, `escritorio_<outro_uuid>`, etc.
- A tabela `_tenant_migrations` em cada schema rastreia o estado de migrations.
- FKs para `public.escritorios` e `public.usuarios` resolvem via `search_path`.

## Exemplo: Add Column in Tenant

```typescript
// 1. Edite a entidade
export class Contrato {
  @Column()
  valor_reajustado: number;  // ← nova coluna
}

// 2. Gere a migration
npm run migration:generate:tenant --schema=escritorio_dev --name=AddValorReajustado

// 3. Revise o arquivo gerado
// src/database/modules/tenant/migrations/<timestamp>-AddValorReajustado.ts

// 4. Sincronize todos os schemas
npm run migration:sync-tenants
```

## Reconciliação da data de reajuste contratual

`1792400000000-reconciliar-data-ultimo-reajuste-contratos` corrige schemas que registraram
`1784300000001` mas não possuem `contratos.data_ultimo_reajuste`. A leitura do cliente carrega
contratos e falhava nesses schemas, inclusive ao abrir as simulações do cliente.
A nova migration adiciona a coluna DATE nullable com `IF NOT EXISTS`, sem preencher datas
históricas. Schemas já corretos preservam os valores. O down não remove a coluna, pois ela
pertence ao contrato da migration original e pode existir antes da reconciliação.

### Acervo de dados operacionais

`1792600000000-criar-registros-operacionais` adiciona `registros_operacionais` (entidade
`RegistroOperacional`): conteúdo fiscal/contábil em uma tabela ampla, sem FK para simulação.
FK para cliente, RLS forçada por escritório e chave única de identidade da origem por cliente.
Datas e tipo/fonte têm índices próprios. Dados ausentes ficam null, sem backfill. Aplicar a migration
na etapa de rollout antes de disponibilizar a API. Regras: `domain/dados-operacionais/README.md`.

`1792700000000-receber-resumos-operacionais` estende o acervo com os campos do extrator mensal e
`importacoes_operacionais_mensais` (entidade `ImportacaoOperacionalMensal`), controle técnico de
recepção/publicação, com RLS forçada. A tabela de negócio continua sendo `registros_operacionais`.
A migration é aditiva; aplicar separadamente no rollout, sem reescrever a migration anterior.
