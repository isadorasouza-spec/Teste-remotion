import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddCreditoPoliticasAcumuladores1790500000000 implements MigrationInterface {
  name = "AddCreditoPoliticasAcumuladores1790500000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "acumuladores_simulacao" ADD COLUMN "gera_credito_padrao" boolean NOT NULL DEFAULT true`);
    await q.query(`ALTER TABLE "acumuladores_simulacao_cliente" ADD COLUMN "gera_credito" boolean`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "acumuladores_simulacao_cliente" DROP COLUMN "gera_credito"`);
    await q.query(`ALTER TABLE "acumuladores_simulacao" DROP COLUMN "gera_credito_padrao"`);
  }
}
