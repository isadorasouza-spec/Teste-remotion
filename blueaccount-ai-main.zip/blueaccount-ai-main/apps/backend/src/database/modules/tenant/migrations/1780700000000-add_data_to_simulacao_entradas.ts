import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddDataToSimulacaoEntradas1780700000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "data" date;
    `);
    // Backfill: entradas sem data usam a data de criação do registro.
    await queryRunner.query(`
      UPDATE "simulacao_entradas" SET "data" = "created_at"::date WHERE "data" IS NULL;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "data";
    `);
  }
}
