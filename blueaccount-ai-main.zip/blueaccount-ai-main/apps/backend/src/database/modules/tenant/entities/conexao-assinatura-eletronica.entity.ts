import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type ProvedorAssinaturaEletronica = "docusign";
export type StatusConexaoAssinatura = "conectado" | "reconexao_necessaria" | "revogado" | "erro";
export type StatusSincronizacaoAssinatura = "ocioso" | "executando" | "erro";

@Index("UQ_conexoes_assinatura_escritorio_provedor", ["escritorio_id", "provedor"], { unique: true })
@Entity("conexoes_assinatura_eletronica")
export class ConexaoAssinaturaEletronica {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "text" }) provedor!: ProvedorAssinaturaEletronica;
  @Column({ type: "text", nullable: true }) conta_id!: string | null;
  @Column({ type: "text", nullable: true }) conta_nome!: string | null;
  @Column({ type: "text", nullable: true }) conta_email!: string | null;
  @Column({ type: "text", nullable: true }) base_uri!: string | null;
  @Column({ type: "text", default: "erro" }) status!: StatusConexaoAssinatura;
  @Column({ type: "boolean", default: false }) ativo!: boolean;
  @Column({ type: "text", nullable: true }) access_token_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) access_token_iv!: string | null;
  @Column({ type: "text", nullable: true }) access_token_tag!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_iv!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_tag!: string | null;
  @Column({ type: "timestamptz", nullable: true }) access_token_expires_at!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) ultima_sincronizacao_em!: Date | null;
  @Column({ type: "uuid", nullable: true }) conectado_por_usuario_id!: string | null;
  @Column({ type: "text", nullable: true }) ultimo_erro!: string | null;
  @Column({ type: "text", nullable: true }) oauth_nonce_hash!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_iv!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_tag!: string | null;
  @Column({ type: "timestamptz", nullable: true }) oauth_expires_at!: Date | null;
  /**
   * Guard de run único da sincronização (State Machine `conector-docusign`).
   * Há exatamente uma `conexao` por `escritorio_id + provedor`, então o
   * ciclo de vida da execução vive aqui em vez de uma tabela de execuções
   * dedicada (padrão diferente de `conector_drive_execucoes`).
   */
  @Column({ type: "text", default: "ocioso" }) sincronizacao_status!: StatusSincronizacaoAssinatura;
  @Column({ type: "uuid", nullable: true }) sincronizacao_run_id!: string | null;
  @Column({ type: "text", nullable: true }) sincronizacao_execution_arn!: string | null;
  @Column({ type: "timestamptz", nullable: true }) sincronizacao_iniciada_em!: Date | null;
  @CreateDateColumn({ type: "timestamptz" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamptz" }) updated_at!: Date;
}
