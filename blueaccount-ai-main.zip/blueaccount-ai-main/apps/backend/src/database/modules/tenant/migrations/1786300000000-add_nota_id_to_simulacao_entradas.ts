import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Inverte a relação nota↔entrada: a importação de NF-e passa a gerar UMA `SimulacaoEntrada` por
 * item do XML (`domain/simulacoes/nfe/mapeador.ts` → `mapearItensParaEntradas`), em vez de uma
 * única entrada agregada por nota inteira. Isso não cabe mais no antigo `entrada_id` singular em
 * `simulacao_notas_fiscais` (uma nota, várias entradas) — o dono da FK passa a ser
 * `simulacao_entradas.nota_id`.
 *
 * Sem backfill nos dois sentidos: confirmado com o usuário que não há dado real em
 * `simulacao_notas_fiscais`/`simulacao_entradas` ainda (feature em `main`, mas não usada em
 * produção). `nota_id` nasce `NULL` para toda entrada existente (manual/legada) e `ON DELETE
 * CASCADE`: remover a nota remove as entradas que ela gerou (ver `removerNotaSimulacao`).
 */
export class AddNotaIdToSimulacaoEntradas1786300000000 implements MigrationInterface {
  name = "AddNotaIdToSimulacaoEntradas1786300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "nota_id" uuid
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1
          FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'FK_simulacao_entradas_nota'
            AND t.relname = 'simulacao_entradas'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "simulacao_entradas"
            ADD CONSTRAINT "FK_simulacao_entradas_nota"
            FOREIGN KEY ("nota_id") REFERENCES "simulacao_notas_fiscais"("id") ON DELETE CASCADE;
        END IF;
      END
      $$;
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "IDX_simulacao_entradas_nota_id"
      ON "simulacao_entradas" ("nota_id")
      WHERE "nota_id" IS NOT NULL
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."nota_id" IS
        'Nota fiscal que gerou esta entrada (um item do XML importado); null para entrada manual/legada ou copiada por duplicar/série. ON DELETE CASCADE: remover a nota remove as entradas que ela gerou.'
    `);

    // Lado antigo da relação (nota → uma única entrada): sem dado real a preservar, dropar direto.
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
      DROP CONSTRAINT IF EXISTS "fk_simulacao_notas_fiscais_entrada"
    `);

    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
      DROP COLUMN IF EXISTS "entrada_id"
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
        ADD COLUMN IF NOT EXISTS "entrada_id" uuid
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1
          FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'fk_simulacao_notas_fiscais_entrada'
            AND t.relname = 'simulacao_notas_fiscais'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "simulacao_notas_fiscais"
            ADD CONSTRAINT "fk_simulacao_notas_fiscais_entrada"
            FOREIGN KEY ("entrada_id") REFERENCES "simulacao_entradas"("id") ON DELETE SET NULL;
        END IF;
      END
      $$;
    `);

    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_simulacao_entradas_nota_id"`);
    await queryRunner.query(
      `ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "FK_simulacao_entradas_nota"`,
    );
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "nota_id"`);
  }
}
