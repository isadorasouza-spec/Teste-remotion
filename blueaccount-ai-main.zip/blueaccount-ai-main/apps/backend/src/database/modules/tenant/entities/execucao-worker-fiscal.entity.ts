import { Entity, Column, PrimaryColumn } from "typeorm";

@Entity("execucoes_worker_fiscal")
export class ExecucaoWorkerFiscal {
  @PrimaryColumn({ type: "uuid" }) escritorio_id!: string;
  @PrimaryColumn({ type: "text" }) id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;
  @Column({ type: "uuid" }) lote_id!: string;
  @Column({ type: "jsonb" }) resultados!: Record<string, unknown>;
  @Column({ type: "jsonb", nullable: true }) resultado!: Record<string, unknown> | null;
  @Column({ type: "boolean" }) callback_entregue!: boolean;
}
