import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation
} from "typeorm";
import { Documento } from "./documento.entity.js";

export type TipoExtracao = "contrato" | "relatorio";

@Index("IDX_extracoes_documento_id", ["documento_id"])
@Entity("extracoes")
export class Extracao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Documento, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "documento_id" })
  documento!: Relation<Documento>;

  @Column({ type: "uuid" })
  documento_id!: string;

  @Column({ type: "text" })
  tipo_extracao!: TipoExtracao;

  @Column({ type: "jsonb" })
  payload_json!: Record<string, unknown>;

  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true })
  confidence!: number | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
