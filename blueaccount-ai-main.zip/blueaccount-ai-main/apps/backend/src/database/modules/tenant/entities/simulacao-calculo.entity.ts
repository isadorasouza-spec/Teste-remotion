import { Column, Entity, Index, PrimaryColumn } from "typeorm";

@Entity("simulacao_calculos")
@Index("IDX_simulacao_calculos_escritorio", ["escritorio_id"])
@Index("IDX_simulacao_calculos_calculado_em", ["calculado_em"])
export class SimulacaoCalculo {
  @PrimaryColumn({ type: "uuid" }) simulacao_id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "int" }) versao_motor!: number;
  @Column({ type: "text" }) assinatura_dependencias!: string;
  @Column({ type: "bytea" }) payload!: Buffer;
  @Column({ type: "jsonb", nullable: true }) resumo_editor!: Record<string, unknown> | null;
  @Column({ type: "timestamptz", default: () => "now()" }) calculado_em!: Date;
}
