import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Premissa de comparação de regimes: o que fazer com o IPI destacado nas receitas quando o regime
 * efetivo do cenário não admite IPI (Simples Nacional, onde ele é componente do DAS).
 *
 * `receita` é o default porque É o comportamento atual do motor — o valor fica no preço e vira
 * receita bruta. Por isso a migration é neutra em deploy: nenhum cenário existente muda de número.
 */
export class AddDestinoIpiSemIncidenciaSimulacoes1789800000002 implements MigrationInterface {
  name = "AddDestinoIpiSemIncidenciaSimulacoes1789800000002";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "destino_ipi_sem_incidencia" varchar(20) NOT NULL DEFAULT 'receita',
        ADD CONSTRAINT "CK_simulacoes_destino_ipi_sem_incidencia"
          CHECK ("destino_ipi_sem_incidencia" IN ('receita', 'reducao_preco'))
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP CONSTRAINT "CK_simulacoes_destino_ipi_sem_incidencia",
        DROP COLUMN "destino_ipi_sem_incidencia"
    `);
  }
}
