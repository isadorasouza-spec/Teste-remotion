import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Cria as tabelas do conector de Google Drive (sync Drive→S3; o processamento
 * do inventário pelo pipeline existente é fase futura):
 * - `conector_drive_execucoes`: uma linha por execução admin-only da State Machine
 *   `apps/services/conector-drive` (guarda de execução única por escritório via
 *   índice parcial único em status='executando').
 * - `conector_drive_arquivos`: ledger de arquivos sincronizados por execução (um
 *   por item do inventário lido do manifesto), usado para deduplicação
 *   (escritorio_id, modulo, md5_checksum) e auditoria.
 */
export class CreateConectorDrive1782700000000 implements MigrationInterface {
  name = "CreateConectorDrive1782700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "conector_drive_execucoes" (
        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "status" text NOT NULL,
        "execution_arn" text NULL,
        "total_listados" int NOT NULL DEFAULT 0,
        "sincronizados" int NOT NULL DEFAULT 0,
        "erros" int NOT NULL DEFAULT 0,
        "ignorados" int NOT NULL DEFAULT 0,
        "truncada" boolean NOT NULL DEFAULT false,
        "detalhes" jsonb NULL,
        "erro" text NULL,
        "iniciada_por_usuario_id" uuid NULL,
        "started_at" timestamptz NOT NULL DEFAULT now(),
        "finished_at" timestamptz NULL,
        CONSTRAINT "PK_conector_drive_execucoes" PRIMARY KEY ("id")
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conector_drive_exec_ativa"
      ON "conector_drive_execucoes" ("escritorio_id")
      WHERE "status" = 'executando'
    `);

    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "conector_drive_arquivos" (
        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "execucao_id" uuid NOT NULL,
        "drive_file_id" text NOT NULL,
        "md5_checksum" text NOT NULL,
        "nome_arquivo" text NOT NULL,
        "mime_type" text NULL,
        "size_bytes" bigint NULL,
        "drive_modified_time" timestamptz NULL,
        "modulo" text NOT NULL,
        "s3_key" text NOT NULL,
        "documento_id" uuid NULL,
        "status" text NOT NULL,
        "motivo" text NULL,
        "created_at" timestamptz NOT NULL DEFAULT now(),
        "updated_at" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "PK_conector_drive_arquivos" PRIMARY KEY ("id"),
        CONSTRAINT "FK_conector_drive_arquivos_execucao" FOREIGN KEY ("execucao_id") REFERENCES "conector_drive_execucoes"("id") ON DELETE CASCADE ON UPDATE NO ACTION
      )
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conector_drive_arq_dedup"
      ON "conector_drive_arquivos" ("escritorio_id", "modulo", "md5_checksum")
      WHERE "status" = 'sincronizado'
    `);
    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "IDX_conector_drive_arq_file"
      ON "conector_drive_arquivos" ("escritorio_id", "drive_file_id")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_conector_drive_arq_file"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_conector_drive_arq_dedup"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "conector_drive_arquivos"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_conector_drive_exec_ativa"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "conector_drive_execucoes"`);
  }
}
