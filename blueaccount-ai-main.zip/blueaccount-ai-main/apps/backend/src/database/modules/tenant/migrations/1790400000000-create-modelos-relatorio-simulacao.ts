import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateModelosRelatorioSimulacao1790400000000 implements MigrationInterface {
  name = "CreateModelosRelatorioSimulacao1790400000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "modelos_relatorio_simulacao" (
      "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "nome" varchar(160) NOT NULL,
      "descricao" text,
      "conteudo_html" text NOT NULL,
      "versao_contrato" varchar(50) NOT NULL DEFAULT 'relatorio_simulacao_v1',
      "checksum_sha256" varchar(64) NOT NULL,
      "tamanho_bytes" integer NOT NULL,
      "created_at" timestamptz NOT NULL DEFAULT now(),
      "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "CHK_modelos_relatorio_simulacao_versao" CHECK ("versao_contrato" = 'relatorio_simulacao_v1'),
      CONSTRAINT "CHK_modelos_relatorio_simulacao_tamanho" CHECK ("tamanho_bytes" BETWEEN 1 AND 5242880)
    )`);
    await q.query(`CREATE INDEX "IDX_modelos_relatorio_simulacao_escritorio" ON "modelos_relatorio_simulacao" ("escritorio_id")`);
    await q.query(`CREATE UNIQUE INDEX "UQ_modelos_relatorio_simulacao_nome" ON "modelos_relatorio_simulacao" ("escritorio_id", lower(btrim("nome")))`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE "modelos_relatorio_simulacao"`);
  }
}
