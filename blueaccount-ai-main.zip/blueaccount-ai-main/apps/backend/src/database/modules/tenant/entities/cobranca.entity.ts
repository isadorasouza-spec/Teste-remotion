import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { PlataformaCobranca } from "./plataforma-cobranca.entity.js";

export type StatusCobranca =
  | "pendente"
  | "paga"
  | "atrasada"
  | "cancelada"
  | "estornada";

@Index("UQ_cobrancas_escritorio_idempotency_key", ["escritorio_id", "idempotency_key"], {
  unique: true,
  where: "idempotency_key IS NOT NULL",
})
@Entity("cobrancas")
export class Cobranca {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "uuid", nullable: true })
  valor_a_cobrar_id!: string | null;

  // Chave de idempotência da emissão: garante que retries/reexecuções de tools
  // não dupliquem a cobrança. Único por (escritorio_id, idempotency_key).
  @Column({ type: "text", nullable: true })
  idempotency_key!: string | null;

  @ManyToOne(() => PlataformaCobranca, { nullable: false })
  @JoinColumn({ name: "plataforma_id" })
  plataforma!: Relation<PlataformaCobranca>;

  @Column({ type: "uuid" })
  plataforma_id!: string;

  @Column({ type: "text" })
  id_externo!: string;

  @Column({ type: "text", nullable: true })
  id_externo_cliente!: string | null;

  @Column({ type: "decimal", precision: 12, scale: 2 })
  valor!: number;

  @Column({ type: "date" })
  vencimento!: string;

  @Column({ type: "text" })
  billing_type!: string;

  @Column({ type: "text", default: "pendente" })
  status!: StatusCobranca;

  @Column({ type: "text", nullable: true })
  status_externo!: string | null;

  @Column({ type: "text", nullable: true })
  url_boleto!: string | null;

  @Column({ type: "text", nullable: true })
  url_pix!: string | null;

  @Column({ type: "timestamptz", nullable: true })
  pago_em!: Date | null;

  @Column({ type: "jsonb", nullable: true })
  payload_ultimo_evento!: Record<string, unknown> | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
