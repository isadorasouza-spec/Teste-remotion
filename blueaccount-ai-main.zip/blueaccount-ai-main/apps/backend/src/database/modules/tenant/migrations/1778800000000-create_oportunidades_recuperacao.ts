import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateOportunidadesRecuperacao1778800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "oportunidades_recuperacao" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "cliente_id" uuid NOT NULL,
        "valores_a_cobrar_id" uuid,
        "competencia" text NOT NULL,
        "valor_delta" numeric(12,2) NOT NULL,
        "descricao" text,
        "prioridade" text NOT NULL DEFAULT 'media',
        "status" text NOT NULL DEFAULT 'aberta',
        "responsavel" text,
        "prazo" date,
        "resultado_final" text,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE INDEX "idx_oportunidades_escritorio_id" ON "oportunidades_recuperacao"("escritorio_id");
      CREATE INDEX "idx_oportunidades_cliente_id" ON "oportunidades_recuperacao"("cliente_id");
      CREATE INDEX "idx_oportunidades_status" ON "oportunidades_recuperacao"("status");
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "oportunidades_recuperacao";`);
  }
}
