import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  Index,
  Unique,
  type Relation,
} from "typeorm";
import { Simulacao } from "./simulacao.entity.js";
import { SimulacaoEntrada } from "./simulacao-entrada.entity.js";
import { Fornecedor } from "./fornecedor.entity.js";

/**
 * Classificação de uma nota importada em relação ao cliente da simulação.
 * `intercompany`/`indeterminado` não geram lançamento (`entradas` fica vazio).
 */
export type ClassificacaoNotaFiscal = "receita" | "custo_direto" | "intercompany" | "indeterminado";
// O CHECK "CK_simulacao_notas_fiscais_origem" (migration 1791100000000) só aceita 'upload'/'sieg'.
// A ingestão de NFC-e por chave de acesso (origem de lote "portal_sefaz") nunca chega aqui hoje
// porque lotes cliente-scoped nunca projetam para `simulacao_entradas`/`simulacao_notas_fiscais`
// (ver guard em `IngestaoDocumentosFiscaisService.criarLote`). Se a projeção for habilitada um dia
// para esse canal, este CHECK vira bloqueador: alterar a constraint é pré-requisito de deploy.
export type OrigemNotaFiscal = "upload" | "sieg";

/** De onde saiu a alíquota derivada: dos itens (`det`) ou do fallback pelos totais do cabeçalho. */
export type AliquotaOrigemNota = "itens" | "totais";

/** Colunas `numeric` voltam como string do driver; o motor e a UI esperam number. */
const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/**
 * Registro de uma NF-e/NFC-e importada para uma simulação. Guarda o mínimo para
 * deduplicar (por chave), rastrear a origem de cada lançamento e permitir revisão.
 */
@Entity("simulacao_notas_fiscais")
@Unique("uq_simulacao_notas_fiscais_chave", ["simulacao_id", "chave"])
@Index("IDX_simulacao_notas_fiscais_fornecedor_id", ["fornecedor_id"], {
  where: '"fornecedor_id" IS NOT NULL',
})
export class SimulacaoNotaFiscal {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  @Index("idx_simulacao_notas_fiscais_escritorio_id")
  escritorio_id!: string;

  @ManyToOne(() => Simulacao, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "simulacao_id" })
  simulacao!: Relation<Simulacao>;

  @Column({ type: "uuid" })
  @Index("idx_simulacao_notas_fiscais_simulacao_id")
  simulacao_id!: string;

  /**
   * Lançamentos gerados por esta nota — um por item do XML (`domain/simulacoes/nfe/mapeador.ts` →
   * `mapearItensParaEntradas`), ou uma única entrada sintética quando a nota não tem itens
   * legíveis. Vazio para nota que não gera lançamento (indeterminada/homologação/intercompany do
   * lado que enviou). `SimulacaoEntrada.nota_id` é o lado dono da FK; remover a nota (`ON DELETE
   * CASCADE` nessa FK) remove todas as entradas que ela gerou — ver `removerNotaSimulacao`.
   */
  @OneToMany(() => SimulacaoEntrada, (e) => e.nota)
  entradas!: Relation<SimulacaoEntrada[]>;

  /**
   * Cadastro do emitente usado pela simulação. É a referência canônica para identificação e
   * crédito; `emitente_documento`/`emitente_nome` permanecem como snapshot histórico do XML.
   */
  @ManyToOne(() => Fornecedor, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "fornecedor_id" })
  fornecedor!: Relation<Fornecedor> | null;

  @Column({ type: "uuid", nullable: true })
  fornecedor_id!: string | null;

  /** Chave de acesso: 44 dígitos na NF-e, 50 na NFS-e nacional. */
  @Column({ type: "varchar", length: 50 })
  chave!: string;

  /** 55 = NF-e, 65 = NFC-e; null = NFS-e nacional. */
  @Column({ type: "int", nullable: true })
  modelo!: number | null;

  /** 1 = produção, 2 = homologação. */
  @Column({ type: "int" })
  ambiente!: number;

  /** 0 = entrada, 1 = saída (tpNF). */
  @Column({ type: "int" })
  tipo_operacao!: number;

  @Column({ type: "varchar", length: 20, nullable: true })
  numero!: string | null;

  @Column({ type: "varchar", length: 10, nullable: true })
  serie!: string | null;

  @Column({ type: "varchar", length: 40, nullable: true })
  data_emissao!: string | null;

  @Column({ type: "varchar", length: 14, nullable: true })
  emitente_documento!: string | null;

  @Column({ type: "varchar", length: 255, nullable: true })
  emitente_nome!: string | null;

  /** CRT do emitente: 1 Simples, 2 Simples com excesso de sublimite, 3 Regime Normal, 4 MEI. */
  @Column({ type: "smallint", nullable: true })
  emitente_regime!: number | null;

  @Column({ type: "varchar", length: 14, nullable: true })
  destinatario_documento!: string | null;

  @Column({ type: "varchar", length: 255, nullable: true })
  destinatario_nome!: string | null;

  @Column({ type: "decimal", precision: 14, scale: 2 })
  valor_total!: number;

  /** `ICMSTot/vProd`. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_produtos!: number | null;

  /** `ISSQNtot/vServ`. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_servicos!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_icms!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_iss!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_ipi!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_pis!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_cofins!: number | null;

  /**
   * `ICMSTot/vFrete`, só para auditoria — quem decide se o frete integra o valor da operação de
   * cada linha é `domain/simulacoes/nfe/frete.ts`, e o componente por item fica em
   * `simulacao_entradas.valor_frete`.
   */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  valor_frete!: number | null;

  /**
   * `transp/modFrete` da nota (0 conta do remetente/CIF … 4 transporte próprio do destinatário),
   * só para auditoria. Ver `NotaFiscalParseada.modalidadeFrete`.
   */
  @Column({ type: "smallint", nullable: true })
  modalidade_frete!: number | null;

  /** Soma das bases de ICMS dos itens tributados — peso da média ponderada por fornecedor. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  base_icms!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true, transformer: numericToNumber })
  base_iss!: number | null;

  /** Alíquota de ICMS como aparece na nota (já reduzida pelo fator do ano de emissão). */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_icms_observada!: number | null;

  /**
   * Alíquota nominal de ICMS = observada / fator do cronograma no ano de emissão. É o valor gravado
   * como `aliquota_icms_override` na entrada; o motor reaplica o fator do ano do cenário.
   */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_icms_nominal!: number | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_iss_observada!: number | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_iss_nominal!: number | null;

  /** `itens` = média ponderada por `vBC` dos itens; `totais` = fallback pelo cabeçalho. */
  @Column({ type: "varchar", length: 10, nullable: true })
  aliquota_origem!: AliquotaOrigemNota | null;

  @Column({ type: "varchar", length: 20 })
  classificacao!: ClassificacaoNotaFiscal;

  @Column({ type: "boolean", default: false })
  divergencia_tpnf!: boolean;

  @Column({ type: "varchar", length: 10, nullable: true })
  storage_provider!: string | null;

  @Column({ type: "varchar", length: 512, nullable: true })
  storage_key!: string | null;

  /** Canal que entregou o XML; credenciais do provedor nunca são persistidas. */
  @Column({ type: "varchar", length: 20, default: "upload" })
  origem!: OrigemNotaFiscal;

  /** SHA-256 do XML cru para detectar conteúdo divergente sob a mesma chave de acesso. */
  @Column({ type: "char", length: 64, nullable: true })
  conteudo_hash!: string | null;

  /** Identidade determinística do documento no warehouse fiscal, independente da simulação. */
  @Column({ type: "uuid", nullable: true })
  documento_canonico_id!: string | null;

  /** Arquivo do ledger tenant que originou esta projeção assíncrona. */
  @Column({ type: "uuid", nullable: true })
  arquivo_ingestao_id!: string | null;

  @CreateDateColumn()
  created_at!: Date;
}
