import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateAssinaturasEletronicas1784600000000 implements MigrationInterface {
  name = "CreateAssinaturasEletronicas1784600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "conexoes_assinatura_eletronica" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "provedor" text NOT NULL,
      "conta_id" text, "conta_nome" text, "conta_email" text, "base_uri" text,
      "status" text NOT NULL DEFAULT 'erro', "ativo" boolean NOT NULL DEFAULT false,
      "access_token_encrypted" text, "access_token_iv" text, "access_token_tag" text,
      "refresh_token_encrypted" text, "refresh_token_iv" text, "refresh_token_tag" text,
      "access_token_expires_at" timestamptz,
      "ultima_sincronizacao_em" timestamptz, "conectado_por_usuario_id" uuid, "ultimo_erro" text,
      "oauth_nonce_hash" text, "oauth_pkce_verifier_encrypted" text,
      "oauth_pkce_verifier_iv" text, "oauth_pkce_verifier_tag" text, "oauth_expires_at" timestamptz,
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_conexoes_assinatura_eletronica" PRIMARY KEY ("id")
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conexoes_assinatura_escritorio_provedor" ON "conexoes_assinatura_eletronica" ("escritorio_id", "provedor")`);

    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "envelopes_assinatura_eletronica" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "provedor" text NOT NULL,
      "envelope_id_externo" text NOT NULL, "status_provedor" text NOT NULL,
      "status_interno" text NOT NULL DEFAULT 'descoberto', "assunto" text,
      "remetente_nome" text, "remetente_email" text, "participantes" jsonb NOT NULL DEFAULT '[]'::jsonb,
      "criado_no_provedor_em" timestamptz, "concluido_em" timestamptz,
      "cliente_sugerido_id" uuid, "motivo_sugestao" text, "documento_id" uuid,
      "documento_s3_key" text, "documento_checksum" text, "documento_size_bytes" bigint,
      "documento_mime_type" text, "sincronizado_em" timestamptz,
      "certificado_s3_key" text, "metadados_provedor" jsonb, "ultimo_erro" text,
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_envelopes_assinatura_eletronica" PRIMARY KEY ("id")
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_envelopes_assinatura_externo" ON "envelopes_assinatura_eletronica" ("escritorio_id", "provedor", "envelope_id_externo")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_envelopes_assinatura_fila" ON "envelopes_assinatura_eletronica" ("escritorio_id", "status_interno", "concluido_em")`);

  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "envelopes_assinatura_eletronica"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "conexoes_assinatura_eletronica"`);
  }
}
