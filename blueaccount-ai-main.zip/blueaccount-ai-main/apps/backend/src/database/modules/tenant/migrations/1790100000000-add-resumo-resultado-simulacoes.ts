import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddResumoResultadoSimulacoes1790100000000 implements MigrationInterface {
  name = "AddResumoResultadoSimulacoes1790100000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacoes" ADD COLUMN "resumo_resultado" jsonb`,
    );
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacoes" DROP COLUMN "resumo_resultado"`,
    );
  }
}
