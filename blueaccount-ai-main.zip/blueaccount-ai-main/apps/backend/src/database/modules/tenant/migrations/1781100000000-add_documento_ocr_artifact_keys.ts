import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddDocumentoOcrArtifactKeys1781100000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "textract_raw_key" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "annotated_markdown_key" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "clean_markdown_key" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "blocks_parquet_key" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "ocr_manifest_key" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "ocr_manifest_key"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "blocks_parquet_key"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "clean_markdown_key"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "annotated_markdown_key"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "textract_raw_key"`);
  }
}
