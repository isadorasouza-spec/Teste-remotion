import type { MigrationInterface, QueryRunner } from "typeorm";

/** Evidência fiscal por item importado; não há backfill para entradas anteriores. */
export class AddCstCsosnToSimulacaoEntradas1786500000000 implements MigrationInterface {
  name = "AddCstCsosnToSimulacaoEntradas1786500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "cst" varchar(2),
        ADD COLUMN IF NOT EXISTS "csosn" varchar(3)
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD CONSTRAINT "chk_simulacao_entradas_cst_ou_csosn"
        CHECK ("cst" IS NULL OR "csosn" IS NULL) NOT VALID
    `).catch(async (erro: unknown) => {
      if (!(erro instanceof Error) || !erro.message.includes("already exists")) throw erro;
    });
    await queryRunner.query(`COMMENT ON COLUMN "simulacao_entradas"."cst" IS 'CST do ICMS extraído do item da NF-e/NFC-e; mutuamente exclusivo com CSOSN e sem backfill.'`);
    await queryRunner.query(`COMMENT ON COLUMN "simulacao_entradas"."csosn" IS 'CSOSN do ICMS extraído do item da NF-e/NFC-e; mutuamente exclusivo com CST e sem backfill.'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "chk_simulacao_entradas_cst_ou_csosn"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "csosn"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "cst"`);
  }
}
