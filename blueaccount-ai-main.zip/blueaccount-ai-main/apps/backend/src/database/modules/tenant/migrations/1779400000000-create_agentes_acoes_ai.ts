import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateAgentesAcoesAi1779400000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "agentes" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "nome" text NOT NULL,
        "descricao" text,
        "instrucoes" text,
        "ativo" boolean NOT NULL DEFAULT true,
        "configuracoes" jsonb,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
      );

      CREATE INDEX "idx_agentes_ativo" ON "agentes"("ativo");

      CREATE TABLE "acoes_ai" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "agente_id" uuid NOT NULL,
        "cliente_id" uuid,
        "titulo" text NOT NULL,
        "descricao" text NOT NULL,
        "tipo_acao" text NOT NULL,
        "prioridade" text NOT NULL DEFAULT 'media',
        "status" text NOT NULL DEFAULT 'pendente',
        "origem" text NOT NULL,
        "payload" jsonb,
        "executada_at" TIMESTAMP,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT "fk_acoes_ai_agente" FOREIGN KEY ("agente_id") REFERENCES "agentes"("id"),
        CONSTRAINT "fk_acoes_ai_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id")
      );

      CREATE INDEX "idx_acoes_ai_agente_id" ON "acoes_ai"("agente_id");
      CREATE INDEX "idx_acoes_ai_cliente_id" ON "acoes_ai"("cliente_id");
      CREATE INDEX "idx_acoes_ai_status" ON "acoes_ai"("status");
      CREATE INDEX "idx_acoes_ai_prioridade" ON "acoes_ai"("prioridade");
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS "acoes_ai";
      DROP TABLE IF EXISTS "agentes";
    `);
  }
}
