import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * UF do contribuinte simulado. Liga a derivação de ICMS/ISS pela localidade do fornecedor
 * (`domain/simulacoes/localidade/`): sem saber onde o comprador está, não há como escolher entre a
 * alíquota interna do estado e a matriz interestadual da Resolução SF 22/1989.
 *
 * **Sem backfill, deliberadamente.** `uf IS NULL` desliga o tier inteiro (ICMS e ISS), então toda
 * simulação já salva nasce com o comportamento de hoje e o deploy não muda um único resultado. É o
 * mesmo mecanismo que fez a introdução de `aliquota_*_nominal` em `fornecedores` ser um no-op.
 *
 * O gate cobre também o ISS, que dependeria só do código IBGE do fornecedor: sem isso, o backfill de
 * `fornecedores.codigo_municipio_ibge` (migration anterior) ligaria o ISS sozinho em cenários
 * antigos — exatamente o que se quer evitar. Um interruptor, um modelo mental: o cenário declara sua
 * localidade.
 */
export class AddUfToSimulacoes1785700000001 implements MigrationInterface {
  name = "AddUfToSimulacoes1785700000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes" ADD COLUMN IF NOT EXISTS "uf" varchar(2)
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacoes"."uf" IS
        'UF do contribuinte simulado (destino nas compras, origem nas receitas). NULL desliga a derivação de ICMS/ISS por localidade.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP COLUMN IF EXISTS "uf"`);
  }
}
