import type { MigrationInterface, QueryRunner } from "typeorm";
import {
  SQL_CRIAR_FUNCAO_UUID_V7,
  SQL_VERIFICAR_FUNCAO_UUID_V7,
  sqlTrocarDefaultsUuid,
} from "../../../uuid-v7.js";

/**
 * Passa as chaves primárias do schema do tenant a gerar UUIDv7 (ordenado por tempo) em vez de v4.
 *
 * Espelha a migration pública `1786500000000-uuid_v7_defaults`, mas roda no `current_schema()` do
 * tenant. Aplicada em todos os escritórios existentes por `migration:sync-tenants` e, em
 * escritórios novos, pelo provisionamento (`provisionEscritorioSchema`), que reexecuta a fila
 * inteira de migrations — por isso o timestamp precisa ser o mais alto da fila, senão tabelas
 * criadas por migrations posteriores nasceriam em v4 no schema novo.
 *
 * O `CREATE OR REPLACE` da função é repetido de propósito: torna a migration autossuficiente caso
 * ela rode antes da pública. A função vive em `public`, compartilhada por todos os schemas.
 *
 * Detalhes de projeto: ver `src/database/uuid-v7.ts`.
 */
export class UuidV7Defaults1786600000000 implements MigrationInterface {
  name = "UuidV7Defaults1786600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(SQL_CRIAR_FUNCAO_UUID_V7);
    await queryRunner.query(SQL_VERIFICAR_FUNCAO_UUID_V7);
    await queryRunner.query(sqlTrocarDefaultsUuid("uuid_generate_v7"));
  }

  /** Reverte os DEFAULTs do schema do tenant. A função em `public` é preservada — ver a migration pública. */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(sqlTrocarDefaultsUuid("gen_random_uuid"));
  }
}
