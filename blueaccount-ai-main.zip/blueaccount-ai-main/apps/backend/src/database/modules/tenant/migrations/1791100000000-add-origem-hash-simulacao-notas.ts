import type { MigrationInterface, QueryRunner } from "typeorm";

/** Proveniência e integridade dos XMLs importados, sem backfill do hash legado. */
export class AddOrigemHashSimulacaoNotas1791100000000 implements MigrationInterface {
  name = "AddOrigemHashSimulacaoNotas1791100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
        ADD COLUMN IF NOT EXISTS "origem" varchar(20) NOT NULL DEFAULT 'upload',
        ADD COLUMN IF NOT EXISTS "conteudo_hash" char(64),
        ADD CONSTRAINT "CK_simulacao_notas_fiscais_origem"
          CHECK ("origem" IN ('upload', 'sieg'))
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
        DROP CONSTRAINT IF EXISTS "CK_simulacao_notas_fiscais_origem",
        DROP COLUMN IF EXISTS "conteudo_hash",
        DROP COLUMN IF EXISTS "origem"
    `);
  }
}
