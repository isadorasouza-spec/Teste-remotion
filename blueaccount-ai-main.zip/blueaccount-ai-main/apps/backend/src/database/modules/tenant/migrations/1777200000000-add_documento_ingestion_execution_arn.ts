import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddDocumentoIngestionExecutionArn1777200000000 implements MigrationInterface {
  name = "AddDocumentoIngestionExecutionArn1777200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "ingestion_execution_arn" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "ingestion_execution_arn"`);
  }
}
