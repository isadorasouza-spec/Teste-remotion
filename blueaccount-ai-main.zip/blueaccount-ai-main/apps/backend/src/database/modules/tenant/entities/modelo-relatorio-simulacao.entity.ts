import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Entity("modelos_relatorio_simulacao")
@Index("IDX_modelos_relatorio_simulacao_escritorio", ["escritorio_id"])
export class ModeloRelatorioSimulacao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "varchar", length: 160 })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text" })
  conteudo_html!: string;

  @Column({ type: "varchar", length: 50, default: "relatorio_simulacao_v1" })
  versao_contrato!: "relatorio_simulacao_v1";

  @Column({ type: "varchar", length: 64 })
  checksum_sha256!: string;

  @Column({ type: "integer" })
  tamanho_bytes!: number;

  @CreateDateColumn({ type: "timestamptz" })
  created_at!: Date;

  @UpdateDateColumn({ type: "timestamptz" })
  updated_at!: Date;
}
