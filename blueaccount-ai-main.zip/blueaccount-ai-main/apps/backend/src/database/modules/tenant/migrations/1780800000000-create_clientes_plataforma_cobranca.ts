import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateClientesPlataformaCobranca1780800000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS clientes_plataforma_cobranca (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        cliente_id UUID NOT NULL REFERENCES clientes(id),
        plataforma_id UUID NOT NULL REFERENCES plataformas_cobranca(id),
        id_externo_cliente TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT UQ_cliente_plataforma UNIQUE (cliente_id, plataforma_id)
      );
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_clientes_plataforma_id_externo
        ON clientes_plataforma_cobranca (plataforma_id, id_externo_cliente);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_clientes_plataforma_id_externo;`);
    await queryRunner.query(`DROP TABLE IF EXISTS clientes_plataforma_cobranca;`);
  }
}
