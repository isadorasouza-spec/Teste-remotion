import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Converte todos os CNPJs persistidos para o formato canônico.
 *
 * Como ainda não há clientes em produção, registros sem 14 dígitos e duplicatas
 * após a normalização são removidos. Entre duplicatas, preserva a linha mais
 * antiga (e o menor UUID como desempate) antes de aplicar a máscara.
 */
export class StandardizeClientesCnpj1782800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DELETE FROM "clientes"
      WHERE length(regexp_replace("cnpj", '\\D', '', 'g')) <> 14
    `);

    await queryRunner.query(`
      WITH duplicados AS (
        SELECT "id", row_number() OVER (
          PARTITION BY regexp_replace("cnpj", '\\D', '', 'g')
          ORDER BY "created_at" ASC, "id" ASC
        ) AS ordem
        FROM "clientes"
      )
      DELETE FROM "clientes" AS cliente
      USING duplicados
      WHERE cliente."id" = duplicados."id" AND duplicados.ordem > 1
    `);

    await queryRunner.query(`
      UPDATE "clientes"
      SET "cnpj" =
        substr(regexp_replace("cnpj", '\\D', '', 'g'), 1, 2) || '.' ||
        substr(regexp_replace("cnpj", '\\D', '', 'g'), 3, 3) || '.' ||
        substr(regexp_replace("cnpj", '\\D', '', 'g'), 6, 3) || '/' ||
        substr(regexp_replace("cnpj", '\\D', '', 'g'), 9, 4) || '-' ||
        substr(regexp_replace("cnpj", '\\D', '', 'g'), 13, 2)
    `);
  }

  public async down(): Promise<void> {
    // Irreversível: a migration remove registros inválidos e duplicados por decisão de produto.
  }
}
