import { MigrationInterface, QueryRunner } from "typeorm";

export class AddFatoresPadraoAcumuladoresSimulacao1787700000000 implements MigrationInterface {
  name = "AddFatoresPadraoAcumuladoresSimulacao1787700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "acumuladores_simulacao"
        ADD COLUMN "fator_ibs_padrao" numeric(7,6),
        ADD COLUMN "fator_cbs_padrao" numeric(7,6)
    `);
    await queryRunner.query(`
      ALTER TABLE "acumuladores_simulacao"
        ADD CONSTRAINT "CK_acumuladores_simulacao_fator_ibs_padrao"
          CHECK ("fator_ibs_padrao" IS NULL OR "fator_ibs_padrao" BETWEEN 0 AND 1),
        ADD CONSTRAINT "CK_acumuladores_simulacao_fator_cbs_padrao"
          CHECK ("fator_cbs_padrao" IS NULL OR "fator_cbs_padrao" BETWEEN 0 AND 1)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "acumuladores_simulacao"
        DROP CONSTRAINT "CK_acumuladores_simulacao_fator_cbs_padrao",
        DROP CONSTRAINT "CK_acumuladores_simulacao_fator_ibs_padrao",
        DROP COLUMN "fator_cbs_padrao",
        DROP COLUMN "fator_ibs_padrao"
    `);
  }
}
