import { ImportacaoOperacionalMensal } from "./entities/importacao-operacional-mensal.entity.js";
import { RegistroOperacional } from "./entities/registro-operacional.entity.js";
import { DocumentoFiscalTotal } from "./entities/documento-fiscal-total.entity.js";
import { DocumentoFiscalItem } from "./entities/documento-fiscal-item.entity.js";
import { ConsultaNotasFiscal } from "./entities/consulta-notas-fiscal.entity.js";
import { ResultadoConsultaNotasFiscal } from "./entities/resultado-consulta-notas-fiscal.entity.js";
import { ExecucaoWorkerFiscal } from "./entities/execucao-worker-fiscal.entity.js";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import type { DataSource } from "typeorm";
import { createTenantDataSource } from "../../tenant-datasource-factory.js";
import { Cliente } from "./entities/cliente.entity.js";
import { Fornecedor } from "./entities/fornecedor.entity.js";
import { Documento } from "./entities/documento.entity.js";
import { Contrato } from "./entities/contrato.entity.js";
import { ContratoDocumentoAnexo } from "./entities/contrato-documento-anexo.entity.js";
import { ClausulasExcedentes } from "./entities/clausulas-excedentes.entity.js";
import { ServicosContratados } from "./entities/servicos-contratados.entity.js";
import { Relatorio } from "./entities/relatorio.entity.js";
import { RelatorioEstatisticaCliente } from "./entities/relatorio-estatistica-cliente.entity.js";
import { Faturamento } from "./entities/faturamento.entity.js";
import { ValoresACobrar } from "./entities/valores-a-cobrar.entity.js";
import { ValoresACobrarVersao } from "./entities/valores-a-cobrar-versoes.entity.js";
import { CobrancaTest } from "./entities/cobranca-test.entity.js";
import { Extracao } from "./entities/extracao.entity.js";
import { Agente } from "./entities/agente.entity.js";
import { AcaoAi } from "./entities/acao-ai.entity.js";
import { HistoricoAcaoAi } from "./entities/historico-acao-ai.entity.js";
import { PlataformaCobranca } from "./entities/plataforma-cobranca.entity.js";
import { Cobranca } from "./entities/cobranca.entity.js";
import { ClientePlataformaCobranca } from "./entities/cliente-plataforma-cobranca.entity.js";
import { ConectorDriveExecucao } from "./entities/conector-drive-execucao.entity.js";
import { ConectorDriveArquivo } from "./entities/conector-drive-arquivo.entity.js";
import { ConectorSharePointConexao } from "./entities/conector-sharepoint-conexao.entity.js";
import { ConectorSharePointExecucao } from "./entities/conector-sharepoint-execucao.entity.js";
import { ConectorSharePointArquivo } from "./entities/conector-sharepoint-arquivo.entity.js";
import { ConexaoAssinaturaEletronica } from "./entities/conexao-assinatura-eletronica.entity.js";
import { EnvelopeAssinaturaEletronica } from "./entities/envelope-assinatura-eletronica.entity.js";
import { OportunidadeRecuperacao } from "./entities/oportunidade-recuperacao.entity.js";
import { Simulacao } from "./entities/simulacao.entity.js";
import { SimulacaoEntrada } from "./entities/simulacao-entrada.entity.js";
import { SimulacaoGrupo } from "./entities/simulacao-grupo.entity.js";
import { SimulacaoGrupoItem } from "./entities/simulacao-grupo-item.entity.js";
import { SimulacaoNotaFiscal } from "./entities/simulacao-nota-fiscal.entity.js";
import { AcumuladorSimulacao } from "./entities/acumulador-simulacao.entity.js";
import { AcumuladorSimulacaoCliente } from "./entities/acumulador-simulacao-cliente.entity.js";
import { SimulacaoEntradaExcluida } from "./entities/simulacao-entrada-excluida.entity.js";
import { SimulacaoResultadoCache } from "./entities/simulacao-resultado-cache.entity.js";
import { SimulacaoCalculoEntrada } from "./entities/simulacao-calculo-entrada.entity.js";
import { SimulacaoCalculo } from "./entities/simulacao-calculo.entity.js";
import { ModeloRelatorioSimulacao } from "./entities/modelo-relatorio-simulacao.entity.js";
import { LoteIngestaoDocumentoFiscal } from "./entities/lote-ingestao-documento-fiscal.entity.js";
import { ArquivoIngestaoDocumentoFiscal } from "./entities/arquivo-ingestao-documento-fiscal.entity.js";
import { CertificadoDigitalCliente } from "./entities/certificado-digital-cliente.entity.js";
import { CursorDistribuicaoDfe } from "./entities/cursor-distribuicao-dfe.entity.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export function createTenantModuleDataSource(schemaName: string): DataSource {
  return createTenantDataSource({
    schemaName,
    entities: [
      Cliente,
      Fornecedor,
      Documento,
      Contrato,
      ContratoDocumentoAnexo,
      ClausulasExcedentes,
      ServicosContratados,
      Relatorio,
      RelatorioEstatisticaCliente,
      Faturamento,
      ValoresACobrar,
      ValoresACobrarVersao,
      CobrancaTest,
      Extracao,
      Agente,
      AcaoAi,
      HistoricoAcaoAi,
      PlataformaCobranca,
      Cobranca,
      ClientePlataformaCobranca,
      ConectorDriveExecucao,
      ConectorDriveArquivo,
      ConectorSharePointConexao,
      ConectorSharePointExecucao,
      ConectorSharePointArquivo,
      ConexaoAssinaturaEletronica,
      EnvelopeAssinaturaEletronica,
      OportunidadeRecuperacao,
      Simulacao,
      SimulacaoEntrada,
      SimulacaoGrupo,
      SimulacaoGrupoItem,
      SimulacaoNotaFiscal,
      AcumuladorSimulacao,
      AcumuladorSimulacaoCliente,
      SimulacaoEntradaExcluida,
      SimulacaoResultadoCache,
      SimulacaoCalculo,
      SimulacaoCalculoEntrada,
      ModeloRelatorioSimulacao,
      LoteIngestaoDocumentoFiscal,
      ArquivoIngestaoDocumentoFiscal,
      CertificadoDigitalCliente,
      CursorDistribuicaoDfe,
      RegistroOperacional,
      ImportacaoOperacionalMensal,
      DocumentoFiscalTotal,
      DocumentoFiscalItem,
      ConsultaNotasFiscal,
      ResultadoConsultaNotasFiscal,
      ExecucaoWorkerFiscal,

    ],
    migrationsDir: join(__dirname, "migrations", "*.{ts,js}"),
  });
}
