import { Column, Entity, PrimaryColumn } from 'typeorm';
import type { EntradaCalculada } from '../../../../domain/simulacoes/calculo-tipos.js';
@Entity('simulacao_calculo_entradas')
export class SimulacaoCalculoEntrada {
    @PrimaryColumn({ type: 'uuid' })
    simulacao_id!: string;
    @PrimaryColumn({ type: 'uuid' })
    entrada_id!: string;
    @Column({ type: 'uuid' })
    escritorio_id!: string;
    @Column({ type: 'jsonb' })
    calculada!: EntradaCalculada;
}
