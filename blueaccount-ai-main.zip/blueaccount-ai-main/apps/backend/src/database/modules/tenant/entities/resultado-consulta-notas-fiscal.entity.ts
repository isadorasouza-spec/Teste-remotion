import { ConsultaNotasFiscal } from "./consulta-notas-fiscal.entity.js";
import { Entity, Column, PrimaryColumn, ForeignKey, Index } from "typeorm";

@Entity("consultas_notas_fiscais_resultados")
@ForeignKey(() => ConsultaNotasFiscal, ["escritorio_id", "consulta_id"], ["escritorio_id", "id"], { name: "fk_resultado_consulta", onDelete: "CASCADE" })
export class ResultadoConsultaNotasFiscal {
  @PrimaryColumn({ type: "uuid" }) escritorio_id!: string;
  @PrimaryColumn({ type: "uuid" }) consulta_id!: string;
  @PrimaryColumn({ type: "integer" }) ordinal!: number;
  @Column({ type: "jsonb" }) dados!: Record<string, unknown>;
  @Column({ type: "text", nullable: true }) normalizado_uri!: string | null;
}
