import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddIcmsIssToSimulacoes1780200000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "aliquota_icms_padrao" DECIMAL(6,4) NOT NULL DEFAULT 0,
        ADD COLUMN "aliquota_iss_padrao"  DECIMAL(6,4) NOT NULL DEFAULT 0;

      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "regra_credito_icms"      VARCHAR(20) NOT NULL DEFAULT 'integral',
        ADD COLUMN "credito_icms_manual"     DECIMAL(14,2),
        ADD COLUMN "percentual_credito_icms" DECIMAL(5,4);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP COLUMN "aliquota_icms_padrao",
        DROP COLUMN "aliquota_iss_padrao";

      ALTER TABLE "simulacao_entradas"
        DROP COLUMN "regra_credito_icms",
        DROP COLUMN "credito_icms_manual",
        DROP COLUMN "percentual_credito_icms";
    `);
  }
}
