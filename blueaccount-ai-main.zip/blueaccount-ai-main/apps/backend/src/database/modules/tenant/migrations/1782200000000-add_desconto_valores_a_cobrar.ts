import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddDescontoValoresACobrar1782200000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS desconto JSONB
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS desconto
    `);
  }
}
