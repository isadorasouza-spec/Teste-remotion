import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddFornecedorToSimulacaoNotas1785330000000 implements MigrationInterface {
  name = "AddFornecedorToSimulacaoNotas1785330000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacao_notas_fiscais" ADD COLUMN IF NOT EXISTS "fornecedor_id" uuid`,
    );

    // Primeiro preserva a referência já normalizada na entrada gerada pela nota.
    await queryRunner.query(`
      UPDATE "simulacao_notas_fiscais" nota
      SET "fornecedor_id" = entrada."fornecedor_id"
      FROM "simulacao_entradas" entrada
      WHERE nota."fornecedor_id" IS NULL
        AND nota."entrada_id" = entrada."id"
        AND nota."escritorio_id" = entrada."escritorio_id"
        AND entrada."fornecedor_id" IS NOT NULL
    `);

    // Notas sem entrada (indeterminadas/homologação) são ligadas pelo documento apenas nesta
    // migração. Em runtime, novos registros recebem o UUID diretamente durante a importação.
    await queryRunner.query(`
      UPDATE "simulacao_notas_fiscais" nota
      SET "fornecedor_id" = fornecedor."id"
      FROM "fornecedores" fornecedor
      WHERE nota."fornecedor_id" IS NULL
        AND nota."classificacao" IN ('custo_direto', 'indeterminado')
        AND nota."escritorio_id" = fornecedor."escritorio_id"
        AND length(regexp_replace(COALESCE(nota."emitente_documento", ''), '\\D', '', 'g')) IN (11, 14)
        AND regexp_replace(nota."emitente_documento", '\\D', '', 'g')
          = regexp_replace(fornecedor."cnpj", '\\D', '', 'g')
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1
          FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'FK_simulacao_notas_fiscais_fornecedor'
            AND t.relname = 'simulacao_notas_fiscais'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "simulacao_notas_fiscais"
            ADD CONSTRAINT "FK_simulacao_notas_fiscais_fornecedor"
            FOREIGN KEY ("fornecedor_id") REFERENCES "fornecedores"("id") ON DELETE SET NULL;
        END IF;
      END
      $$;
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "IDX_simulacao_notas_fiscais_fornecedor_id"
      ON "simulacao_notas_fiscais" ("fornecedor_id")
      WHERE "fornecedor_id" IS NOT NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX IF EXISTS "IDX_simulacao_notas_fiscais_fornecedor_id"`,
    );
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
      DROP CONSTRAINT IF EXISTS "FK_simulacao_notas_fiscais_fornecedor"
    `);
    await queryRunner.query(
      `ALTER TABLE "simulacao_notas_fiscais" DROP COLUMN IF EXISTS "fornecedor_id"`,
    );
  }
}
