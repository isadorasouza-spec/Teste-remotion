import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `risco_credito` em `fornecedores`: risco de inadimplência do fornecedor sobre o débito de IBS/CBS
 * que a sua venda gera. LC 214/2025, art. 47, §1º condiciona a apropriação do crédito de IBS/CBS
 * pelo adquirente à EXTINÇÃO desse débito pelo fornecedor — ver `domain/simulacoes/risco-credito.ts`.
 *
 * `NULL` = risco não declarado (sem corte, fator 1) — não confundir com `'baixo'` (fator 0,75).
 * Nullable, sem default e sem backfill: nenhum fornecedor existente muda de crédito com este
 * deploy. `CHECK` trava os três literais do domínio (`RiscoCredito`), mesmo padrão de
 * `1789800000002-add-destino-ipi-sem-incidencia-simulacoes`.
 */
export class AddRiscoCreditoFornecedores1790700000000 implements MigrationInterface {
  name = "AddRiscoCreditoFornecedores1790700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "fornecedores"
        ADD COLUMN IF NOT EXISTS "risco_credito" varchar(10) NULL,
        ADD CONSTRAINT "CK_fornecedores_risco_credito"
          CHECK ("risco_credito" IS NULL OR "risco_credito" IN ('alto', 'medio', 'baixo'))
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."risco_credito" IS
        'Risco de inadimplência do fornecedor sobre o próprio débito de IBS/CBS (LC 214/2025, art. 47, §1º). NULL = sem risco declarado, sem corte de crédito.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "fornecedores"
        DROP CONSTRAINT IF EXISTS "CK_fornecedores_risco_credito",
        DROP COLUMN IF EXISTS "risco_credito"
    `);
  }
}
