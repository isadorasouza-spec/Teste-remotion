import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Custódia do certificado A1 do cliente e cursor NSU do `NFeDistribuicaoDFe`.
 *
 * Ambas ganham RLS explícita (`FORCE ROW LEVEL SECURITY` + política por `app.escritorio_id`), no
 * padrão de `1791700000000-publicacao-fiscal-postgres`: `certificados_digitais_clientes` guarda
 * material de credencial de terceiro e não deve depender só do isolamento por schema/role.
 */
export class CreateCertificadosDigitaisECursorDfe1791900000000 implements MigrationInterface {
  name = "CreateCertificadosDigitaisECursorDfe1791900000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "certificados_digitais_clientes" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "cnpj_titular" varchar(14) NOT NULL,
      "titular_nome" text NOT NULL,
      "emissor" text NOT NULL,
      "serie" text NOT NULL,
      "valido_de" timestamptz NOT NULL,
      "valido_ate" timestamptz NOT NULL,
      "bucket_pfx" text NOT NULL,
      "chave_pfx" text NOT NULL,
      "sha256_pfx" char(64) NOT NULL,
      "senha_encrypted" text NOT NULL,
      "senha_iv" text NOT NULL,
      "senha_tag" text NOT NULL,
      "consentimento_registrado_por" uuid NOT NULL,
      "consentimento_registrado_em" timestamptz NOT NULL DEFAULT now(),
      "ativo" boolean NOT NULL DEFAULT true,
      "revogado_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_certificados_digitais_clientes" PRIMARY KEY ("id"),
      CONSTRAINT "FK_certificados_digitais_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE CASCADE,
      CONSTRAINT "CHK_certificados_digitais_cnpj" CHECK ("cnpj_titular" ~ '^[0-9]{14}$'),
      CONSTRAINT "CHK_certificados_digitais_sha256" CHECK ("sha256_pfx" ~ '^[0-9a-f]{64}$'),
      CONSTRAINT "CHK_certificados_digitais_validade" CHECK ("valido_ate" > "valido_de"),
      CONSTRAINT "CHK_certificados_digitais_revogacao" CHECK ("ativo" = false OR "revogado_em" IS NULL)
    )`);
    await q.query(`CREATE INDEX "IDX_certificados_digitais_cliente" ON "certificados_digitais_clientes" ("cliente_id", "criado_em")`);
    await q.query(`CREATE UNIQUE INDEX "UQ_certificados_digitais_ativo" ON "certificados_digitais_clientes" ("escritorio_id", "cliente_id") WHERE "ativo"`);
    await q.query(`ALTER TABLE "certificados_digitais_clientes" ENABLE ROW LEVEL SECURITY`);
    await q.query(`ALTER TABLE "certificados_digitais_clientes" FORCE ROW LEVEL SECURITY`);
    await q.query(`CREATE POLICY isolamento_escritorio ON "certificados_digitais_clientes" USING (escritorio_id::text = current_setting('app.escritorio_id', true)) WITH CHECK (escritorio_id::text = current_setting('app.escritorio_id', true))`);

    await q.query(`CREATE TABLE "cursores_distribuicao_dfe" (
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "ambiente" varchar(12) NOT NULL,
      "ultimo_nsu" bigint NOT NULL DEFAULT 0,
      "max_nsu" bigint NOT NULL DEFAULT 0,
      "primeiro_nsu_visto" bigint,
      "ultima_consulta_em" timestamptz,
      "bloqueado_ate" timestamptz,
      "ultimo_cstat" varchar(4),
      "consultas_na_janela" smallint NOT NULL DEFAULT 0,
      "janela_iniciada_em" timestamptz,
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_cursores_distribuicao_dfe" PRIMARY KEY ("escritorio_id", "cliente_id", "ambiente"),
      CONSTRAINT "FK_cursores_dfe_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE CASCADE,
      CONSTRAINT "CHK_cursores_dfe_ambiente" CHECK ("ambiente" IN ('producao','homologacao')),
      CONSTRAINT "CHK_cursores_dfe_nsu" CHECK ("ultimo_nsu" >= 0 AND "max_nsu" >= 0),
      CONSTRAINT "CHK_cursores_dfe_janela" CHECK ("consultas_na_janela" >= 0)
    )`);
    await q.query(`ALTER TABLE "cursores_distribuicao_dfe" ENABLE ROW LEVEL SECURITY`);
    await q.query(`ALTER TABLE "cursores_distribuicao_dfe" FORCE ROW LEVEL SECURITY`);
    await q.query(`CREATE POLICY isolamento_escritorio ON "cursores_distribuicao_dfe" USING (escritorio_id::text = current_setting('app.escritorio_id', true)) WITH CHECK (escritorio_id::text = current_setting('app.escritorio_id', true))`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE "cursores_distribuicao_dfe"`);
    await q.query(`DROP TABLE "certificados_digitais_clientes"`);
  }
}
