import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Versionamento e invalidação (stale) de cobranças após edição de insumos
 * (ação Kontiva 45ffd83e — auditoria Revestia 06/2026).
 *
 * Problema: a reconsolidação sobrescreve `valores_observados` mas não recalcula
 * `valores_calculados`; o total antigo permanecia e era emitido. Não havia
 * histórico do que foi calculado nem detecção de que os insumos mudaram.
 *
 * Esta migration adiciona:
 * - colunas de controle no `valores_a_cobrar`:
 *   - `input_hash`: hash canônico dos insumos do último cálculo ativo.
 *   - `versao_ativa_id`: ponte para a versão ativa válida (active_billing_version).
 *   - `stale` (+ motivo/em/por): insumos mudaram após o cálculo ativo.
 * - tabela imutável `valores_a_cobrar_versoes`: um snapshot por execução de
 *   cálculo bem-sucedida (billing_run), nunca sobrescrito.
 */
export class AddBillingVersioningValoresACobrar1781900000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS input_hash TEXT NULL,
        ADD COLUMN IF NOT EXISTS versao_ativa_id UUID NULL,
        ADD COLUMN IF NOT EXISTS stale BOOLEAN NOT NULL DEFAULT false,
        ADD COLUMN IF NOT EXISTS stale_motivo TEXT NULL,
        ADD COLUMN IF NOT EXISTS stale_em TIMESTAMP NULL,
        ADD COLUMN IF NOT EXISTS stale_por TEXT NULL
    `);

    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS valores_a_cobrar_versoes (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        valor_a_cobrar_id UUID NOT NULL REFERENCES valores_a_cobrar(id) ON DELETE CASCADE,
        versao INTEGER NOT NULL,
        input_hash TEXT NULL,
        valores_contratados JSONB NOT NULL DEFAULT '{}'::jsonb,
        valores_observados JSONB NOT NULL DEFAULT '{}'::jsonb,
        valores_calculados JSONB NOT NULL DEFAULT '{}'::jsonb,
        linhagem JSONB NULL,
        outros_servicos_prestados JSONB NOT NULL DEFAULT '[]'::jsonb,
        total DECIMAL(12,2) NULL,
        total_excedentes DECIMAL(12,2) NULL,
        status_no_momento VARCHAR(30) NULL,
        ator TEXT NULL,
        motivo TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_vac_versoes_vac_versao
        ON valores_a_cobrar_versoes (valor_a_cobrar_id, versao);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_vac_versoes_vac
        ON valores_a_cobrar_versoes (valor_a_cobrar_id);
    `);

    // Ponte da versão ativa: FK adicionada após a tabela de versões existir.
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD CONSTRAINT FK_vac_versao_ativa
        FOREIGN KEY (versao_ativa_id) REFERENCES valores_a_cobrar_versoes(id)
        ON DELETE SET NULL;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar DROP CONSTRAINT IF EXISTS FK_vac_versao_ativa;
    `);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_vac_versoes_vac;`);
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_vac_versoes_vac_versao;`);
    await queryRunner.query(`DROP TABLE IF EXISTS valores_a_cobrar_versoes;`);
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS input_hash,
        DROP COLUMN IF EXISTS versao_ativa_id,
        DROP COLUMN IF EXISTS stale,
        DROP COLUMN IF EXISTS stale_motivo,
        DROP COLUMN IF EXISTS stale_em,
        DROP COLUMN IF EXISTS stale_por
    `);
  }
}
