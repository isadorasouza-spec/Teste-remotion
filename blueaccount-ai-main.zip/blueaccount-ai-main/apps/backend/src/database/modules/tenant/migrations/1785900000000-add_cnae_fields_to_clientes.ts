import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Campos de CNAE do cliente, espelhando os equivalentes já existentes em `fornecedores`
 * (`1784900000000-create_fornecedores`): `cnae_principal`, `cnae_principal_descricao` e
 * `cnaes_secundarios` são preenchidos pela consulta pública de CNPJ na criação do cliente (ver
 * `createCliente` em `domain/clientes/cliente.service.ts`), editáveis depois.
 *
 * `cnaes_fornecedores_permitidos` é um conceito novo, sem equivalente em `Fornecedor`: allowlist
 * manual de CNAE de FORNECEDOR que o contador considera elegível a gerar crédito de IBS/CBS para
 * este cliente (LC 214/2025 restringe crédito a insumos ligados à atividade econômica do
 * contribuinte). Nunca vem da consulta de CNPJ — é dado puramente manual, nunca derivado de
 * CNPJ/lookup.
 *
 * **Sem backfill, deliberadamente**, para os três primeiros campos: nascem `NULL` para todo
 * cliente já cadastrado — só a próxima edição manual (ou recriação) do cadastro os preenche. Mesmo
 * mecanismo de `1785700000002-add_uf_to_clientes` e `1785700000003-add_ibs_cbs_fields_to_clientes`.
 */
export class AddCnaeFieldsToClientes1785900000000 implements MigrationInterface {
  name = "AddCnaeFieldsToClientes1785900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "cnae_principal" varchar(7)
    `);
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "cnae_principal_descricao" text
    `);
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "cnaes_secundarios" jsonb
    `);
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "cnaes_fornecedores_permitidos" jsonb
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."cnae_principal" IS
        'CNAE principal (7 dígitos, sem pontuação) do cliente, espelhando fornecedores.cnae_principal. Preenchido pela consulta pública de CNPJ na criação, editável depois. Sem backfill: NULL para todo cliente já cadastrado até a próxima edição manual.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."cnae_principal_descricao" IS
        'Descrição textual do CNAE principal, como devolvida pela consulta de CNPJ. Sem backfill.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."cnaes_secundarios" IS
        'Lista de CNAEs secundários ({codigo, descricao}[]) como devolvida pela consulta de CNPJ. Sem backfill.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."cnaes_fornecedores_permitidos" IS
        'Allowlist manual ({codigo, descricao}[]) de CNAE de FORNECEDOR considerado elegível a gerar crédito de IBS/CBS para este cliente (LC 214/2025). Puramente dado de digitação do contador — NUNCA vem da consulta de CNPJ (que resolve o CNAE do próprio cliente, não de terceiros). NULL/lista vazia = nenhuma restrição cadastrada.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "cnaes_fornecedores_permitidos"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "cnaes_secundarios"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "cnae_principal_descricao"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "cnae_principal"`);
  }
}
