import { MigrationInterface, QueryRunner } from "typeorm";

export class AddClienteContractGeneralInfo1778100000000 implements MigrationInterface {
  name = "AddClienteContractGeneralInfo1778100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" ADD "endereco" text`);
    await queryRunner.query(`ALTER TABLE "clientes" ADD "representante_legal" text`);
    await queryRunner.query(`ALTER TABLE "clientes" ADD "informacoes_gerais" jsonb`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN "informacoes_gerais"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN "representante_legal"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN "endereco"`);
  }
}
