import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddResultadoDadosSimulacaoDocumentos1788300000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "resultado_dados_simulacao" jsonb;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "documentos" DROP COLUMN IF EXISTS "resultado_dados_simulacao";
    `);
  }
}
