import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Reaplica a herança global depois de tornar toda regra configurada automática. Mantém intactos os
 * fatores manuais, de acumulador e de tratamento e preserva exceções pelo longest-prefix match.
 */
export class AplicarHerancaFatoresNcm1789200000000 implements MigrationInterface {
  name = "AplicarHerancaFatoresNcm1789200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    for (const tributo of ["ibs", "cbs"] as const) {
      await queryRunner.query(`
        UPDATE "simulacao_entradas" AS entrada
        SET "fator_${tributo}" = COALESCE((
          SELECT regra."fator_${tributo}"
          FROM public."ncms_referencia" AS regra
          WHERE regra."fatores_configurados" = true
            AND entrada."ncm" LIKE regra."codigo" || '%'
          ORDER BY length(regra."codigo") DESC, regra."codigo" ASC
          LIMIT 1
        ), 1)
        WHERE entrada."origem_fator_${tributo}" = 'ncm'
          AND entrada."ncm" IS NOT NULL
      `);
    }
  }

  public async down(): Promise<void> {
    // Reconciliação derivada do catálogo: não existe snapshot anterior seguro para restaurar.
  }
}
