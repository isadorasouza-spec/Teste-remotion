import type { MigrationInterface, QueryRunner } from "typeorm";

export class MakeDocumentoClienteNullable1777100000000 implements MigrationInterface {
  name = "MakeDocumentoClienteNullable1777100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" ALTER COLUMN "cliente_id" DROP NOT NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "documentos" WHERE "cliente_id" IS NULL`);
    await queryRunner.query(`ALTER TABLE "documentos" ALTER COLUMN "cliente_id" SET NOT NULL`);
  }
}
