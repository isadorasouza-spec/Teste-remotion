import { type MigrationInterface, type QueryRunner } from "typeorm";

export class AddDocumentoContratosFields1777300000000 implements MigrationInterface {
  name = "AddDocumentoContratosFields1777300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "contratos_execution_arn" text`,
    );
    await queryRunner.query(
      `ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "status_contrato" text`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documentos" DROP COLUMN IF EXISTS "status_contrato"`,
    );
    await queryRunner.query(
      `ALTER TABLE "documentos" DROP COLUMN IF EXISTS "contratos_execution_arn"`,
    );
  }
}
