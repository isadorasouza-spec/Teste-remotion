import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddHistoricoAcaoAi1779900000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS historico_acao_ai (
        id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        acao_id    UUID NOT NULL REFERENCES acoes_ai(id) ON DELETE CASCADE,
        status     TEXT NOT NULL,
        resultado  TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS historico_acao_ai`);
  }
}
