import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDefaultsNovasEntradasSimulacao1787500000000 implements MigrationInterface {
  name = "AddDefaultsNovasEntradasSimulacao1787500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "fornecedor_padrao_id" uuid,
        ADD COLUMN "tipo_valor_entrada_padrao" varchar(20) NOT NULL DEFAULT 'valor_total'
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD CONSTRAINT "CHK_simulacoes_tipo_valor_entrada_padrao"
        CHECK ("tipo_valor_entrada_padrao" IN ('valor_total', 'valor_operacao'))
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD CONSTRAINT "FK_simulacoes_fornecedor_padrao"
        FOREIGN KEY ("fornecedor_padrao_id") REFERENCES "fornecedores"("id") ON DELETE SET NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP CONSTRAINT "FK_simulacoes_fornecedor_padrao"`);
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP CONSTRAINT "CHK_simulacoes_tipo_valor_entrada_padrao"`);
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP COLUMN "tipo_valor_entrada_padrao",
        DROP COLUMN "fornecedor_padrao_id"
    `);
  }
}
