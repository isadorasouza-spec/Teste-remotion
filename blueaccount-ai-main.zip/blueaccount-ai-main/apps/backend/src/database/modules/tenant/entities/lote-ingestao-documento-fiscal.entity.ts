import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  JoinColumn,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { Simulacao } from "./simulacao.entity.js";
import { ArquivoIngestaoDocumentoFiscal } from "./arquivo-ingestao-documento-fiscal.entity.js";

// "portal_sefaz" cabe sem migration: a coluna é varchar(20) sem CHECK (migration
// 1791400000000 só adiciona a coluna). Se um CHECK de domínio for adicionado depois,
// atualizá-lo é pré-requisito de deploy junto com este valor.
export type OrigemIngestaoFiscal = "upload_manual" | "sieg" | "portal_sefaz" | "planilha_fiscal" | "distribuicao_dfe";

export type StatusLoteIngestaoDocumentoFiscal =
  | "armazenando"
  | "em_fila"
  | "processando"
  | "parcial"
  | "concluido"
  | "erro";

export type RascunhoPlanilhaFiscal = { versao: number; movimentos: { id: string; movimento: "entrada" | "saida" | null }[]; bloqueado?: boolean; resultado?: { lote_id: string; enriquecimento_pendente: boolean } };

@Entity("lotes_ingestao_documentos_fiscais")
@Index("IDX_lotes_ingestao_fiscal_simulacao", ["simulacao_id", "criado_em"])
@Index("IDX_lotes_ingestao_fiscal_cliente", ["cliente_id", "criado_em"])
export class LoteIngestaoDocumentoFiscal {
  @Column({ type: "text", nullable: true }) execucao_worker_id!: string | null;
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;
  @Column({ type: "uuid" }) cliente_id!: string;

  @ManyToOne(() => Simulacao, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "simulacao_id" })
  simulacao!: Relation<Simulacao> | null;
  @Column({ type: "uuid", nullable: true }) simulacao_id!: string | null;

  @Column({ type: "varchar", length: 20, default: "armazenando" })
  status!: StatusLoteIngestaoDocumentoFiscal;
  @Column({ type: "varchar", length: 20, default: "upload_manual" })
  origem!: OrigemIngestaoFiscal;
  @Column({ type: "jsonb", nullable: true }) rascunho_planilha!: RascunhoPlanilhaFiscal | null;
  @Column({ type: "int" }) total_arquivos!: number;
  @Column({ type: "int", default: 0 }) armazenados!: number;
  @Column({ type: "int", default: 0 }) carregados!: number;
  @Column({ type: "int", default: 0 }) projetados!: number;
  @Column({ type: "int", default: 0 }) duplicados!: number;
  @Column({ type: "int", default: 0 }) conflitos!: number;
  @Column({ type: "int", default: 0 }) falhas!: number;
  @Column({ type: "varchar", length: 1024, nullable: true }) manifesto_s3_uri!: string | null;
  @Column({ type: "varchar", length: 255, nullable: true }) execucao_glue_id!: string | null;
  @Column({ type: "varchar", length: 1024, nullable: true }) execucao_state_machine_arn!: string | null;
  @Column({ type: "varchar", length: 80, nullable: true }) codigo_erro!: string | null;
  @Column({ type: "text", nullable: true }) detalhe_erro!: string | null;
  @Column({ type: "timestamptz", nullable: true }) concluido_em!: Date | null;

  @OneToMany(() => ArquivoIngestaoDocumentoFiscal, (arquivo) => arquivo.lote)
  arquivos!: Relation<ArquivoIngestaoDocumentoFiscal[]>;

  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
