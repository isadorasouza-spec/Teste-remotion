import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddBloqueioEdicaoSimulacoes1790600000000 implements MigrationInterface {
  name = "AddBloqueioEdicaoSimulacoes1790600000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacoes" ADD COLUMN "bloqueada_edicao" boolean NOT NULL DEFAULT false`,
    );
    await queryRunner.query(
      `COMMENT ON COLUMN "simulacoes"."bloqueada_edicao" IS 'Bloqueio manual reversível da edição; cópias vinculadas permanecem somente leitura por simulacao_origem_id.'`,
    );
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacoes" DROP COLUMN "bloqueada_edicao"`,
    );
  }
}
