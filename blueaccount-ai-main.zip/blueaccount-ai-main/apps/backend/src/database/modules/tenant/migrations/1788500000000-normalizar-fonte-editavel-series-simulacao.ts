import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Corrige séries criadas durante a transição em que todas as cópias ainda apontavam para o cenário
 * externo. A cópia do mesmo ano dentro do grupo passa a ser a fonte editável; os demais anos passam
 * a apontar para ela. Séries antigas cuja fonte já pertence ao grupo não são alteradas.
 */
export class NormalizarFonteEditavelSeriesSimulacao1788500000000 implements MigrationInterface {
  name = "NormalizarFonteEditavelSeriesSimulacao1788500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TEMP TABLE "fontes_editaveis_series_simulacao" ON COMMIT DROP AS
      SELECT DISTINCT
        item_base."simulacao_grupo_id" AS "grupo_id",
        copia_base."id" AS "copia_base_id",
        copia_base."simulacao_origem_id" AS "fonte_externa_id"
      FROM "simulacao_grupo_itens" item_base
      INNER JOIN "simulacoes" copia_base
        ON copia_base."id" = item_base."simulacao_id"
      INNER JOIN "simulacoes" fonte_externa
        ON fonte_externa."id" = copia_base."simulacao_origem_id"
       AND fonte_externa."ano" = copia_base."ano"
       AND fonte_externa."cliente_id" = copia_base."cliente_id"
       AND fonte_externa."escritorio_id" = copia_base."escritorio_id"
      WHERE NOT EXISTS (
        SELECT 1
        FROM "simulacao_grupo_itens" item_fonte
        WHERE item_fonte."simulacao_grupo_id" = item_base."simulacao_grupo_id"
          AND item_fonte."simulacao_id" = fonte_externa."id"
      );
    `);

    // As entradas dos outros anos devem observar a entrada equivalente da cópia-base.
    await queryRunner.query(`
      UPDATE "simulacao_entradas" entrada_destino
      SET "fonte_seed" = entrada_base."id"
      FROM "fontes_editaveis_series_simulacao" normalizacao
      INNER JOIN "simulacao_grupo_itens" item_destino
        ON item_destino."simulacao_grupo_id" = normalizacao."grupo_id"
      INNER JOIN "simulacoes" simulacao_destino
        ON simulacao_destino."id" = item_destino."simulacao_id"
       AND simulacao_destino."id" <> normalizacao."copia_base_id"
       AND simulacao_destino."simulacao_origem_id" = normalizacao."fonte_externa_id"
      INNER JOIN "simulacao_entradas" entrada_base
        ON entrada_base."simulacao_id" = normalizacao."copia_base_id"
      WHERE entrada_destino."simulacao_id" = simulacao_destino."id"
        AND entrada_base."fonte_seed" IS NOT NULL
        AND entrada_destino."fonte_seed" = entrada_base."fonte_seed";
    `);

    await queryRunner.query(`
      UPDATE "simulacoes" simulacao_destino
      SET "simulacao_origem_id" = normalizacao."copia_base_id"
      FROM "fontes_editaveis_series_simulacao" normalizacao
      INNER JOIN "simulacao_grupo_itens" item_destino
        ON item_destino."simulacao_grupo_id" = normalizacao."grupo_id"
      WHERE item_destino."simulacao_id" = simulacao_destino."id"
        AND simulacao_destino."id" <> normalizacao."copia_base_id"
        AND simulacao_destino."simulacao_origem_id" = normalizacao."fonte_externa_id";
    `);

    await queryRunner.query(`
      UPDATE "simulacao_entradas" entrada_base
      SET "fonte_seed" = NULL
      FROM "fontes_editaveis_series_simulacao" normalizacao
      WHERE entrada_base."simulacao_id" = normalizacao."copia_base_id";
    `);

    await queryRunner.query(`
      UPDATE "simulacoes" copia_base
      SET "simulacao_origem_id" = NULL
      FROM "fontes_editaveis_series_simulacao" normalizacao
      WHERE copia_base."id" = normalizacao."copia_base_id";
    `);
  }

  /**
   * Não há reversão segura: depois que a cópia-base é editada, religá-la à fonte externa descartaria
   * a distinção de autoria estabelecida por esta migration.
   */
  public async down(): Promise<void> {}
}
