import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `modo_recolhimento_ibs_cbs` em `simulacao_entradas`: como o IBS/CBS da linha chega ao fisco
 * (`fornecedor_recolhe` | `rad` | `split_payment`).
 *
 * Premissa registrada, não cálculo — nenhum caminho de `domain/simulacoes/calculo.ts` ou de
 * `fluxo-caixa.ts` lê a coluna nesta entrega, então o deploy é numericamente neutro. `NOT NULL` com
 * default `fornecedor_recolhe`: o valor do backfill é exatamente o comportamento que a projeção
 * mensal de hoje já assume, então nenhuma linha existente muda de significado. `CHECK` trava os
 * três literais.
 */
export class AddModoRecolhimentoIbsCbsSimulacaoEntradas1790900000000
  implements MigrationInterface
{
  name = "AddModoRecolhimentoIbsCbsSimulacaoEntradas1790900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "modo_recolhimento_ibs_cbs" varchar(20) NOT NULL DEFAULT 'fornecedor_recolhe',
        ADD CONSTRAINT "CK_simulacao_entradas_modo_recolhimento_ibs_cbs"
          CHECK ("modo_recolhimento_ibs_cbs" IN ('fornecedor_recolhe', 'rad', 'split_payment'))
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."modo_recolhimento_ibs_cbs" IS
        'Como o IBS/CBS da linha e recolhido: fornecedor_recolhe (default) | rad | split_payment. Premissa registrada, sem efeito no calculo.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP CONSTRAINT IF EXISTS "CK_simulacao_entradas_modo_recolhimento_ibs_cbs",
        DROP COLUMN IF EXISTS "modo_recolhimento_ibs_cbs"
    `);
  }
}
