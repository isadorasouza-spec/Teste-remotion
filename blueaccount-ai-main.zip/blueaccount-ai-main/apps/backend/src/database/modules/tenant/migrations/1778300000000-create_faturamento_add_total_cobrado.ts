import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateFaturamentoAddTotalCobrado1778300000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS faturamento (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        cliente_id UUID NOT NULL REFERENCES clientes(id),
        competencia TEXT,
        razao_social TEXT,
        valor_cobrado DECIMAL(12,2),
        discriminacao TEXT,
        arquivo_origem TEXT,
        extracao_bruta JSONB,
        payload_normalizado_ui JSONB,
        faturamento_ativo BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_faturamento_ativo_cliente_competencia
        ON faturamento (cliente_id, competencia)
        WHERE faturamento_ativo = true;
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_faturamento_escritorio_cliente
        ON faturamento (escritorio_id, cliente_id);
    `);

    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS total_cobrado DECIMAL(12,2);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS total_cobrado;
    `);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_faturamento_escritorio_cliente;`);
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_faturamento_ativo_cliente_competencia;`);
    await queryRunner.query(`DROP TABLE IF EXISTS faturamento;`);
  }
}
