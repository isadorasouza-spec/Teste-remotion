import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/**
 * Certificado digital A1 (PKCS#12) do cliente, usado no mTLS contra os web services da SEFAZ.
 *
 * O binário `.pfx` fica no S3 (`bucket_pfx`/`chave_pfx`) porque `CryptoService` cifra apenas
 * `string`; a senha vai nas colunas `senha_*` no padrão AES-256-GCM de `PlataformaCobranca`.
 * A senha precisa ser **reversível**: o handshake TLS exige o PKCS#12 aberto. Hash não serve.
 *
 * `cnpj_titular`, `titular_nome`, `valido_de` e `valido_ate` são extraídos do próprio certificado
 * no upload, nunca digitados. O CN de e-CNPJ ICP-Brasil vem como `NOME:CNPJ`.
 *
 * Um único certificado ativo por cliente (`UQ_certificados_digitais_ativo`).
 */
@Entity("certificados_digitais_clientes")
@Index("IDX_certificados_digitais_cliente", ["cliente_id", "criado_em"])
@Check("CHK_certificados_digitais_cnpj", `"cnpj_titular" ~ '^[0-9]{14}$'`)
@Check("CHK_certificados_digitais_sha256", `"sha256_pfx" ~ '^[0-9a-f]{64}$'`)
@Check("CHK_certificados_digitais_validade", `"valido_ate" > "valido_de"`)
@Check("CHK_certificados_digitais_revogacao", `"ativo" = false OR "revogado_em" IS NULL`)
export class CertificadoDigitalCliente {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;

  /** Somente dígitos, extraído do CN do certificado e conferido contra `clientes.cnpj`. */
  @Column({ type: "varchar", length: 14 }) cnpj_titular!: string;
  @Column({ type: "text" }) titular_nome!: string;
  @Column({ type: "text" }) emissor!: string;
  /** Serial do X.509 em hexadecimal maiúsculo. */
  @Column({ type: "text" }) serie!: string;
  @Column({ type: "timestamptz" }) valido_de!: Date;
  @Column({ type: "timestamptz" }) valido_ate!: Date;

  @Column({ type: "text" }) bucket_pfx!: string;
  @Column({ type: "text" }) chave_pfx!: string;
  @Column({ type: "char", length: 64 }) sha256_pfx!: string;

  @Column({ type: "text" }) senha_encrypted!: string;
  @Column({ type: "text" }) senha_iv!: string;
  @Column({ type: "text" }) senha_tag!: string;

  /** Quem autorizou a custódia do certificado, e quando. Exigido pela trilha de LGPD. */
  @Column({ type: "uuid" }) consentimento_registrado_por!: string;
  @Column({ type: "timestamptz", default: () => "now()" }) consentimento_registrado_em!: Date;

  @Column({ type: "boolean", default: true }) ativo!: boolean;
  @Column({ type: "timestamptz", nullable: true }) revogado_em!: Date | null;

  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
