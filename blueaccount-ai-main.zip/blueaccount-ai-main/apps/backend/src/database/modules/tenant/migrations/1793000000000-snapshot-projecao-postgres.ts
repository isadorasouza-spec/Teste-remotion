import type { MigrationInterface, QueryRunner } from "typeorm";

/** Gerada com SQL memory do TypeORM; snapshot nullable para cenários do acervo Postgres. */
export class SnapshotProjecaoPostgres1793000000000 implements MigrationInterface {
  name = "SnapshotProjecaoPostgres1793000000000";
  async up(q: QueryRunner): Promise<void> {
    await q.query("ALTER TABLE \"arquivos_ingestao_documentos_fiscais\" ADD \"snapshot_projecao\" jsonb");
  }
  async down(q: QueryRunner): Promise<void> {
    await q.query("ALTER TABLE \"arquivos_ingestao_documentos_fiscais\" DROP COLUMN \"snapshot_projecao\"");
  }
}
