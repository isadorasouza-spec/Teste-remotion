import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  type Relation,
} from "typeorm";
import { AcaoAi } from "./acao-ai.entity.js";

@Entity("agentes")
export class Agente {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text", nullable: true })
  instrucoes!: string | null;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @Column({ type: "jsonb", nullable: true })
  configuracoes!: Record<string, unknown> | null;

  @OneToMany(() => AcaoAi, (acao) => acao.agente)
  acoes!: Relation<AcaoAi[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
