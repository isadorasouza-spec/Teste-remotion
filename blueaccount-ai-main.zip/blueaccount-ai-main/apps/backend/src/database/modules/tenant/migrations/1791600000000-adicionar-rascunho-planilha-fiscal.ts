import type { MigrationInterface, QueryRunner } from "typeorm";

/** SQL gerado pelo PostgresQueryRunner em memória; coluna aditiva, sem alterar lotes existentes. */
export class AdicionarRascunhoPlanilhaFiscal1791600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"lotes_ingestao_documentos_fiscais\" ADD \"rascunho_planilha\" jsonb");
  }
  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"lotes_ingestao_documentos_fiscais\" DROP COLUMN \"rascunho_planilha\"");
  }
}
