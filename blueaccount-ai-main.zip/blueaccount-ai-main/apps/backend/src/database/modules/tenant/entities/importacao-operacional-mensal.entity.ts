import { Column, Entity, PrimaryColumn } from "typeorm";

/** Controle técnico de recepção/publicação; guarda no máximo uma carga em andamento por mês. */
@Entity("importacoes_operacionais_mensais")
export class ImportacaoOperacionalMensal {
  @PrimaryColumn("uuid") escritorio_id!: string;
  @PrimaryColumn("uuid") cliente_id!: string;
  @PrimaryColumn("text") chave_escopo!: string;
  @Column("uuid") importacao_id!: string;
  @Column("timestamptz") extraido_em!: Date;
  @Column("text") hash_esperado!: string;
  @Column("integer") total_registros!: number;
  @Column("integer") total_lotes!: number;
  @Column({ type: "jsonb", default: {} }) lotes!: Record<string, unknown[]>;
  @Column({ type: "timestamptz", nullable: true }) publicado_em!: Date | null;
  @Column({ type: "text", nullable: true }) hash_publicado!: string | null;
}
