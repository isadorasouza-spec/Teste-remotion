import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona a NBS (Nomenclatura Brasileira de Serviços) à linha de simulação, mutuamente exclusiva
 * com o NCM já existente: uma linha carrega classificação de mercadoria OU de serviço, nunca as
 * duas. Toda linha existente tem `nbs` nulo, então o CHECK valida sem backfill.
 */
export class AddNbsToSimulacaoEntradas1789600000000 implements MigrationInterface {
  name = "AddNbsToSimulacaoEntradas1789600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      ADD COLUMN IF NOT EXISTS "nbs" varchar(9),
      ADD COLUMN IF NOT EXISTS "credito_ibs_cbs_vedado" boolean NOT NULL DEFAULT false,
      ADD COLUMN IF NOT EXISTS "regime_especifico" varchar(40)`);
    await queryRunner.query(`DO $$ BEGIN
      ALTER TABLE "simulacao_entradas" ADD CONSTRAINT "CHK_simulacao_entrada_ncm_xor_nbs"
        CHECK ("ncm" IS NULL OR "nbs" IS NULL);
    EXCEPTION WHEN duplicate_object THEN NULL; END $$`);
    await queryRunner.query(`COMMENT ON COLUMN "simulacao_entradas"."nbs" IS
      'NBS (Nomenclatura Brasileira de Serviços), 9 dígitos. Mutuamente exclusiva com "ncm". Dirige exclusivamente IBS/CBS (fator de alíquota, vedação de crédito ao adquirente e regime específico) — nunca ICMS, ISS ou DIFAL.'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      DROP CONSTRAINT IF EXISTS "CHK_simulacao_entrada_ncm_xor_nbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      DROP COLUMN IF EXISTS "regime_especifico",
      DROP COLUMN IF EXISTS "credito_ibs_cbs_vedado",
      DROP COLUMN IF EXISTS "nbs"`);
  }
}
