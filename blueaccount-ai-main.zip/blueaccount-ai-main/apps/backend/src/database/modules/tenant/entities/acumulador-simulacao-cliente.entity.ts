import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn, type Relation } from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { AcumuladorSimulacao, type AcumuladorSimulacaoTipo } from "./acumulador-simulacao.entity.js";
import type { TratamentoIbsCbs } from "./simulacao-entrada.entity.js";

export type ModoOverrideNumero = "herdar" | "limpar" | "valor";

@Index("UQ_acumuladores_simulacao_cliente", ["cliente_id", "acumulador_id"], { unique: true })
@Entity("acumuladores_simulacao_cliente")
export class AcumuladorSimulacaoCliente {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;
  @ManyToOne(() => Cliente, { onDelete: "CASCADE" }) @JoinColumn({ name: "cliente_id" }) cliente!: Relation<Cliente>;
  @Column({ type: "uuid" }) acumulador_id!: string;
  @ManyToOne(() => AcumuladorSimulacao, { onDelete: "CASCADE" }) @JoinColumn({ name: "acumulador_id" }) acumulador!: Relation<AcumuladorSimulacao>;
  @Column({ type: "boolean", nullable: true }) ativo!: boolean | null;
  @Column({ type: "varchar", length: 10, nullable: true }) tipo!: AcumuladorSimulacaoTipo | null;
  @Column({ type: "varchar", length: 20, nullable: true }) tratamento_ibs_cbs!: TratamentoIbsCbs | null;
  @Column({ type: "boolean", nullable: true }) gera_credito!: boolean | null;
  @Column({ type: "varchar", length: 8, default: "herdar" }) modo_fator_ibs!: ModoOverrideNumero;
  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true }) fator_ibs!: number | null;
  @Column({ type: "varchar", length: 8, default: "herdar" }) modo_fator_cbs!: ModoOverrideNumero;
  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true }) fator_cbs!: number | null;
  @Column({ type: "varchar", length: 8, default: "herdar" }) modo_percentual_reducao!: ModoOverrideNumero;
  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true }) percentual_reducao_ibs_cbs!: number | null;
  @CreateDateColumn() created_at!: Date;
  @UpdateDateColumn() updated_at!: Date;
}
