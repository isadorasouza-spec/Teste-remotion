import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { Simulacao } from "./simulacao.entity.js";
import type { ErroPlanilhaDadosSimulacao } from "../../../../infrastructure/dados-simulacao-client.js";

export type DocumentoModulo = "contratos" | "relatorios_periodicos" | "cobrancas" | "simulation_data";
export type DocumentoStatusUpload = "pendente" | "uploadando" | "sucesso" | "erro";
// "aguardando_correcao": canal de ingestão por IA (MCP) com seções pendentes/ inválidas
// numa extração parcial — só este caminho usa esse estado; o pipeline de arquivo nunca o emite.
export type DocumentoStatusExtracao =
  | "pendente"
  | "em_fila"
  | "processando"
  | "aguardando_correcao"
  | "aguardando_confirmacao"
  | "concluido"
  | "erro";
export type TipoDocumentoContratual =
  | "contrato_novo"
  | "aditivo"
  | "renovacao"
  | "cancelamento"
  | "correcao"
  | "desconhecido";

@Index("UQ_documentos_storage_key", ["storage_key"], { unique: true })
@Index("IDX_documentos_cliente_modulo", ["cliente_id", "modulo"])
@Index("IDX_documentos_simulacao", ["simulacao_id"])
@Entity("documentos")
export class Documento {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: true })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente | null>;

  @Column({ type: "uuid", nullable: true })
  cliente_id!: string | null;

  @ManyToOne(() => Simulacao, { nullable: true, onDelete: "CASCADE" })
  @JoinColumn({ name: "simulacao_id" })
  simulacao!: Relation<Simulacao | null>;

  @Column({ type: "uuid", nullable: true })
  simulacao_id!: string | null;

  @Column({ type: "uuid", nullable: true })
  uploaded_by_usuario_id!: string | null;

  @Column({ type: "text" })
  modulo!: DocumentoModulo;

  @Column({ type: "text" })
  filename_original!: string;

  @Column({ type: "text" })
  storage_provider!: "s3" | "local";

  @Column({ type: "text" })
  storage_bucket!: string;

  @Column({ type: "text" })
  storage_key!: string;

  @Column({ type: "text", nullable: true })
  mime_type!: string | null;

  @Column({ type: "bigint", nullable: true })
  size_bytes!: string | null;

  @Column({ type: "text", nullable: true })
  competencia!: string | null;

  @Column({ type: "text", nullable: true })
  checksum!: string | null;

  /** Idempotência de importações externas (simulação + CNPJ + competência). */
  @Column({ type: "text", nullable: true })
  chave_importacao!: string | null;

  /** Resultado normalizado temporário mantido somente até confirmar uma importação Domínio. */
  @Column({ type: "text", nullable: true })
  dados_simulacao_output_key!: string | null;

  @Column({ type: "text", default: "pendente" })
  status_upload!: DocumentoStatusUpload;

  @Column({ type: "text", nullable: true })
  erro_upload!: string | null;

  @Column({ type: "text", default: "pendente" })
  status_extracao!: DocumentoStatusExtracao;

  @Column({ type: "text", nullable: true })
  erro_extracao!: string | null;

  @Column({ type: "timestamp with time zone", nullable: true })
  processed_at!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;

  @Column({ type: "text", nullable: true })
  s3_textract_path!: string | null;

  @Column({ type: "text", nullable: true })
  textract_raw_key!: string | null;

  @Column({ type: "text", nullable: true })
  annotated_markdown_key!: string | null;

  @Column({ type: "text", nullable: true })
  clean_markdown_key!: string | null;

  @Column({ type: "text", nullable: true })
  blocks_parquet_key!: string | null;

  @Column({ type: "text", nullable: true })
  ocr_manifest_key!: string | null;

  @Column({ type: "text", nullable: true })
  ingestion_execution_arn!: string | null;

  @Column({ type: "text", nullable: true })
  contratos_execution_arn!: string | null;

  @Column({ type: "text", nullable: true })
  status_contrato!: "em_fila" | "processando" | "concluido" | "erro" | null;

  // ── Campos de ingestão contratual ─────────────────────────────────────

  @Column({ type: "text", nullable: true })
  tipo_documento_contratual!: TipoDocumentoContratual | null;

  @Column({ type: "text", nullable: true })
  versao_schema_contrato!: string | null;

  @Column({ type: "jsonb", nullable: true })
  dados_extraidos_contrato!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  alteracao_proposta_contrato!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  alteracao_aplicada_contrato!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  snapshot_servicos_contratados!: Record<string, unknown> | null;

  @Column({ type: "jsonb", default: {} })
  metadados_ia_contrato!: Record<string, unknown>;

  @Column({ type: "jsonb", default: {} })
  validacao_contrato!: Record<string, unknown>;

  @Column({ type: "timestamp with time zone", nullable: true })
  contrato_processado_em!: Date | null;

  @Column({ type: "text", nullable: true })
  erro_contrato!: string | null;

  @Column({ type: "jsonb", nullable: true })
  payload_normalizado_ui!: Record<string, unknown> | null;

  @Column({ type: "boolean", default: false })
  documento_ilegivel!: boolean;

  // ── Resultado da importação de dados de simulação (`modulo: "simulation_data"`) ──

  @Column({ type: "jsonb", nullable: true })
  resultado_dados_simulacao!: {
    erros: ErroPlanilhaDadosSimulacao[];
    avisos: string[];
    acumuladores_criados: string[];
    total_linhas: number;
    total_linhas_incluidas?: number;
    total_linhas_excluidas?: number;
    acumuladores_excluidos?: Array<{
      acumulador_id: string;
      codigo: string;
      descricao: string;
      motivo: "acumulador_inativo";
      total_linhas: number;
      valor_total: number;
      origem_politica: "escritorio" | "cliente";
    }>;
    checksum: string;
    aba: string | null;
    origem?: "xlsx" | "dominio";
    /** Como o valor monetário do pacote Domínio foi persistido nas entradas confirmadas. */
    tipo_valor_importado?: "valor_operacao" | "valor_total";
    manifesto?: Record<string, unknown>;
    cobertura?: { incluidos: string[]; excluidos: string[] };
    contrapartes_pendentes?: string[];
    /** Nome por CNPJ pendente, só para exibição. A chave continua sendo o CNPJ em dígitos. */
    contrapartes_nomes?: Record<string, string>;
    /** Linhas por regime que o Domínio classificou sozinho, sem premissa do contador. */
    contrapartes_resolvidas?: Record<string, number>;
    /**
     * Linhas de CUSTO sem contraparte nenhuma. Sempre o pacote inteiro no grão
     * `acumulador_consolidado`, onde o Connector nem lê `effornece`. A tela usa esse número para
     * decidir se pede o perfil de fornecedor padrão do lote na confirmação.
     */
    linhas_custo_sem_contraparte?: number;
    /** Granularidade declarada no manifesto do pacote Domínio. */
    granularidade?: string;
    /** Contadores do que a consolidação por acumulador descartou, crus como vieram do manifesto. */
    consolidacao?: Record<string, unknown>;
  } | null;
}
