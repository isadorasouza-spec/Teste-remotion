import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * A competência ainda aberta não pode ser revisada ou emitida: o agente pode
 * calcular durante o mês, mas o veredito normal fica guardado até a virada.
 */
export class AddStatusAposApuracaoValoresACobrar1788800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS status_apos_apuracao VARCHAR(30) NULL;
    `);

    // Migração de estado para VACs já calculados do mês atual/futuro. Não toca
    // registros enviados, pagos ou inválidos, que são estados terminais/especiais.
    await queryRunner.query(`
      UPDATE valores_a_cobrar
      SET status_apos_apuracao = status,
          status = 'em_apuracao'
      WHERE status IN ('revisado', 'pronto_para_revisao')
        AND valores_calculados IS NOT NULL
        AND valores_calculados <> '{}'::jsonb
        AND competencia ~ '^(0[1-9]|1[0-2])/[0-9]{4}$'
        AND to_date(competencia, 'MM/YYYY') >= date_trunc('month', now() AT TIME ZONE 'America/Sao_Paulo')::date;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE valores_a_cobrar
      SET status = COALESCE(status_apos_apuracao, 'revisado')
      WHERE status = 'em_apuracao';
    `);
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar DROP COLUMN IF EXISTS status_apos_apuracao;
    `);
  }
}
