import {
  Entity,
  PrimaryColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Simulacao } from "./simulacao.entity.js";
import { SimulacaoGrupo } from "./simulacao-grupo.entity.js";

@Entity("simulacao_grupo_itens")
@Index("idx_simulacao_grupo_itens_grupo_id", ["simulacao_grupo_id"])
@Index("idx_simulacao_grupo_itens_simulacao_id", ["simulacao_id"])
export class SimulacaoGrupoItem {
  @PrimaryColumn({ type: "uuid" })
  simulacao_grupo_id!: string;

  @PrimaryColumn({ type: "uuid" })
  simulacao_id!: string;

  @ManyToOne(() => SimulacaoGrupo, (g) => g.itens, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "simulacao_grupo_id" })
  grupo!: Relation<SimulacaoGrupo>;

  @ManyToOne(() => Simulacao, (s) => s.itensGrupo, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "simulacao_id" })
  simulacao!: Relation<Simulacao>;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @CreateDateColumn()
  created_at!: Date;
}
