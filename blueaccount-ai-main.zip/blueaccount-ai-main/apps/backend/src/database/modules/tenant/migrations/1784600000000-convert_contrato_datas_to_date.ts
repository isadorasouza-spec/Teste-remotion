import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Converte datas textuais legadas sem permitir que uma linha inválida interrompa
 * a migração de todos os escritórios. Somente ISO YYYY-MM-DD de calendário real
 * é preservado; qualquer outro conteúdo passa a NULL.
 */
export class ConvertContratoDatasToDate1784600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    for (const coluna of ["data_inicio", "data_emissao", "inicio_faturamento", "ultima_renovacao"]) {
      await queryRunner.query(`
        ALTER TABLE contratos
        ALTER COLUMN ${coluna} TYPE DATE
        USING CASE
          WHEN ${coluna} ~ '^\\d{4}-\\d{2}-\\d{2}$'
            AND to_char(to_date(${coluna}, 'YYYY-MM-DD'), 'YYYY-MM-DD') = ${coluna}
          THEN to_date(${coluna}, 'YYYY-MM-DD')
          ELSE NULL
        END
      `);
    }
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    for (const coluna of ["data_inicio", "data_emissao", "inicio_faturamento", "ultima_renovacao"]) {
      await queryRunner.query(`
        ALTER TABLE contratos
        ALTER COLUMN ${coluna} TYPE TEXT
        USING ${coluna}::text
      `);
    }
  }
}
