import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Allowlist manual de NCM (classificação fiscal da mercadoria) análoga a
 * `cnaes_fornecedores_permitidos` (`1785900000000-add_cnae_fields_to_clientes`), mas chaveada pelo
 * NCM da LINHA (`simulacao_entradas.ncm`, já existente — migration `1786400000000`) em vez do CNAE do
 * fornecedor.
 *
 * Puramente digitação do contador — assim como `cnaes_fornecedores_permitidos`, NUNCA vem de consulta
 * pública/lookup externo (o catálogo de NCM em `GET /api/ncms/:codigo` é validação de UX, não fonte
 * de dado deste campo). `NULL`/lista vazia = nenhuma restrição cadastrada.
 *
 * **Sem backfill, deliberadamente**: nasce `NULL` para todo cliente já cadastrado, mesmo mecanismo de
 * `1785900000000-add_cnae_fields_to_clientes` e `1785700000002-add_uf_to_clientes`.
 */
export class AddNcmsPermitidosToClientes1786800000000 implements MigrationInterface {
  name = "AddNcmsPermitidosToClientes1786800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "ncms_permitidos" jsonb
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."ncms_permitidos" IS
        'Allowlist manual ({codigo, descricao}[]) de NCM (classificação fiscal da mercadoria) considerado elegível a gerar crédito de ICMS para este cliente (LC 214/2025). Puramente dado de digitação do contador — NUNCA vem de consulta/lookup externo. NULL/lista vazia = nenhuma restrição cadastrada.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "ncms_permitidos"`);
  }
}
