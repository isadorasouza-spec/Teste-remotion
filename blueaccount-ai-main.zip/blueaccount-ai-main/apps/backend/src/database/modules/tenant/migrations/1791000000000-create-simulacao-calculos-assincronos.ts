import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSimulacaoCalculosAssincronos1791000000000 implements MigrationInterface {
  name = "CreateSimulacaoCalculosAssincronos1791000000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "simulacoes"
      ADD COLUMN "status_calculo" varchar(20) NOT NULL DEFAULT 'nao_calculado',
      ADD COLUMN "calculo_solicitado_em" timestamptz,
      ADD COLUMN "calculo_iniciado_em" timestamptz,
      ADD COLUMN "calculado_em" timestamptz,
      ADD COLUMN "erro_calculo" text,
      ADD CONSTRAINT "CHK_simulacoes_status_calculo" CHECK (
        "status_calculo" IN ('nao_calculado', 'na_fila', 'processando', 'calculado', 'erro', 'cancelado')
      )`);
    await q.query(`CREATE TABLE "simulacao_calculos" (
      "simulacao_id" uuid NOT NULL,
      "escritorio_id" uuid NOT NULL,
      "versao_motor" integer NOT NULL,
      "assinatura_dependencias" text NOT NULL,
      "payload" bytea NOT NULL,
      "calculado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_simulacao_calculos" PRIMARY KEY ("simulacao_id"),
      CONSTRAINT "FK_simulacao_calculos_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE
    )`);
    await q.query(`CREATE INDEX "IDX_simulacao_calculos_escritorio" ON "simulacao_calculos" ("escritorio_id")`);
    await q.query(`CREATE INDEX "IDX_simulacao_calculos_calculado_em" ON "simulacao_calculos" ("calculado_em")`);
    await q.query(`INSERT INTO "simulacao_calculos"
      ("simulacao_id", "escritorio_id", "versao_motor", "assinatura_dependencias", "payload", "calculado_em")
      SELECT cache."simulacao_id", cache."escritorio_id", cache."versao_motor", cache."assinatura_dependencias", cache."payload", cache."calculado_em"
      FROM "simulacao_resultados_cache" cache
      JOIN "simulacoes" simulacao ON simulacao."id" = cache."simulacao_id"
      ON CONFLICT ("simulacao_id") DO NOTHING`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE "simulacao_calculos"`);
    await q.query(`ALTER TABLE "simulacoes" DROP CONSTRAINT "CHK_simulacoes_status_calculo"`);
    await q.query(`ALTER TABLE "simulacoes"
      DROP COLUMN "erro_calculo",
      DROP COLUMN "calculado_em",
      DROP COLUMN "calculo_iniciado_em",
      DROP COLUMN "calculo_solicitado_em",
      DROP COLUMN "status_calculo"`);
  }
}
