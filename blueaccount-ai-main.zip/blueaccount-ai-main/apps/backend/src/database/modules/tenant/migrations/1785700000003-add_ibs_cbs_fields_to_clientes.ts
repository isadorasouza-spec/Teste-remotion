import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Campos de IBS/CBS do cliente, espelhando os equivalentes já existentes em `fornecedores`
 * (`1785600000000-add_aliquotas_atuais_to_fornecedores`), mas para gatear o débito/crédito do
 * PRÓPRIO cliente, não o que um terceiro tomaria da nota dele.
 *
 * `opcao_ibs_cbs` só importa quando `regime_tributario = "Simples Nacional"` — ver
 * `domain/clientes/regime-credito.ts`. As duas alíquotas de crédito presumido incidem sobre o valor
 * BRUTO da linha, não sobre o crédito cheio.
 *
 * **Sem backfill, deliberadamente.** Nascem `NULL` para todo cliente já cadastrado — não vêm da
 * consulta pública de CNPJ (BrasilAPI não expõe essa informação), então só a próxima edição manual
 * do cadastro os preenche. Mesmo mecanismo de `1785700000002-add_uf_to_clientes`.
 */
export class AddIbsCbsFieldsToClientes1785700000003 implements MigrationInterface {
  name = "AddIbsCbsFieldsToClientes1785700000003";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "opcao_ibs_cbs" varchar(20)
    `);
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "aliquota_credito_presumido_ibs" decimal(6,4)
    `);
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "aliquota_credito_presumido_cbs" decimal(6,4)
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."opcao_ibs_cbs" IS
        'Opção de recolhimento de IBS/CBS do cliente optante do Simples Nacional. Só é consultada quando regime_tributario = Simples Nacional. NULL = não informado (equivale a regime_unico).'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."aliquota_credito_presumido_ibs" IS
        'Alíquota de crédito presumido de IBS do próprio cliente, aplicada sobre o valor BRUTO da despesa (não é fração do crédito integral). NULL = zero.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."aliquota_credito_presumido_cbs" IS
        'Idem para CBS. Separado porque IBS e CBS são apurados em linhas distintas do resultado.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "aliquota_credito_presumido_cbs"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "aliquota_credito_presumido_ibs"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "opcao_ibs_cbs"`);
  }
}
