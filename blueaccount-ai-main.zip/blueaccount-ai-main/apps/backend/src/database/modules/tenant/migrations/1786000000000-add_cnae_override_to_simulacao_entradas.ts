import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `cnae_override`/`cnae_override_descricao` em `simulacao_entradas`: CNAE manual por linha, mesmo
 * padrão de `aliquota_icms_override`/`aliquota_iss_override` na mesma tabela. Nível mais forte da
 * precedência de 2 níveis resolvida por `resolverCnaeEntrada` (`domain/simulacoes/calculo.ts`) —
 * perde apenas para nada, ganha do `fornecedor.cnae_principal` do fornecedor vinculado à linha.
 *
 * Usado exclusivamente para gatear crédito de ICMS pela allowlist manual do cliente
 * (`clientes.cnaes_fornecedores_permitidos`, ver `1785900000000-add_cnae_fields_to_clientes`) via
 * `permiteCreditoPorCnaeFornecedor` (`domain/clientes/regime-credito.ts`). Nunca afeta IBS/CBS/ISS.
 *
 * **Sem backfill, deliberadamente**: nasce `NULL` para toda entrada já existente, mesmo mecanismo de
 * `1785900000000-add_cnae_fields_to_clientes` e `1785700000003-add_ibs_cbs_fields_to_clientes`.
 */
export class AddCnaeOverrideToSimulacaoEntradas1786000000000 implements MigrationInterface {
  name = "AddCnaeOverrideToSimulacaoEntradas1786000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "cnae_override" varchar(7)
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "cnae_override_descricao" text
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."cnae_override" IS
        'CNAE manual da linha (7 dígitos, sem pontuação). Vence sobre o cnae_principal do fornecedor vinculado (resolverCnaeEntrada em domain/simulacoes/calculo.ts). Usado só para gatear crédito de ICMS pela allowlist do cliente (clientes.cnaes_fornecedores_permitidos) — nunca afeta IBS/CBS/ISS. Sem backfill.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."cnae_override_descricao" IS
        'Descrição textual do cnae_override, digitada ou resolvida pela consulta de CNAE. Sem backfill.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "cnae_override_descricao"`,
    );
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "cnae_override"`);
  }
}
