import type { MigrationInterface, QueryRunner } from "typeorm";

/** Diff gerado pelo PostgresQueryRunner e revisado: ampliação preserva dados/índice único. */
export class AmpliarChaveNfseNacional1791300000000 implements MigrationInterface {
  name = "AmpliarChaveNfseNacional1791300000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE "simulacao_notas_fiscais" ALTER COLUMN "chave" TYPE varchar(50)');
    await queryRunner.query("ALTER TABLE \"simulacao_notas_fiscais\" ALTER COLUMN \"modelo\" DROP NOT NULL");
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    // Bloqueia escritas entre a conferência e o estreitamento; migrations rodam em transação.
    await queryRunner.query('LOCK TABLE "simulacao_notas_fiscais" IN ACCESS EXCLUSIVE MODE');
    const [restricao] = await queryRunner.query(`SELECT EXISTS (
      SELECT 1 FROM "simulacao_notas_fiscais" WHERE length("chave") > 44 OR "modelo" IS NULL
    ) AS bloqueado`);
    if (restricao?.bloqueado !== false) {
      throw new Error("Rollback exige tratar previamente as NFS-e nacionais, sem truncar chaves.");
    }
    await queryRunner.query('ALTER TABLE "simulacao_notas_fiscais" ALTER COLUMN "chave" TYPE varchar(44)');
    await queryRunner.query('ALTER TABLE "simulacao_notas_fiscais" ALTER COLUMN "modelo" SET NOT NULL');
  }
}
