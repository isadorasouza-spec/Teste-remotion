import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  type Relation,
} from "typeorm";
import { AcaoAi } from "./acao-ai.entity.js";

@Entity("historico_acao_ai")
export class HistoricoAcaoAi {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => AcaoAi, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "acao_id" })
  acao!: Relation<AcaoAi>;

  @Column({ type: "uuid" })
  acao_id!: string;

  @Column({ type: "text" })
  status!: string;

  @Column({ type: "text", nullable: true })
  resultado!: string | null;

  @CreateDateColumn({ type: "timestamptz" })
  created_at!: Date;
}
