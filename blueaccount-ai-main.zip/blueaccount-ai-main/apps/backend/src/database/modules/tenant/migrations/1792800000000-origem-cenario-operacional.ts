import type { MigrationInterface, QueryRunner } from "typeorm";

/** Gerada por schema diff TypeORM em schema local descartável. */
export class OrigemCenarioOperacional1792800000000 implements MigrationInterface {
  name = "OrigemCenarioOperacional1792800000000";
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"simulacoes\" ADD \"origem_operacional\" jsonb");
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" ADD \"origem_operacional\" jsonb");
  }
  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"simulacoes\" DROP COLUMN \"origem_operacional\"");
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" DROP COLUMN \"origem_operacional\"");
  }
}
