import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddAgenteCobrancaOutputS3PathValoresACobrar1779500000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS agente_cobranca_output_s3_path TEXT NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS agente_cobranca_output_s3_path
    `);
  }
}
