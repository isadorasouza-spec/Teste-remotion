import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddEdicoesToReviewableRecords1779200000000 implements MigrationInterface {
  name = "AddEdicoesToReviewableRecords1779200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "edicoes" jsonb`);
    await queryRunner.query(`ALTER TABLE "relatorios" ADD COLUMN IF NOT EXISTS "edicoes" jsonb`);
    await queryRunner.query(`ALTER TABLE "valores_a_cobrar" ADD COLUMN IF NOT EXISTS "edicoes" jsonb`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "valores_a_cobrar" DROP COLUMN IF EXISTS "edicoes"`);
    await queryRunner.query(`ALTER TABLE "relatorios" DROP COLUMN IF EXISTS "edicoes"`);
    await queryRunner.query(`ALTER TABLE "contratos" DROP COLUMN IF EXISTS "edicoes"`);
  }
}
