import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
  type Relation,
} from "typeorm";
import { LoteIngestaoDocumentoFiscal } from "./lote-ingestao-documento-fiscal.entity.js";

export type TipoDocumentoFiscal = "nfe" | "nfce" | "nfse" | "cte" | "desconhecido";
export type StatusArquivoIngestaoDocumentoFiscal =
  | "armazenado"
  | "em_fila"
  | "processando"
  | "carregado"
  | "projetando"
  | "projetado"
  | "duplicado"
  | "conflito_conteudo"
  | "erro_tecnico"
  | "erro_validacao";

@Entity("arquivos_ingestao_documentos_fiscais")
@Index("IDX_arquivos_ingestao_fiscal_lote", ["lote_id", "criado_em"])
@Index("IDX_arquivos_ingestao_fiscal_checksum", ["escritorio_id", "cliente_id", "sha256"])
@Index("IDX_arquivos_ingestao_fiscal_chave", ["escritorio_id", "cliente_id", "tipo_documento", "chave_acesso"])
export class ArquivoIngestaoDocumentoFiscal {
  /** Contrato de projeção fixado na criação do cenário Postgres, independente do acervo mutável. */
  @Column({ type: "jsonb", nullable: true, select: false }) snapshot_projecao!: Record<string, unknown> | null;

  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;

  @ManyToOne(() => LoteIngestaoDocumentoFiscal, (lote) => lote.arquivos, {
    nullable: false,
    onDelete: "CASCADE",
  })
  @JoinColumn({ name: "lote_id" })
  lote!: Relation<LoteIngestaoDocumentoFiscal>;
  @Column({ type: "uuid" }) lote_id!: string;

  @Column({ type: "varchar", length: 255 }) nome_original!: string;
  @Column({ type: "varchar", length: 20, default: "desconhecido" })
  tipo_documento!: TipoDocumentoFiscal;
  @Column({ type: "varchar", length: 10, nullable: true }) modelo!: string | null;
  @Column({ type: "varchar", length: 30, nullable: true }) versao_layout!: string | null;
  @Column({ type: "varchar", length: 64, nullable: true }) chave_acesso!: string | null;
  @Column({ type: "uuid", nullable: true }) documento_canonico_id!: string | null;
  @Column({ type: "char", length: 64 }) sha256!: string;
  @Column({ type: "bigint" }) tamanho_bytes!: string;
  @Column({ type: "varchar", length: 100, default: "application/xml" }) tipo_conteudo!: string;
  @Column({ type: "varchar", length: 255 }) bucket_raw!: string;
  @Column({ type: "varchar", length: 1024 }) chave_raw!: string;
  @Column({ type: "varchar", length: 255, nullable: true }) bucket_normalizado!: string | null;
  @Column({ type: "varchar", length: 1024, nullable: true }) chave_normalizado!: string | null;
  @Column({ type: "varchar", length: 20, default: "armazenado" })
  status!: StatusArquivoIngestaoDocumentoFiscal;
  @Column({ type: "boolean", default: false }) duplicado_exato!: boolean;
  @Column({ type: "smallint", default: 0 }) tentativas!: number;
  @Column({ type: "varchar", length: 255, nullable: true }) execucao_glue_id!: string | null;
  @Column({ type: "bigint", nullable: true }) snapshot_itens_id!: string | null;
  @Column({ type: "bigint", nullable: true }) snapshot_totais_id!: string | null;
  @Column({ type: "int", nullable: true }) quantidade_itens!: number | null;
  @Column({ type: "jsonb", default: () => "'[]'::jsonb" }) avisos!: Array<Record<string, unknown>>;
  @Column({ type: "varchar", length: 80, nullable: true }) codigo_erro!: string | null;
  @Column({ type: "text", nullable: true }) detalhe_erro!: string | null;
  @Column({ type: "timestamptz", nullable: true }) processado_em!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) projetado_em!: Date | null;

  @CreateDateColumn({ type: "timestamptz", name: "criado_em" }) criado_em!: Date;
  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
