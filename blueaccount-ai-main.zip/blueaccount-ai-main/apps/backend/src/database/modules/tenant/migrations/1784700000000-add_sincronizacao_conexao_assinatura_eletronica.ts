import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Guard de run único da sincronização DocuSign movida para a State Machine
 * `conector-docusign`: como há exatamente uma `conexao` por
 * `escritorio_id + provedor`, o ciclo de vida da execução (status/run id/
 * execution arn/início) vive como colunas na própria conexão em vez de uma
 * tabela de execuções dedicada (diferente de `conector_drive_execucoes`).
 *
 * Idempotente (`ADD COLUMN IF NOT EXISTS` / `DROP COLUMN IF EXISTS`).
 */
export class AddSincronizacaoConexaoAssinaturaEletronica1784700000000 implements MigrationInterface {
  name = "AddSincronizacaoConexaoAssinaturaEletronica1784700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "conexoes_assinatura_eletronica"
        ADD COLUMN IF NOT EXISTS "sincronizacao_status" text NOT NULL DEFAULT 'ocioso',
        ADD COLUMN IF NOT EXISTS "sincronizacao_run_id" uuid NULL,
        ADD COLUMN IF NOT EXISTS "sincronizacao_execution_arn" text NULL,
        ADD COLUMN IF NOT EXISTS "sincronizacao_iniciada_em" timestamptz NULL;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "conexoes_assinatura_eletronica"
        DROP COLUMN IF EXISTS "sincronizacao_iniciada_em",
        DROP COLUMN IF EXISTS "sincronizacao_execution_arn",
        DROP COLUMN IF EXISTS "sincronizacao_run_id",
        DROP COLUMN IF EXISTS "sincronizacao_status";
    `);
  }
}
