import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddReajusteContratoEValoresACobrar1784300000001 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE contratos
        ADD COLUMN IF NOT EXISTS ultima_competencia_reajuste VARCHAR(7),
        ADD COLUMN IF NOT EXISTS data_ultimo_reajuste DATE;
    `);
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS contrato_reajustado BOOLEAN NOT NULL DEFAULT false,
        ADD COLUMN IF NOT EXISTS reajuste_contrato JSONB NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE valores_a_cobrar DROP COLUMN IF EXISTS reajuste_contrato, DROP COLUMN IF EXISTS contrato_reajustado;`);
    await queryRunner.query(`ALTER TABLE contratos DROP COLUMN IF EXISTS data_ultimo_reajuste, DROP COLUMN IF EXISTS ultima_competencia_reajuste;`);
  }
}
