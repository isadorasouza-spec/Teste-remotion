import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddIdempotencyKeyCobrancas1780900000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE cobrancas
        ADD COLUMN IF NOT EXISTS idempotency_key TEXT NULL
    `);

    // Único por escritório quando informado: bloqueia emissão duplicada em retries.
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_cobrancas_escritorio_idempotency_key
        ON cobrancas (escritorio_id, idempotency_key)
        WHERE idempotency_key IS NOT NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_cobrancas_escritorio_idempotency_key;`);
    await queryRunner.query(`ALTER TABLE cobrancas DROP COLUMN IF EXISTS idempotency_key;`);
  }
}
