import { Check, Column, Entity, PrimaryColumn, UpdateDateColumn } from "typeorm";

export type AmbienteDistribuicaoDfe = "producao" | "homologacao";

/**
 * Cursor NSU do `NFeDistribuicaoDFe`, por `(cliente, ambiente)`. Vive além de qualquer job porque
 * o protocolo é sequencial e punitivo:
 *
 * - `distNSU` fora da sequência ascendente bloqueia o CNPJ por 1h (`cStat 656`);
 * - `cStat 137` (sem mais documentos) obriga esperar 1h antes da consulta seguinte;
 * - a cota é de 20 consultas/hora por CNPJ, compartilhada com o ERP/contabilidade do cliente.
 *
 * Por isso `bloqueado_ate` e a janela de cota são **persistidos**: um token bucket em memória
 * zeraria no reinício do processo e provocaria 656.
 *
 * `ambiente` entra na chave porque produção e homologação têm sequências de NSU e bloqueios
 * independentes.
 *
 * NSU tem 15 dígitos e é `bigint`; o TypeORM devolve `string` (padrão de `tamanho_bytes` em
 * `ArquivoIngestaoDocumentoFiscal`).
 *
 * `primeiro_nsu_visto` registra o NSU inicial que o Ambiente Nacional devolveu na primeira
 * varredura: sondagem em produção (2026-09-10) mostrou que `distNSU=0` **não** começa no NSU 1,
 * e sim no mais antigo ainda retido (3 meses). Sem esse registro a lacuna fica invisível.
 */
@Entity("cursores_distribuicao_dfe")
@Check("CHK_cursores_dfe_ambiente", `"ambiente" IN ('producao','homologacao')`)
@Check("CHK_cursores_dfe_nsu", `"ultimo_nsu" >= 0 AND "max_nsu" >= 0`)
@Check("CHK_cursores_dfe_janela", `"consultas_na_janela" >= 0`)
export class CursorDistribuicaoDfe {
  @PrimaryColumn({ type: "uuid" }) escritorio_id!: string;
  @PrimaryColumn({ type: "uuid" }) cliente_id!: string;
  @PrimaryColumn({ type: "varchar", length: 12 }) ambiente!: AmbienteDistribuicaoDfe;

  @Column({ type: "bigint", default: 0 }) ultimo_nsu!: string;
  @Column({ type: "bigint", default: 0 }) max_nsu!: string;
  @Column({ type: "bigint", nullable: true }) primeiro_nsu_visto!: string | null;

  @Column({ type: "timestamptz", nullable: true }) ultima_consulta_em!: Date | null;
  /** Cobre tanto a espera de 1h do `cStat 137` quanto o bloqueio do `cStat 656`. */
  @Column({ type: "timestamptz", nullable: true }) bloqueado_ate!: Date | null;
  @Column({ type: "varchar", length: 4, nullable: true }) ultimo_cstat!: string | null;

  @Column({ type: "smallint", default: 0 }) consultas_na_janela!: number;
  @Column({ type: "timestamptz", nullable: true }) janela_iniciada_em!: Date | null;

  @UpdateDateColumn({ type: "timestamptz", name: "atualizado_em" }) atualizado_em!: Date;
}
