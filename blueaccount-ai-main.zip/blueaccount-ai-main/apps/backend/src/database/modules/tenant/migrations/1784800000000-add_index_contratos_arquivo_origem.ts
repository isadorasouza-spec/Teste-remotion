import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * A listagem paginada de documentos resolve `contrato_id`/`tem_contrato` por
 * subconsulta correlacionada em `contratos.arquivo_origem`. `relatorios` e
 * `faturamento` já tinham índice equivalente (AddPerformanceIndexes1782400000000);
 * `contratos` ficou de fora e pagava seq scan por linha da página.
 */
export class AddIndexContratosArquivoOrigem1784800000000 implements MigrationInterface {
  name = "AddIndexContratosArquivoOrigem1784800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE INDEX IF NOT EXISTS "IDX_contratos_arquivo_origem" ON "contratos" ("arquivo_origem") WHERE "arquivo_origem" IS NOT NULL`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_contratos_arquivo_origem"`);
  }
}
