import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Cache do resultado do motor de simulação. É `UNLOGGED` de propósito: o conteúdo é sempre
 * reconstruível por `obterSimulacao`, então não vale WAL, réplica de leitura nem PITR. O preço é
 * que o Postgres trunca a tabela em crash/shutdown sujo, e que não existe FK para `simulacoes`
 * (o Postgres proíbe FK entre persistências diferentes) — a limpeza de órfãos é explícita, em
 * `excluirSimulacao` e em `limpar-simulacoes-antigas.ts`.
 *
 * `payload` é `bytea` com JSON gzipado, não `jsonb`. Medido num cenário de 2.880 linhas (JSON cru
 * de 15 MB): ler o mesmo payload custa 153 ms em `jsonb` contra 41 ms em `bytea` + gunzip, porque
 * o `jsonb` volta expandido no protocolo e são 15 MB atravessando o socket a cada leitura. Nada
 * consulta o conteúdo por SQL — o payload é opaco, sempre lido inteiro — então `jsonb` só custaria
 * o parse/reserialize dos dois lados sem dar nada em troca.
 */
export class CreateSimulacaoResultadosCache1790300000000 implements MigrationInterface {
  name = "CreateSimulacaoResultadosCache1790300000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE UNLOGGED TABLE "simulacao_resultados_cache" (
      "simulacao_id" uuid NOT NULL,
      "escritorio_id" uuid NOT NULL,
      "versao_motor" integer NOT NULL,
      "assinatura_dependencias" text NOT NULL,
      "payload" bytea NOT NULL,
      "calculado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_simulacao_resultados_cache" PRIMARY KEY ("simulacao_id")
    )`);
    await q.query(`CREATE INDEX "IDX_simulacao_resultados_cache_escritorio" ON "simulacao_resultados_cache" ("escritorio_id")`);
    await q.query(`CREATE INDEX "IDX_simulacao_resultados_cache_calculado_em" ON "simulacao_resultados_cache" ("calculado_em")`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE "simulacao_resultados_cache"`);
  }
}
