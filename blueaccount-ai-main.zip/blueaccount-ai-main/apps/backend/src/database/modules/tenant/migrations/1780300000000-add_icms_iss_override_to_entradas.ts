import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddIcmsIssOverrideToEntradas1780300000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "aliquota_icms_override" DECIMAL(6,4),
        ADD COLUMN "aliquota_iss_override"  DECIMAL(6,4);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP COLUMN "aliquota_icms_override",
        DROP COLUMN "aliquota_iss_override";
    `);
  }
}
