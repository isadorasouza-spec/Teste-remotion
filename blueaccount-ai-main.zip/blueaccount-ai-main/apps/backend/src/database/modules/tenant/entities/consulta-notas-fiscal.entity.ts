
import { Entity, Column, PrimaryColumn, ForeignKey, Index } from "typeorm";

@Entity("consultas_notas_fiscais")
@Index("idx_consultas_expiracao", ["expira_em"])
export class ConsultaNotasFiscal {
  @PrimaryColumn({ type: "uuid" }) escritorio_id!: string;
  @PrimaryColumn({ type: "uuid" }) id!: string;
  @Column({ type: "uuid" }) cliente_id!: string;
  @Column({ type: "timestamptz" }) expira_em!: Date;
}
