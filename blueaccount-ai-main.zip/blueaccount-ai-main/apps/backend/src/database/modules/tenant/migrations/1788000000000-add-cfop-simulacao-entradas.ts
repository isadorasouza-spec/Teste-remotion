import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * CFOP por linha de entrada da simulação.
 *
 * Nasce nula e sem backfill: linhas já importadas não têm o código guardado (o parser só passou a
 * ler `det/prod/CFOP` agora) e o XML de origem nem sempre continua acessível. Reimportar a nota é o
 * caminho para preencher o histórico, igual ao que já vale para `ncm`/`cst`/`csosn`.
 *
 * Sem CHECK de domínio de propósito: a validação de formato (quatro dígitos, grupo em 1/2/3/5/6/7)
 * vive em `domain/simulacoes/nfe/cfop.ts`, que é onde o código é interpretado. Um CHECK aqui
 * duplicaria a regra e rejeitaria a correção manual de uma linha antiga.
 */
export class AddCfopSimulacaoEntradas1788000000000 implements MigrationInterface {
  name = "AddCfopSimulacaoEntradas1788000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD "cfop" varchar(4)`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN "cfop"`);
  }
}
