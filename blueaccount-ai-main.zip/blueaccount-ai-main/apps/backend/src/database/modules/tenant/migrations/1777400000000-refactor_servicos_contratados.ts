import { type MigrationInterface, type QueryRunner } from "typeorm";

export class RefactorServicosContratados1777400000000 implements MigrationInterface {
  name = "RefactorServicosContratados1777400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Drop old servicos_contratados (FK from contrato)
    await queryRunner.query(`DROP TABLE IF EXISTS "servicos_contratados" CASCADE`);

    // Recreate servicos_contratados com novo modelo JSONB + FK para clientes
    await queryRunner.query(`
      CREATE TABLE "servicos_contratados" (
        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "cliente_id" uuid NOT NULL,
        "versao_schema" text NOT NULL DEFAULT 'servicos_contratados.v1',
        "status" text NOT NULL DEFAULT 'ativo',
        "dados" jsonb NOT NULL,
        "resumo_normalizado" jsonb NOT NULL DEFAULT '{}',
        "validacao" jsonb NOT NULL DEFAULT '{}',
        "ultimo_documento_id" uuid,
        "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        CONSTRAINT "PK_servicos_contratados" PRIMARY KEY ("id"),
        CONSTRAINT "FK_servicos_contratados_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id"),
        CONSTRAINT "FK_servicos_contratados_ultimo_documento" FOREIGN KEY ("ultimo_documento_id") REFERENCES "documentos"("id")
      )
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_servicos_contratados_escritorio_cliente"
        ON "servicos_contratados" ("escritorio_id", "cliente_id")
    `);

    // Índices para documentos de contratos
    await queryRunner.query(`
      CREATE INDEX "IDX_documentos_historico_contratos"
        ON "documentos" ("escritorio_id", "cliente_id", "modulo", "created_at" DESC)
        WHERE "modulo" = 'contratos'
    `);

    await queryRunner.query(`
      CREATE INDEX "IDX_documentos_status_contrato"
        ON "documentos" ("escritorio_id", "status_contrato")
        WHERE "modulo" = 'contratos'
    `);

    // Novos campos na tabela documentos
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "tipo_documento_contratual" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "versao_schema_contrato" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "dados_extraidos_contrato" jsonb`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "alteracao_proposta_contrato" jsonb`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "alteracao_aplicada_contrato" jsonb`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "snapshot_servicos_contratados" jsonb`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "metadados_ia_contrato" jsonb NOT NULL DEFAULT '{}'`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "validacao_contrato" jsonb NOT NULL DEFAULT '{}'`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "contrato_processado_em" TIMESTAMP WITH TIME ZONE`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "erro_contrato" text`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Remove novos índices de documentos
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_documentos_status_contrato"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_documentos_historico_contratos"`);

    // Remove novos campos de documentos
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "erro_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "contrato_processado_em"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "validacao_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "metadados_ia_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "snapshot_servicos_contratados"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "alteracao_aplicada_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "alteracao_proposta_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "dados_extraidos_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "versao_schema_contrato"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN IF EXISTS "tipo_documento_contratual"`);

    // Drop nova servicos_contratados
    await queryRunner.query(`DROP TABLE IF EXISTS "servicos_contratados" CASCADE`);

    // Recriar tabela antiga (estrutura original)
    await queryRunner.query(`
      CREATE TABLE "servicos_contratados" (
        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "contrato_id" uuid NOT NULL,
        "numero_de_documentos" integer,
        "numero_de_colaboradores" integer,
        "numero_de_prolabores" integer,
        "numero_de_estabelecimentos" integer,
        "base_de_calculo" text,
        "outros_servicos_contratados" jsonb,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_95b20856122d8c65a77779ea328" PRIMARY KEY ("id"),
        CONSTRAINT "FK_7ef317b5e3dc4b158a098fe5376" FOREIGN KEY ("contrato_id") REFERENCES "contratos"("id")
      )
    `);
  }
}
