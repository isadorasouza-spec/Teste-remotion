import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { Documento } from "./documento.entity.js";

export type StatusServicosContratados = "ativo" | "inativo" | "requer_revisao";

@Index("UQ_servicos_contratados_escritorio_cliente", ["escritorio_id", "cliente_id"], { unique: true })
@Entity("servicos_contratados")
export class ServicosContratados {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "text", default: "servicos_contratados.v1" })
  versao_schema!: string;

  @Column({ type: "text", default: "ativo" })
  status!: StatusServicosContratados;

  @Column({ type: "jsonb" })
  dados!: Record<string, unknown>;

  @Column({ type: "jsonb", default: {} })
  resumo_normalizado!: Record<string, unknown>;

  @Column({ type: "jsonb", default: {} })
  validacao!: Record<string, unknown>;

  @ManyToOne(() => Documento, { nullable: true })
  @JoinColumn({ name: "ultimo_documento_id" })
  ultimo_documento!: Relation<Documento | null>;

  @Column({ type: "uuid", nullable: true })
  ultimo_documento_id!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
