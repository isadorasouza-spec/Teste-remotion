import type { MigrationInterface, QueryRunner } from "typeorm";

/** Ledger tenant-scoped da ingestão canônica e vínculos idempotentes da projeção. */
export class CreateIngestaoDocumentosFiscais1791200000000 implements MigrationInterface {
  name = "CreateIngestaoDocumentosFiscais1791200000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`CREATE TABLE "lotes_ingestao_documentos_fiscais" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "simulacao_id" uuid,
      "status" varchar(20) NOT NULL DEFAULT 'armazenando',
      "total_arquivos" integer NOT NULL,
      "armazenados" integer NOT NULL DEFAULT 0,
      "carregados" integer NOT NULL DEFAULT 0,
      "projetados" integer NOT NULL DEFAULT 0,
      "duplicados" integer NOT NULL DEFAULT 0,
      "conflitos" integer NOT NULL DEFAULT 0,
      "falhas" integer NOT NULL DEFAULT 0,
      "manifesto_s3_uri" varchar(1024),
      "execucao_glue_id" varchar(255),
      "execucao_state_machine_arn" varchar(1024),
      "codigo_erro" varchar(80),
      "detalhe_erro" text,
      "concluido_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_lotes_ingestao_documentos_fiscais" PRIMARY KEY ("id"),
      CONSTRAINT "FK_lotes_ingestao_fiscal_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE CASCADE,
      CONSTRAINT "FK_lotes_ingestao_fiscal_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE SET NULL,
      CONSTRAINT "CHK_lotes_ingestao_fiscal_status" CHECK ("status" IN ('armazenando','em_fila','processando','parcial','concluido','erro')),
      CONSTRAINT "CHK_lotes_ingestao_fiscal_contadores" CHECK (
        "total_arquivos" >= 0 AND "armazenados" >= 0 AND "carregados" >= 0 AND "projetados" >= 0
        AND "duplicados" >= 0 AND "conflitos" >= 0 AND "falhas" >= 0
      )
    )`);
    await q.query(`CREATE INDEX "IDX_lotes_ingestao_fiscal_simulacao" ON "lotes_ingestao_documentos_fiscais" ("simulacao_id", "criado_em")`);
    await q.query(`CREATE INDEX "IDX_lotes_ingestao_fiscal_cliente" ON "lotes_ingestao_documentos_fiscais" ("cliente_id", "criado_em")`);

    await q.query(`CREATE TABLE "arquivos_ingestao_documentos_fiscais" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL,
      "lote_id" uuid NOT NULL,
      "nome_original" varchar(255) NOT NULL,
      "tipo_documento" varchar(20) NOT NULL DEFAULT 'desconhecido',
      "modelo" varchar(10),
      "versao_layout" varchar(30),
      "chave_acesso" varchar(64),
      "documento_canonico_id" uuid,
      "sha256" char(64) NOT NULL,
      "tamanho_bytes" bigint NOT NULL,
      "tipo_conteudo" varchar(100) NOT NULL DEFAULT 'application/xml',
      "bucket_raw" varchar(255) NOT NULL,
      "chave_raw" varchar(1024) NOT NULL,
      "bucket_normalizado" varchar(255),
      "chave_normalizado" varchar(1024),
      "status" varchar(20) NOT NULL DEFAULT 'armazenado',
      "duplicado_exato" boolean NOT NULL DEFAULT false,
      "tentativas" smallint NOT NULL DEFAULT 0,
      "execucao_glue_id" varchar(255),
      "snapshot_itens_id" bigint,
      "snapshot_totais_id" bigint,
      "quantidade_itens" integer,
      "avisos" jsonb NOT NULL DEFAULT '[]'::jsonb,
      "codigo_erro" varchar(80),
      "detalhe_erro" text,
      "processado_em" timestamptz,
      "projetado_em" timestamptz,
      "criado_em" timestamptz NOT NULL DEFAULT now(),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_arquivos_ingestao_documentos_fiscais" PRIMARY KEY ("id"),
      CONSTRAINT "FK_arquivos_ingestao_fiscal_lote" FOREIGN KEY ("lote_id") REFERENCES "lotes_ingestao_documentos_fiscais"("id") ON DELETE CASCADE,
      CONSTRAINT "CHK_arquivos_ingestao_fiscal_tipo" CHECK ("tipo_documento" IN ('nfe','nfce','nfse','cte','desconhecido')),
      CONSTRAINT "CHK_arquivos_ingestao_fiscal_status" CHECK ("status" IN ('armazenado','em_fila','processando','carregado','projetando','projetado','duplicado','conflito_conteudo','erro_tecnico','erro_validacao')),
      CONSTRAINT "CHK_arquivos_ingestao_fiscal_sha256" CHECK ("sha256" ~ '^[0-9a-f]{64}$'),
      CONSTRAINT "CHK_arquivos_ingestao_fiscal_tamanho" CHECK ("tamanho_bytes" > 0 AND "tentativas" >= 0)
    )`);
    await q.query(`CREATE INDEX "IDX_arquivos_ingestao_fiscal_lote" ON "arquivos_ingestao_documentos_fiscais" ("lote_id", "criado_em")`);
    await q.query(`CREATE INDEX "IDX_arquivos_ingestao_fiscal_checksum" ON "arquivos_ingestao_documentos_fiscais" ("escritorio_id", "cliente_id", "sha256")`);
    await q.query(`CREATE INDEX "IDX_arquivos_ingestao_fiscal_chave" ON "arquivos_ingestao_documentos_fiscais" ("escritorio_id", "cliente_id", "tipo_documento", "chave_acesso") WHERE "chave_acesso" IS NOT NULL`);

    await q.query(`ALTER TABLE "simulacao_notas_fiscais"
      ADD COLUMN "documento_canonico_id" uuid,
      ADD COLUMN "arquivo_ingestao_id" uuid,
      ADD CONSTRAINT "UQ_simulacao_notas_documento_canonico" UNIQUE ("simulacao_id", "documento_canonico_id")`);
    await q.query(`CREATE INDEX "IDX_simulacao_notas_arquivo_ingestao" ON "simulacao_notas_fiscais" ("arquivo_ingestao_id") WHERE "arquivo_ingestao_id" IS NOT NULL`);
    await q.query(`ALTER TABLE "simulacao_entradas" ADD COLUMN "item_canonico_id" uuid`);
    await q.query(`CREATE UNIQUE INDEX "UQ_simulacao_entradas_item_canonico" ON "simulacao_entradas" ("simulacao_id", "item_canonico_id") WHERE "item_canonico_id" IS NOT NULL`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP INDEX IF EXISTS "UQ_simulacao_entradas_item_canonico"`);
    await q.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "item_canonico_id"`);
    await q.query(`DROP INDEX IF EXISTS "IDX_simulacao_notas_arquivo_ingestao"`);
    await q.query(`ALTER TABLE "simulacao_notas_fiscais" DROP CONSTRAINT IF EXISTS "UQ_simulacao_notas_documento_canonico", DROP COLUMN IF EXISTS "arquivo_ingestao_id", DROP COLUMN IF EXISTS "documento_canonico_id"`);
    await q.query(`DROP TABLE "arquivos_ingestao_documentos_fiscais"`);
    await q.query(`DROP TABLE "lotes_ingestao_documentos_fiscais"`);
  }
}
