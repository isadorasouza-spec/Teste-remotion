import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddLinhagemValoresACobrar1778700000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS linhagem JSONB NOT NULL DEFAULT '{"contrato":null,"relatorios":[],"faturamento":[],"gerado_em":null}';
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS linhagem;
    `);
  }
}
