import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import type { ProvedorAssinaturaEletronica } from "./conexao-assinatura-eletronica.entity.js";

export type StatusEnvelopeAssinatura =
  | "descoberto"
  | "aguardando_revisao"
  | "sincronizando"
  | "sincronizado"
  | "processando"
  | "importando"
  | "importado"
  | "ignorado"
  | "erro";

export type ParticipanteAssinatura = {
  nome: string | null;
  email: string | null;
  status: string | null;
};

@Index("UQ_envelopes_assinatura_externo", ["escritorio_id", "provedor", "envelope_id_externo"], { unique: true })
@Index("IDX_envelopes_assinatura_fila", ["escritorio_id", "status_interno", "concluido_em"])
@Entity("envelopes_assinatura_eletronica")
export class EnvelopeAssinaturaEletronica {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "text" }) provedor!: ProvedorAssinaturaEletronica;
  @Column({ type: "text" }) envelope_id_externo!: string;
  @Column({ type: "text" }) status_provedor!: string;
  @Column({ type: "text", default: "descoberto" }) status_interno!: StatusEnvelopeAssinatura;
  @Column({ type: "text", nullable: true }) assunto!: string | null;
  @Column({ type: "text", nullable: true }) remetente_nome!: string | null;
  @Column({ type: "text", nullable: true }) remetente_email!: string | null;
  @Column({ type: "jsonb", default: [] }) participantes!: ParticipanteAssinatura[];
  @Column({ type: "timestamptz", nullable: true }) criado_no_provedor_em!: Date | null;
  @Column({ type: "timestamptz", nullable: true }) concluido_em!: Date | null;
  @Column({ type: "uuid", nullable: true }) cliente_sugerido_id!: string | null;
  @Column({ type: "text", nullable: true }) motivo_sugestao!: string | null;
  @Column({ type: "uuid", nullable: true }) documento_id!: string | null;
  @Column({ type: "text", nullable: true }) documento_s3_key!: string | null;
  @Column({ type: "text", nullable: true }) documento_checksum!: string | null;
  @Column({ type: "bigint", nullable: true }) documento_size_bytes!: string | null;
  @Column({ type: "text", nullable: true }) documento_mime_type!: string | null;
  @Column({ type: "timestamptz", nullable: true }) sincronizado_em!: Date | null;
  @Column({ type: "text", nullable: true }) certificado_s3_key!: string | null;
  @Column({ type: "jsonb", nullable: true }) metadados_provedor!: Record<string, unknown> | null;
  @Column({ type: "text", nullable: true }) ultimo_erro!: string | null;
  @CreateDateColumn({ type: "timestamptz" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamptz" }) updated_at!: Date;
}
