import type { MigrationInterface, QueryRunner } from 'typeorm';
/** Aditiva: artefato legado preservado; somente o worker publica a projeção nova. */
export class PaginarCalculosSimulacoes1793100000000 implements MigrationInterface {
    name = 'PaginarCalculosSimulacoes1793100000000';
    async up(q: QueryRunner): Promise<void> {
        await q.query(`ALTER TABLE "simulacao_calculos" ADD COLUMN "resumo_editor" jsonb`);
        await q.query(`CREATE TABLE "simulacao_calculo_entradas" (
      "simulacao_id" uuid NOT NULL, "entrada_id" uuid NOT NULL, "escritorio_id" uuid NOT NULL,
      "calculada" jsonb NOT NULL,
      CONSTRAINT "PK_simulacao_calculo_entradas" PRIMARY KEY ("simulacao_id", "entrada_id"),
      CONSTRAINT "FK_simulacao_calculo_entradas_calculo" FOREIGN KEY ("simulacao_id")
        REFERENCES "simulacao_calculos"("simulacao_id") ON DELETE CASCADE
    )`);
        await q.query(`ALTER TABLE "simulacao_calculo_entradas" ENABLE ROW LEVEL SECURITY`);
        await q.query(`ALTER TABLE "simulacao_calculo_entradas" FORCE ROW LEVEL SECURITY`);
        await q.query(`CREATE POLICY "isolamento_escritorio" ON "simulacao_calculo_entradas"
      USING ("escritorio_id" = nullif(current_setting('app.escritorio_id', true), '')::uuid)
      WITH CHECK ("escritorio_id" = nullif(current_setting('app.escritorio_id', true), '')::uuid)`);
    }
    async down(q: QueryRunner): Promise<void> {
        await q.query(`DROP TABLE "simulacao_calculo_entradas"`);
        await q.query(`ALTER TABLE "simulacao_calculos" DROP COLUMN "resumo_editor"`);
    }
}
