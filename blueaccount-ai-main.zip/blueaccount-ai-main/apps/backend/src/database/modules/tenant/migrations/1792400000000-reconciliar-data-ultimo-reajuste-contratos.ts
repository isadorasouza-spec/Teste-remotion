import type { MigrationInterface, QueryRunner } from "typeorm";

/** Corrige tenants que registraram a migration histórica sem esta coluna. */
export class ReconciliarDataUltimoReajusteContratos1792400000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE contratos ADD COLUMN IF NOT EXISTS data_ultimo_reajuste DATE;
    `);
  }

  async down(): Promise<void> {
    // A coluna pertence à migration 1784300000001 e pode preexistir a este reparo.
    // Não apagar datas de reajuste nem desfazer o contrato histórico da entidade.
  }
}
