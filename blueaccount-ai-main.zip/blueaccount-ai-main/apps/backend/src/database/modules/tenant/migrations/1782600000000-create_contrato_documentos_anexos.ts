import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateContratoDocumentosAnexos1782600000000 implements MigrationInterface {
  name = "CreateContratoDocumentosAnexos1782600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "contrato_documentos_anexos" (
        "id" uuid NOT NULL DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "contrato_id" uuid NOT NULL,
        "documento_id" uuid NOT NULL,
        "tipo_documento_contratual" text NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_contrato_documentos_anexos" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_contrato_documentos_anexos_documento" UNIQUE ("documento_id"),
        CONSTRAINT "FK_contrato_documentos_anexos_contrato" FOREIGN KEY ("contrato_id") REFERENCES "contratos"("id") ON DELETE CASCADE ON UPDATE NO ACTION,
        CONSTRAINT "FK_contrato_documentos_anexos_documento" FOREIGN KEY ("documento_id") REFERENCES "documentos"("id") ON DELETE CASCADE ON UPDATE NO ACTION
      )
    `);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_contrato_documentos_anexos_contrato" ON "contrato_documentos_anexos" ("contrato_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_contrato_documentos_anexos_contrato"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "contrato_documentos_anexos"`);
  }
}
