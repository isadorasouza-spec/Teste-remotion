import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddStripePlatformSupport1781500000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE plataformas_cobranca
        ADD COLUMN IF NOT EXISTS webhook_secret_encrypted TEXT,
        ADD COLUMN IF NOT EXISTS webhook_secret_iv TEXT,
        ADD COLUMN IF NOT EXISTS webhook_secret_tag TEXT,
        ADD COLUMN IF NOT EXISTS webhook_secret_hint TEXT;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE plataformas_cobranca
        DROP COLUMN IF EXISTS webhook_secret_hint,
        DROP COLUMN IF EXISTS webhook_secret_tag,
        DROP COLUMN IF EXISTS webhook_secret_iv,
        DROP COLUMN IF EXISTS webhook_secret_encrypted;
    `);
  }
}
