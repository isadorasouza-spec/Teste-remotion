import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Renomeia o status "aprovado_para_emissao" para "pronto_para_revisao": o valor
 * nunca significou aprovação humana — o cálculo automático do agente chega
 * direto nesse estado sem revisão alguma; só a emissão de fato aprova/despacha
 * a cobrança.
 */
export class RenameAprovadoParaEmissaoStatus1785800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE valores_a_cobrar SET status = 'pronto_para_revisao' WHERE status = 'aprovado_para_emissao'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE valores_a_cobrar SET status = 'aprovado_para_emissao' WHERE status = 'pronto_para_revisao'
    `);
  }
}
