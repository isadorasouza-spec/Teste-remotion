import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddPoliticasAcumuladoresCliente1790200000000 implements MigrationInterface {
  name = "AddPoliticasAcumuladoresCliente1790200000000";

  async up(q: QueryRunner): Promise<void> {
    await q.query(`ALTER TABLE "acumuladores_simulacao" ADD COLUMN "tratamento_ibs_cbs_padrao" varchar(20) NOT NULL DEFAULT 'padrao', ADD COLUMN "percentual_reducao_ibs_cbs_padrao" numeric(5,4), ADD CONSTRAINT "CHK_acumuladores_tratamento_ibs_cbs" CHECK ("tratamento_ibs_cbs_padrao" IN ('padrao','reduzida','aliquota_zero','exportacao')), ADD CONSTRAINT "CHK_acumuladores_percentual_reducao" CHECK ("percentual_reducao_ibs_cbs_padrao" IS NULL OR "percentual_reducao_ibs_cbs_padrao" BETWEEN 0 AND 1)`);
    await q.query(`CREATE TABLE "acumuladores_simulacao_cliente" (
      "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "escritorio_id" uuid NOT NULL,
      "cliente_id" uuid NOT NULL, "acumulador_id" uuid NOT NULL, "ativo" boolean,
      "tipo" varchar(10), "tratamento_ibs_cbs" varchar(20),
      "modo_fator_ibs" varchar(8) NOT NULL DEFAULT 'herdar', "fator_ibs" numeric(7,6),
      "modo_fator_cbs" varchar(8) NOT NULL DEFAULT 'herdar', "fator_cbs" numeric(7,6),
      "modo_percentual_reducao" varchar(8) NOT NULL DEFAULT 'herdar', "percentual_reducao_ibs_cbs" numeric(5,4),
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "UQ_acumuladores_simulacao_cliente" UNIQUE ("cliente_id","acumulador_id"),
      CONSTRAINT "FK_acumulador_cliente_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE CASCADE,
      CONSTRAINT "FK_acumulador_cliente_acumulador" FOREIGN KEY ("acumulador_id") REFERENCES "acumuladores_simulacao"("id") ON DELETE CASCADE,
      CONSTRAINT "CHK_acumulador_cliente_tipo" CHECK ("tipo" IS NULL OR "tipo" IN ('receita','custo')),
      CONSTRAINT "CHK_acumulador_cliente_tratamento" CHECK ("tratamento_ibs_cbs" IS NULL OR "tratamento_ibs_cbs" IN ('padrao','reduzida','aliquota_zero','exportacao')),
      CONSTRAINT "CHK_acumulador_cliente_modos" CHECK ("modo_fator_ibs" IN ('herdar','limpar','valor') AND "modo_fator_cbs" IN ('herdar','limpar','valor') AND "modo_percentual_reducao" IN ('herdar','limpar','valor')),
      CONSTRAINT "CHK_acumulador_cliente_fatores" CHECK ((("modo_fator_ibs" = 'valor') = ("fator_ibs" IS NOT NULL)) AND ("fator_ibs" IS NULL OR "fator_ibs" BETWEEN 0 AND 1) AND (("modo_fator_cbs" = 'valor') = ("fator_cbs" IS NOT NULL)) AND ("fator_cbs" IS NULL OR "fator_cbs" BETWEEN 0 AND 1) AND (("modo_percentual_reducao" = 'valor') = ("percentual_reducao_ibs_cbs" IS NOT NULL)) AND ("percentual_reducao_ibs_cbs" IS NULL OR "percentual_reducao_ibs_cbs" BETWEEN 0 AND 1))
    )`);
    await q.query(`CREATE INDEX "IDX_acumuladores_simulacao_cliente_escritorio" ON "acumuladores_simulacao_cliente" ("escritorio_id")`);
    await q.query(`CREATE TABLE "simulacao_entradas_excluidas" (
      "id" uuid PRIMARY KEY DEFAULT uuid_generate_v7(), "escritorio_id" uuid NOT NULL,
      "simulacao_id" uuid NOT NULL, "documento_origem_id" uuid, "documento_origem_referencia" uuid NOT NULL, "acumulador_id" uuid NOT NULL,
      "ordem_origem" int NOT NULL, "valor" numeric(14,2) NOT NULL,
      "motivo" varchar(40) NOT NULL DEFAULT 'acumulador_inativo', "status" varchar(12) NOT NULL DEFAULT 'excluida',
      "linha_normalizada" jsonb NOT NULL, "politica_aplicada" jsonb NOT NULL,
      "entrada_resultante_id" uuid, "incluido_at" timestamptz,
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "UQ_simulacao_entradas_excluidas_simulacao_documento_ordem" UNIQUE ("simulacao_id","documento_origem_referencia","ordem_origem"),
      CONSTRAINT "FK_entrada_excluida_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE,
      CONSTRAINT "FK_entrada_excluida_documento" FOREIGN KEY ("documento_origem_id") REFERENCES "documentos"("id") ON DELETE SET NULL,
      CONSTRAINT "FK_entrada_excluida_acumulador" FOREIGN KEY ("acumulador_id") REFERENCES "acumuladores_simulacao"("id") ON DELETE RESTRICT,
      CONSTRAINT "FK_entrada_excluida_resultante" FOREIGN KEY ("entrada_resultante_id") REFERENCES "simulacao_entradas"("id") ON DELETE SET NULL,
      CONSTRAINT "CHK_entrada_excluida_status" CHECK ("status" IN ('excluida','incluida'))
    )`);
    await q.query(`CREATE INDEX "IDX_simulacao_entradas_excluidas_grupo" ON "simulacao_entradas_excluidas" ("simulacao_id","acumulador_id","status")`);
    await q.query(`CREATE INDEX "IDX_simulacao_entradas_excluidas_escritorio" ON "simulacao_entradas_excluidas" ("escritorio_id")`);
  }

  async down(q: QueryRunner): Promise<void> {
    await q.query(`DROP TABLE "simulacao_entradas_excluidas"`);
    await q.query(`DROP TABLE "acumuladores_simulacao_cliente"`);
    await q.query(`ALTER TABLE "acumuladores_simulacao" DROP CONSTRAINT "CHK_acumuladores_percentual_reducao", DROP CONSTRAINT "CHK_acumuladores_tratamento_ibs_cbs", DROP COLUMN "percentual_reducao_ibs_cbs_padrao", DROP COLUMN "tratamento_ibs_cbs_padrao"`);
  }
}
