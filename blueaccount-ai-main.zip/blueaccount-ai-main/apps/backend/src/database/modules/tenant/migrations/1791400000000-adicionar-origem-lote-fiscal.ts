import type { MigrationInterface, QueryRunner } from "typeorm";

/** SQL gerado em memória pelo PostgresQueryRunner e revisado; preserva os lotes existentes. */
export class AdicionarOrigemLoteFiscal1791400000000 implements MigrationInterface {
  name = "AdicionarOrigemLoteFiscal1791400000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "lotes_ingestao_documentos_fiscais" ADD "origem" varchar(20) NOT NULL DEFAULT 'upload_manual'`);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query('ALTER TABLE "lotes_ingestao_documentos_fiscais" DROP COLUMN "origem"');
  }
}
