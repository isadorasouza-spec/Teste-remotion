import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Reaplica o catálogo público a todo fator cuja origem já é `ncm`. Valores manuais, de acumulador e
 * de tratamento não são tocados. O longest-prefix match preserva exceções filhas sobre regras-pai.
 */
export class ReconciliarFatoresNcmSimulacoes1788900000000 implements MigrationInterface {
  name = "ReconciliarFatoresNcmSimulacoes1788900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    for (const tributo of ["ibs", "cbs"] as const) {
      await queryRunner.query(`
        UPDATE "simulacao_entradas" AS entrada
        SET "fator_${tributo}" = COALESCE((
          SELECT regra."fator_${tributo}"
          FROM public."ncms_referencia" AS regra
          WHERE regra."fatores_configurados" = true
            AND entrada."ncm" LIKE regra."codigo" || '%'
          ORDER BY length(regra."codigo") DESC, regra."codigo" ASC
          LIMIT 1
        ), 1)
        WHERE entrada."origem_fator_${tributo}" = 'ncm'
          AND entrada."ncm" IS NOT NULL
      `);
    }
  }

  public async down(): Promise<void> {
    // Reconciliação de dados derivada do catálogo: não há estado anterior seguro para reconstruir.
  }
}
