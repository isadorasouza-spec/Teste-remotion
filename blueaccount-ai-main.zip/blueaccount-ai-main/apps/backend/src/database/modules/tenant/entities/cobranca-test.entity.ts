import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { ValoresACobrar } from "./valores-a-cobrar.entity.js";

export type StatusCobrancaTest = "em_processamento" | "aprovado" | "reprovado" | "erro";

@Index("IDX_cobranca_tests_valor_a_cobrar", ["valor_a_cobrar_id"])
@Index("IDX_cobranca_tests_escritorio_created", ["escritorio_id", "created_at"])
@Entity("cobranca_tests")
export class CobrancaTest {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => ValoresACobrar, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "valor_a_cobrar_id" })
  valor_a_cobrar!: Relation<ValoresACobrar>;

  @Column({ type: "uuid" })
  valor_a_cobrar_id!: string;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "varchar", length: 7 })
  competencia!: string;

  @Column({ type: "varchar", length: 20, default: "em_processamento" })
  status!: StatusCobrancaTest;

  @Column({ type: "text", nullable: true })
  agent_trace_id!: string | null;

  @Column({ type: "text", nullable: true })
  agent_output_s3_uri!: string | null;

  @Column({ type: "text", nullable: true })
  agent_response!: string | null;

  @Column({ type: "jsonb", nullable: true })
  target!: Record<string, unknown> | null;

  @Column({ type: "text" })
  grading_instructions!: string;

  @Column({ type: "integer", nullable: true })
  grade!: number | null;

  @Column({ type: "text", nullable: true })
  explanation!: string | null;

  @Column({ type: "jsonb", nullable: true })
  grader_raw_response!: Record<string, unknown> | null;

  @Column({ type: "text", nullable: true })
  erro!: string | null;

  @Column({ type: "timestamp" })
  started_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  finished_at!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
