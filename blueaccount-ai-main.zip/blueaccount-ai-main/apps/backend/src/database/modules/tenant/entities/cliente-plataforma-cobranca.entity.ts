import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { PlataformaCobranca } from "./plataforma-cobranca.entity.js";

@Index("UQ_cliente_plataforma", ["cliente_id", "plataforma_id"], { unique: true })
@Entity("clientes_plataforma_cobranca")
export class ClientePlataformaCobranca {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @ManyToOne(() => PlataformaCobranca, { nullable: false })
  @JoinColumn({ name: "plataforma_id" })
  plataforma!: Relation<PlataformaCobranca>;

  @Column({ type: "uuid" })
  plataforma_id!: string;

  @Column({ type: "text" })
  id_externo_cliente!: string;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
