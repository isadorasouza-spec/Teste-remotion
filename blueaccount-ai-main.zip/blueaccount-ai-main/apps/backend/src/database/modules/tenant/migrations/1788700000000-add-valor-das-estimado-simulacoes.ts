import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddValorDasEstimadoSimulacoes1788700000000 implements MigrationInterface {
  name = "AddValorDasEstimadoSimulacoes1788700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "valor_das_estimado" numeric(14,2),
        ADD CONSTRAINT "ck_simulacoes_valor_das_estimado_nao_negativo"
          CHECK ("valor_das_estimado" IS NULL OR "valor_das_estimado" >= 0)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP CONSTRAINT "ck_simulacoes_valor_das_estimado_nao_negativo",
        DROP COLUMN "valor_das_estimado"
    `);
  }
}
