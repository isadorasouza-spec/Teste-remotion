import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Componentes do valor da operação da linha importada de NF-e (art. 12 da LC 214/2025: base = tudo
 * cobrado do adquirente, incluindo frete cobrado pelo fornecedor/por sua conta e ordem) — ver
 * `domain/simulacoes/nfe/mapeador.ts` e `domain/simulacoes/README.md`.
 *
 * Sem backfill e sem recálculo de propósito: linhas já importadas continuam com `valor_produtos`
 * nulo (o discriminador de "linha pré-fix" documentado na entidade), e reprocessar exigiria reler o
 * XML original — mesma decisão de `1791300000000-ampliar-chave-nfse-nacional`.
 */
export class AdicionarComposicaoValorOperacaoEntrada1792500000000 implements MigrationInterface {
  name = "AdicionarComposicaoValorOperacaoEntrada1792500000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "valor_produtos" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "valor_frete" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "valor_seguro" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "valor_outros" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "valor_desconto" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "revisao_composicao_valor" boolean NOT NULL DEFAULT false;
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
        ADD COLUMN IF NOT EXISTS "valor_frete" numeric(14,2),
        ADD COLUMN IF NOT EXISTS "modalidade_frete" smallint;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP COLUMN IF EXISTS "valor_produtos",
        DROP COLUMN IF EXISTS "valor_frete",
        DROP COLUMN IF EXISTS "valor_seguro",
        DROP COLUMN IF EXISTS "valor_outros",
        DROP COLUMN IF EXISTS "valor_desconto",
        DROP COLUMN IF EXISTS "revisao_composicao_valor";
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_notas_fiscais"
        DROP COLUMN IF EXISTS "valor_frete",
        DROP COLUMN IF EXISTS "modalidade_frete";
    `);
  }
}
