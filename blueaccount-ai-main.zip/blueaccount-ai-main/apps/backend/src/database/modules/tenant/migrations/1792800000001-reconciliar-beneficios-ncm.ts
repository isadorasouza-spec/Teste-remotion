import type { MigrationInterface, QueryRunner } from "typeorm";

/** Reaplica somente origens NCM e invalida/enfileira resultados e cópias vinculadas. */
export class ReconciliarBeneficiosNcm1792800000001 implements MigrationInterface {
  name = "ReconciliarBeneficiosNcm1792800000001";

  async up(queryRunner: QueryRunner): Promise<void> {
    const revisao = await queryRunner.query(`SELECT to_regclass('public.ncms_revisao_20260916') AS tabela`);
    if (!revisao[0]?.tabela) throw new Error("Aplicar primeiro a revisão pública dos benefícios NCM.");
    await queryRunner.query(`SELECT id FROM simulacoes ORDER BY id FOR UPDATE`);
    const contexto = await queryRunner.query(`SELECT current_setting('app.escritorio_id', true) AS id`);
    const alteradas = await queryRunner.query(`WITH fatores AS (
      SELECT e.id,
        CASE WHEN e.origem_fator_ibs = 'ncm' THEN
          CASE WHEN r.aplicacao_automatica THEN r.fator_ibs ELSE 1 END ELSE e.fator_ibs END AS ibs,
        CASE WHEN e.origem_fator_cbs = 'ncm' THEN
          CASE WHEN r.aplicacao_automatica THEN r.fator_cbs ELSE 1 END ELSE e.fator_cbs END AS cbs
      FROM simulacao_entradas e LEFT JOIN LATERAL (
        SELECT fator_ibs, fator_cbs, aplicacao_automatica FROM public.ncms_referencia
        WHERE fatores_configurados AND e.ncm LIKE codigo || '%'
        ORDER BY length(codigo) DESC, codigo LIMIT 1
      ) r ON true
      WHERE e.ncm IS NOT NULL AND (e.origem_fator_ibs = 'ncm' OR e.origem_fator_cbs = 'ncm')
    ), atualizadas AS (
      UPDATE simulacao_entradas e SET fator_ibs = f.ibs, fator_cbs = f.cbs
      FROM fatores f WHERE e.id = f.id
        AND (e.fator_ibs IS DISTINCT FROM f.ibs OR e.fator_cbs IS DISTINCT FROM f.cbs)
      RETURNING e.simulacao_id, e.escritorio_id
    ) SELECT DISTINCT simulacao_id, escritorio_id FROM atualizadas`);
    for (const escritorioId of new Set<string>(alteradas.map((r: { escritorio_id: string }) => r.escritorio_id))) {
      const ids = alteradas.filter((r: { escritorio_id: string }) => r.escritorio_id === escritorioId)
        .map((r: { simulacao_id: string }) => r.simulacao_id);
      const afetadas = await queryRunner.query(`WITH RECURSIVE afetadas AS (
        SELECT id FROM simulacoes WHERE escritorio_id = $1 AND id = ANY($2::uuid[])
        UNION SELECT s.id FROM simulacoes s JOIN afetadas a ON s.simulacao_origem_id = a.id
          WHERE s.escritorio_id = $1
      ) SELECT id FROM afetadas`, [escritorioId, ids]);
      const alvos = afetadas.map((r: { id: string }) => r.id);
      await queryRunner.query(`SELECT set_config('app.escritorio_id', $1, true)`, [escritorioId]);
      await queryRunner.query(`SELECT public.enfileirar_calculos_simulacao($1::uuid, $2::uuid[], true)`, [escritorioId, alvos]);
      await queryRunner.query(`UPDATE simulacoes SET status_calculo = 'na_fila',
        calculo_solicitado_em = now(), calculo_iniciado_em = NULL, erro_calculo = NULL
        WHERE escritorio_id = $1 AND id = ANY($2::uuid[])`, [escritorioId, alvos]);
    }
    await queryRunner.query(`SELECT set_config('app.escritorio_id', $1, true)`, [contexto[0]?.id ?? ""]);
  }

  async down(): Promise<void> {
    throw new Error("Não restaurar fatores fiscais incorretos; revisar catálogo e reconciliar novamente.");
  }
}
