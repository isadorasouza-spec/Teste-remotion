import { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoValorMensal1777800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "contratos"
      ADD COLUMN IF NOT EXISTS "valor_mensal" numeric(12,2) NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "contratos" DROP COLUMN IF EXISTS "valor_mensal"
    `);
  }
}
