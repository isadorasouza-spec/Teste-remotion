import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddOrigemFatoresNcmSimulacao1787900000000 implements MigrationInterface {
  name = "AddOrigemFatoresNcmSimulacao1787900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      ADD "origem_fator_ibs" varchar(20) NOT NULL DEFAULT 'tratamento',
      ADD "origem_fator_cbs" varchar(20) NOT NULL DEFAULT 'tratamento'`);
    await queryRunner.query(`UPDATE "simulacao_entradas"
      SET "origem_fator_ibs" = CASE WHEN "fator_ibs" IS NULL THEN 'tratamento' ELSE 'manual' END,
          "origem_fator_cbs" = CASE WHEN "fator_cbs" IS NULL THEN 'tratamento' ELSE 'manual' END`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_ibs" CHECK ("origem_fator_ibs" IN ('manual','ncm','acumulador','tratamento')),
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_cbs" CHECK ("origem_fator_cbs" IN ('manual','ncm','acumulador','tratamento'))`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      DROP CONSTRAINT "CHK_simulacao_entradas_origem_fator_cbs",
      DROP CONSTRAINT "CHK_simulacao_entradas_origem_fator_ibs",
      DROP COLUMN "origem_fator_cbs",
      DROP COLUMN "origem_fator_ibs"`);
  }
}
