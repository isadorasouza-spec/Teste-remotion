import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type ConectorSharePointStatus = "conectado" | "reconexao_necessaria" | "revogado" | "erro";

@Index("UQ_conector_sharepoint_conexao_escritorio", ["escritorio_id"], { unique: true })
@Entity("conector_sharepoint_conexoes")
export class ConectorSharePointConexao {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "text", nullable: true }) url_pasta!: string | null;
  @Column({ type: "text", nullable: true }) site_id!: string | null;
  @Column({ type: "text", nullable: true }) drive_id!: string | null;
  @Column({ type: "text", nullable: true }) root_item_id!: string | null;
  @Column({ type: "text", nullable: true }) microsoft_tenant_id!: string | null;
  @Column({ type: "text", nullable: true }) microsoft_account_id!: string | null;
  @Column({ type: "text", nullable: true }) microsoft_account_email!: string | null;
  @Column({ type: "text", default: "erro" }) status!: ConectorSharePointStatus;
  @Column({ type: "boolean", default: false }) ativo!: boolean;
  @Column({ type: "text", nullable: true }) access_token_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) access_token_iv!: string | null;
  @Column({ type: "text", nullable: true }) access_token_tag!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_iv!: string | null;
  @Column({ type: "text", nullable: true }) refresh_token_tag!: string | null;
  @Column({ type: "timestamptz", nullable: true }) access_token_expires_at!: Date | null;
  @Column({ type: "uuid", nullable: true }) conectado_por_usuario_id!: string | null;
  @Column({ type: "uuid", nullable: true }) reconectado_por_usuario_id!: string | null;
  @Column({ type: "text", nullable: true }) ultimo_erro!: string | null;

  // Material temporário do OAuth. Não altera a conexão ativa antes da validação.
  @Column({ type: "text", nullable: true }) oauth_nonce_hash!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_encrypted!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_iv!: string | null;
  @Column({ type: "text", nullable: true }) oauth_pkce_verifier_tag!: string | null;
  @Column({ type: "timestamptz", nullable: true }) oauth_expires_at!: Date | null;
  @Column({ type: "text", nullable: true }) oauth_url_pasta!: string | null;

  @CreateDateColumn({ type: "timestamptz" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamptz" }) updated_at!: Date;
}
