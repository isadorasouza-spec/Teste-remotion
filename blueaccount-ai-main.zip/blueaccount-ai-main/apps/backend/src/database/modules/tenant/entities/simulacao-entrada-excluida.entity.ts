import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn, type Relation } from "typeorm";
import { Simulacao } from "./simulacao.entity.js";
import { Documento } from "./documento.entity.js";
import { AcumuladorSimulacao } from "./acumulador-simulacao.entity.js";
import { SimulacaoEntrada } from "./simulacao-entrada.entity.js";

export type StatusEntradaExcluida = "excluida" | "incluida";

@Index("UQ_simulacao_entradas_excluidas_simulacao_documento_ordem", ["simulacao_id", "documento_origem_referencia", "ordem_origem"], { unique: true })
@Index("IDX_simulacao_entradas_excluidas_grupo", ["simulacao_id", "acumulador_id", "status"])
@Entity("simulacao_entradas_excluidas")
export class SimulacaoEntradaExcluida {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) simulacao_id!: string;
  @ManyToOne(() => Simulacao, { onDelete: "CASCADE" }) @JoinColumn({ name: "simulacao_id" }) simulacao!: Relation<Simulacao>;
  @Column({ type: "uuid", nullable: true }) documento_origem_id!: string | null;
  @ManyToOne(() => Documento, { nullable: true, onDelete: "SET NULL" }) @JoinColumn({ name: "documento_origem_id" }) documento_origem!: Relation<Documento> | null;
  @Column({ type: "uuid" }) documento_origem_referencia!: string;
  @Column({ type: "uuid" }) acumulador_id!: string;
  @ManyToOne(() => AcumuladorSimulacao, { onDelete: "RESTRICT" }) @JoinColumn({ name: "acumulador_id" }) acumulador!: Relation<AcumuladorSimulacao>;
  @Column({ type: "int" }) ordem_origem!: number;
  @Column({ type: "decimal", precision: 14, scale: 2 }) valor!: number;
  @Column({ type: "varchar", length: 40, default: "acumulador_inativo" }) motivo!: string;
  @Column({ type: "varchar", length: 12, default: "excluida" }) status!: StatusEntradaExcluida;
  @Column({ type: "jsonb" }) linha_normalizada!: Record<string, unknown>;
  @Column({ type: "jsonb" }) politica_aplicada!: Record<string, unknown>;
  @Column({ type: "uuid", nullable: true }) entrada_resultante_id!: string | null;
  @ManyToOne(() => SimulacaoEntrada, { nullable: true, onDelete: "SET NULL" }) @JoinColumn({ name: "entrada_resultante_id" }) entrada_resultante!: Relation<SimulacaoEntrada> | null;
  @Column({ type: "timestamptz", nullable: true }) incluido_at!: Date | null;
  @CreateDateColumn() created_at!: Date;
  @UpdateDateColumn() updated_at!: Date;
}
