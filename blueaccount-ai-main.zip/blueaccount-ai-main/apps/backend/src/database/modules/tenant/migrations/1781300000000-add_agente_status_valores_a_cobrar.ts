import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Geração de cobrança via agente AgentCore passou a ser assíncrona (disparo +
 * callback). Estes campos rastreiam o ciclo de vida dessa execução, separados do
 * `status` de negócio:
 * - `agente_status`: em_processamento | concluido | erro
 * - `agente_trace_id`: correlação/idempotência do disparo em curso
 * - `agente_erro`: mensagem de falha
 * - `agente_iniciado_em`: quando o disparo começou (observabilidade/reconciliação)
 */
export class AddAgenteStatusValoresACobrar1781300000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS agente_status VARCHAR(20) NULL,
        ADD COLUMN IF NOT EXISTS agente_trace_id TEXT NULL,
        ADD COLUMN IF NOT EXISTS agente_erro TEXT NULL,
        ADD COLUMN IF NOT EXISTS agente_iniciado_em TIMESTAMP NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS agente_status,
        DROP COLUMN IF EXISTS agente_trace_id,
        DROP COLUMN IF EXISTS agente_erro,
        DROP COLUMN IF EXISTS agente_iniciado_em
    `);
  }
}
