import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCobrancaTests1782100000000 implements MigrationInterface {
  name = "CreateCobrancaTests1782100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS cobranca_tests (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        valor_a_cobrar_id UUID NOT NULL REFERENCES valores_a_cobrar(id) ON DELETE CASCADE,
        cliente_id UUID NOT NULL,
        competencia VARCHAR(7) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'em_processamento',
        agent_trace_id TEXT NULL,
        agent_output_s3_uri TEXT NULL,
        agent_response TEXT NULL,
        target JSONB NULL,
        grading_instructions TEXT NOT NULL,
        grade INTEGER NULL,
        explanation TEXT NULL,
        grader_raw_response JSONB NULL,
        erro TEXT NULL,
        started_at TIMESTAMP NOT NULL DEFAULT NOW(),
        finished_at TIMESTAMP NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_cobranca_tests_valor_a_cobrar
        ON cobranca_tests (valor_a_cobrar_id);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_cobranca_tests_escritorio_created
        ON cobranca_tests (escritorio_id, created_at DESC);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_cobranca_tests_escritorio_created;`);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_cobranca_tests_valor_a_cobrar;`);
    await queryRunner.query(`DROP TABLE IF EXISTS cobranca_tests;`);
  }
}
