import type { MigrationInterface, QueryRunner } from "typeorm";

// Gerada do modelo de recepção mensal e dos campos acrescentados ao registro; sem backfill.
export class ReceberResumosOperacionais1792700000000 implements MigrationInterface {
 name = "ReceberResumosOperacionais1792700000000";
 async up(q: QueryRunner): Promise<void> {
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "origem_conteudo" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "classificacao_origem" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "uf" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "requer_revisao" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "motivo_revisao" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "premissa_icms_origem" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "versao_extrator" text`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "credito_pis_cofins" numeric(28,10)`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "debito_pis_cofins" numeric(28,10)`);
  await q.query(`ALTER TABLE registros_operacionais ADD COLUMN "quantidade_documentos" numeric(28,10)`);
  await q.query(`CREATE TABLE importacoes_operacionais_mensais (
 escritorio_id uuid NOT NULL, cliente_id uuid NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
 chave_escopo text NOT NULL, importacao_id uuid NOT NULL, extraido_em timestamptz NOT NULL,
 hash_esperado text NOT NULL, total_registros integer NOT NULL CHECK (total_registros BETWEEN 0 AND 10000),
 total_lotes integer NOT NULL CHECK (total_lotes BETWEEN 1 AND 1000), lotes jsonb NOT NULL DEFAULT '{}',
 publicado_em timestamptz, hash_publicado text,
 PRIMARY KEY(escritorio_id, cliente_id, chave_escopo))`);
  await q.query(`ALTER TABLE importacoes_operacionais_mensais ENABLE ROW LEVEL SECURITY`);
  await q.query(`ALTER TABLE importacoes_operacionais_mensais FORCE ROW LEVEL SECURITY`);
  await q.query(`CREATE POLICY isolamento_escritorio ON importacoes_operacionais_mensais
 USING (escritorio_id = nullif(current_setting('app.escritorio_id', true), '')::uuid)
 WITH CHECK (escritorio_id = nullif(current_setting('app.escritorio_id', true), '')::uuid)`);
  await q.query(`CREATE INDEX IDX_registros_operacionais_competencia ON registros_operacionais(cliente_id, competencia_origem)`);
 }
 async down(q: QueryRunner): Promise<void> {
  await q.query('DROP TABLE importacoes_operacionais_mensais');
  await q.query('DROP INDEX IDX_registros_operacionais_competencia');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "origem_conteudo"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "classificacao_origem"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "uf"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "requer_revisao"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "motivo_revisao"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "premissa_icms_origem"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "versao_extrator"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "credito_pis_cofins"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "debito_pis_cofins"');
  await q.query('ALTER TABLE registros_operacionais DROP COLUMN "quantidade_documentos"');
 }
}
