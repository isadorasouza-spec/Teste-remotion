import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `transferencia_intragrupo` em `simulacao_entradas`: gate único e explícito para transferência
 * entre estabelecimentos da MESMA empresa (matriz/filial, mesma raiz de CNPJ, ADC 49/STF — ver
 * `domain/simulacoes/nfe/classificador.ts`). Hoje essa condição já era gravada, mas só de forma
 * IMPLÍCITA, por três campos coincidentes (`aliquota_icms_override: 0` + `regra_credito:
 * sem_credito` + `tratamento_icms: sem_efeito`) que a importação de NF-e grava juntos. Esta coluna
 * dá um nome explícito a essa condição, no mesmo espírito do interruptor único `simulacoes.uf`.
 *
 * Motivo imediato: é o gate que sempre desliga DIFAL (diferencial de alíquota) de uma linha, mesmo
 * interestadual e do tipo certo — ver `domain/simulacoes/calculo.ts` → `calcularEntrada` e
 * `domain/simulacoes/README.md` → "DIFAL (diferencial de alíquota)".
 *
 * `BOOLEAN NOT NULL DEFAULT false`, mesmo padrão já usado em `simulacao_entradas`/`valores_a_cobrar`
 * para colunas booleanas (ver `1781700000000-add_precisa_clarificacao_valores_a_cobrar`,
 * `1784500000000-add_bloqueio_contrato_valores_a_cobrar`): adicionar uma coluna com default
 * constante não reescreve a tabela em Postgres moderno, e toda linha existente nasce `false` — o
 * deploy é bit-a-bit neutro, nenhuma simulação já salva muda de resultado.
 */
export class AddTransferenciaIntragrupoToSimulacaoEntradas1786100000000
  implements MigrationInterface
{
  name = "AddTransferenciaIntragrupoToSimulacaoEntradas1786100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "transferencia_intragrupo" boolean NOT NULL DEFAULT false
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."transferencia_intragrupo" IS
        'Transferência entre estabelecimentos da mesma empresa (matriz/filial, mesma raiz de CNPJ, ADC 49/STF). Gate único e explícito: true desliga DIFAL sempre, mesmo interestadual e do tipo certo (domain/simulacoes/calculo.ts). Default false, sem backfill.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "transferencia_intragrupo"`,
    );
  }
}
