import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Persiste os tributos da nota importada. Até aqui `simulacao_notas_fiscais` não guardava nenhum:
 * o parser lia os totais e o único número que sobrevivia era o ICMS derivado, gravado direto no
 * `aliquota_icms_override` da entrada.
 *
 * Guardar observada **e** nominal é o que torna a derivação auditável e re-derivável: a razão entre
 * as duas é exatamente o fator de retenção do ano de emissão. `base_icms`/`base_iss` são o peso da
 * média ponderada usada para consolidar a alíquota no cadastro do fornecedor.
 *
 * O índice `(fornecedor_id)` parcial que a consolidação usa já existe
 * (`1785330000000-add_fornecedor_to_simulacao_notas`).
 */
export class AddTributosToSimulacaoNotas1785600000001 implements MigrationInterface {
  name = "AddTributosToSimulacaoNotas1785600000001";

  private readonly colunas: Array<[string, string]> = [
    ["valor_produtos", "numeric(14,2)"],
    ["valor_servicos", "numeric(14,2)"],
    ["valor_icms", "numeric(14,2)"],
    ["valor_iss", "numeric(14,2)"],
    ["valor_ipi", "numeric(14,2)"],
    ["valor_pis", "numeric(14,2)"],
    ["valor_cofins", "numeric(14,2)"],
    ["base_icms", "numeric(14,2)"],
    ["base_iss", "numeric(14,2)"],
    ["aliquota_icms_observada", "numeric(6,4)"],
    ["aliquota_icms_nominal", "numeric(6,4)"],
    ["aliquota_iss_observada", "numeric(6,4)"],
    ["aliquota_iss_nominal", "numeric(6,4)"],
    ["aliquota_origem", "varchar(10)"],
  ];

  public async up(queryRunner: QueryRunner): Promise<void> {
    const adds = this.colunas
      .map(([coluna, tipo]) => `ADD COLUMN IF NOT EXISTS "${coluna}" ${tipo}`)
      .join(",\n        ");
    await queryRunner.query(`ALTER TABLE "simulacao_notas_fiscais"\n        ${adds}`);

    await queryRunner.query(`DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_simulacao_notas_fiscais_aliquota_origem'
            AND t.relname = 'simulacao_notas_fiscais'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "simulacao_notas_fiscais"
            ADD CONSTRAINT "CHK_simulacao_notas_fiscais_aliquota_origem"
            CHECK ("aliquota_origem" IS NULL OR "aliquota_origem" IN ('itens', 'totais'));
        END IF;
      END
    $$`);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_notas_fiscais"."aliquota_icms_observada" IS
        'Alíquota de ICMS como aparece na nota (já reduzida pelo fator do ano de emissão).'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_notas_fiscais"."aliquota_icms_nominal" IS
        'Alíquota de ICMS nominal = observada / fator do cronograma no ano de emissão.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_notas_fiscais"."aliquota_origem" IS
        'itens = média ponderada por vBC dos itens (det); totais = fallback pelo cabeçalho.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacao_notas_fiscais" DROP CONSTRAINT IF EXISTS "CHK_simulacao_notas_fiscais_aliquota_origem"`,
    );
    const drops = this.colunas
      .map(([coluna]) => `DROP COLUMN IF EXISTS "${coluna}"`)
      .join(",\n        ");
    await queryRunner.query(`ALTER TABLE "simulacao_notas_fiscais"\n        ${drops}`);
  }
}
