import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCobrancas1780700000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS cobrancas (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        cliente_id UUID NOT NULL REFERENCES clientes(id),
        valor_a_cobrar_id UUID REFERENCES valores_a_cobrar(id),
        plataforma_id UUID NOT NULL REFERENCES plataformas_cobranca(id),
        id_externo TEXT NOT NULL,
        id_externo_cliente TEXT,
        valor DECIMAL(12,2) NOT NULL,
        vencimento DATE NOT NULL,
        billing_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pendente',
        status_externo TEXT,
        url_boleto TEXT,
        url_pix TEXT,
        pago_em TIMESTAMPTZ,
        payload_ultimo_evento JSONB,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_cobrancas_plataforma_id_externo
        ON cobrancas (plataforma_id, id_externo);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_cobrancas_valor_a_cobrar ON cobrancas (valor_a_cobrar_id);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_cobrancas_status ON cobrancas (status);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_cobrancas_escritorio ON cobrancas (escritorio_id);
    `);

    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS cobranca_id UUID REFERENCES cobrancas(id);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE valores_a_cobrar DROP COLUMN IF EXISTS cobranca_id;`);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_cobrancas_escritorio;`);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_cobrancas_status;`);
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_cobrancas_valor_a_cobrar;`);
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_cobrancas_plataforma_id_externo;`);
    await queryRunner.query(`DROP TABLE IF EXISTS cobrancas;`);
  }
}
