import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Instala o contrato não versionado do novo motor.
 *
 * **A migration apaga as simulações existentes.** Não há caminho de conversão: o contrato antigo
 * guardava um `valor_bruto` único e o novo exige exatamente um entre `valor_operacao` (antes de
 * IBS/CBS) e `valor_total` (preço final) — decidir qual dos dois um `valor_bruto` histórico
 * representava é impossível sem o documento, e chutar mudaria número de simulação em silêncio. Sem a
 * limpeza o `ADD CONSTRAINT ck_simulacao_entrada_valor_exclusivo` falharia de todo jeito, porque a
 * validação roda contra as linhas existentes (nas quais os dois campos nascem `NULL`).
 *
 * Apagar aqui, e não num comando separado rodado antes, é deliberado: `runMigrations()` roda em
 * transação, então limpeza e DDL sobem ou caem juntas por tenant, e o deploy deixa de depender de um
 * passo manual que, se esquecido em UM escritório, derrubaria `migration:sync-tenants` com o backend
 * já parado. Não faz sentido preservar dado de um recurso que nenhum cliente usa ainda.
 *
 * `simulacao_entradas` e `simulacao_notas_fiscais` caem por cascade de `simulacoes`.
 *
 * O que ela NÃO faz: remover os XMLs de NF-e do S3, que ficam órfãos sob
 * `<escritorio>/simulacoes-nfe/`. Para varrê-los existe `db:limpar-simulacoes`
 * (`database/limpar-simulacoes-antigas.ts`), agora housekeeping opcional e não pré-requisito de
 * deploy. Clientes, fornecedores e catálogos ficam intactos nos dois casos.
 */
export class SubstituirContratoSimulacoes1787100000000 implements MigrationInterface {
  name = "SubstituirContratoSimulacoes1787100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "simulacao_grupo_itens"`);
    await queryRunner.query(`DELETE FROM "simulacao_grupos"`);
    await queryRunner.query(`DELETE FROM "simulacoes"`);

    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "aliquota_credito_presumido_ibs"`);
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "aliquota_credito_presumido_cbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "valor_bruto"`);
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "valor_operacao" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "valor_total" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "base_ibs_cbs" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "base_icms" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "base_iss" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "base_difal" decimal(14,2),
        ADD COLUMN IF NOT EXISTS "origem_base_ibs_cbs" varchar(12) NOT NULL DEFAULT 'estimada',
        ADD COLUMN IF NOT EXISTS "origem_base_icms" varchar(12) NOT NULL DEFAULT 'estimada',
        ADD COLUMN IF NOT EXISTS "origem_base_iss" varchar(12) NOT NULL DEFAULT 'estimada',
        ADD COLUMN IF NOT EXISTS "origem_base_difal" varchar(12) NOT NULL DEFAULT 'estimada',
        ADD COLUMN IF NOT EXISTS "confianca_base_ibs_cbs" varchar(8) NOT NULL DEFAULT 'baixa',
        ADD COLUMN IF NOT EXISTS "confianca_base_icms" varchar(8) NOT NULL DEFAULT 'baixa',
        ADD COLUMN IF NOT EXISTS "confianca_base_iss" varchar(8) NOT NULL DEFAULT 'baixa',
        ADD COLUMN IF NOT EXISTS "confianca_base_difal" varchar(8) NOT NULL DEFAULT 'baixa',
        ADD COLUMN IF NOT EXISTS "tratamento_ibs_cbs" varchar(20) NOT NULL DEFAULT 'padrao',
        ADD COLUMN IF NOT EXISTS "percentual_reducao_ibs_cbs" decimal(5,4),
        ADD COLUMN IF NOT EXISTS "fundamento_legal_ibs_cbs" text,
        ADD CONSTRAINT "ck_simulacao_entrada_valor_exclusivo"
          CHECK (("valor_operacao" IS NOT NULL) <> ("valor_total" IS NOT NULL)),
        ADD CONSTRAINT "ck_simulacao_entrada_tratamento_ibs_cbs"
          CHECK ("tratamento_ibs_cbs" IN ('padrao', 'reduzida', 'aliquota_zero', 'exportacao')),
        ADD CONSTRAINT "ck_simulacao_entrada_reducao_ibs_cbs"
          CHECK ("percentual_reducao_ibs_cbs" IS NULL OR "percentual_reducao_ibs_cbs" BETWEEN 0 AND 1)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_reducao_ibs_cbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_tratamento_ibs_cbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_valor_exclusivo"`);
    for (const coluna of [
      "fundamento_legal_ibs_cbs", "percentual_reducao_ibs_cbs", "tratamento_ibs_cbs",
      "confianca_base_difal", "confianca_base_iss", "confianca_base_icms", "confianca_base_ibs_cbs",
      "origem_base_difal", "origem_base_iss", "origem_base_icms", "origem_base_ibs_cbs",
      "base_difal", "base_iss", "base_icms", "base_ibs_cbs", "valor_total", "valor_operacao",
    ]) {
      await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "${coluna}"`);
    }
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "valor_bruto" decimal(14,2) NOT NULL`);
    await queryRunner.query(`ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "aliquota_credito_presumido_ibs" decimal(6,4)`);
    await queryRunner.query(`ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "aliquota_credito_presumido_cbs" decimal(6,4)`);
  }
}
