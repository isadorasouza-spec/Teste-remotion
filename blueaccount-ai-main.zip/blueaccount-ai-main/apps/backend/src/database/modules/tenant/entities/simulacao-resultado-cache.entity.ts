import { Column, Entity, Index, PrimaryColumn } from "typeorm";

@Index("IDX_simulacao_resultados_cache_escritorio", ["escritorio_id"])
@Index("IDX_simulacao_resultados_cache_calculado_em", ["calculado_em"])
// Tabela UNLOGGED (migration 1790300000000-create-simulacao-resultados-cache): escrita não gera
// WAL e o conteúdo some em parada suja → o próximo `obterSimulacao` reconstrói. TypeORM não
// gerencia LOGGED/UNLOGGED, então o estado vive só na migration. Sem relação ORM para `Simulacao`
// porque o Postgres proíbe FK entre persistências diferentes.
@Entity("simulacao_resultados_cache")
export class SimulacaoResultadoCache {
  @PrimaryColumn({ type: "uuid" }) simulacao_id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "int" }) versao_motor!: number;
  @Column({ type: "text" }) assinatura_dependencias!: string;
  /** JSON do payload, gzipado. Opaco para o SQL: ver o comentário da migration. */
  @Column({ type: "bytea" }) payload!: Buffer;
  @Column({ type: "timestamptz", default: () => "now()" }) calculado_em!: Date;
}
