import type { MigrationInterface, QueryRunner } from "typeorm";

/** Gerada com TypeORM SQL memory; aditiva, sem backfill de dados ausentes. */
export class AdicionarCclasstribSimulacao1792900000000 implements MigrationInterface {
  name = "AdicionarCclasstribSimulacao1792900000000";
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" ADD \"cst_ibs_cbs\" text");
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" ADD \"classificacao_tributaria_ibs_cbs\" text");
  }
  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" DROP COLUMN \"classificacao_tributaria_ibs_cbs\"");
    await queryRunner.query("ALTER TABLE \"simulacao_entradas\" DROP COLUMN \"cst_ibs_cbs\"");
  }
}
