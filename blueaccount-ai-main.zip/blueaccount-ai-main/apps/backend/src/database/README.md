# `src/database`

Camada de persistência do BlueAccount. Define o schema relacional, configura o TypeORM e mantém migrations versionadas para o schema `public` e para os schemas de tenant (por escritório).

---

## Arquitetura

O banco é dividido em dois níveis de schema:

### Schema `public` — dados de plataforma

Autenticação humana também persiste os fatores TOTP cifrados em `fatores_mfa_usuario` e no
singleton `fator_mfa_admin_plataforma`. `desafios_mfa` é `UNLOGGED`: guarda somente hash do token,
segredo de enrollment cifrado, identidade, destino local validado, tentativas, expiração e consumo.
Não registrar código TOTP, segredo, URI/QR ou token de desafio em logs.

Tabelas compartilhadas, sem isolamento por escritório. Gerenciadas pelo TypeORM CLI padrão.

**6 entidades:** Escritorio, Usuario, Sessao, AdminSession, AgentLog, Contexto

> **Sessões são UNLOGGED** (workaround p/ não depender de Redis). `Sessao` (`sessoes`) e
> `AdminSession` (`admin_session`) são tabelas **UNLOGGED** (migration
> `1784112210638-set_sessoes_unlogged`): escrita não gera WAL, aliviando o UPDATE de `last_seen_at`
> a cada request. Contrapartida: em parada suja (crash/reboot/patch do RDS) o Postgres **trunca** a
> tabela — o único efeito é o usuário/admin reautenticar. Dados de sessão são efêmeros por design.
>
> Como UNLOGGED não pode ter FK para/tabela LOGGED, a migration derruba as FKs que tocam `sessoes`
> (`sessoes.usuario_id`, `sessoes.escritorio_id`, `contexto.sessao_id`) e as relações ORM passam a
> usar `createForeignKeyConstraints: false`. Sem FK, o crescimento é contido por jobs **pg_cron**
> (`purge-sessoes`/`purge-admin-session`, `*/15 * * * *`) que a **própria migration agenda** — o bloco
> é guardado por `shared_preload_libraries LIKE '%pg_cron%'`, então roda só em prod (após reboot do
> RDS com o parameter group `shared_preload_libraries = pg_cron`, `cron.database_name = kontiva`) e
> pula em local/CI. **Em prod, rodar a migration DEPOIS do reboot**, senão o agendamento é pulado e
> não se repete (migration é one-shot).

Entidades em: `src/database/modules/public/entities/`  
Migrations em: `src/database/modules/public/migrations/`  
Detalhes: [`modules/public/README.md`](modules/public/README.md)

### Schemas de tenant — dados por escritório

Cada escritório recebe um schema dedicado (`escritorio_<uuid>`).  
As tabelas existem dentro desse schema e são isoladas por schema.

Entidades principais: Cliente, Fornecedor, Documento, Contrato, ContratoDocumentoAnexo, ClausulasExcedentes,
ServicosContratados, Relatorio, Faturamento, ValoresACobrar, ConectorDriveExecucao,
ConectorDriveArquivo e demais tabelas operacionais do tenant.
Assinaturas eletrônicas usam ConexaoAssinaturaEletronica e EnvelopeAssinaturaEletronica dentro do
schema do escritório. SimulacaoResultadoCache é a exceção do módulo: tabela **UNLOGGED**, sem FK e
com payload opaco em `bytea` (ver **Cache de resultado das simulações** abaixo).

Módulo único: `src/database/modules/tenant/`
- `entities/` — entidades TypeORM
- `migrations/` — migrations TypeORM (`MigrationInterface`)
- `tenant-datasource.ts` — DataSource factory apontado para um schema
- `tenant-datasource.cli.ts` — DataSource para uso com o CLI TypeORM

Detalhes: [`modules/tenant/README.md`](modules/tenant/README.md)

Documentos fiscais canônicos usam três registros de controle: lote e arquivo ficam no schema do
tenant (`lotes_ingestao_documentos_fiscais` e `arquivos_ingestao_documentos_fiscais`); a fila
durável de projeção fica em `public.projecoes_documentos_fiscais_fila`, pois o worker precisa
adquirir trabalho entre escritórios. O enqueue público só ocorre pela função `SECURITY DEFINER`
`enfileirar_projecao_documento_fiscal`, que confere `app.escritorio_id`. A projeção e o cálculo são
drenados pelo mesmo processo, mas têm leases, tentativas e estados independentes.

---

A migration tenant `1791400000000-adicionar-origem-lote-fiscal` adiciona `origem` ao lote
(`upload_manual` por padrão, `sieg` para coleta SIEG). É aditiva e deve preceder backend/worker.
A fila pública permanece sem origem: o worker resolve a procedência do lote via RLS, evitando
herdar a origem de um artefato canônico reutilizado.

A coluna `origem` é `varchar(20)` sem `CHECK` (a migration acima só adiciona a coluna), então o
terceiro valor `"portal_sefaz"` (ingestão de NFC-e por chave de acesso) não exigiu migration nova —
só uma atualização do tipo `OrigemIngestaoFiscal`. Lotes dessa origem são sempre cliente-scoped
(`simulacao_id IS NULL`, já suportado desde `1791200000000-create-ingestao-documentos-fiscais`) e
nunca projetam para `simulacao_entradas`/`simulacao_notas_fiscais` — o CHECK
`CK_simulacao_notas_fiscais_origem` (`1791100000000`, só aceita `upload`/`sieg`) nunca é alcançado
por esse caminho, mas vira bloqueador se a projeção for habilitada para ele algum dia.

### Filas fiscais Postgres

`1792300000000-criar-fila-ingestao-fiscal` cria a fila WAL-durável de uploads e a função
`enfileirar_ingestao_fiscal`, que valida contexto e lote/cliente antes do enqueue na transação
tenant. O worker recebe somente SELECT/UPDATE da fila; não recebe senha owner.
`1792200000000-remover-consultas-chaves-fiscais-fila` retira a fila do coletor aposentado.
A migration remove a tabela com todos os registros do coletor aposentado, sem exigir limpeza
manual. O DROP adquire lock exclusivo e não usa CASCADE. É idempotente após remoção; o down
recusa recriar uma fila vazia como se restaurasse o histórico. As filas de upload e DFe são preservadas.
A migration histórica de criação permanece em disco. Nenhuma migration foi aplicada em produção.

A distribuição usa `public.distribuicoes_dfe_fila`. Novos escritórios já recebem associação à
role fiscal em `grantTenantRoleToRuntimeRoles`; informe DOCUMENTOS_FISCAIS_DB_USERNAME na task
que executa migrations/reconciliação. O supervisor alerta divergências de roles via pg_catalog.

## Arquivos principais

| Arquivo | Função |
|---------|--------|
| `data-source.ts` | `AppDataSource` e `RlsDataSource` usados pela aplicação |
| `migration-data-source.ts` | DataSource para o CLI TypeORM (schema público) |
| `migration-data-source-runtime.ts` | Idem, para uso em produção com JS compilado |
| `tenant-datasource-factory.ts` | Factory compartilhada de DataSource por schema de tenant |
| `tenant-module-runner.ts` | Orquestra migrations de tenant em um schema |
| `escritorio-schema.ts` | Provisionamento completo de um schema de escritório |
| `sync-tenant-schemas.ts` | CLI: aplica migrations em todos os schemas existentes |
| `tenant-naming.ts` | Funções de naming: `buildEscritorioSchemaName`, `buildEscritorioRoleName` |
| `certificado-ssl.ts` | `resolverCaSsl()`: lê o bundle de CA de `DB_SSL_CA_PATH` |
| `limpar-simulacoes-antigas.ts` | Housekeeping opcional: varre os XMLs de simulação órfãos no S3 (ver abaixo) |

### TLS: todo DataSource precisa do CA

`runModuleMigrations` serializa migrations de tenant por processo, antes de criar ou
inicializar o DataSource, e só libera a próxima chamada após fechar o pool. A fila
vale também entre schemas diferentes e não abre conexões para chamadas em espera.
O limite é **por processo**, não um lock global entre réplicas: com pool tenant de 2,
API máximo 2 e sobreposição de deploy de 200%, reservar até 8 conexões adicionais
para provisionamento/migrations HTTP. CRM e CLI usam a mesma fila dentro de seus
processos; suas conexões continuam nos respectivos orçamentos.

O job `deploy-backend` usa o grupo fixo `deploy-backend-prd` com
`cancel-in-progress: false`, abrangendo build/push, migrations e rollout. Migrations
manuais e tasks deixadas por cancelamento manual precisam de controle operacional
separado; não iniciar outro job enquanto uma task de migrations anterior estiver ativa.

As migrations de tenant **não** reusam a conexão de `data-source.ts`. `tenant-module-runner.ts`
abre uma conexão nova pela factory, e essa conexão precisa do mesmo `ca` de `DB_SSL_CA_PATH`.
Sem ele, um runtime com `DB_SSL_REJECT_UNAUTHORIZED=true` falha o handshake com
`self-signed certificate in certificate chain`, porque a cadeia da Amazon não está no trust
store padrão do Node. Onde a verificação está desligada o defeito fica invisível, então ao
criar um DataSource novo use `resolverCaSsl()` em vez de montar o bloco `ssl` na mão.

---

## Resumo persistido das simulações

A migration tenant `1790100000000-add-resumo-resultado-simulacoes` adiciona o JSONB nullable
`simulacoes.resumo_resultado`. Ela não tenta reproduzir o motor fiscal em SQL e não faz backfill:
durante a fase de testes, cenários históricos permanecem com snapshot nulo e aparecem como **Não
calculado** na listagem. A primeira abertura do cenário usa `obterSimulacao`, executa o cálculo
autoritativo e persiste o resumo para as próximas visitas.

A migration tenant `1790200000000-add-politicas-acumuladores-cliente` é aditiva. Ela acrescenta
tratamento e redução ao default de `acumuladores_simulacao`, cria
`acumuladores_simulacao_cliente` para overrides esparsos por cliente e
`simulacao_entradas_excluidas` para snapshots de linhas importadas fora do cálculo. Não há backfill
nem recálculo: simulações e resumos históricos permanecem intactos. As novas tabelas carregam
`escritorio_id`, FKs e índices tenant-aware e são registradas nos datasources de runtime e tenant.

## Cache de resultado das simulações

A migration tenant `1790300000000-create-simulacao-resultados-cache` cria
`simulacao_resultados_cache`, **uma linha por simulação**, com o payload de `obterSimulacao`
serializado. É a segunda tabela **UNLOGGED** do projeto, e a primeira em schema de tenant.

A migration tenant `1790500000000-add-credito-politicas-acumuladores` adiciona o booleano
`gera_credito_padrao` (default `true`) ao catálogo e o override nullable `gera_credito` por cliente.
Ela não recalcula entradas existentes; a política passa a ser copiada somente em novas associações e
importações.

A migration tenant `1790600000000-add-bloqueio-edicao-simulacoes` adiciona
`simulacoes.bloqueada_edicao` como booleano `NOT NULL DEFAULT false`. É aditiva e não bloqueia
cenários históricos: o estado só muda pelo endpoint dedicado. O bloqueio estrutural das cópias de
séries continua derivado de `simulacao_origem_id`.

Três decisões que fogem do padrão das outras tabelas de tenant, todas deliberadas:

- **`UNLOGGED`**: o conteúdo é sempre reconstruível pelo motor, então não vale WAL, réplica de
  leitura nem PITR. Em parada suja o Postgres trunca a tabela e o próximo `obterSimulacao`
  reconstrói. Como TypeORM não modela LOGGED/UNLOGGED, o estado vive só na migration (a entidade
  carrega o comentário-âncora, igual a `sessao.entity.ts`).
- **Sem FK para `simulacoes`**: o Postgres proíbe FK entre persistências diferentes. A entidade não
  declara relação nenhuma, então não há `createForeignKeyConstraints: false` a acrescentar — mas
  também não há cascata: `excluirSimulacao` apaga a linha explicitamente e
  `limpar-simulacoes-antigas.ts` limpa a tabela junto com as simulações.
- **`payload bytea`, não `jsonb`**: o payload é opaco, nunca consultado por SQL, e grande (um cenário
  de 2.880 linhas dá ~15 MB de JSON cru). Medido: 153 ms para ler em `jsonb` contra 41 ms em
  `bytea` + gunzip, porque o `jsonb` volta expandido no protocolo. Ver
  `domain/simulacoes/README.md` → **Cache de resultado**.

A PK é `simulacao_id`, fornecida pelo chamador — não há `DEFAULT uuid_generate_v*`, então o guard
`verificar:uuid-v7` passa sem escape hatch. Escrita e leitura acontecem sob a role do tenant; as
default privileges do schema já cobrem `SELECT/INSERT/UPDATE/DELETE`, mas rode
`npm run db:reconcile-tenant-privileges` depois do `migration:sync-tenants` se algum schema antigo
divergir.

Invalidação (versão do motor + assinatura de dependências + TTL) está documentada em
`domain/simulacoes/README.md`; aqui só interessa que nenhuma coluna da tabela é consultada por
filtro além de `simulacao_id`/`escritorio_id`.

## Fila assíncrona e cálculo durável

As migrations `1791000000000` criam `public.simulacao_calculos_fila`, o singleton
`public.simulacao_fila_controle`, os campos de estado em `simulacoes` e a tabela tenant LOGGED
`simulacao_calculos`. A fila reutiliza uma linha por escritório/simulação e usa gerações, lease UUID,
`FOR UPDATE SKIP LOCKED`, tentativas e cancelamento. O enqueue tenant chama uma função
security-definer que exige que `app.escritorio_id` seja igual ao escritório solicitado; assim a fila
pública participa da mesma transação sem conceder acesso direto às tabelas públicas ao role tenant.

Não há backfill de fila. Payloads antigos são copiados para o artefato durável como último resultado,
mas continuam desatualizados até um enqueue preguiçoso ou uma ação bulk confirmada pelo admin.

## Substituição do contrato de simulações

A migration tenant `1787100000000-substituir-contrato-simulacoes` **apaga as simulações existentes
ela mesma** e não exige passo manual nenhum antes. Deploy normal: `migration:sync-tenants` e publicar
backend, frontend e MCP juntos.

Por que apagar em vez de converter: o contrato antigo guardava um `valor_bruto` único e o novo exige
exatamente um entre `valor_operacao` (antes de IBS/CBS) e `valor_total` (preço final). Decidir qual
dos dois um `valor_bruto` histórico representava é impossível sem o documento, e chutar mudaria número
de simulação em silêncio. Não há dado de cliente em risco: o recurso ainda não está em uso externo.

Por que dentro da migration e não num comando rodado antes: `runMigrations()` roda em transação, então
limpeza e DDL sobem ou caem juntas por tenant. Um pré-requisito manual esquecido em UM escritório
derrubaria `migration:sync-tenants` com o backend já parado.

`simulacao_entradas` e `simulacao_notas_fiscais` caem por cascade de `simulacoes`. Clientes,
fornecedores e catálogos ficam intactos.

A migration tenant `1787300000000-add-ipi-composicao-base-icms-simulacoes` é aditiva: cria
`simulacoes.composicao_base_icms` com default `sem_ibs_cbs` e, nas entradas,
`valor_ipi`/`composicao_base_icms_override`, com CHECKs de domínio e valor não negativo. A migration
seguinte, `1787400000000-add-valor-icms-simulacao-entradas`, acrescenta `valor_icms` nullable com o
mesmo CHECK não negativo. Nenhuma faz backfill: `valor_icms` e `composicao_base_icms_override` seguem
limitados às entradas manuais, e `valor_ipi` passou a ser preenchido também pela importação de NF-e
(`det/imposto/IPI`) — linhas importadas antes dessa mudança continuam com `NULL`, portanto sem efeito
no resultado até serem reimportadas.

A migration tenant `1788600000000-add-pis-cofins-manual-zfm-simulacao-entradas` adiciona
`produto_concorrente_zfm` (boolean, default `false`), `debito_pis_cofins_manual` e
`credito_pis_cofins_manual` (numeric nullable com CHECK não negativo). Não há backfill monetário:
linhas existentes mantêm o proxy de débito de 2026, crédito zero e IPI zerado desde 2027 por default.
`1789000000000-add-fundamento-credito-pis-cofins` acrescenta o fundamento textual nullable: créditos
já existentes continuam calculados, mas ficam pendentes de revisão até receberem a base legal/contábil.

A migration `1787500000000-add-defaults-novas-entradas-simulacao` adiciona ao cenário o fornecedor
genérico padrão e o tipo de valor (`valor_total` ou `valor_operacao`) usado ao criar novas entradas
manuais. É aditiva e não faz backfill em `simulacao_entradas`: cenários existentes começam com
`tipo_valor_entrada_padrao = 'valor_total'` e sem fornecedor padrão.

A migration tenant `1788500000000-normalizar-fonte-editavel-series-simulacao` é um backfill
idempotente para séries criadas durante a transição do vínculo. Ela preserva a simulação externa,
torna editável a cópia do ano-base que já está no grupo e redireciona os demais anos e suas entradas
para essa cópia. O backfill não modifica séries cuja fonte já pertence ao grupo e não possui reversão
automática segura depois que a nova fonte editável recebe alterações.

### XMLs órfãos no S3 (opcional)

A migration não alcança o S3: os XMLs de NF-e importados continuam sob
`<escritorio>/simulacoes-nfe/` sem nenhuma linha apontando para eles. Para varrê-los,
`npm run db:limpar-simulacoes --workspace apps/backend -- --confirmar-exclusao-irreversivel`. É
**irreversível** e opcional — não é pré-requisito de deploy. Ele apaga por prefixo além das
`storage_key` conhecidas, então confirme que nenhuma outra feature escreve sob esse infixo antes de
rodar.

---

## Como o RLS funciona

O isolamento por escritório usa dois mecanismos combinados:

1. **Schema separado por escritório** — cada escritório opera em seu próprio schema (`escritorio_<uuid>`), com tabelas próprias.
2. **Row Level Security (quando habilitado)** — políticas podem filtrar por `escritorio_id = current_setting('app.escritorio_id')`.

### Fluxo de uma query autenticada

```
Request com session_id
  → lookup na tabela sessoes (public)
  → deriva escritorio_id e schema
  → runQueryWithRls({ escritorio_id, schema_name })
      → SET LOCAL ROLE user_escritorio_<uuid>
      → SET search_path = escritorio_<uuid>, public
      → SET app.escritorio_id = '<uuid>'
      → callback com manager isolado
```

> **Guarda em CI:** `npm run verificar:rls` (`scripts/verificar-rls-tenant.mjs`) falha o build se
> alguém usar `AppDataSource.getRepository(<EntidadeDeTenant>)` (role dono, ignora o isolamento) ou
> referenciar `RlsDataSource` fora de `data-source.ts`. Roda no gate de PR (`e2e.yml`) e no deploy
> (`deploy.yml`). Cross-tenant intencional e admin-gated (ex.: analytics de plataforma) se anota com
> `// rls-guard-ok: <motivo>`. A guarda não cobre SQL cru com schema de tenant interpolado — revise à mão.
>
> **Armadilha:** a guarda é regex sobre texto puro, não AST — não distingue código de comentário.
> Um doc-comment que cite `RlsDataSource` pelo nome (ex.: explicando atomicidade de transação) dispara
> falso-positivo fora de `data-source.ts`. Para referenciar o mecanismo em prosa sem disparar a guarda,
> descreva-o sem o token literal (ex.: "transação do datasource com RLS") ou anote `// rls-guard-ok`.
>
> **Exceção documentada — transações de fila.** `transacaoFilaTenant`
> (`database/transacao-fila-tenant.ts`) abre transação pelo `AppDataSource` (role dona) e
> define o `search_path` para o schema do tenant à mão, em vez de passar por `runQueryWithRls`. O
> motivo é atomicidade entre camadas: `concluirCalculo`, `falharCalculo` e `cancelarItemFilaCalculo`
> movem a linha da fila em `public.simulacao_calculos_fila` **e** a linha de `simulacoes` no schema do
> tenant no mesmo commit; se fossem duas transações, um crash entre elas deixaria a fila `concluido`
> com a simulação `processando`. A role do tenant não alcança `public` (esta mesma seção revoga), então
> role dona é a única forma de ter as duas juntas.
> Isolamento aqui é `search_path` + `escritorio_id` explícito no WHERE de **toda** query — não RLS.
> Isso cai justamente no ponto cego que a guarda anuncia acima ("não cobre SQL cru com schema de tenant
> interpolado"), então quem editar essas queries revisa o filtro à mão: schema certo com id errado
> atravessa tenant sem o banco reclamar.
>
> **Guarda em runtime:** além do regex de CI, `data-source.ts` também barra em tempo de execução:
> `runQueryWithRls` recusa `manager.getRepository(<EntidadeDePublic>)` e `AppDataSource` recusa
> `getRepository(<EntidadeDeTenant>)`, os dois via o mesmo `comGuardaDeRepositorio` (Proxy sobre
> `getRepository`), cada um com o Set de entidades invertido. Não depende de comentário nem de texto —
> pega o uso real e falha com o nome da entidade. Ponto cego: `AppDataSource.manager.getRepository(...)`
> passa direto (o getter `.manager` devolve o `EntityManager` sem o Proxy) — mesmo ponto cego que o
> script de CI já tinha.

Para queries de tenant usar sempre `runQueryWithRls()`:

```typescript
import { runQueryWithRls } from "../../database/data-source.js";

const clientes = await runQueryWithRls({ escritorio_id }, async (manager) => {
  return manager.getRepository(Cliente).find();
});
```

---

## Como fazer migrations

### Schema público

O schema público é gerenciado pelo TypeORM CLI padrão, apontado para `migration-data-source.ts`.

#### Gerar migration (detecta diff entre entidades e banco)

```bash
npm run migration:generate --name=NomeDaMigration
# Gera: src/database/modules/public/migrations/<timestamp>-NomeDaMigration.ts
```

#### Aplicar migrations pendentes

```bash
npm run migration:run
```

#### Reverter última migration

```bash
npm run migration:revert
```

---

### Chaves primárias são UUIDv7 (ordenado por tempo)

Desde as migrations `1786500000000-uuid_v7_defaults` (public) e `1786600000000-uuid_v7_defaults`
(tenant), toda coluna `uuid` com default gera **UUIDv7** via `uuid_generate_v7()`, e não mais v4.
Os 48 bits mais altos do v7 são o timestamp em milissegundos, então as inserções vão para a borda
direita do índice B-tree em vez de espalhar por páginas aleatórias.

> ⚠️ **Tabela nova nasce em v4 — corrija à mão.** O TypeORM emite `DEFAULT uuid_generate_v4()` em
> todo `CREATE TABLE` que ele gera; o gerador é fixo no driver e não tem hook para função
> customizada. Depois de `migration:generate`, troque por `DEFAULT uuid_generate_v7()`.
> `npm run verificar:uuid-v7` falha o build (PR e deploy) se uma migration acima do corte
> `1786400000000` ainda mencionar `uuid_generate_v4()` ou `gen_random_uuid()`. Uso intencional
> (ex.: um `down()`) se anota com `// uuid-guard-ok: <motivo>`.

Pontos que costumam gerar dúvida:

- **O nome da função é inglês de propósito.** O TypeORM só trata a coluna como "uuid gerado" se o
  default casar com `gen_random_uuid()` ou `/^uuid_generate_v\d\(\)/`. Com qualquer outro nome —
  inclusive um `gerar_uuid_v7()` em português — todo `migration:generate` passaria a emitir ALTERs
  revertendo as ~56 PKs para v4. É um shim de compatibilidade, não nome de domínio.
- **O default é gravado sem qualificar o schema** (`uuid_generate_v7()`, não
  `public.uuid_generate_v7()`), pelo mesmo motivo: o texto qualificado não casaria com o regex.
- **O corpo muda conforme a versão do servidor.** No PG18+ (produção) a função delega para o
  `uuidv7()` nativo, que tem precisão sub-milissegundo; no PG16 (local/CI) usa um shim em plpgsql
  sobre `gen_random_uuid()`, com granularidade de milissegundo. Nome, defaults e autoteste são os
  mesmos nos dois casos. Detalhes em [`uuid-v7.ts`](uuid-v7.ts).
- **Linhas antigas continuam em v4.** Não houve backfill: as tabelas têm ids v4 e v7 misturados.
  Portanto `ORDER BY id` **não** é ordem cronológica confiável — e mesmo entre linhas novas o
  desempate dentro do mesmo milissegundo é aleatório no PG16. Para cursor/paginação continue usando
  `created_at`.
- A migration se autoverifica: se a manipulação de bits gerar versão, variante ou timestamp errados,
  ela levanta exceção e falha em vez de deixar o banco gerando UUID malformado em silêncio.

> 🔒 **A virada é só das chaves primárias do banco. NÃO propague v7 para os `randomUUID()` da
> aplicação.** Os ~21 `crypto.randomUUID()` do código (trace ids, chaves S3, session id do MCP,
> `family_id` de refresh token) continuam v4 de propósito. O v7 troca 48 bits aleatórios por um
> timestamp previsível, e três lugares dependem justamente da aleatoriedade dos primeiros
> caracteres:
>
> | Lugar | O que quebra com v7 |
> |---|---|
> | `apps/e2e/setup/global-setup.ts:369` e `setup/run-local.mjs:41` | usam os 20 primeiros hex do UUID como **senha**; os 12 primeiros viram timestamp e a entropia despenca |
> | `domain/escritorios/escritorio-usuarios.ts:210` | usa os 5 primeiros hex como sufixo único do e-mail no soft delete; em v7 eles quase não mudam → colisão no índice único |
> | `apps/mcp/src/server.ts:397` | session id do MCP cairia de 122 para 74 bits aleatórios, sem nenhum ganho (esse id não vive em índice) |
>
> Nenhum UUID é segredo no fluxo de autenticação — a credencial de sessão é `randomBytes(32)` e o
> banco guarda só o SHA-256 (`sessoes.session_id_hash`). Por isso a virada para v7 não afeta
> segurança. O risco está em uma varredura futura "vamos padronizar tudo em v7".

---

### Schema de tenant

O tenant agora usa um único módulo (`modules/tenant`) com um único DataSource apontado para o schema.

Esse DataSource força `search_path=<schema_tenant>,public`, garantindo que SQL sem schema qualificado (ex.: `CREATE TABLE "clientes"`) seja aplicado no schema do tenant.

> **Pré-requisito:** você precisa de um schema de tenant existente para `migration:generate`. Crie um escritório primeiro ou use um schema de desenvolvimento.

#### Gerar migration de tenant

```bash
npm run migration:generate:tenant \
  --schema=escritorio_abc123 \
  --name=NomeDaMigration

# Exemplo:
npm run migration:generate:tenant \
  --schema=escritorio_abc123 \
  --name=AddValorReajustado
```

O arquivo gerado vai para `src/database/modules/tenant/migrations/`.
Após gerar, o script `scripts/normalize-tenant-migration.mjs` remove automaticamente prefixos do schema (ex.: `"escritorio_dev".`) para manter a migration reutilizável em qualquer tenant.

#### Aplicar migrations em todos os tenants

```bash
npm run migration:sync-tenants

# Ou explicitando o módulo único:
npm run migration:sync-tenants -- --module=tenant
```

Durante o sync, o sistema atualiza `public.tenant_migration_state` com a última migration aplicada por schema (`last_migration_timestamp` e `last_migration_name`).

#### Reverter última migration de tenant em um schema

```bash
npm run migration:revert:tenant -- --schema=escritorio_abc123
```

---

## Fluxo completo: adicionar uma nova coluna em tenant

Exemplo: adicionar `valor_reajustado` em `contratos`.

```
1. Gerar a migration:
   npm run migration:generate:tenant \
     --schema=escritorio_dev \
     --name=AddValorReajustado

2. Revisar o arquivo gerado em:
   src/database/modules/tenant/migrations/<timestamp>-AddValorReajustado.ts

3. Aplicar em todos os schemas existentes:
   npm run migration:sync-tenants -- --module=tenant
```

Novos escritórios criados após o passo 3 receberão automaticamente a migration no provisionamento.

---

## Fluxo completo: adicionar uma nova entidade/tabela em tenant

⚠️ **Uma entidade de tenant precisa ser registrada em DOIS DataSources.** Esquecer um deles compila normalmente, mas estoura em runtime com `No metadata for "X" was found` (HTTP 500) — porque o `getRepository(X)` dentro de `runQueryWithRls` usa o `AppDataSource`, não o DataSource das migrations.

1. Criar a entidade em `src/database/modules/tenant/entities/<nome>.entity.ts`.
2. **Registrar nos dois arrays `entities`:**
   - `data-source.ts` (`AppDataSource`/`RlsDataSource`) — usado por **`runQueryWithRls`** (toda query de aplicação). **É o que faltava e causava 500.**
   - `modules/tenant/tenant-datasource.ts` (`createTenantModuleDataSource`) — usado pelas **migrations** e provisionamento.
   - (`test-data-source.ts` carrega entidades por glob, então pega automaticamente.)
3. Criar a migration de `CREATE TABLE` (ver fluxo de coluna acima) e aplicar com `npm run migration:sync-tenants`.
4. Se a tabela precisa de **backfill** de linhas existentes, faça uma migration separada e idempotente (ex.: `WHERE NOT EXISTS (...)`), pois editar uma migration já aplicada não a re-executa.

---

## Provisionamento de um novo escritório

Quando um escritório é criado, `provisionEscritorioSchema()` em `escritorio-schema.ts`:

1. Cria o schema `escritorio_<uuid>`
2. Cria o role `user_escritorio_<uuid>` (NOLOGIN)
3. Configura grants atuais e `ALTER DEFAULT PRIVILEGES` no schema do tenant
4. Revoga privilégios em tabelas do schema `public` para a role do tenant
5. Aplica as migrations de tenant via `runTenantMigrations()`
6. Reconcilia novamente grants atuais e membership da role do tenant

O passo 5 usa `dataSource.runMigrations()` com DataSource tenant apontado para o schema do escritório.  
A tabela `_tenant_migrations` dentro de cada schema controla o que já foi aplicado.

---

## Fuso horário e colunas `timestamp` sem timezone

O processo Node roda **fixado em UTC** por `src/relogio-utc.ts`, que é o primeiro import de todo
entrypoint (`server.ts`, `cli.ts`, os workers) e também o `TZ` que o `runapp.py` passa aos filhos.
A suíte usa o mesmo fuso (`env: { TZ: "UTC" }` nos configs do vitest).

Isso não é preferência de formatação, é correção. Cerca de 109 colunas do banco ainda são
`timestamp without time zone` (62 no `public`, ~47 por schema de tenant) e a semântica de quem
escreve nelas é **mista**:

| Quem escreve | O que fica gravado |
| --- | --- |
| Postgres (`DEFAULT now()`, `UPDATE ... now()`) | naive em **UTC** |
| TypeORM/Node | naive no **fuso do processo** |

O driver lê naive como hora local do processo. Com o processo em UTC os dois relógios coincidem.
Com o processo em outro fuso, o que veio do banco aparece deslocado — e comparações de tempo
quebram sem erro nenhum. Caso concreto observado em dev (macOS, UTC-3): `exigeReautenticacao` lia
`sessoes.created_at` 3h adiantado e a janela de step-up auth de 10 minutos passava a valer
~3h10min, afrouxando o controle sem sinal algum. Produção nunca expôs isso porque os containers
já rodam UTC, mas por default do sistema operacional, não por decisão registrada.

Ao escrever código novo:

- prefira `timestamptz` em coluna nova (é o que as tabelas fiscais mais recentes usam);
- não compare coluna naive com `now()` dentro de SQL sem saber quem gravou o valor;
- não altere `TZ` do processo. O override é respeitado, mas emite aviso e derruba a garantia acima.

Converter as 109 colunas para `timestamptz` é o conserto de raiz e continua **pendente**: a
conversão precisa saber em que fuso cada valor já gravado foi escrito, e isso varia por coluna.
Com o relógio fixo, todo valor novo passa a ser inequívoco.

## Nomenclatura

```typescript
// Os hífens do UUID viram underscore (não são removidos) — ver `tenant-naming.ts`.
buildEscritorioSchemaName(escritorioId: string): string
// → "escritorio_550e8400_e29b_41d4_a716_446655440000"

buildEscritorioRoleName(escritorioId: string): string
// → "user_escritorio_550e8400_e29b_41d4_a716_446655440000"
```

---

## Scripts disponíveis

| Script | O que faz |
|--------|-----------|
| `migration:run` | Aplica migrations pendentes no schema público |
| `migration:revert` | Reverte última migration do schema público |
| `migration:generate --name=X` | Gera migration para o schema público |
| `migration:generate:tenant --schema=S --name=X` | Gera migration para o módulo tenant |
| `migration:sync-tenants` | Aplica migrations pendentes em todos os tenants |
| `migration:sync-tenants -- --module=tenant` | Idem, explicitando o módulo tenant |
| `migration:revert:tenant -- --schema=S` | Reverte última migration de tenant em S |
| `db:reconcile-tenant-privileges` | Corrige grants e default privileges para todos os tenants existentes |
| `verificar:uuid-v7` | Falha se uma migration nova criar chave primária em UUIDv4 |

Use `npm run db:reconcile-tenant-privileges` quando uma migration de tenant já criou tabelas antes das permissões padrão estarem configuradas. O comando é idempotente: para cada escritório em `public.escritorios`, ele garante schema, role `user_escritorio_<uuid>`, grants em tabelas/sequences atuais do schema do tenant, `ALTER DEFAULT PRIVILEGES` para novas tabelas/sequences criadas pelo owner de migration (`DB_AI_USERNAME`, depois `DB_USERNAME`, ou `postgres` como fallback), e revoga privilégios da role do tenant em tabelas do schema `public`.

## Modo da plataforma

A migration pública `1791300000000-adicionar-modo-plataforma` adiciona `escritorios.modo_plataforma`, texto obrigatório com default `escritorio` e CHECK para `escritorio | empresa`. Não há migration tenant, movimentação de dados ou alteração de RLS. Implantar a migration antes do backend que lê o campo, depois publicar o frontend e habilitar um tenant piloto no painel administrativo. Reverter o modo para `escritorio` restaura o shell anterior sem remover empresas ou simulações. Não remover a coluna enquanto o backend novo estiver em uso.

### Rascunho de planilha fiscal

A migration tenant `1791600000000-adicionar-rascunho-planilha-fiscal` adiciona a coluna nullable
JSONB `rascunho_planilha` ao lote fiscal existente. Guarda versão, movimentos revisados, bloqueio
de confirmação e recibo de enqueue. Escritas usam RLS e bloqueio pessimista da linha com checagem
da versão enviada; não há nova entidade ou fila. Aplicar/sincronizar nos tenants antes do backend.

## Publicação fiscal e snapshots de pesquisa

A migration tenant `1791700000000-publicacao-fiscal-postgres` adiciona totais e itens completos,
execuções/checkpoints/outbox de callbacks e snapshots de pesquisas. É aditiva; não migra histórico
Iceberg. As cinco entidades estão nos datasources de runtime e tenant e na guarda de repositórios.
As tabelas usam RLS forçada por `app.escritorio_id`; grants seguem o provisionamento existente.
Os itens têm FK composta para o total; resultados de pesquisa têm FK com cascade para a consulta.
A role Python deve ser NOSUPERUSER/NOBYPASSRLS/NOINHERIT, membro somente das roles dos tenants do
piloto. O worker usa SET LOCAL ROLE/search_path/contexto dentro de cada transação, valida UUIDs e
confere a relação cliente/escritório; não aceita schema de manifesto.

`execucoes_worker_fiscal` armazena checkpoints e entregas pendentes sob RLS. Não limpar execuções
com entrega pendente. `consultas_notas_fiscais` expira em 15 minutos; exclusão limitada a 20 por nova
pesquisa remove resultados por cascade. Sem pesquisa nova, dados expirados permanecem até a próxima
limpeza, mas não podem ser lidos. O rollback operacional para o piloto para consumidores e preserva
dados e filas; não executar down destrutivo como rotina.

Matriz completa: `apps/services/documentos-fiscais/CONTRATO_POSTGRES.md` na raiz do monorepo.
`apps/backend/scripts/preparar-piloto-fiscal.ts` provisiona três tenants somente no banco explícito
`kontiva_fiscal_piloto` em 127.0.0.1, usando o provisionamento normal. A senha demonstrativa da role
`fiscal_piloto` é exclusiva deste banco de teste; não usar em qualquer outro ambiente.

A migration pública `1791800000000` concede as roles de todos os schemas de escritório
existentes a `DOCUMENTOS_FISCAIS_DB_USERNAME`. A credencial deve existir e ser
NOSUPERUSER/NOBYPASSRLS/NOINHERIT; nenhuma senha ou login é criado. Sem credencial
configurada, a migration não concede acessos (modo worker exige a variável).
O provisionamento e a sincronização de tenants também incluem essa credencial entre
as roles de runtime, cobrindo escritórios novos e configuração posterior à migration.
Os grants são idempotentes e não incluem ADMIN OPTION. A reversão automática é recusada
para preservar memberships anteriores; revogações exigem revisão explícita.

`npm run db:reconcile-tenant-privileges` também valida a role fiscal e recupera SELECT/UPDATE nas
duas filas públicas. Isso cobre migrations antigas que passaram sem username configurado.
O provisionamento de escritório falha se a role fiscal configurada não existir, em vez de
criar um escritório invisível ao worker. A migration 1792300000000 também recompõe o grant DFe.

## Revisão fiscal NCM de setembro de 2026

Aplicar `1792800000000-revisar-beneficios-ncm` no schema público antes da migration tenant
`1792800000001-reconciliar-beneficios-ncm`. A primeira guarda referências anteriores em
`public.ncms_revisao_20260916`, substitui o manifesto legal antigo e permite regras condicionais.
Overrides administrativos fora dos dois códigos explicitamente auditados são preservados; conflitos
nesses outros códigos devem ser revisados separadamente. As descrições oficiais do cache permanecem.
A segunda preserva fatores manuais e demais origens, reconciliando só NCM e enfileirando as
simulações alteradas e cópias vinculadas. Reversões automáticas são recusadas para não restaurar
benefícios incorretos; usar snapshot e nova revisão fiscal. Não executar migrations antigas novamente.

## Limites de conexão e migrations

`limite-pool.ts` resolve `DB_POOL_MAX` (padrão 10) para `AppDataSource` e `RlsDataSource`.
O limite é por pool, não por processo; dois pools de 2 no ECS permitem até 4 conexões.
Os DataSources CLI público (TS e runtime JS) e a factory por tenant usam `poolSize=2`,
preservando SSL, search_path e timeouts. Limites de pools não são limites globais do banco.
Provisionamentos simultâneos abrem pools adicionais e devem entrar no orçamento ECS.

`DatabaseBootstrapService` respeita `DB_SYNC_TENANTS_ON_BOOT`; esse flag não desliga
os comandos explícitos de migration/sync nem o provisionamento de novos escritórios.
O fechamento de owner/RLS fica encapsulado em `encerrarConexoesBanco()` neste módulo,
chamado pelo hook `onApplicationShutdown` após drenar HTTP. A guarda estática de RLS
continua proibindo acesso direto ao datasource RLS fora de `data-source.ts`.

A migration tenant `1792900000000-adicionar-cclasstrib-simulacao` acrescenta `cst_ibs_cbs` e
`classificacao_tributaria_ibs_cbs` como texto nullable em `simulacao_entradas`. Gerada com SQL
memory do TypeORM e revisada; sem aplicação automática nesta mudança e sem backfill. Mantém
zeros à esquerda e separa a evidência IBS/CBS do CST de ICMS. Aplicar antes de publicar o código.

A migration tenant `1793000000000-snapshot-projecao-postgres` adiciona JSONB nullable
`snapshot_projecao` em `arquivos_ingestao_documentos_fiscais`, gerada com SQL memory do
TypeORM. O snapshot mantém a projeção escolhida pelo cenário independente do acervo mutável.
Não altera RLS/grants nem preenche filas antigas. Aplicação de migration permanece pendente.

## Catálogo NCM local versionado

Migration pública `1792900000000` (publicação atômica + arquivo integral). Não há migration tenant:
fatores, resultados, caches, filas e cópias vinculadas existentes permanecem intactos. O motor
permanece na versão 8. DDL gerado via TypeORM em banco descartável e revisado.
O schema público mantém versão/hash/metodologia; prefixos e registros fora da fonte só permanecem
no arquivo histórico. Colunas BrasilAPI legadas não alimentam o resolver. Não reescrever migrations
históricas. Prévia somente leitura: `npm run db:previa-catalogo-ncm --workspace apps/backend`.
Procedimento coordenado e testes: `docs/operations/CATALOGO_NCM_LOCAL.md`.

## Catálogo NBS local versionado

`1793000000000-publicar-catalogo-nbs-local` arquiva e substitui o catálogo global pela planilha
com 920 códigos exatos, sem mesclar regras antigas nem alterar simulações. Runtime e schema
devem ser publicados juntos. Guia: `docs/operations/CATALOGO_NBS_LOCAL.md`.
