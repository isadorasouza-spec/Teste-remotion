#!/usr/bin/env node
import { AppDataSource } from "./data-source.js";
import {
  buildTenantPrivilegeTarget,
  grantTenantRoleToRuntimeRoles,
  reconcileTenantPrivileges,
  reconciliarPrivilegiosWorkerFiscal,
  resolveTenantObjectOwnerRole,
  revokePublicTablePrivilegesFromTenantRole,
} from "./tenant-privileges.js";

type EscritorioRow = {
  id: string;
};

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

async function readEscritorios(): Promise<EscritorioRow[]> {
  const rows = await AppDataSource.query("SELECT id FROM public.escritorios ORDER BY created_at ASC");
  if (!Array.isArray(rows)) {
    return [];
  }
  return rows.map((row) => ({ id: String(row.id) }));
}

async function reconcileAllTenants(): Promise<void> {
  await reconciliarPrivilegiosWorkerFiscal(AppDataSource.manager);
  const ownerRole = resolveTenantObjectOwnerRole();
  const escritorios = await readEscritorios();

  console.log(`Reconciliando privilégios de ${escritorios.length} tenant(s) [owner: ${ownerRole}]...`);

  for (const escritorio of escritorios) {
    const target = buildTenantPrivilegeTarget(escritorio.id);
    const quotedSchemaName = quoteIdentifier(target.schemaName);

    console.log(`  -> ${target.schemaName} / ${target.roleName}`);
    await AppDataSource.query(`CREATE SCHEMA IF NOT EXISTS ${quotedSchemaName}`);
    await reconcileTenantPrivileges(AppDataSource.manager, target, ownerRole);
    await revokePublicTablePrivilegesFromTenantRole(AppDataSource.manager, target.roleName);
    await grantTenantRoleToRuntimeRoles(AppDataSource.manager, target.roleName);
  }
}

async function main(): Promise<void> {
  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
  }

  try {
    await reconcileAllTenants();
    console.log("Privilégios de tenants reconciliados.");
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
    }
  }
}

main().catch((error) => {
  console.error("Falha ao reconciliar privilégios de tenants:", error);
  process.exit(1);
});
