/** Prévia somente leitura; executa sob transação READ ONLY e não enfileira nem altera fatores. */
import { pathToFileURL } from "node:url";
import type { DataSource } from "typeorm";
import { CATALOGO_NCM } from "./modules/public/migrations/dados/ncm-catalogo-20260916.js";
import { METADADOS_CATALOGO_NCM } from "./modules/public/migrations/dados/ncm-metadados-20260916.js";
import { buildEscritorioSchemaName } from "./tenant-naming.js";

export async function previaCatalogoNcm(ds: DataSource) {
  const q = ds.createQueryRunner(); await q.connect();
  await q.startTransaction("REPEATABLE READ");
  try {
    await q.query("SET TRANSACTION READ ONLY");
    const manifesto = JSON.stringify(CATALOGO_NCM);
    const catalogo = await q.query(`WITH novo AS (
      SELECT * FROM jsonb_to_recordset($1::jsonb) AS n(codigo text, fator numeric, situacao text)
    ) SELECT
      (SELECT count(*)::int FROM public.ncms_referencia a WHERE length(a.codigo) < 8) AS prefixos_a_arquivar,
      (SELECT count(*)::int FROM public.ncms_referencia a WHERE length(a.codigo) = 8 AND NOT EXISTS (SELECT 1 FROM novo n WHERE n.codigo = a.codigo)) AS codigos_antigos_fora_fonte,
      (SELECT count(*)::int FROM public.ncms_referencia WHERE origem_configuracao_fatores = 'admin-plataforma') AS edicoes_admin_a_arquivar,
      (SELECT count(*)::int FROM novo WHERE situacao <> 'automatica') AS requerem_revisao`, [manifesto]);
    const escritorios = await q.query(`SELECT id FROM public.escritorios ORDER BY id`);
    const tenants = [];
    for (const { id } of escritorios as { id: string }[]) {
      const nome = buildEscritorioSchemaName(id);
      const schema = `"${nome.replaceAll('"', '""')}"`;
      const [existe] = await q.query(`SELECT to_regclass($1) AS tabela`, [`${schema}.simulacao_entradas`]);
      if (!existe?.tabela) { tenants.push({ escritorio_id: id, indisponivel: true }); continue; }
      // Owner de migrations pode ler múltiplos schemas; contexto continua explícito por tenant.
      await q.query(`SELECT set_config('app.escritorio_id', $1, true)`, [id]);
      const [impacto] = await q.query(`WITH RECURSIVE novo AS (
        SELECT * FROM jsonb_to_recordset($1::jsonb) AS n(codigo text, fator numeric, situacao text)
      ), entradas AS (
        SELECT e.*, n.codigo AS catalogado, n.situacao,
          CASE WHEN n.situacao = 'automatica' THEN n.fator ELSE 1 END AS novo_fator
        FROM ${schema}.simulacao_entradas e LEFT JOIN novo n ON e.ncm = n.codigo
        WHERE e.escritorio_id = $2 AND e.ncm IS NOT NULL
      ), alvos AS (
        SELECT DISTINCT simulacao_id AS id FROM entradas
        UNION SELECT s.id FROM ${schema}.simulacoes s JOIN alvos a ON s.simulacao_origem_id = a.id WHERE s.escritorio_id = $2
      ) SELECT count(*)::int AS entradas_ncm,
        count(*) FILTER (WHERE catalogado IS NULL)::int AS entradas_fora_catalogo,
        count(*) FILTER (WHERE origem_fator_ibs = 'ncm' AND fator_ibs IS DISTINCT FROM novo_fator)::int AS fatores_ibs_divergentes,
        count(*) FILTER (WHERE origem_fator_cbs = 'ncm' AND fator_cbs IS DISTINCT FROM novo_fator)::int AS fatores_cbs_divergentes,
        (SELECT count(*)::int FROM alvos) AS simulacoes_com_ncm_ou_vinculadas,
        (SELECT coalesce(jsonb_agg(id ORDER BY id), '[]'::jsonb) FROM alvos) AS simulacoes_ids,
        coalesce(jsonb_agg(DISTINCT ncm) FILTER (WHERE catalogado IS NULL), '[]'::jsonb) AS codigos_fora_catalogo,
        coalesce(jsonb_agg(DISTINCT jsonb_build_object('ncm', ncm, 'ibs_anterior', fator_ibs,
          'cbs_anterior', fator_cbs, 'ibs_catalogo', CASE WHEN origem_fator_ibs = 'ncm' THEN novo_fator ELSE fator_ibs END,
          'cbs_catalogo', CASE WHEN origem_fator_cbs = 'ncm' THEN novo_fator ELSE fator_cbs END))
          FILTER (WHERE (origem_fator_ibs = 'ncm' AND fator_ibs IS DISTINCT FROM novo_fator)
            OR (origem_fator_cbs = 'ncm' AND fator_cbs IS DISTINCT FROM novo_fator)), '[]'::jsonb) AS diferencas_fatores
        FROM entradas`, [manifesto, id]);
      tenants.push({ escritorio_id: id, ...impacto });
    }
    await q.commitTransaction();
    // A lista de conflitos é o que exige leitura humana antes de publicar: nela a planilha e a
    // revisão da LC 214/2025 discordam do fator, e o catálogo publica a revisão apenas como sugestão.
    const conflitos = CATALOGO_NCM.filter(r => r.situacao === "conflito").map(r => ({
      codigo: r.codigo, fator_publicado: r.fator,
      fator_planilha: r.evidencias.find(e => e.fonte === "planilha-20260916")?.fator ?? null,
      fator_revisao: r.evidencias.find(e => e.fonte === "revisao-LC214-20260916")?.fator ?? null,
    }));
    const porMotivo = Object.fromEntries([...new Set(CATALOGO_NCM.flatMap(r => r.motivos))]
      .map(motivo => [motivo, CATALOGO_NCM.filter(r => r.motivos.includes(motivo)).length]));
    return { simulacoes_historicas_preservadas: true, versao: METADADOS_CATALOGO_NCM.versao, sha256: METADADOS_CATALOGO_NCM.sha256,
      total: CATALOGO_NCM.length, catalogo: catalogo[0],
      reconciliacao: { ...METADADOS_CATALOGO_NCM.reconciliacao, por_motivo: porMotivo, conflitos }, tenants };
  } catch (erro) { await q.rollbackTransaction(); throw erro; }
  finally { await q.release(); }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { AppDataSource } = await import("./data-source.js");
  try {
    await AppDataSource.initialize();
    console.log(JSON.stringify(await previaCatalogoNcm(AppDataSource), null, 2));
  } finally { if (AppDataSource.isInitialized) await AppDataSource.destroy(); }
}
