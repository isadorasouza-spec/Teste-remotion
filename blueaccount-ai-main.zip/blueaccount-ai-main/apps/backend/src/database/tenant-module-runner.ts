import type { DataSource } from "typeorm";
import { createTenantModuleDataSource } from "./modules/tenant/tenant-datasource.js";

type ModuleName = "tenant";

const MODULE_FACTORIES: Record<ModuleName, (schema: string) => DataSource> = {
  tenant: createTenantModuleDataSource,
};

const MODULE_ORDER: ModuleName[] = ["tenant"];

// Uma única migration de tenant por processo, inclusive entre schemas diferentes.
// A fila deve ser adquirida antes da factory/initialize para não abrir pools em espera.
let filaMigracoesTenant: Promise<void> = Promise.resolve();

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

async function withTenantMigrationLock<T>(
  ds: DataSource,
  schemaName: string,
  moduleName: ModuleName,
  callback: () => Promise<T>,
): Promise<T> {
  const lockNamespace = "blueaccount:tenant-migration";
  const lockResource = `${moduleName}:${schemaName}`;

  await ds.query("SELECT pg_advisory_lock(hashtext($1), hashtext($2))", [lockNamespace, lockResource]);
  try {
    return await callback();
  } finally {
    await ds.query("SELECT pg_advisory_unlock(hashtext($1), hashtext($2))", [lockNamespace, lockResource]);
  }
}

/**
 * Aplica todas as migrations pendentes de todos os módulos em um schema de tenant.
 * Chamado durante o provisionamento de um novo escritório e pelo sync.
 */
export async function runTenantMigrations(schemaName: string): Promise<void> {
  for (const moduleName of MODULE_ORDER) {
    await runModuleMigrations(schemaName, MODULE_FACTORIES[moduleName], moduleName);
  }
}

/**
 * Aplica migrations pendentes de um módulo específico em um schema de tenant.
 */
export async function runModuleMigrations(
  schemaName: string,
  factory: (schema: string) => DataSource,
  moduleName: ModuleName = "tenant",
): Promise<void> {
  const anterior = filaMigracoesTenant;
  let liberar!: () => void;
  filaMigracoesTenant = new Promise<void>((resolve) => { liberar = resolve; });
  await anterior;
  try {
    const ds = factory(schemaName);
    await ds.initialize();
    try {
      await withTenantMigrationLock(ds, schemaName, moduleName, async () => {
        await ds.query(`CREATE SCHEMA IF NOT EXISTS ${quoteIdentifier(schemaName)}`);
        await ds.runMigrations();
      });
    } finally {
      await ds.destroy();
    }
  } finally {
    liberar();
  }
}

/**
 * Aplica migrations de todos os módulos de tenant em todos os escritórios existentes.
 * Usado pelo DatabaseBootstrapService na inicialização da aplicação.
 */
export async function syncTenantSchemasFromDatabase(): Promise<void> {
  const { AppDataSource } = await import("./data-source.js");
  const { Escritorio } = await import("./modules/public/entities/escritorio.entity.js");
  const { buildEscritorioSchemaName } = await import("./tenant-naming.js");

  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
  }

  const escritorios = await AppDataSource.getRepository(Escritorio).find({ select: { id: true } });
  for (const escritorio of escritorios) {
    await runTenantMigrations(buildEscritorioSchemaName(escritorio.id));
  }
}

export { MODULE_FACTORIES, MODULE_ORDER };
export type { ModuleName };
