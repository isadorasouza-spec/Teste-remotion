export function buildEscritorioSchemaName(escritorioId: string): string {
  const normalized = escritorioId.trim().toLowerCase().replace(/-/g, "_");
  if (!normalized) {
    throw new Error("escritorio_id é obrigatório.");
  }

  return `escritorio_${normalized}`;
}

export function buildEscritorioRoleName(escritorioId: string): string {
  const normalized = escritorioId.trim().toLowerCase().replace(/-/g, "_");
  if (!normalized) {
    throw new Error("escritorio_id é obrigatório.");
  }

  return `user_escritorio_${normalized}`;
}

