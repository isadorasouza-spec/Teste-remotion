/** Limite por pool; cada processo mantém pools owner e RLS independentes. */
export function resolverLimitePool(valor = process.env.DB_POOL_MAX): number {
  if (typeof valor !== "string" || !/^\d+$/.test(valor.trim())) return 10;
  const limite = Number(valor);
  return Number.isSafeInteger(limite) && limite > 0 && limite <= 10_000 ? limite : 10;
}
