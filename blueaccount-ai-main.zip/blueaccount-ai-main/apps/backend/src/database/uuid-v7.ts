/**
 * SQL compartilhado da migração de chaves primárias para UUIDv7 (ordenado por tempo).
 *
 * As duas migrations (`public` e `tenant`) executam exatamente o mesmo corpo, cada uma no seu
 * `current_schema()`. Mantê-lo aqui evita divergência entre elas.
 *
 * ## Por que o nome da função é inglês (`uuid_generate_v7`)
 *
 * É um shim de compatibilidade, não um nome de domínio. O TypeORM só reconhece uma coluna como
 * "uuid gerado" se o DEFAULT casar com `gen_random_uuid()` ou com `/^uuid_generate_v\d\(\)/`
 * (`typeorm/driver/postgres/PostgresQueryRunner.js`, em `loadTables`). Com qualquer outro nome, o
 * `migration:generate` passaria a emitir ALTERs revertendo as ~56 PKs para v4 a cada execução.
 * O nome também acompanha a família `uuid-ossp` já usada no schema público.
 *
 * ## Nativo no PG18, shim no PG16
 *
 * `uuidv7()` existe nativo a partir do Postgres 18 (em `pg_catalog`, junto de `uuid_extract_version()`
 * e `uuid_extract_timestamp()`). Produção roda o parameter group `postgres18`; local/CI/stress rodam
 * `postgres:16-alpine`. A função escolhe o corpo uma única vez, na criação:
 *
 * - **PG18+** delega para o `uuidv7()` nativo, que preenche o campo `rand_a` com precisão
 *   sub-milissegundo (método 3 da RFC 9562). Medido: 2000 inserções em 3 milissegundos, nenhuma
 *   fora de ordem.
 * - **PG16** usa o shim em plpgsql sobre `gen_random_uuid()` (core desde o PG13), cuja granularidade
 *   é o milissegundo. Medido: 2000 inserções em 7 milissegundos, ordenadas entre milissegundos mas
 *   empatadas dentro de cada um.
 *
 * O que NÃO diverge entre ambientes: o nome da função, todos os DEFAULTs gravados nas colunas e o
 * autoteste. A diferença fica confinada ao corpo. Nos dois casos a localidade de inserção no índice
 * — o objetivo real da mudança — é idêntica.
 *
 * Efeito colateral bem-vindo: depois desta migration nada no schema depende mais da extensão
 * `uuid-ossp`, que nenhuma migration do repositório chega a criar.
 */

/**
 * Cria a função geradora de UUIDv7, escolhendo o corpo conforme a versão do servidor.
 *
 * Layout do UUIDv7 (RFC 9562): os 48 bits mais significativos são o timestamp Unix em
 * milissegundos, big-endian, seguidos do nibble de versão (`7`) e de 74 bits aleatórios. Por isso
 * ids gerados em sequência são crescentes e inserem na borda direita do índice B-tree, em vez de
 * espalhar por páginas aleatórias como o v4.
 *
 * O shim (PG16) sobrepõe o timestamp nos 6 primeiros bytes de um `gen_random_uuid()` e corrige o
 * nibble de versão de 4 (`0100`) para 7 (`0111`). O nibble de variante do v4 já é o exigido pelo v7
 * (`10xx`), então permanece intacto.
 *
 * A função é sempre `VOLATILE`: precisa ser reavaliada por linha, nunca dobrada em constante.
 *
 * `CREATE OR REPLACE` torna a criação idempotente — as duas migrations podem declará-la sem
 * conflito. Se o banco for atualizado do PG16 para o PG18 depois, basta reexecutar este bloco para
 * a função passar a delegar ao nativo; os DEFAULTs das colunas não mudam.
 */
export const SQL_CRIAR_FUNCAO_UUID_V7 = `
DO $criacao$
BEGIN
  IF current_setting('server_version_num')::int >= 180000 THEN
    EXECUTE $nativo$
      CREATE OR REPLACE FUNCTION public.uuid_generate_v7() RETURNS uuid
      LANGUAGE sql VOLATILE AS 'SELECT uuidv7()'
    $nativo$;
  ELSE
    EXECUTE $shim$
      CREATE OR REPLACE FUNCTION public.uuid_generate_v7() RETURNS uuid
      LANGUAGE plpgsql VOLATILE AS $corpo$
      BEGIN
        RETURN encode(
          set_bit(
            set_bit(
              overlay(
                uuid_send(gen_random_uuid())
                PLACING substring(int8send(floor(extract(epoch FROM clock_timestamp()) * 1000)::bigint) FROM 3)
                FROM 1 FOR 6
              ),
              52, 1),
            53, 1),
          'hex')::uuid;
      END
      $corpo$
    $shim$;
  END IF;
END
$criacao$
`;

/**
 * Autoteste executado logo após criar a função: a migration falha alto se a manipulação de bits
 * estiver errada, em vez de deixar o banco gerando UUID malformado em silêncio.
 *
 * Verifica as três propriedades que importam:
 * 1. nibble de versão = `7` (posição 15 do texto canônico);
 * 2. nibble de variante em `8|9|a|b` (posição 20) — RFC 9562;
 * 3. o prefixo de 48 bits decodifica para o horário atual (tolerância de 60s), que é o que prova
 *    que o timestamp foi sobreposto na ordem e no offset certos. Só o nibble de versão não pegaria
 *    um erro de endianness.
 */
export const SQL_VERIFICAR_FUNCAO_UUID_V7 = `
DO $verificacao$
DECLARE
  gerado uuid;
  ms_do_id bigint;
  ms_agora bigint;
BEGIN
  gerado := public.uuid_generate_v7();

  IF substring(gerado::text FROM 15 FOR 1) <> '7' THEN
    RAISE EXCEPTION 'uuid_generate_v7() gerou versao invalida: %', gerado;
  END IF;

  IF substring(gerado::text FROM 20 FOR 1) NOT IN ('8', '9', 'a', 'b') THEN
    RAISE EXCEPTION 'uuid_generate_v7() gerou variante invalida: %', gerado;
  END IF;

  ms_do_id := (('x0000' || substring(replace(gerado::text, '-', '') FROM 1 FOR 12))::bit(64))::bigint;
  ms_agora := floor(extract(epoch FROM clock_timestamp()) * 1000)::bigint;

  IF abs(ms_agora - ms_do_id) > 60000 THEN
    RAISE EXCEPTION 'uuid_generate_v7() gerou timestamp fora de hora (id=%, ms_do_id=%, ms_agora=%)',
      gerado, ms_do_id, ms_agora;
  END IF;
END
$verificacao$
`;

/**
 * Troca o DEFAULT de toda coluna `uuid` do schema corrente que ainda gera v4.
 *
 * É dirigido por catálogo, e não por uma lista fixa de ~56 tabelas, por dois motivos: a lista
 * envelheceria, e schemas de tenant diferentes podem estar em pontos diferentes da fila de
 * migrations. O join com `information_schema.tables` filtrando `BASE TABLE` é obrigatório —
 * `information_schema.columns` também lista views, e `ALTER TABLE` em view falha.
 *
 * O DEFAULT é gravado SEM qualificar o schema (`uuid_generate_v7()`, não
 * `public.uuid_generate_v7()`): o Postgres só renderiza a expressão qualificada quando a função
 * não está visível pelo `search_path` de quem introspecta, e a forma qualificada não casaria com
 * o regex do TypeORM. A resolução em tempo de DDL não muda — `public` está no `search_path` tanto
 * do datasource público quanto do de tenant (`search_path=<schema>,public`).
 */
export function sqlTrocarDefaultsUuid(funcaoDestino: "uuid_generate_v7" | "gen_random_uuid"): string {
  const condicaoOrigem =
    funcaoDestino === "uuid_generate_v7"
      ? `(c.column_default = 'gen_random_uuid()' OR c.column_default ~ '^uuid_generate_v\\d\\(\\)')`
      : `c.column_default = 'uuid_generate_v7()'`;

  return `
DO $troca$
DECLARE alvo record;
BEGIN
  FOR alvo IN
    SELECT c.table_schema, c.table_name, c.column_name
    FROM information_schema.columns c
    JOIN information_schema.tables t
      ON t.table_schema = c.table_schema AND t.table_name = c.table_name
    WHERE c.table_schema = current_schema()
      AND t.table_type = 'BASE TABLE'
      AND c.data_type = 'uuid'
      AND ${condicaoOrigem}
  LOOP
    EXECUTE format(
      'ALTER TABLE %I.%I ALTER COLUMN %I SET DEFAULT ${funcaoDestino}()',
      alvo.table_schema, alvo.table_name, alvo.column_name
    );
  END LOOP;
END
$troca$
`;
}
