// Public module
export { AdminSession } from "./modules/public/entities/admin-session.entity.js";
export { AgentLog } from "./modules/public/entities/agent-log.entity.js";
export { Contexto } from "./modules/public/entities/contexto.entity.js";
export type { JsonValue } from "./modules/public/entities/contexto.entity.js";
export { Escritorio } from "./modules/public/entities/escritorio.entity.js";
export { Sessao } from "./modules/public/entities/sessao.entity.js";
export { Usuario } from "./modules/public/entities/usuario.entity.js";

// Módulo escritório
export { Cliente } from "./modules/tenant/entities/cliente.entity.js";
export { Documento } from "./modules/tenant/entities/documento.entity.js";
export type { DocumentoModulo, DocumentoStatusUpload, DocumentoStatusExtracao, TipoDocumentoContratual } from "./modules/tenant/entities/documento.entity.js";
export { Extracao } from "./modules/tenant/entities/extracao.entity.js";
export type { TipoExtracao } from "./modules/tenant/entities/extracao.entity.js";

// Módulo contrato
export { Contrato } from "./modules/tenant/entities/contrato.entity.js";
export { ContratoDocumentoAnexo } from "./modules/tenant/entities/contrato-documento-anexo.entity.js";
export { ClausulasExcedentes } from "./modules/tenant/entities/clausulas-excedentes.entity.js";
export type { TipoCobrancaExcedente } from "./modules/tenant/entities/clausulas-excedentes.entity.js";
export { ServicosContratados } from "./modules/tenant/entities/servicos-contratados.entity.js";

// Módulo relatório
export { Relatorio } from "./modules/tenant/entities/relatorio.entity.js";
export type { TipoRelatorio } from "./modules/tenant/entities/relatorio.entity.js";
export { RelatorioEstatisticaCliente } from "./modules/tenant/entities/relatorio-estatistica-cliente.entity.js";

// Módulo valores a cobrar
export { ValoresACobrar } from "./modules/tenant/entities/valores-a-cobrar.entity.js";
export { CobrancaTest } from "./modules/tenant/entities/cobranca-test.entity.js";
export type {
  CobrancaMitigacao,
  StatusAuditoriaCobranca,
  StatusValoresACobrar,
  ItemCobrado,
  ValoresCalculados,
} from "./modules/tenant/entities/valores-a-cobrar.entity.js";
export type { StatusCobrancaTest } from "./modules/tenant/entities/cobranca-test.entity.js";

// Utilitários de banco
export { AppDataSource } from "./data-source.js";
export { buildEscritorioSchemaName, buildEscritorioRoleName } from "./tenant-naming.js";
export { provisionEscritorioSchema } from "./escritorio-schema.js";
