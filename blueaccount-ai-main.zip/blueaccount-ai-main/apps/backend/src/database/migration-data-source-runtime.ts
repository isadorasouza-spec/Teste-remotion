import "reflect-metadata";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { DataSource } from "typeorm";
import { config } from "dotenv";
import { AdminSession } from "./modules/public/entities/admin-session.entity.js";
import { DesafioMfa } from "./modules/public/entities/desafio-mfa.entity.js";
import { FatorMfaAdminPlataforma } from "./modules/public/entities/fator-mfa-admin-plataforma.entity.js";
import { FatorMfaUsuario } from "./modules/public/entities/fator-mfa-usuario.entity.js";
import { EventoAuditoriaSeguranca } from "./modules/public/entities/evento-auditoria-seguranca.entity.js";
import { AgentLog } from "./modules/public/entities/agent-log.entity.js";
import { AlertaAgentcore } from "./modules/public/entities/alerta-agentcore.entity.js";
import { Contexto } from "./modules/public/entities/contexto.entity.js";
import { Escritorio } from "./modules/public/entities/escritorio.entity.js";
import { SeedRun } from "./modules/public/entities/seed-run.entity.js";
import { SeedRunApiCall } from "./modules/public/entities/seed-run-api-call.entity.js";
import { Sessao } from "./modules/public/entities/sessao.entity.js";
import { Usuario } from "./modules/public/entities/usuario.entity.js";
import { IngestaoControleConcorrencia } from "./modules/public/entities/ingestao-controle-concorrencia.entity.js";
import { IngestaoPermissaoProcessamento } from "./modules/public/entities/ingestao-permissao-processamento.entity.js";
import { CobrancaFila } from "./modules/public/entities/cobranca-fila.entity.js";
import { SimulacaoCalculoFila } from "./modules/public/entities/simulacao-calculo-fila.entity.js";
import { SimulacaoFilaControle } from "./modules/public/entities/simulacao-fila-controle.entity.js";
import { IndiceInflacao } from "./modules/public/entities/indice-inflacao.entity.js";
import { CnaeReferencia } from "./modules/public/entities/cnae-referencia.entity.js";
import { NcmReferencia } from "./modules/public/entities/ncm-referencia.entity.js";
import { NbsReferencia } from "./modules/public/entities/nbs-referencia.entity.js";
import { SimplesCnae } from "./modules/public/entities/simples-cnae.entity.js";
import { SimplesAnexo } from "./modules/public/entities/simples-anexo.entity.js";
import { SimplesAnexoReparticao } from "./modules/public/entities/simples-anexo-reparticao.entity.js";
import { SolicitacaoPrivacidade } from "./modules/public/entities/solicitacao-privacidade.entity.js";
import { IncidenteDadosPessoais } from "./modules/public/entities/incidente-dados-pessoais.entity.js";
import { TombstonePrivacidade } from "./modules/public/entities/tombstone-privacidade.entity.js";

config();

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (typeof value !== "string") {
    return fallback;
  }
  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "y", "on"].includes(normalized)) {
    return true;
  }
  if (["0", "false", "no", "n", "off"].includes(normalized)) {
    return false;
  }
  return fallback;
}

const sslEnabled = parseBoolean(process.env.DB_SSL, false);
const sslRejectUnauthorized = parseBoolean(process.env.DB_SSL_REJECT_UNAUTHORIZED, true);

// Glob absoluto resolvido a partir da localização deste arquivo, NÃO do
// process.cwd(). O deploy/CI invoca o CLI do TypeORM a partir da raiz do
// monorepo (`node node_modules/typeorm/cli.js -d apps/backend/dist/...`), então
// um glob relativo como "dist/database/..." resolvia para <raiz>/dist/... e não
// casava com nenhum arquivo — migration:run carregava 0 migrations e virava
// no-op silencioso (exit 0). Manter absoluto (padrão de tenant-datasource.ts).
const migrationsDir = join(
  dirname(fileURLToPath(import.meta.url)),
  "modules/public/migrations/*.js",
);

const MigrationDataSourceRuntime = new DataSource({
  poolSize: 2,
  type: "postgres",
  host: process.env.DB_HOST ?? "localhost",
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USERNAME ?? "blueaccount",
  password: process.env.DB_PASSWORD ?? "blueaccount",
  database: process.env.DB_DATABASE ?? "blueaccount",
  synchronize: false,
  logging: process.env.DB_LOGGING === "true",
  ssl: sslEnabled ? { rejectUnauthorized: sslRejectUnauthorized } : false,
  entities: [AdminSession, DesafioMfa, FatorMfaAdminPlataforma, FatorMfaUsuario, EventoAuditoriaSeguranca, AgentLog, AlertaAgentcore, CnaeReferencia, NcmReferencia, NbsReferencia, SimplesCnae, SimplesAnexo, SimplesAnexoReparticao, Contexto, Escritorio, IngestaoControleConcorrencia, IngestaoPermissaoProcessamento, CobrancaFila, SimulacaoCalculoFila, SimulacaoFilaControle, IndiceInflacao, SeedRun, SeedRunApiCall, Sessao, Usuario, SolicitacaoPrivacidade, IncidenteDadosPessoais, TombstonePrivacidade],
  migrations: [migrationsDir],
});

export default MigrationDataSourceRuntime;
