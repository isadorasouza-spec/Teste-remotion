import type { EntityManager } from "typeorm";
import { runTenantMigrations } from "./tenant-module-runner.js";
import { buildEscritorioRoleName, buildEscritorioSchemaName } from "./tenant-naming.js";
import {
  grantTenantRoleToRuntimeRoles,
  reconcileTenantPrivileges,
  resolveTenantObjectOwnerRole,
  revokePublicTablePrivilegesFromTenantRole,
} from "./tenant-privileges.js";

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

export async function provisionEscritorioSchema(
  manager: EntityManager,
  escritorioId: string,
): Promise<{ schemaName: string }> {
  const schemaName = buildEscritorioSchemaName(escritorioId);
  const roleName = buildEscritorioRoleName(escritorioId);
  const quotedSchemaName = quoteIdentifier(schemaName);
  const quotedRoleName = quoteIdentifier(roleName);
  const ownerRole = resolveTenantObjectOwnerRole();
  const quotedOwnerRole = quoteIdentifier(ownerRole);

  await manager.query(`CREATE SCHEMA IF NOT EXISTS ${quotedSchemaName}`);

  const existingRole = await manager.query(`SELECT 1 FROM pg_roles WHERE rolname = $1 LIMIT 1`, [roleName]);
  if (!Array.isArray(existingRole) || existingRole.length === 0) {
    await manager.query(`CREATE ROLE ${quotedRoleName} NOLOGIN`);
  }

  await reconcileTenantPrivileges(manager, { schemaName, roleName }, ownerRole);
  await revokePublicTablePrivilegesFromTenantRole(manager, roleName);
  await runTenantMigrations(schemaName);
  await reconcileTenantPrivileges(manager, { schemaName, roleName }, ownerRole);
  await revokePublicTablePrivilegesFromTenantRole(manager, roleName);
  await manager.query(`GRANT ${quotedRoleName} TO ${quotedOwnerRole}`);
  await grantTenantRoleToRuntimeRoles(manager, roleName);

  return { schemaName };
}

/**
 * Contraparte de `provisionEscritorioSchema`: dropa o schema do tenant (CASCADE,
 * removendo todas as tabelas/dados) e a role do escritório. Idempotente — pode
 * rodar de novo mesmo que schema/role já não existam. Usado no hard-delete de
 * escritório (compliance/LGPD).
 */
export async function dropEscritorioSchema(
  manager: EntityManager,
  escritorioId: string,
): Promise<{ schemaName: string }> {
  const schemaName = buildEscritorioSchemaName(escritorioId);
  const roleName = buildEscritorioRoleName(escritorioId);
  const quotedSchemaName = quoteIdentifier(schemaName);
  const quotedRoleName = quoteIdentifier(roleName);

  await manager.query(`DROP SCHEMA IF EXISTS ${quotedSchemaName} CASCADE`);

  const existingRole = await manager.query(`SELECT 1 FROM pg_roles WHERE rolname = $1 LIMIT 1`, [roleName]);
  if (Array.isArray(existingRole) && existingRole.length > 0) {
    // DROP OWNED remove privilégios e default privileges concedidos à role;
    // DROP ROLE em seguida derruba as memberships (owner + runtime roles).
    await manager.query(`DROP OWNED BY ${quotedRoleName} CASCADE`);
    await manager.query(`DROP ROLE ${quotedRoleName}`);
  }

  return { schemaName };
}
