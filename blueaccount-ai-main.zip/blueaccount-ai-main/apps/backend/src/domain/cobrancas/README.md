# Domínio: Cobranças

Este README é a referência do cluster de cobrança do backend. O cluster é
dividido por etapa do fluxo, não por canal de entrada:

| Área | Responsabilidade | Não deve fazer |
| --- | --- | --- |
| `domain/valores-a-cobrar` | Consolidação mensal, snapshot de contrato/relatórios/faturamento, geração do cálculo pelo agente e versionamento do resultado | Emitir cobranças no provedor |
| `domain/cobrancas` | Cálculo comparativo legado, emissão em plataformas externas, ciclo de vida da cobrança e avaliações de cobrança | Recalcular VAC ou consolidar relatórios |
| `domain/faturamento` | Faturamento observado/manual e gatilho de reconsolidação quando o valor cobrado muda | Chamar provedor externo diretamente |
| `modules/valores-a-cobrar` | HTTP/orquestração do VAC, callback interno do agente e endpoints de contexto | Regra central ou SDK AWS |
| `modules/cobrancas` | HTTP/orquestração de plataformas, emissão e webhooks | Cálculo de excedentes/VAC |
| `modules/faturamento` | HTTP/orquestração de faturamento manual e sincronização via `CobrancasService` | Implementar provider |
| `modules/eval-cobranca` | HTTP/orquestração do harness de avaliação de cobrança | Expor eval para escritórios não-teste |

Fluxo principal:

```txt
relatórios/contratos/faturamento
  -> domain/valores-a-cobrar consolida VAC
  -> gerarCobranca chama AgentCore via infrastructure e versiona resultado
  -> domain/cobrancas valida preview/approval_hash e emite no provedor
  -> webhook/sincronização atualiza cobrancas, valores_a_cobrar e faturamento
  -> domain/faturamento dispara reconsolidação quando o observado muda
```

AWS/AgentCore/S3 pertencem a `infrastructure/external-services`. Os arquivos
de domínio deste cluster não devem importar `@aws-sdk/*` diretamente.

Regras de negócio da emissão e do ciclo de vida de cobranças em plataformas externas. Independente de Nest/HTTP — só usa entidades TypeORM e o `runQueryWithRls`.

## Arquivos

| Arquivo | Função |
| --- | --- |
| `cobranca.service.ts` | Cálculo comparativo legado e helpers puros usados por clientes/serviços contratados |
| `cobrancas.service.ts` | Fachada Nest/DI que preserva o contrato público e delega para os casos de uso transacionais |
| `cobrancas-context.ts` | Dependências compartilhadas da fachada (`CryptoService`, `PlataformasCobrancaService`) |
| `cobrancas-customers.ts` | Garantia/resolução de customer externo no provedor |
| `cobrancas-grupo.ts` | Regras de grupo consolidado/híbrido para emissão |
| `cobrancas-faturamento-sync.ts` | Sincronização de faturamento observado a partir do provedor |
| `cobrancas-emissao.ts` | Preview e emissão financeira a partir de `valores_a_cobrar` |
| `cobrancas-lifecycle.ts` | Cancelamento, retificação, sincronização, listagens e aplicação de status/webhooks |
| `cobrancas-approval.ts` | Hash server-side de aprovação |
| `cobrancas-desconto.ts` | Parsing e cálculo de desconto por adimplência |
| `cobrancas-descricao.ts` | Descrição compacta enviada ao provedor |
| `cobrancas-errors.ts` | Erros de domínio e pendências de grupo |
| `cobrancas-types.ts` | Tipos públicos de input/preview/sincronização |
| `cobrancas-utils.ts` | Helpers de plataforma, competência e idempotência |
| `cobranca-tests.service.ts` | Harness de avaliação de cobrança para escritórios marcados como ambiente de teste |
| `plataformas-cobranca.service.ts` | CRUD da configuração por escritório (lista, cadastra, testa, desativa, registra webhook) |
| `provedor.factory.ts` | Constrói o `ProvedorCobranca` a partir de uma `PlataformaCobranca` (decifra a key + instancia o client) |
| `provedor-cobranca.interface.ts` | Contrato comum entre provedores (criar/atualizar/deletar/consultar customer + cobrança + webhook) |
| `provedores/asaas.provider.ts` | Implementação Asaas + `mapAsaasStatus()` |
| `provedores/stripe.provider.ts` | Implementação Stripe Invoicing + mapeamento de status de invoice |

## Testes

- `tests/cobranca.service.test.ts`
- `tests/cobranca-tests.service.test.ts`
- `tests/cobrancas.service.test.ts`
- `tests/plataformas-cobranca.service.test.ts`
- `tests/asaas.provider.test.ts`
- `tests/stripe.provider.test.ts`

## Cálculo do valor

`enviarCobrancaParaValorACobrar` soma o valor a partir de `valores_calculados`:

```
valor = valor_base + Σ(excedente.quantidade × excedente.valor_unitario)
```

Não usa `valores_a_cobrar.total` nem `total_excedentes` diretamente (esses são snapshots derivados que podem estar zerados). Se o resultado for ≤ 0, lança erro com os componentes no payload.

## Garantia de customer

Antes de criar a cobrança, `garantirCustomerExterno` busca em `clientes_plataforma_cobranca`. Se não houver mapping local, o provider tenta resolver o customer pelo documento antes de criar um novo. Asaas consulta CPF/CNPJ diretamente; Stripe usa metadata `cpfCnpj`. Quando encontra um cliente existente, persiste esse `id_externo_cliente`; quando não encontra, cria customer no provedor (`razao_social` + `cnpj`) e persiste o mapping. Reuso garante que o mesmo `id_externo_cliente` é usado em todas as cobranças subsequentes daquele cliente naquela plataforma.

## Idempotência

`externalReference` enviado ao provedor é sempre `valores_a_cobrar.id`. Permite identificar duplicatas no painel da plataforma e reconciliar cobranças manualmente se necessário.

## Stripe Invoicing

No v1, a Stripe cria invoice em BRL com `collection_method = send_invoice`, cria o invoice item preso diretamente ao draft (`invoice: invoice.id`), finaliza a invoice e persiste o `hosted_invoice_url` em `url_boleto` por compatibilidade. O draft usa `pending_invoice_items_behavior = exclude` para não misturar itens pendentes antigos do customer nem depender de pending items para compor o total. A chamada explícita `sendInvoice` não é executada automaticamente porque contas/test mode podem retornar `invalid_request_error` com "This invoice cannot be sent right now"; a Kontiva deve salvar a invoice finalizada e expor o link de pagamento. Se o envio automático por email voltar a ser requisito, reintroduzir essa etapa como ação separada e resiliente.

## Webhook → propagação

`aplicarStatusViaToken` é chamado pelo controller público após validar o token. Quando o novo status é `paga`:

1. `cobrancas.status = "paga"`, `pago_em = NOW()`, `payload_ultimo_evento = payload`.
2. `valores_a_cobrar.status = "pago"`, `total_cobrado = cobranca.valor`.
3. Upsert em `faturamento` (criação ou update da linha `(cliente_id, competencia)` ativa) com `discriminacao = "<Provedor> <id_externo>"`.

Tudo acontece dentro de uma transação RLS por escritório.

## Consulta de faturamento no provedor

`sincronizarFaturamentoDoProvedor({ escritorioId, clienteId, competencia })` consulta a plataforma ativa para descobrir quanto foi cobrado de um cliente em uma competência (MM/AAAA) e grava o resultado em `faturamento`. É o caminho inverso do webhook: em vez de esperar o pagamento de uma cobrança emitida pela Kontiva, busca ativamente o que existe na plataforma — inclusive cobranças lançadas direto lá.

1. Resolve o customer externo **sem criar** (`resolverCustomerExterno` → mapping local ou `buscarCustomerPorDocumento` pelo CNPJ; se não existir, retorna `encontrado: false` e não grava nada).
2. Converte a competência no intervalo de **vencimento** `[YYYY-MM-01, último dia]` e chama `provedor.listarCobrancas` (pagina enquanto `hasMore`).
3. Soma o `valor` de **todas as cobranças não deletadas**, independente do status.
4. Upsert em `faturamento` da linha `(cliente_id, competencia)` ativa com `arquivo_origem = "<Provedor> (consulta)"` e os itens em `payload_normalizado_ui`.
5. Dispara `consolidarCompetencia` em background para refletir o novo faturamento na comparação `valores_a_cobrar × faturamento`.

Exposto por `POST /api/faturamento/sincronizar-plataforma`. Sem plataforma ativa → `PlataformaCobrancaAusenteError` (HTTP 409).

## Dependências DI

Os services `CobrancasService` e `PlataformasCobrancaService` usam `@Inject(Token)` explícito no construtor — este projeto exige Inject decorator, não funciona com inferência por tipo. `CryptoService` é provider local do módulo `CobrancasModule`.

## RLS

Todas as operações: `runQueryWithRls({ escritorio_id }, ...)`. O webhook é público, mas o controller abre o contexto RLS com o `escritorioId` da URL antes de consultar `plataformas_cobranca` — e só prossegue se o token do webhook bater.

O `webhook_auth_token` é guardado criptografado (`webhook_auth_token_encrypted`/`_iv`/`_tag`, AES-256-GCM
via `CryptoService`), como a `api_key` e o `webhook_secret` da mesma tabela. Precisa ser reversível, e
não hash, porque `registrarWebhook()` reenvia o token em texto puro para a Asaas ao registrar/renovar.
Use `lerTokenWebhook(row, crypto)` para obtê-lo; ela devolve `null` quando a linha não tem as três partes.
