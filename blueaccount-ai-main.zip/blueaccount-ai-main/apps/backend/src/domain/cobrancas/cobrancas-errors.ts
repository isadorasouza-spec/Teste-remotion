// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
/** Emissão/sincronização recusada porque não há plataforma ativa configurada. */
export class PlataformaCobrancaAusenteError extends Error {
  /** Cria erro de ausência de plataforma com mensagem segura para usuário final. */
  constructor() {
    super("Nenhuma plataforma de cobrança ativa cadastrada para este escritório.");
  }
}

/** Emissão recusada porque o registro não está no estado elegível (`pronto_para_revisao`). */
export class StatusNaoElegivelError extends Error {
  /** Guarda o status atual para o controller devolver diagnóstico acionável. */
  constructor(public readonly statusAtual: string) {
    super(
      `Cobrança só pode ser emitida quando o registro está "pronto_para_revisao" (status atual: "${statusAtual}"). ` +
        `Feche o registro antes de emitir.`,
    );
  }
}

/**
 * Emissão recusada porque os insumos (contrato/relatório/faturamento/serviços)
 * mudaram desde o último cálculo: o billing está `stale`. Diferente do
 * approval_hash, que cobre o OUTPUT (valores_calculados/total) — este cobre os
 * INSUMOS, fechando o caso em que um insumo muda sem alterar o output persistido.
 */
export class CobrancaStaleError extends Error {
  /** Guarda o motivo da divergência de insumos para orientar recálculo. */
  constructor(public readonly motivo: string | null) {
    super(
      "Os insumos desta cobrança mudaram desde o último cálculo" +
        (motivo ? ` (${motivo})` : "") +
        ". Recalcule a cobrança (gerar-cobranca) para gerar uma nova versão antes de emitir.",
    );
  }
}

/** Emissão recusada porque já existe faturamento observado para o VAC. */
export class FaturamentoExistenteError extends Error {
  /** Cria erro de bloqueio para evitar emissão duplicada quando faturamento já foi importado/sincronizado. */
  constructor() {
    super(
      "Este valor a cobrar já possui faturamento observado. Não é possível criar uma nova cobrança para evitar duplicidade.",
    );
  }
}

/** Emissão recusada porque o approval_hash não corresponde ao snapshot atual do registro. */
export class ApprovalHashMismatchError extends Error {
  /** Guarda hashes esperado e calculado para auditoria e resposta HTTP 409. */
  constructor(
    public readonly expected: string,
    public readonly computed: string,
  ) {
    super(
      "O registro foi modificado desde o preview. Chame o preview novamente para obter um approval_hash " +
        "atualizado e revisar os novos valores antes de emitir.",
    );
  }
}

/**
 * Emissão recusada porque o registro pertence a uma filha de grupo em modo
 * consolidado: o valor dela é cobrado na fatura única da holding.
 */
export class MembroGrupoConsolidadoError extends Error {
  /** Cria erro de bloqueio para filhas cobradas pela holding. */
  constructor() {
    super(
      "Empresas de grupo consolidado não emitem cobrança no próprio nome — o valor desta empresa entra " +
        "como item na cobrança única da holding. Emita a cobrança pelo registro da holding.",
    );
  }
}

/**
 * Emissão da holding recusada porque há filhas com contrato próprio sem
 * cobrança calculada (ou com itens desatualizados) na competência.
 */
export class MembrosPendentesError extends Error {
  /** Guarda membros pendentes para que a UI consiga indicar quais cobranças recalcular. */
  constructor(public readonly membrosPendentes: MembroPendente[]) {
    const nomes = membrosPendentes.map((m) => m.razao_social ?? m.cliente_id).join(", ");
    super(
      `A cobrança da holding só pode ser emitida quando todas as empresas do grupo com contrato próprio ` +
        `tiverem cobrança calculada e atualizada na competência. Pendentes: ${nomes}. ` +
        `Gere/recalcule a cobrança dessas empresas e refaça o preview.`,
    );
  }
}

export interface MembroPendente {
  cliente_id: string;
  cnpj: string | null;
  razao_social: string | null;
  motivo: "sem_calculo" | "desatualizado";
}
