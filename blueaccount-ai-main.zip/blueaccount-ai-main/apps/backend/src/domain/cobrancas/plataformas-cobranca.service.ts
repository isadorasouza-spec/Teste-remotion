import { Inject, Injectable } from "@nestjs/common";
import { randomBytes } from "node:crypto";
import { runQueryWithRls } from "../../database/data-source.js";
import {
  PlataformaCobranca,
  type AmbientePlataformaCobranca,
  type TipoPlataformaCobranca,
} from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";
import { CryptoService } from "../../infrastructure/security/crypto.service.js";
import { buildProvedor } from "./provedor.factory.js";
import { settings } from "../../settings.js";
import { AsaasApiError } from "../../infrastructure/external-services/asaas/asaas.client.js";

export interface PlataformaCobrancaPublic {
  id: string;
  plataforma: TipoPlataformaCobranca;
  ambiente: AmbientePlataformaCobranca;
  api_key_hint: string | null;
  webhook_secret_hint: string | null;
  webhook_id_externo: string | null;
  ativo: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface CreatePlataformaInput {
  plataforma: TipoPlataformaCobranca;
  ambiente: AmbientePlataformaCobranca;
  api_key: string;
  webhook_secret?: string;
  registrar_webhook?: boolean;
}

/**
 * Descriptografa o token de webhook da plataforma.
 *
 * Compartilhado entre o cadastro/renovação (que reenvia o token à Asaas) e o handler do webhook
 * (que compara com o header recebido). Devolve `null` quando a linha não tem as três partes do
 * segredo — chamador trata como token inválido em vez de estourar.
 */
export function lerTokenWebhook(
  row: Pick<PlataformaCobranca, "webhook_auth_token_encrypted" | "webhook_auth_token_iv" | "webhook_auth_token_tag">,
  crypto: CryptoService,
): string | null {
  if (!row.webhook_auth_token_encrypted || !row.webhook_auth_token_iv || !row.webhook_auth_token_tag) {
    return null;
  }
  return crypto.decrypt({
    ciphertext: row.webhook_auth_token_encrypted,
    iv: row.webhook_auth_token_iv,
    tag: row.webhook_auth_token_tag,
  });
}

/** Remove credenciais sensíveis da plataforma antes de devolver para HTTP/MCP. */
function toPublic(row: PlataformaCobranca): PlataformaCobrancaPublic {
  return {
    id: row.id,
    plataforma: row.plataforma,
    ambiente: row.ambiente,
    api_key_hint: row.api_key_hint,
    webhook_secret_hint: row.webhook_secret_hint,
    webhook_id_externo: row.webhook_id_externo,
    ativo: row.ativo,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

const DEFAULT_WEBHOOK_EVENTS = [
  "PAYMENT_CREATED",
  "PAYMENT_UPDATED",
  "PAYMENT_CONFIRMED",
  "PAYMENT_RECEIVED",
  "PAYMENT_OVERDUE",
  "PAYMENT_DELETED",
  "PAYMENT_RESTORED",
  "PAYMENT_REFUNDED",
  "PAYMENT_RECEIVED_IN_CASH_UNDONE",
  "PAYMENT_CHARGEBACK_REQUESTED",
  "PAYMENT_CHARGEBACK_DISPUTE",
  "PAYMENT_AWAITING_CHARGEBACK_REVERSAL",
];

/** Nome humano do provedor usado em mensagens de erro. */
function providerLabel(plataforma: TipoPlataformaCobranca): string {
  return plataforma === "stripe" ? "Stripe" : "Asaas";
}

@Injectable()
export class PlataformasCobrancaService {
  /** Recebe o serviço de criptografia usado para segredos de plataformas. */
  constructor(
    @Inject(CryptoService)
    private readonly crypto: CryptoService,
  ) {}

  /** Lista plataformas cadastradas sem expor segredos em texto plano. */
  async list(escritorioId: string): Promise<PlataformaCobrancaPublic[]> {
    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const rows = await manager
        .getRepository(PlataformaCobranca)
        .find({ where: { escritorio_id: escritorioId }, order: { created_at: "DESC" } });
      return rows.map(toPublic);
    });
  }

  /** Cria uma plataforma ativa, criptografa segredos e registra webhook Asaas quando aplicável. */
  async create(escritorioId: string, input: CreatePlataformaInput, callbackEmail: string): Promise<PlataformaCobrancaPublic> {
    if (!input.api_key || input.api_key.trim().length < 8) {
      throw new Error("API key inválida.");
    }
    const enc = this.crypto.encrypt(input.api_key.trim());
    const hint = this.crypto.mask(input.api_key.trim());
    const webhookSecret = input.webhook_secret?.trim()
      ? this.crypto.encrypt(input.webhook_secret.trim())
      : null;
    const webhookSecretHint = input.webhook_secret?.trim()
      ? this.crypto.mask(input.webhook_secret.trim())
      : null;
    const webhookToken = randomBytes(24).toString("hex");
    const webhookTokenEnc = this.crypto.encrypt(webhookToken);

    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const repo = manager.getRepository(PlataformaCobranca);

      // desativar existente da mesma plataforma
      await repo
        .createQueryBuilder()
        .update()
        .set({ ativo: false })
        .where("escritorio_id = :escritorio_id AND plataforma = :plataforma AND ativo = true", {
          escritorio_id: escritorioId,
          plataforma: input.plataforma,
        })
        .execute();

      const entity = repo.create({
        escritorio_id: escritorioId,
        plataforma: input.plataforma,
        ambiente: input.ambiente,
        api_key_encrypted: enc.ciphertext,
        api_key_iv: enc.iv,
        api_key_tag: enc.tag,
        api_key_hint: hint,
        webhook_secret_encrypted: webhookSecret?.ciphertext ?? null,
        webhook_secret_iv: webhookSecret?.iv ?? null,
        webhook_secret_tag: webhookSecret?.tag ?? null,
        webhook_secret_hint: webhookSecretHint,
        webhook_auth_token_encrypted: webhookTokenEnc.ciphertext,
        webhook_auth_token_iv: webhookTokenEnc.iv,
        webhook_auth_token_tag: webhookTokenEnc.tag,
        webhook_id_externo: null,
        ativo: true,
      });
      const saved = await repo.save(entity);

      if (input.plataforma === "asaas" && input.registrar_webhook !== false && settings.PUBLIC_BASE_URL) {
        try {
          const provedor = buildProvedor(saved, this.crypto);
          const result = await provedor.registrarWebhook({
            url: `${settings.PUBLIC_BASE_URL.replace(/\/$/, "")}/api/webhooks/cobrancas/${input.plataforma}/${escritorioId}`,
            email: callbackEmail,
            authToken: webhookToken,
            events: DEFAULT_WEBHOOK_EVENTS,
          });
          saved.webhook_id_externo = result.idExterno;
          await repo.save(saved);
        } catch (err) {
          await repo.delete(saved.id);
          const detail = err instanceof AsaasApiError
            ? `HTTP ${err.status} — ${JSON.stringify(err.body)}`
            : err instanceof Error ? err.message : String(err);
          throw new Error(`Falha ao registrar webhook na ${providerLabel(input.plataforma)}: ${detail}`);
        }
      }

      return toPublic(saved);
    });
  }

  /** Valida a credencial salva chamando o ping/listagem mínima do provedor. */
  async testar(escritorioId: string, id: string): Promise<{ ok: true }> {
    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const row = await manager.getRepository(PlataformaCobranca).findOne({
        where: { id, escritorio_id: escritorioId },
      });
      if (!row) throw new Error("Plataforma não encontrada.");
      const provedor = buildProvedor(row, this.crypto);
      await provedor.validarChave();
      return { ok: true as const };
    });
  }

  /** Desativa a plataforma sem apagar histórico de cobranças emitidas. */
  async deactivate(escritorioId: string, id: string): Promise<{ ok: true }> {
    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const repo = manager.getRepository(PlataformaCobranca);
      const row = await repo.findOne({ where: { id, escritorio_id: escritorioId } });
      if (!row) throw new Error("Plataforma não encontrada.");
      row.ativo = false;
      await repo.save(row);
      return { ok: true as const };
    });
  }

  /** Registra ou renova o webhook remoto para uma plataforma Asaas existente. */
  async registrarWebhook(escritorioId: string, id: string, callbackEmail: string): Promise<PlataformaCobrancaPublic> {
    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const repo = manager.getRepository(PlataformaCobranca);
      const row = await repo.findOne({ where: { id, escritorio_id: escritorioId } });
      if (!row) throw new Error("Plataforma não encontrada.");
      if (!settings.PUBLIC_BASE_URL) throw new Error("PUBLIC_BASE_URL não configurada.");
      if (row.plataforma === "stripe") {
        throw new Error("Webhooks Stripe devem ser configurados no Stripe Dashboard usando o signing secret.");
      }

      const authToken = lerTokenWebhook(row, this.crypto);
      if (!authToken) {
        throw new Error("Plataforma sem token de webhook armazenado — recadastre a credencial.");
      }

      const provedor = buildProvedor(row, this.crypto);
      const result = await provedor.registrarWebhook({
        url: `${settings.PUBLIC_BASE_URL.replace(/\/$/, "")}/api/webhooks/cobrancas/${row.plataforma}/${escritorioId}`,
        email: callbackEmail,
        authToken,
        events: DEFAULT_WEBHOOK_EVENTS,
      });
      row.webhook_id_externo = result.idExterno;
      return toPublic(await repo.save(row));
    });
  }

  /** Troca a API key criptografada mantendo a configuração de plataforma. */
  async atualizarApiKey(escritorioId: string, id: string, apiKey: string): Promise<PlataformaCobrancaPublic> {
    if (!apiKey || apiKey.trim().length < 8) throw new Error("API key inválida.");
    const enc = this.crypto.encrypt(apiKey.trim());
    const hint = this.crypto.mask(apiKey.trim());

    return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
      const repo = manager.getRepository(PlataformaCobranca);
      const row = await repo.findOne({ where: { id, escritorio_id: escritorioId } });
      if (!row) throw new Error("Plataforma não encontrada.");
      row.api_key_encrypted = enc.ciphertext;
      row.api_key_iv = enc.iv;
      row.api_key_tag = enc.tag;
      row.api_key_hint = hint;
      return toPublic(await repo.save(row));
    });
  }

  /** Recupera a plataforma ativa dentro de uma transação RLS já aberta. */
  async getAtivaParaEscritorio(
    manager: import("typeorm").EntityManager,
    escritorioId: string,
  ): Promise<PlataformaCobranca | null> {
    return manager.getRepository(PlataformaCobranca).findOne({
      where: { escritorio_id: escritorioId, ativo: true },
    });
  }
}
