import type { EntityManager } from "typeorm";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import {
  ValoresACobrar,
  type MembroComContratoSnapshot,
} from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { listarMembrosComContratoAtivo } from "../clientes/grupo.service.js";
import { buildMembrosComContratoSnapshot } from "../valores-a-cobrar/cobrancas-membros.js";
import type { MembroPendente } from "./cobrancas-errors.js";

/** Detecta quando uma empresa filha deve entrar na cobrança consolidada da holding. */
export async function isFilhaEmGrupoConsolidado(
  manager: EntityManager,
  escritorioId: string,
  cliente: Cliente | null | undefined,
): Promise<boolean> {
  if (!cliente?.holding_id) return false;
  const contratoHolding = await manager.getRepository(Contrato).findOne({
    where: { cliente_id: cliente.holding_id, escritorio_id: escritorioId, contrato_ativo: true },
  });
  return contratoHolding !== null;
}

/** Compara membros vivos do grupo com o snapshot calculado para bloquear emissões desatualizadas. */
export async function avaliarMembrosDoGrupo(
  manager: EntityManager,
  escritorioId: string,
  vac: ValoresACobrar,
): Promise<{ itensVivos: MembroComContratoSnapshot[]; pendentes: MembroPendente[] } | null> {
  if (!vac.linhagem?.grupo) return null;

  const membros = await manager.getRepository(Cliente).find({
    where: { holding_id: vac.cliente_id, escritorio_id: escritorioId },
  });
  const membrosComContrato = await listarMembrosComContratoAtivo(manager, escritorioId, membros);
  const itensVivos = await buildMembrosComContratoSnapshot(manager, escritorioId, membrosComContrato, vac.competencia);

  const calc = (vac.valores_calculados ?? {}) as Record<string, unknown>;
  const persistidos = Array.isArray(calc.cobrancas_membros)
    ? (calc.cobrancas_membros as MembroComContratoSnapshot[])
    : [];
  const temCalculoProprio = Object.keys(calc).some(
    (key) => key !== "cobrancas_membros" && key !== "valor_membros_total",
  );

  const chave = (item: MembroComContratoSnapshot) =>
    JSON.stringify({
      vac_id: item.vac_id,
      total: item.total,
      calculado: item.calculado,
      ja_cobrado: !!item.ja_cobrado_individualmente,
    });
  const persistidoPorCliente = new Map(persistidos.map((item) => [item.cliente_id, item]));

  const pendentes: MembroPendente[] = [];
  for (const item of itensVivos) {
    const base = { cliente_id: item.cliente_id, cnpj: item.cnpj, razao_social: item.razao_social };
    if (!item.calculado && !item.ja_cobrado_individualmente) {
      pendentes.push({ ...base, motivo: "sem_calculo" });
      continue;
    }
    if (!temCalculoProprio) continue;
    const persistido = persistidoPorCliente.get(item.cliente_id);
    if (!persistido || chave(persistido) !== chave(item)) {
      pendentes.push({ ...base, motivo: "desatualizado" });
    }
  }
  if (temCalculoProprio) {
    const vivosIds = new Set(itensVivos.map((item) => item.cliente_id));
    for (const persistido of persistidos) {
      if (!vivosIds.has(persistido.cliente_id)) {
        pendentes.push({
          cliente_id: persistido.cliente_id,
          cnpj: persistido.cnpj,
          razao_social: persistido.razao_social,
          motivo: "desatualizado",
        });
      }
    }
  }

  return { itensVivos, pendentes };
}
