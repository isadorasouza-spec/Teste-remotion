// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
import type { PlataformaCobranca } from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";

export const PG_UNIQUE_VIOLATION = "23505";

/** Retorna o nome humano do provedor para descrições e faturamento. */
export function plataformaLabel(plataforma: PlataformaCobranca | string): string {
  const value = typeof plataforma === "string" ? plataforma : plataforma.plataforma;
  return value === "stripe" ? "Stripe" : "Asaas";
}

/**
 * Converte uma competência "MM/AAAA" no intervalo de vencimento [primeiro dia, último dia]
 * do mês, em datas "YYYY-MM-DD" (formato aceito pelos provedores).
 */
export function competenciaParaIntervaloVencimento(competencia: string): { de: string; ate: string } {
  const match = competencia.match(/^(\d{2})\/(\d{4})$/);
  if (!match) {
    throw new Error("competencia deve estar no formato MM/AAAA.");
  }
  const mes = Number(match[1]);
  const ano = Number(match[2]);
  if (mes < 1 || mes > 12) {
    throw new Error("competencia deve estar no formato MM/AAAA.");
  }
  const mm = String(mes).padStart(2, "0");
  const ultimoDia = new Date(ano, mes, 0).getDate();
  return {
    de: `${ano}-${mm}-01`,
    ate: `${ano}-${mm}-${String(ultimoDia).padStart(2, "0")}`,
  };
}
