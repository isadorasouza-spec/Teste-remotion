// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
import type { MembroComContratoSnapshot } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { somaCobrancasMembros } from "../valores-a-cobrar/cobrancas-membros.js";

/** Formata valores em BRL para a descrição enviada ao provedor. */
const fmtBRL = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 2 });

/** Monta a descrição compacta enviada ao provedor com base, excedentes, grupo e descontos. */
export function buildDescricaoCobranca(input: {
  competencia: string | null;
  valorBase: number;
  excedentes: Array<{
    referencia?: string | null;
    quantidade?: number | null;
    valor_unitario?: number | null;
    valor_total?: number | null;
  }>;
  totalExcedentes: number;
  /** Modo híbrido: itens das filhas com contrato próprio incluídos na fatura da holding. */
  membros?: MembroComContratoSnapshot[];
  /** Ajuste de grupo (negativo = desconto) aplicado sobre o total do grupo. */
  ajusteGrupo?: number;
  /** Multas ressarcidas ao cliente (abatimento negativo no total). */
  multas?: Array<{ valor?: number | null; motivo?: string | null }>;
  /** Total (R$) das multas ressarcidas; subtraído do total da cobrança. */
  valorMultasTotal?: number;
  /** Desconto condicional por adimplência (R$) concedido se pago até o vencimento. */
  descontoAdimplencia?: number;
  /** Total autoritativo emitido (`vac.total`), declarado no fim da descrição. */
  total?: number;
}): string {
  const linhas: string[] = [`Kontiva — competência ${input.competencia ?? "—"}`];
  linhas.push(`Valor base: ${fmtBRL(input.valorBase)}`);

  const itens = input.excedentes
    .filter((exc) => Number(exc.quantidade ?? 0) > 0)
    .map((exc) => {
      const qtd = Number(exc.quantidade ?? 0);
      const unit = Number(exc.valor_unitario ?? 0);
      const total = Number(exc.valor_total ?? qtd * unit);
      const ref = (exc.referencia ?? "item").trim() || "item";
      return ` · ${qtd} ${ref} × ${fmtBRL(unit)} = ${fmtBRL(total)}`;
    });

  if (itens.length) {
    linhas.push(`Excedentes (${fmtBRL(input.totalExcedentes)}):`);
    linhas.push(...itens);
  }

  const membrosCobraveis = (input.membros ?? []).filter(
    (m) => m.calculado && !m.ja_cobrado_individualmente,
  );
  if (membrosCobraveis.length) {
    const totalMembros = somaCobrancasMembros(input.membros ?? []);
    linhas.push(`Empresas do grupo (${fmtBRL(totalMembros)}):`);
    for (const m of membrosCobraveis) {
      const nome = (m.razao_social ?? m.cnpj ?? m.cliente_id).trim();
      linhas.push(` · ${nome}${m.cnpj ? ` (${m.cnpj})` : ""}: ${fmtBRL(Number(m.total ?? 0))}`);
    }
  }

  if (input.ajusteGrupo) {
    const rotulo = input.ajusteGrupo < 0 ? "Desconto de grupo" : "Acréscimo de grupo";
    linhas.push(`${rotulo}: ${fmtBRL(input.ajusteGrupo)}`);
  }

  const multas = (input.multas ?? []).filter((m) => Number(m.valor ?? 0) > 0);
  if (multas.length) {
    const totalMultas = input.valorMultasTotal ?? multas.reduce((sum, m) => sum + Number(m.valor ?? 0), 0);
    linhas.push(`Ressarcimento de multas (-${fmtBRL(totalMultas)}):`);
    for (const m of multas) {
      const motivo = (m.motivo ?? "multa").trim() || "multa";
      linhas.push(` · ${motivo}: -${fmtBRL(Number(m.valor ?? 0))}`);
    }
  }

  if (typeof input.total === "number") {
    linhas.push(`Total: ${fmtBRL(input.total)}`);
  }

  if (input.descontoAdimplencia && input.descontoAdimplencia > 0) {
    linhas.push(`Desconto adimplência (se pago até o vencimento): -${fmtBRL(input.descontoAdimplencia)}`);
  }

  let desc = linhas.join("\n");
  if (desc.length > 500) desc = desc.slice(0, 497) + "...";
  return desc;
}
