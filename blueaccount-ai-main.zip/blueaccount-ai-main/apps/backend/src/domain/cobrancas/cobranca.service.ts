import { pl } from "nodejs-polars";
import type { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import type { Relatorio, TipoRelatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import type { ClausulasExcedentes } from "../../database/modules/tenant/entities/clausulas-excedentes.entity.js";

export type ServicosValores = {
  contrato_id: string;
  numero_de_documentos: number | null;
  numero_de_colaboradores: number | null;
  numero_de_prolabores: number | null;
  numero_de_estabelecimentos: number | null;
};

export type CobrancaData = {
  valor_excedente_folha: number;
  valor_excedente_doc: number;
};

export type ComparacaoItem = {
  label: string;
  contratado: number | null;
  realizado: number | null;
  excedente: number | null;
};

/** Normaliza aliases históricos de relatórios para as chaves usadas no cálculo legado. */
function normalizeReportType(type: string): TipoRelatorio | "numero_de_documentos" | "lancamentos_contabeis" {
  switch (type) {
    case "resumo_folha":
    case "relatorio_excedente":
    case "numero_notas_fiscais":
    case "numero_de_documentos":
    case "lancamentos_contabeis":
      return type;
    case "notas_fiscais":
      return "numero_notas_fiscais";
    case "excedentes":
      return "relatorio_excedente";
    default:
      return type as never;
  }
}

/** Calcula o excedente positivo entre contratado e realizado. */
function calcExcedente(contratado: number | null | undefined, realizado: number | null | undefined): number | null {
  if (contratado == null || realizado == null) return null;
  const diff = realizado - contratado;
  return diff > 0 ? diff : 0;
}

/** Converte valores vindos do banco/relatório para número ou null quando inválidos. */
function toNumber(value: unknown): number | null {
  if (value == null || value === "") return null;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Monta o DataFrame Polars usado pelo cálculo legado de excedentes. */
function createDataFrameExcedente(input: {
  contrato: Contrato;
  servicos: ServicosValores;
  relatorios: Relatorio[];
  exedentes: ClausulasExcedentes[];
}): pl.DataFrame {
  let df_contrato = pl.DataFrame({
    id: [input.contrato.id],
    valor_original: [toNumber(input.contrato.valor_original)],
  });

  const df_servicos = pl.DataFrame({
    contrato_id: [input.servicos.contrato_id],
    numero_de_documentos: [toNumber(input.servicos.numero_de_documentos)],
    numero_de_colaboradores: [toNumber(input.servicos.numero_de_colaboradores)],
    numero_de_prolabores: [toNumber(input.servicos.numero_de_prolabores)],
    numero_de_estabelecimentos: [toNumber(input.servicos.numero_de_estabelecimentos)],
  });

  let df_contrato_com_servicos = df_contrato.join(df_servicos, { leftOn: "id", rightOn: "contrato_id", how: "left" });

  let df_relatorio_no_id = pl.DataFrame({
    competencia: input.relatorios.map((r) => r.competencia),
    colaboradores_ativos: input.relatorios.map((r) => r.tipo_relatorio === "resumo_folha" ? toNumber(r.colaboradores_ativos) : null),
    admissoes: input.relatorios.map((r) => r.tipo_relatorio === "resumo_folha" ? toNumber(r.admissoes) : null),
    rescisoes: input.relatorios.map((r) => r.tipo_relatorio === "resumo_folha" ? toNumber(r.rescisoes) : null),
    total_notas_fiscais: input.relatorios.map((r) => r.tipo_relatorio === "numero_notas_fiscais" ? toNumber(r.total_notas_fiscais) : null),
  });

  let df_relatorio = df_relatorio_no_id.withColumn(pl.lit(input.contrato.id).alias("contrato_id"));

  const df_exedentes = pl.DataFrame({
    contrato_id: input.exedentes?.map((c) => c.contrato_id),
    tipo_cobranca: input.exedentes?.map((c) => c.tipo_cobranca),
    quantidade_inicial: input.exedentes?.map((c) => c.quantidade_inicial),
    quantidade_final: input.exedentes?.map((c) => c.quantidade_final),
    valor: input.exedentes?.map((c) => Number(c.valor)),
    referencia: input.exedentes?.map((c) => c.referencia),
  });

  return df_contrato_com_servicos.join(df_relatorio, { leftOn: "id", rightOn: "contrato_id", how: "left" }).join(df_exedentes, { leftOn: "id", rightOn: "contrato_id", how: "left" });
}

/** Calcula o valor excedente por colaboradores ativos no contrato legado. */
function gerar_excedente_por_colaborador(df: pl.DataFrame): number {
  let filter_expr = pl.col("tipo_cobranca").eq(pl.lit("por_funcionario")).and(pl.col("referencia").eq(pl.lit("empregados_ativos")));
  filter_expr = filter_expr.and(pl.col("colaboradores_ativos").gtEq(pl.col("quantidade_inicial")).and(pl.col("colaboradores_ativos").ltEq(pl.col("quantidade_final").fillNull(1.0e12))));
  let excedentes_de_folha_df_func = df.where(filter_expr).select("id", "competencia", "colaboradores_ativos", "quantidade_inicial", "quantidade_final", "valor", "numero_de_colaboradores");
  excedentes_de_folha_df_func = excedentes_de_folha_df_func.withColumn(pl.col("colaboradores_ativos").sub(pl.col("numero_de_colaboradores")).mul(pl.col("valor")).alias("valor_excedente"));

  if (excedentes_de_folha_df_func.isEmpty()) return 0;

  let resultado = excedentes_de_folha_df_func.getColumn("valor_excedente").cast(pl.Float64, false).toArray()[0];
  return resultado ?? 0;
}

/** Calcula o valor excedente por documentos fiscais no contrato legado. */
function gerar_excedente_por_numero_doc(df: pl.DataFrame): number {
  let filter_expr = pl.col("tipo_cobranca").eq(pl.lit("por_documento")).and(pl.col("referencia").eq(pl.lit("documentos_fiscais")));
  const total_documentos = pl.col("total_notas_fiscais").alias("total_documentos");
  filter_expr = filter_expr.and(pl.col("total_documentos").gtEq(pl.col("quantidade_inicial")).and(pl.col("total_documentos").ltEq(pl.col("quantidade_final").fillNull(1.0e12))));

  let excedentes_de_doc_df = df.withColumn(total_documentos).where(filter_expr).select("id", "competencia", "total_documentos", "quantidade_inicial", "quantidade_final", "valor", "numero_de_documentos");
  excedentes_de_doc_df = excedentes_de_doc_df.withColumn(pl.col("total_documentos").sub(pl.col("numero_de_documentos")).mul(pl.col("valor")).alias("valor_excedente"));

  if (excedentes_de_doc_df.isEmpty()) return 0;
  let resultado = excedentes_de_doc_df.getColumn("valor_excedente").cast(pl.Float64, false).toArray()[0];
  return resultado ?? 0;
}

/** Retorna os totais de excedente calculados pela rotina comparativa antiga. */
export function buildCobrancaData(input: {
  contrato: Contrato;
  servicos: ServicosValores;
  relatorios: Relatorio[];
  exedentes: ClausulasExcedentes[];
}): CobrancaData {
  const df = createDataFrameExcedente(input);

  const valor_excedente_folha = gerar_excedente_por_colaborador(df);
  const valor_excedente_doc = gerar_excedente_por_numero_doc(df);

  return {
    valor_excedente_folha,
    valor_excedente_doc,
  };
}

/** Monta itens de comparação contratado x realizado para exibição e auditoria. */
export function buildComparacaoItems(input: {
  servicos: ServicosValores | null;
  relatorios: Relatorio[];
}): ComparacaoItem[] {
  const folha = input.relatorios.find((r) => normalizeReportType(r.tipo_relatorio) === "resumo_folha");
  const nfs = input.relatorios.find((r) => normalizeReportType(r.tipo_relatorio) === "numero_notas_fiscais");
  const docs = input.relatorios.find((r) => normalizeReportType(r.tipo_relatorio) === "numero_de_documentos");
  const lanc = input.relatorios.find((r) => normalizeReportType(r.tipo_relatorio) === "lancamentos_contabeis");

  const servicos = input.servicos;

  return [
    {
      label: "Colaboradores",
      contratado: servicos?.numero_de_colaboradores ?? null,
      realizado: folha?.colaboradores_ativos ?? null,
      excedente: calcExcedente(servicos?.numero_de_colaboradores, folha?.colaboradores_ativos),
    },
    {
      label: "Pró-labores",
      contratado: servicos?.numero_de_prolabores ?? null,
      realizado: folha?.prolabores_ativos ?? null,
      excedente: calcExcedente(servicos?.numero_de_prolabores, folha?.prolabores_ativos),
    },
    {
      label: "Documentos (NFs)",
      contratado: servicos?.numero_de_documentos ?? null,
      realizado: docs?.total_notas_fiscais ?? nfs?.total_notas_fiscais ?? null,
      excedente: calcExcedente(servicos?.numero_de_documentos, docs?.total_notas_fiscais ?? nfs?.total_notas_fiscais),
    },
    {
      label: "Lançamentos contábeis",
      contratado: null,
      realizado: lanc?.total_lancamentos ?? null,
      excedente: null,
    },
    {
      label: "Admissões",
      contratado: null,
      realizado: folha?.admissoes ?? null,
      excedente: null,
    },
    {
      label: "Rescisões",
      contratado: null,
      realizado: folha?.rescisoes ?? null,
      excedente: null,
    },
  ];
}
