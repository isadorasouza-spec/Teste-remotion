export interface ProvedorAssinaturaEletronica {
  criarUrlAutorizacao(input: { state: string; codeChallenge: string }): string;
  trocarCodigo(code: string, codeVerifier: string): Promise<{
    accessToken: string;
    refreshToken: string | null;
    expiresIn: number;
  }>;
  renovarToken(refreshToken: string): Promise<{
    accessToken: string;
    refreshToken: string | null;
    expiresIn: number;
  }>;
  obterConta(accessToken: string): Promise<{
    id: string;
    nome: string | null;
    email: string | null;
    baseUri: string;
  }>;
  baixarDocumentoConsolidado(input: {
    accessToken: string;
    baseUri: string;
    contaId: string;
    envelopeId: string;
  }): Promise<Buffer>;
  baixarCertificado(input: {
    accessToken: string;
    baseUri: string;
    contaId: string;
    envelopeId: string;
  }): Promise<Buffer | null>;
}
