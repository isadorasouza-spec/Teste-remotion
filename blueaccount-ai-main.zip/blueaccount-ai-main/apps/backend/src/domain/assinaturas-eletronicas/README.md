# Assinaturas eletrônicas

Define o contrato neutro de provedor para envelopes concluídos.
A vinculação nunca importa nem associa um documento automaticamente: a confirmação humana no módulo
`assinaturas-eletronicas` é obrigatória.

O adaptador DocuSign vive em `src/infrastructure/external-services/docusign`; OAuth, persistência,
sincronização incremental e handoff ao pipeline de documentos ficam no módulo Nest.
