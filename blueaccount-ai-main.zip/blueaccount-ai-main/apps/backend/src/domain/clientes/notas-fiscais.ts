import { runQueryWithRls } from "../../database/data-source.js";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { buildPaginatedResult, normalizePagination, type PaginationInput } from "../pagination.js";

export type FiltrosNotasEmpresa = PaginationInput & { busca?: string; tipo?: string };

/** Catálogo da empresa: o ledger preserva a identidade mesmo sem projeções em cenários. */
export async function listarNotasFiscaisEmpresa(escritorioId: string, clienteId: string, filtros: FiltrosNotasEmpresa) {
  const { page, pageSize, skip } = normalizePagination(filtros);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const cliente = await manager.getRepository(Cliente).findOne({ where: { id: clienteId, escritorio_id: escritorioId }, select: { id: true } });
    if (!cliente) return null;
    // As projeções são snapshots do XML, nunca resultados calculados do cenário.
    // DISTINCT antes da paginação evita multiplicar uma nota por simulação ou reenvio.
    const consulta = `WITH projecoes AS (
      SELECT DISTINCT ON (n.chave) n.chave, n.numero, n.serie, n.data_emissao,
        n.emitente_nome, n.emitente_documento, n.destinatario_nome, n.destinatario_documento,
        n.valor_total, n.ambiente,
        CASE WHEN n.modelo = 55 THEN 'nfe' WHEN n.modelo = 65 THEN 'nfce' ELSE 'nfse' END AS tipo
      FROM simulacao_notas_fiscais n
      JOIN simulacoes s ON s.id = n.simulacao_id AND s.escritorio_id = n.escritorio_id
      WHERE n.escritorio_id = $1 AND s.escritorio_id = $1 AND s.cliente_id = $2
      ORDER BY n.chave, n.created_at ASC, n.id ASC
    ), canonicas AS (
      SELECT DISTINCT ON (a.chave_acesso) a.chave_acesso AS chave, a.tipo_documento AS tipo
      FROM arquivos_ingestao_documentos_fiscais a
      WHERE a.escritorio_id = $1 AND a.cliente_id = $2
        AND a.documento_canonico_id IS NOT NULL AND a.chave_acesso IS NOT NULL
        AND a.status NOT IN ('erro_validacao', 'conflito_conteudo')
      ORDER BY a.chave_acesso, a.criado_em ASC, a.id ASC
    ), catalogo AS (
      SELECT COALESCE(c.chave, p.chave) AS chave, COALESCE(c.tipo, p.tipo) AS tipo,
        p.numero, p.serie, p.data_emissao, p.emitente_nome, p.emitente_documento,
        p.destinatario_nome, p.destinatario_documento, p.valor_total, p.ambiente,
        (p.chave IS NOT NULL) AS dados_disponiveis
      FROM canonicas c FULL JOIN projecoes p ON p.chave = c.chave
    ), filtradas AS (
      SELECT * FROM catalogo
      WHERE ($3 = '' OR strpos(lower(concat_ws(' ', chave, numero, emitente_nome,
        emitente_documento, destinatario_nome, destinatario_documento)), lower($3)) > 0)
        AND ($4 = '' OR tipo = $4)
    )
    SELECT (SELECT count(*)::int FROM filtradas) AS total,
      COALESCE((SELECT jsonb_agg(linha) FROM (
        SELECT * FROM filtradas ORDER BY data_emissao DESC NULLS LAST, chave ASC LIMIT $5 OFFSET $6
      ) linha), '[]'::jsonb) AS items`;
    const [resultado] = await manager.query(consulta, [escritorioId, clienteId, filtros.busca?.trim() ?? "", filtros.tipo ?? "", pageSize, skip]);
    return buildPaginatedResult(resultado.items, Number(resultado.total), page, pageSize);
  });
}
