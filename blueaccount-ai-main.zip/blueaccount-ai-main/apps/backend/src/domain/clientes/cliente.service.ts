import { runQueryWithRls } from "../../database/data-source.js";
import { Cliente, type NcmPermitido } from "../../database/modules/tenant/entities/cliente.entity.js";
import { somenteDigitos } from "../texto.js";
import type { OpcaoIbsCbs, CnaeSecundario } from "../../database/modules/tenant/entities/fornecedor.entity.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import { ServicosContratados } from "../../database/modules/tenant/entities/servicos-contratados.entity.js";
import { ClausulasExcedentes } from "../../database/modules/tenant/entities/clausulas-excedentes.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import {
  getGrupoDoCliente,
  listarMembrosComContratoAtivo,
  sincronizarGrupoEconomicoPorCnpj,
  validarAssociacaoHolding,
} from "./grupo.service.js";
import { buildCobrancaData, buildComparacaoItems, type ServicosValores } from "../cobrancas/cobranca.service.js";
import { Brackets, type EntityManager } from "typeorm";
import { normalizarRegimeParaDocumento } from "./regime-tributario.js";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginatedResult,
  type PaginationInput,
} from "../pagination.js";
import { consultarCnpjSemBloquear, type CadastroCnpjConsultado } from "../fornecedores/consulta-cnpj.service.js";
import { assertLimiteClientes } from "../escritorios/limite-clientes.js";
import { enfileirarSimulacoesDoCliente } from "../simulacoes/fila-calculo.service.js";

/** Documento (CPF/CNPJ) do cliente com comprimento inválido. Vira HTTP 400, não 500. */
export class DocumentoClienteInvalidoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "DocumentoClienteInvalidoError";
  }
}

/** `opcao_ibs_cbs` fora do enum `regime_unico | regime_regular`. Vira HTTP 400, não 500. */
export class OpcaoIbsCbsInvalidaError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "OpcaoIbsCbsInvalidaError";
  }
}

/**
 * Payload de `cnaes_secundarios`/`cnaes_fornecedores_permitidos` não é uma lista (nem `null`/
 * `undefined`). Vira HTTP 400, não 500 — sinal de bug no chamador, não dado de terceiro malformado
 * (itens individuais malformados dentro de uma lista válida são apenas descartados, sem lançar).
 */
export class CnaeInvalidoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CnaeInvalidoError";
  }
}

/**
 * Payload de `ncms_permitidos` não é uma lista (nem `null`/`undefined`). Mesma semântica de
 * `CnaeInvalidoError`: vira HTTP 400, não 500 — sinal de bug no chamador, não dado malformado de
 * terceiro (itens individuais malformados dentro de uma lista válida são apenas descartados).
 */
export class NcmPermitidoInvalidoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "NcmPermitidoInvalidoError";
  }
}

/**
 * Nem a consulta de CNPJ nem o chamador informaram `razao_social`. Vira HTTP 400, não 500 — o
 * cadastro manual segue possível preenchendo o nome à mão.
 */
export class RazaoSocialObrigatoriaError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RazaoSocialObrigatoriaError";
  }
}

/** Já existe cliente com este documento (CPF/CNPJ) no escritório. Vira HTTP 409, não 500. */
export class ClienteJaExisteError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ClienteJaExisteError";
  }
}

/** `holding_id` informado não existe no escritório, ou já pertence a outro grupo. Vira HTTP 400, não 500. */
export class HoldingInvalidaError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "HoldingInvalidaError";
  }
}

export type ClienteGrupoResumo = {
  id: string;
  cnpj: string;
  razao_social: string;
  nome_fantasia: string | null;
  /** Presente nos membros de uma holding: contrato ativo próprio (modo híbrido). */
  tem_contrato_ativo?: boolean;
};

export type ClienteResumo = {
  id: string;
  cnpj: string;
  razao_social: string;
  email: string | null;
  regime_tributario: string | null;
  endereco: string | null;
  uf: string | null;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
  representante_legal: string | null;
  cnae_principal: string | null;
  cnae_principal_descricao: string | null;
  informacoes_gerais: Record<string, unknown> | null;
  contratos_count: number;
  relatorios_count: number;
  aniversario_contrato: string | null;
  vencimento_contrato: string | null;
  holding_id: string | null;
  pagador_grupo: "holding" | "empresa" | null;
  membros_count: number;
  ativo: boolean;
};

export type ClienteListaItem = Omit<ClienteResumo, "informacoes_gerais"> & {
  nome_fantasia: string | null;
};

export type ClienteDetalhe = {
  id: string;
  cnpj: string;
  razao_social: string;
  email: string | null;
  regime_tributario: string | null;
  endereco: string | null;
  uf: string | null;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
  representante_legal: string | null;
  cnae_principal: string | null;
  cnae_principal_descricao: string | null;
  cnaes_secundarios: CnaeSecundario[] | null;
  cnaes_fornecedores_permitidos: CnaeSecundario[] | null;
  ncms_permitidos: NcmPermitido[] | null;
  informacoes_gerais: Record<string, unknown> | null;
  contratos: Contrato[];
  relatorios: Relatorio[];
  holding_id: string | null;
  pagador_grupo: "holding" | "empresa" | null;
  holding: ClienteGrupoResumo | null;
  membros: ClienteGrupoResumo[];
};

export type ClientePatchInput = {
  razao_social?: string;
  nome_fantasia?: string | null;
  email?: string | null;
  regime_tributario?: string | null;
  endereco?: string | null;
  uf?: string | null;
  opcao_ibs_cbs?: OpcaoIbsCbs | null;
  representante_legal?: string | null;
  cnae_principal?: string | null;
  cnae_principal_descricao?: string | null;
  cnaes_secundarios?: CnaeSecundario[] | null;
  cnaes_fornecedores_permitidos?: CnaeSecundario[] | null;
  ncms_permitidos?: NcmPermitido[] | null;
  informacoes_gerais?: Record<string, unknown> | null;
  holding_id?: string | null;
  pagador_grupo?: "holding" | "empresa" | null;
  ativo?: boolean;
};

export type ClienteCreateInput = {
  cnpj: string;
  razao_social: string;
  nome_fantasia?: string | null;
  email?: string | null;
  regime_tributario?: string | null;
  endereco?: string | null;
  uf?: string | null;
  opcao_ibs_cbs?: OpcaoIbsCbs | null;
  representante_legal?: string | null;
  cnae_principal?: string | null;
  cnae_principal_descricao?: string | null;
  cnaes_secundarios?: CnaeSecundario[] | null;
  cnaes_fornecedores_permitidos?: CnaeSecundario[] | null;
  ncms_permitidos?: NcmPermitido[] | null;
  informacoes_gerais?: Record<string, unknown> | null;
  holding_id?: string | null;
  pagador_grupo?: "holding" | "empresa" | null;
};

export type ClientePatchResult = {
  ok: true;
  cliente: {
    id: string;
    cnpj: string;
    razao_social: string;
    nome_fantasia: string | null;
    email: string | null;
    regime_tributario: string | null;
    endereco: string | null;
    uf: string | null;
    opcao_ibs_cbs: OpcaoIbsCbs | null;
    representante_legal: string | null;
    cnae_principal: string | null;
    cnae_principal_descricao: string | null;
    informacoes_gerais: Record<string, unknown> | null;
    holding_id: string | null;
    pagador_grupo: "holding" | "empresa" | null;
  };
};

export type ClienteCreateResult = ClientePatchResult;

export type ComparacaoResult = {
  contrato: { id: string } | null;
  items: ReturnType<typeof buildComparacaoItems>;
  cobranca: ReturnType<typeof buildCobrancaData> | null;
};

/**
 * Normaliza o identificador fiscal do cliente e devolve o valor mascarado.
 *
 * O campo se chama `cnpj` em toda a stack (coluna, payloads de API, tools MCP e
 * prompts de extração) por compatibilidade, mas aceita os dois documentos:
 *
 * - 14 dígitos → CNPJ, mascarado como `##.###.###/####-##`
 * - 11 dígitos → CPF (cliente pessoa física, ex.: profissional liberal),
 *   mascarado como `###.###.###-##`
 *
 * Só o comprimento é validado; não há verificação de dígito verificador, para
 * não rejeitar dado legado nem documento vindo de OCR imperfeito.
 */
export function normalizarCnpj(value: unknown): string {
  const digitos = somenteDigitos(value);

  if (digitos.length === 14) {
    return `${digitos.slice(0, 2)}.${digitos.slice(2, 5)}.${digitos.slice(5, 8)}/${digitos.slice(8, 12)}-${digitos.slice(12)}`;
  }

  if (digitos.length === 11) {
    return `${digitos.slice(0, 3)}.${digitos.slice(3, 6)}.${digitos.slice(6, 9)}-${digitos.slice(9)}`;
  }

  throw new DocumentoClienteInvalidoError("cnpj deve conter 11 dígitos (CPF) ou 14 dígitos (CNPJ).");
}

export async function listClientes(escritorioId: string): Promise<ClienteResumo[]> {
  await ensureDatabase();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    const clientes = await repo.find({
      relations: ["contratos", "relatorios"],
      order: { razao_social: "ASC" },
    });

    const membrosPorHolding = new Map<string, number>();
    for (const c of clientes) {
      if (c.holding_id) {
        membrosPorHolding.set(c.holding_id, (membrosPorHolding.get(c.holding_id) ?? 0) + 1);
      }
    }

    return clientes.map((c) => {
      const contratoAtivo = c.contratos?.find((ct) => ct.contrato_ativo) ?? null;
      return {
        id: c.id,
        cnpj: c.cnpj,
        razao_social: c.razao_social,
        email: c.email ?? null,
        regime_tributario: c.regime_tributario,
        endereco: c.endereco,
        uf: c.uf,
        opcao_ibs_cbs: c.opcao_ibs_cbs ?? null,
        representante_legal: c.representante_legal,
        cnae_principal: c.cnae_principal ?? null,
        cnae_principal_descricao: c.cnae_principal_descricao ?? null,
        informacoes_gerais: c.informacoes_gerais,
        contratos_count: c.contratos?.length ?? 0,
        relatorios_count: c.relatorios?.length ?? 0,
        aniversario_contrato: contratoAtivo?.data_inicio ?? null,
        vencimento_contrato: contratoAtivo?.data_termino ?? null,
        holding_id: c.holding_id ?? null,
        pagador_grupo: c.pagador_grupo ?? null,
        membros_count: membrosPorHolding.get(c.id) ?? 0,
        ativo: c.ativo,
      };
    });
  });
}

export async function listClientesPaginated(
  escritorioId: string,
  input: PaginationInput & { query?: string } = {},
): Promise<PaginatedResult<ClienteListaItem>> {
  await ensureDatabase();
  const { page, pageSize, skip } = normalizePagination(input);

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Cliente)
      .createQueryBuilder("cliente")
      .select("cliente.id", "id")
      .addSelect("cliente.cnpj", "cnpj")
      .addSelect("cliente.razao_social", "razao_social")
      .addSelect("cliente.nome_fantasia", "nome_fantasia")
      .addSelect("cliente.email", "email")
      .addSelect("cliente.regime_tributario", "regime_tributario")
      .addSelect("cliente.endereco", "endereco")
      .addSelect("cliente.uf", "uf")
      .addSelect("cliente.opcao_ibs_cbs", "opcao_ibs_cbs")
      .addSelect("cliente.representante_legal", "representante_legal")
      .addSelect("cliente.cnae_principal", "cnae_principal")
      .addSelect("cliente.cnae_principal_descricao", "cnae_principal_descricao")
      .addSelect("cliente.holding_id", "holding_id")
      .addSelect("cliente.pagador_grupo", "pagador_grupo")
      .addSelect("cliente.ativo", "ativo")
      .addSelect(`(SELECT COUNT(*) FROM contratos ct WHERE ct.cliente_id = cliente.id)`, "contratos_count")
      .addSelect(`(SELECT COUNT(*) FROM relatorios rel WHERE rel.cliente_id = cliente.id)`, "relatorios_count")
      .addSelect(`(SELECT COUNT(*) FROM clientes membro WHERE membro.holding_id = cliente.id)`, "membros_count")
      .addSelect(
        `(SELECT ct.data_inicio FROM contratos ct WHERE ct.cliente_id = cliente.id AND ct.contrato_ativo = true LIMIT 1)`,
        "aniversario_contrato",
      )
      .addSelect(
        `(SELECT ct.data_termino FROM contratos ct WHERE ct.cliente_id = cliente.id AND ct.contrato_ativo = true LIMIT 1)`,
        "vencimento_contrato",
      )
      .where("cliente.escritorio_id = :escritorioId", { escritorioId });

    const query = input.query?.trim();
    if (query) {
      qb.andWhere(
        new Brackets((sub) => {
          sub
            .where("cliente.cnpj ILIKE :query", { query: `%${query}%` })
            .orWhere("cliente.razao_social ILIKE :query", { query: `%${query}%` })
            .orWhere("cliente.nome_fantasia ILIKE :query", { query: `%${query}%` });
        }),
      );
    }

    const total = await qb.clone().getCount();
    const rows = await qb
      .orderBy("cliente.razao_social", "ASC")
      .offset(skip)
      .limit(pageSize)
      .getRawMany<Record<string, unknown>>();

    const items = rows.map((row) => ({
      id: String(row.id),
      cnpj: String(row.cnpj),
      razao_social: String(row.razao_social),
      nome_fantasia: row.nome_fantasia == null ? null : String(row.nome_fantasia),
      email: row.email == null ? null : String(row.email),
      regime_tributario: row.regime_tributario == null ? null : String(row.regime_tributario),
      endereco: row.endereco == null ? null : String(row.endereco),
      uf: row.uf == null ? null : String(row.uf),
      opcao_ibs_cbs: row.opcao_ibs_cbs == null ? null : String(row.opcao_ibs_cbs) as OpcaoIbsCbs,
      representante_legal: row.representante_legal == null ? null : String(row.representante_legal),
      cnae_principal: row.cnae_principal == null ? null : String(row.cnae_principal),
      cnae_principal_descricao: row.cnae_principal_descricao == null ? null : String(row.cnae_principal_descricao),
      contratos_count: Number(row.contratos_count ?? 0),
      relatorios_count: Number(row.relatorios_count ?? 0),
      aniversario_contrato: row.aniversario_contrato == null ? null : String(row.aniversario_contrato),
      vencimento_contrato: row.vencimento_contrato == null ? null : String(row.vencimento_contrato),
      holding_id: row.holding_id == null ? null : String(row.holding_id),
      pagador_grupo: row.pagador_grupo == null ? null : String(row.pagador_grupo) as "holding" | "empresa",
      membros_count: Number(row.membros_count ?? 0),
      ativo: row.ativo !== false,
    }));

    return buildPaginatedResult(items, total, page, pageSize);
  });
}

export async function getCliente(escritorioId: string, clienteId: string): Promise<ClienteDetalhe | null> {
  await ensureDatabase();

  const cliente = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({
      where: { id: clienteId, escritorio_id: escritorioId },
    });
  });
  if (!cliente) return null;

  const contratos = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Contrato);
    return await repo.find({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId },
      order: { created_at: "ASC" },
    });
  });

  const relatorios = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Relatorio);
    return await repo.find({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId },
      order: { competencia: "DESC" },
    });
  });

  const { grupo, membrosComContratoIds } = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const grupoDoCliente = await getGrupoDoCliente(manager, escritorioId, cliente.id);
    const membrosComContrato =
      grupoDoCliente.papel === "holding"
        ? await listarMembrosComContratoAtivo(manager, escritorioId, grupoDoCliente.membros)
        : [];
    return {
      grupo: grupoDoCliente,
      membrosComContratoIds: new Set(membrosComContrato.map((m) => m.cliente.id)),
    };
  });

  const toGrupoResumo = (c: Cliente): ClienteGrupoResumo => ({
    id: c.id,
    cnpj: c.cnpj,
    razao_social: c.razao_social,
    nome_fantasia: c.nome_fantasia ?? null,
  });

  const toMembroResumo = (c: Cliente): ClienteGrupoResumo => ({
    ...toGrupoResumo(c),
    tem_contrato_ativo: membrosComContratoIds.has(c.id),
  });

  return {
    id: cliente.id,
    cnpj: cliente.cnpj,
    razao_social: cliente.razao_social,
    email: cliente.email ?? null,
    regime_tributario: cliente.regime_tributario,
    endereco: cliente.endereco,
    uf: cliente.uf,
    opcao_ibs_cbs: cliente.opcao_ibs_cbs ?? null,
    representante_legal: cliente.representante_legal,
    cnae_principal: cliente.cnae_principal ?? null,
    cnae_principal_descricao: cliente.cnae_principal_descricao ?? null,
    cnaes_secundarios: cliente.cnaes_secundarios ?? null,
    cnaes_fornecedores_permitidos: cliente.cnaes_fornecedores_permitidos ?? null,
    ncms_permitidos: cliente.ncms_permitidos ?? null,
    informacoes_gerais: cliente.informacoes_gerais,
    contratos,
    relatorios,
    holding_id: cliente.holding_id ?? null,
    pagador_grupo: cliente.pagador_grupo ?? null,
    holding: grupo.papel === "membro" && grupo.holding ? toGrupoResumo(grupo.holding) : null,
    membros: grupo.papel === "holding" ? grupo.membros.map(toMembroResumo) : [],
  };
}

export async function patchCliente(escritorioId: string, clienteId: string, input: ClientePatchInput): Promise<ClientePatchResult | null> {
  await ensureDatabase();

  const cliente = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({
      where: { id: clienteId, escritorio_id: escritorioId },
    });
  });

  if (!cliente) return null;

  if (input.razao_social) {
    cliente.razao_social = input.razao_social.trim();
  }

  if ("nome_fantasia" in input) {
    cliente.nome_fantasia = input.nome_fantasia == null ? null : String(input.nome_fantasia).trim() || null;
  }

  if ("email" in input) {
    cliente.email = normalizeEmail(input.email);
  }

  if ("regime_tributario" in input) {
    // `cnpj` não é patchável, então o par é cruzado contra o documento já gravado.
    cliente.regime_tributario = normalizarRegimeParaDocumento(input.regime_tributario, cliente.cnpj);
  }

  if ("endereco" in input) {
    cliente.endereco = input.endereco == null ? null : String(input.endereco).trim() || null;
  }

  if ("uf" in input) cliente.uf = normalizarUfOuNulo(input.uf);

  if ("opcao_ibs_cbs" in input) cliente.opcao_ibs_cbs = validarOpcaoIbsCbsOuNula(input.opcao_ibs_cbs);

  if ("representante_legal" in input) {
    cliente.representante_legal = input.representante_legal == null ? null : String(input.representante_legal).trim() || null;
  }

  if ("cnae_principal" in input) cliente.cnae_principal = cnaeOuNuloCliente(input.cnae_principal);

  if ("cnae_principal_descricao" in input) {
    cliente.cnae_principal_descricao =
      input.cnae_principal_descricao == null ? null : String(input.cnae_principal_descricao).trim() || null;
  }

  // Replace completo do array, não merge — consistente com `Fornecedor.cnaes_secundarios` e
  // `informacoes_gerais` neste mesmo arquivo (não há helper de merge de array jsonb no repo).
  if ("cnaes_secundarios" in input) {
    cliente.cnaes_secundarios = cnaesSecundariosOuNulo(input.cnaes_secundarios);
  }

  if ("cnaes_fornecedores_permitidos" in input) {
    cliente.cnaes_fornecedores_permitidos = cnaesFornecedoresPermitidosOuNulo(input.cnaes_fornecedores_permitidos);
  }

  // Replace completo do array, mesma regra de `cnaes_fornecedores_permitidos` acima.
  if ("ncms_permitidos" in input) {
    cliente.ncms_permitidos = ncmsPermitidosOuNulo(input.ncms_permitidos);
  }

  if ("informacoes_gerais" in input) {
    cliente.informacoes_gerais = input.informacoes_gerais ?? null;
  }

  if ("pagador_grupo" in input) {
    const pagador = input.pagador_grupo ?? null;
    if (pagador !== null && pagador !== "holding" && pagador !== "empresa") {
      throw new Error("pagador_grupo deve ser 'holding', 'empresa' ou null.");
    }
    cliente.pagador_grupo = pagador;
  }

  if ("ativo" in input && typeof input.ativo === "boolean") {
    cliente.ativo = input.ativo;
  }

  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    if ("holding_id" in input) {
      const holdingId = input.holding_id ?? null;
      if (holdingId !== null && holdingId !== cliente.holding_id) {
        await validarAssociacaoHolding(manager, escritorioId, cliente.id, holdingId);
      }
      cliente.holding_id = holdingId;
    }
    const repo = manager.getRepository(Cliente);
    await repo.save(cliente);
    await enfileirarSimulacoesDoCliente(manager, escritorioId, clienteId);
    return null;
  });

  return {
    ok: true,
    cliente: {
      id: cliente.id,
      cnpj: cliente.cnpj,
      razao_social: cliente.razao_social,
      nome_fantasia: cliente.nome_fantasia,
      email: cliente.email ?? null,
      regime_tributario: cliente.regime_tributario,
      endereco: cliente.endereco,
      uf: cliente.uf,
      opcao_ibs_cbs: cliente.opcao_ibs_cbs ?? null,
      representante_legal: cliente.representante_legal,
      cnae_principal: cliente.cnae_principal ?? null,
      cnae_principal_descricao: cliente.cnae_principal_descricao ?? null,
      informacoes_gerais: cliente.informacoes_gerais,
      holding_id: cliente.holding_id ?? null,
      pagador_grupo: cliente.pagador_grupo ?? null,
    },
  };
}

/**
 * UF do cliente. Nunca lança: comprimento além de 2 é truncado, e valor vazio devolve `null`. A
 * consulta pública de CNPJ (ver `createCliente`) é quem normalmente preenche o campo.
 */
function normalizarUfOuNulo(value: unknown): string | null {
  const texto = String(value ?? "").trim().toUpperCase();
  return texto === "" ? null : texto.slice(0, 2);
}

/**
 * `opcao_ibs_cbs` do cliente. Diferente de `uf`/`pagador_grupo`, não vem de nenhuma consulta
 * externa — é só digitação do contador (BrasilAPI não expõe essa informação, mesma limitação
 * documentada para `Fornecedor`). Por isso não silencia valor inválido: um enum de 2 opções errado
 * é sinal de bug no chamador, não dado de terceiro malformado.
 */
function validarOpcaoIbsCbsOuNula(value: unknown): OpcaoIbsCbs | null {
  if (value == null) return null;
  if (value !== "regime_unico" && value !== "regime_regular") {
    throw new OpcaoIbsCbsInvalidaError("opcao_ibs_cbs deve ser 'regime_unico', 'regime_regular' ou null.");
  }
  return value;
}

/**
 * Alíquota de crédito presumido de IBS/CBS do cliente. Guard simples de número finito — mesmo
 * princípio de `numberOrNull` em `simulacoes/simulacao.service.ts`, mas sem lançar: um valor não
 * numérico aqui é tratado como ausência, não como erro de validação.
 */
function decimalOuNulo(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const numero = Number(value);
  return Number.isFinite(numero) ? numero : null;
}

/**
 * CNAE (principal) do cliente: dígitos apenas, zero-padded a 7 posições. Mesma semântica de
 * `cnaeOuNulo` em `fornecedores/fornecedor.service.ts`, reimplementada localmente (sem import
 * cross-domain) para manter `cliente.service.ts` autocontido. Valor vazio/ausente → `null`.
 */
function cnaeOuNuloCliente(value: unknown): string | null {
  if (value == null) return null;
  const texto = String(value).trim();
  if (texto === "") return null;
  const digitos = somenteDigitos(texto).slice(0, 7);
  return digitos === "" ? null : digitos.padStart(7, "0");
}

/**
 * Valida um array de `{codigo, descricao}`, descartando silenciosamente itens malformados (sem
 * `codigo` válido) — mesmo comportamento de `cnaesSecundariosOuNulo` em `fornecedores/fornecedor.service.ts`.
 * Lança `CnaeInvalidoError` apenas quando o payload de nível superior não é array nem `null`/`undefined`
 * (sinal de bug no chamador, não dado de terceiro malformado). Lista vazia (após filtragem, ou
 * literalmente `[]`) vira `null`.
 */
function validarListaCnae(value: unknown, campo: string): CnaeSecundario[] | null {
  if (value == null) return null;
  if (!Array.isArray(value)) {
    throw new CnaeInvalidoError(`${campo} deve ser uma lista.`);
  }
  const itens = value
    .map((item) => {
      const registro = (item ?? {}) as Record<string, unknown>;
      const codigoTexto = registro.codigo == null ? "" : String(registro.codigo).trim();
      const codigo = somenteDigitos(codigoTexto);
      if (!codigo) return null;
      const descricao = registro.descricao == null ? "" : String(registro.descricao).trim();
      return { codigo: codigo.slice(0, 7).padStart(7, "0"), descricao };
    })
    .filter((item): item is CnaeSecundario => item !== null);
  return itens.length > 0 ? itens : null;
}

/** CNAEs secundários do cliente, como devolvidos pela consulta de CNPJ. */
function cnaesSecundariosOuNulo(value: unknown): CnaeSecundario[] | null {
  return validarListaCnae(value, "cnaes_secundarios");
}

/**
 * Allowlist manual de CNAE de fornecedor elegível a gerar crédito para este cliente. Mesma forma de
 * validação de `cnaesSecundariosOuNulo` — a diferença de origem do dado (nunca vem da consulta de
 * CNPJ) fica em `createCliente`/`patchCliente`, não neste validador.
 */
function cnaesFornecedoresPermitidosOuNulo(value: unknown): CnaeSecundario[] | null {
  return validarListaCnae(value, "cnaes_fornecedores_permitidos");
}

/**
 * Valida um array de `{codigo, descricao}` de NCM, mesma lógica de `validarListaCnae` mas com
 * padding de 8 dígitos (NCM) em vez de 7 (CNAE). Itens malformados (sem `codigo` válido) são
 * descartados silenciosamente; payload de nível superior que não é array nem `null`/`undefined`
 * lança `NcmPermitidoInvalidoError`.
 */
function validarListaNcm(value: unknown, campo: string): NcmPermitido[] | null {
  if (value == null) return null;
  if (!Array.isArray(value)) {
    throw new NcmPermitidoInvalidoError(`${campo} deve ser uma lista.`);
  }
  const itens = value
    .map((item) => {
      const registro = (item ?? {}) as Record<string, unknown>;
      const codigo = somenteDigitos(registro.codigo == null ? "" : String(registro.codigo).trim());
      if (!codigo) return null;
      const descricao = registro.descricao == null ? "" : String(registro.descricao).trim();
      return { codigo: codigo.slice(0, 8).padStart(8, "0"), descricao };
    })
    .filter((item): item is NcmPermitido => item !== null);
  return itens.length > 0 ? itens : null;
}

/**
 * Allowlist manual de NCM elegível a gerar crédito de ICMS para este cliente. Análoga a
 * `cnaesFornecedoresPermitidosOuNulo`: nunca vem de consulta/lookup externo, é 100% digitação do
 * contador — a diferença de fonte fica em `createCliente`/`patchCliente`, não neste validador.
 */
function ncmsPermitidosOuNulo(value: unknown): NcmPermitido[] | null {
  return validarListaNcm(value, "ncms_permitidos");
}

export async function createCliente(escritorioId: string, input: ClienteCreateInput): Promise<ClienteCreateResult> {
  await ensureDatabase();

  // Antes da consulta pública de CNPJ abaixo: não gastar I/O externo numa criação
  // que o teto do escritório já vai recusar.
  await assertLimiteClientes(escritorioId);

  const cnpj = normalizarCnpj(input.cnpj);
  // A consulta pública de CNPJ vence quando tiver o dado: aqui a API é autoritativa e o
  // extraído/digitado só entra como fallback — a regra inversa da de `fornecedor.service.ts`.
  // Best-effort: indisponibilidade/inexistência nunca bloqueiam a criação manual do cliente.
  const consulta = await consultarCnpjSemBloquear(cnpj);
  const nomeFantasiaAtual = input.nome_fantasia == null ? null : String(input.nome_fantasia).trim() || null;
  const enderecoAtual = input.endereco == null ? null : String(input.endereco).trim() || null;

  const razaoSocial = (consulta?.razao_social || input.razao_social || "").trim();
  const nomeFantasia = consulta?.nome_fantasia ?? nomeFantasiaAtual;
  const regimeTributario = normalizarRegimeParaDocumento(
    consulta?.regime_tributario_sugerido ?? input.regime_tributario,
    cnpj,
  );
  const endereco = consulta?.endereco_sugerido ?? enderecoAtual;
  const uf = normalizarUfOuNulo(consulta?.uf ?? input.uf);
  // A opção de IBS/CBS é decisão do contador; a consulta pública não a expõe.
  const opcaoIbsCbs = validarOpcaoIbsCbsOuNula(input.opcao_ibs_cbs);
  const email = normalizeEmail(input.email);
  const representanteLegal = input.representante_legal == null ? null : String(input.representante_legal).trim() || null;
  // API sempre vence, sem fallback para `input.*`: a consulta de CNPJ resolve o CNAE do próprio
  // cliente, digitação manual não substitui esse dado (mesma regra de `razao_social`/`endereco`/`uf`
  // enriquecidos pela API). Ausência de consulta (indisponibilidade/CNPJ não encontrado) devolve null.
  const cnaePrincipal = consulta?.cnae_principal ?? null;
  const cnaePrincipalDescricao = consulta?.cnae_principal_descricao ?? null;
  const cnaesSecundarios = consulta?.cnaes_secundarios ?? null;
  // Diferente dos três acima: NUNCA vem da consulta de CNPJ (que não conhece fornecedores de
  // terceiros) — é 100% digitação manual do contador, mesma categoria de `opcao_ibs_cbs`.
  const cnaesFornecedoresPermitidos = cnaesFornecedoresPermitidosOuNulo(input.cnaes_fornecedores_permitidos);
  // Mesma categoria: allowlist de NCM também nunca vem de consulta/lookup externo.
  const ncmsPermitidos = ncmsPermitidosOuNulo(input.ncms_permitidos);

  if (!cnpj) throw new Error("cnpj é obrigatório.");
  if (!razaoSocial) {
    throw new RazaoSocialObrigatoriaError(
      "razao_social é obrigatória: a consulta de CNPJ não encontrou o cadastro.",
    );
  }

  const existing = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({ where: { cnpj, escritorio_id: escritorioId } });
  });
  if (existing) {
    throw new ClienteJaExisteError("Já existe um cliente com este identificador neste escritório.");
  }

  const pagadorGrupo = input.pagador_grupo ?? null;
  if (pagadorGrupo !== null && pagadorGrupo !== "holding" && pagadorGrupo !== "empresa") {
    throw new Error("pagador_grupo deve ser 'holding', 'empresa' ou null.");
  }

  const cliente = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    const holdingId = input.holding_id ?? null;
    if (holdingId !== null) {
      const holding = await repo.findOne({ where: { id: holdingId, escritorio_id: escritorioId } });
      if (!holding) throw new HoldingInvalidaError("Holding não encontrada para o escritório.");
      if (holding.holding_id) {
        throw new HoldingInvalidaError("A holding escolhida já pertence a outro grupo — a hierarquia suporta apenas um nível.");
      }
    }
    const novoCliente = await repo.save({
      escritorio_id: escritorioId,
      cnpj,
      razao_social: razaoSocial,
      nome_fantasia: nomeFantasia,
      email,
      regime_tributario: regimeTributario,
      endereco,
      uf,
      opcao_ibs_cbs: opcaoIbsCbs,
      representante_legal: representanteLegal,
      cnae_principal: cnaePrincipal,
      cnae_principal_descricao: cnaePrincipalDescricao,
      cnaes_secundarios: cnaesSecundarios,
      cnaes_fornecedores_permitidos: cnaesFornecedoresPermitidos,
      ncms_permitidos: ncmsPermitidos,
      informacoes_gerais: input.informacoes_gerais ?? null,
      holding_id: holdingId,
      pagador_grupo: pagadorGrupo,
      ativo: true,
    });

    // Grupo econômico automático por raiz de CNPJ: só quando o chamador não informou
    // `holding_id` explicitamente — associação manual sempre vence sobre a inferida.
    if (input.holding_id === undefined) {
      await sincronizarGrupoEconomicoPorCnpj(manager, escritorioId, novoCliente);
    }

    return novoCliente;
  });

  return {
    ok: true,
    cliente: {
      id: cliente.id,
      cnpj: cliente.cnpj,
      razao_social: cliente.razao_social,
      nome_fantasia: cliente.nome_fantasia,
      email: cliente.email ?? null,
      regime_tributario: cliente.regime_tributario,
      endereco: cliente.endereco,
      uf: cliente.uf,
      opcao_ibs_cbs: cliente.opcao_ibs_cbs ?? null,
      representante_legal: cliente.representante_legal,
      cnae_principal: cliente.cnae_principal ?? null,
      cnae_principal_descricao: cliente.cnae_principal_descricao ?? null,
      informacoes_gerais: cliente.informacoes_gerais,
      holding_id: cliente.holding_id ?? null,
      pagador_grupo: cliente.pagador_grupo ?? null,
    },
  };
}

export type ClienteDadosContratoInput = {
  razao_social?: string | null;
  nome_fantasia?: string | null;
  regime_tributario?: string | null;
  endereco?: string | null;
  representante_legal?: string | null;
  informacoes_gerais?: Record<string, unknown> | null;
};

/**
 * `razao_social` é NOT NULL: quando um cliente é criado por ingestão sem nome real
 * (relatório/contrato antes do cadastro), `findOrCreateClienteByCnpj` grava o
 * placeholder `Cliente <cnpj>`. Considera-se "sem nome" o placeholder ou um valor
 * em branco — nunca sobrescrevemos uma razão social real já cadastrada.
 */
function isRazaoSocialSemCadastro(value: string | null | undefined, cnpj: string): boolean {
  const atual = (value ?? "").trim();
  return atual === "" || atual === `Cliente ${cnpj}`;
}

function nullableText(value: unknown): string | null {
  if (value == null) return null;
  const text = String(value).trim();
  return text || null;
}

function normalizeEmail(value: string | null | undefined): string | null {
  if (value == null) return null;
  const email = String(value).trim().toLowerCase();
  return email || null;
}

function isNullishClienteField(value: unknown): boolean {
  return value == null;
}

function mergeInformacoesGerais(
  current: Record<string, unknown> | null,
  incoming: Record<string, unknown> | null | undefined,
): Record<string, unknown> | null {
  if (!incoming) return current;
  return {
    ...(current ?? {}),
    ...incoming,
  };
}

export async function fillClienteNullFieldsFromContrato(
  manager: EntityManager,
  escritorioId: string,
  clienteId: string,
  input: ClienteDadosContratoInput,
  opts?: { preencherIdentificacao?: boolean; consulta?: CadastroCnpjConsultado | null },
): Promise<Cliente | null> {
  const repo = manager.getRepository(Cliente);
  const cliente = await repo.findOne({ where: { id: clienteId, escritorio_id: escritorioId } });
  if (!cliente) return null;

  let changed = false;

  // A consulta pública de CNPJ vence quando tiver o dado; o que veio do contrato só entra como
  // fallback. `uf` é tratado separadamente abaixo: a extração de contrato nunca fornece esse campo.
  const consulta = opts?.consulta ?? null;
  const dadosEfetivos: ClienteDadosContratoInput = {
    ...input,
    razao_social: consulta?.razao_social ?? input.razao_social,
    nome_fantasia: consulta?.nome_fantasia ?? input.nome_fantasia,
    regime_tributario: consulta?.regime_tributario_sugerido ?? input.regime_tributario,
    endereco: consulta?.endereco_sugerido ?? input.endereco,
  };

  // Primeiro contrato de um cliente ainda sem nome real: backfill da identificação
  // a partir do contrato extraído. `razao_social` só é sobrescrita quando for
  // placeholder/vazia; `nome_fantasia` só quando null. Nunca sobrescreve dado real.
  if (opts?.preencherIdentificacao) {
    const razaoSocial = nullableText(dadosEfetivos.razao_social);
    if (razaoSocial !== null && isRazaoSocialSemCadastro(cliente.razao_social, cliente.cnpj)) {
      cliente.razao_social = razaoSocial;
      changed = true;
    }
    const nomeFantasia = nullableText(dadosEfetivos.nome_fantasia);
    if (nomeFantasia !== null && isNullishClienteField(cliente.nome_fantasia)) {
      cliente.nome_fantasia = nomeFantasia;
      changed = true;
    }
  }

  const contractAuthoritativeFields = {
    // Regime é autoritativo do contrato: sobrescreve o valor do cliente. Por isso
    // é validado aqui contra o documento do cliente — sem o cruzamento, uma
    // extração errada apagaria silenciosamente um regime correto.
    regime_tributario: normalizarRegimeParaDocumento(dadosEfetivos.regime_tributario, cliente.cnpj),
    endereco: nullableText(dadosEfetivos.endereco),
    // `uf` é campo novo que a extração de contrato nunca fornece: só chega pela consulta de CNPJ.
    uf: normalizarUfOuNulo(consulta?.uf),
  } satisfies Record<"regime_tributario" | "endereco" | "uf", string | null>;

  for (const [field, value] of Object.entries(contractAuthoritativeFields) as Array<[keyof typeof contractAuthoritativeFields, string | null]>) {
    if (value !== null && cliente[field] !== value) {
      cliente[field] = value;
      changed = true;
    }
  }

  const fillOnlyTextFields = {
    representante_legal: nullableText(input.representante_legal),
  } satisfies Record<"representante_legal", string | null>;

  for (const [field, value] of Object.entries(fillOnlyTextFields) as Array<[keyof typeof fillOnlyTextFields, string | null]>) {
    if (value !== null && isNullishClienteField(cliente[field])) {
      cliente[field] = value;
      changed = true;
    }
  }

  const informacoesGerais = mergeInformacoesGerais(cliente.informacoes_gerais, input.informacoes_gerais);
  if (informacoesGerais !== cliente.informacoes_gerais) {
    cliente.informacoes_gerais = informacoesGerais;
    changed = true;
  }

  return changed ? await repo.save(cliente) : cliente;
}

function extrairServicosValores(contratoId: string, sc: ServicosContratados): ServicosValores {
  const vc = (sc.dados as Record<string, unknown>)?.valores_contratados as Record<string, Record<string, unknown>> | undefined;
  const resumo = sc.resumo_normalizado as Record<string, unknown> | undefined;

  function num(obj: Record<string, unknown> | undefined, campo: string): number | null {
    const v = (obj?.[campo] as Record<string, unknown> | undefined)?.valor ?? resumo?.[campo] ?? null;
    if (v == null) return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  return {
    contrato_id: contratoId,
    numero_de_documentos: num(vc, "numero_de_documentos"),
    numero_de_colaboradores: num(vc, "numero_de_colaboradores"),
    numero_de_prolabores: num(vc, "numero_de_prolabores"),
    numero_de_estabelecimentos: num(vc, "numero_de_estabelecimentos"),
  };
}

export async function getComparacaoCliente(escritorioId: string, clienteId: string, competencia: string): Promise<ComparacaoResult | null> {
  await ensureDatabase();

  const cliente = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({
      where: { id: clienteId, escritorio_id: escritorioId },
    });
  });
  if (!cliente) return null;

  const contrato = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Contrato);
    return await repo.findOne({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId, contrato_ativo: true },
    });
  });

  if (!contrato) {
    return { contrato: null, items: [], cobranca: null };
  }

  const exedentes = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ClausulasExcedentes);
    return await repo.find({
      where: { contrato_id: contrato.id, escritorio_id: escritorioId },
    });
  });

  const servicosContratados = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.getRepository(ServicosContratados).findOne({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId },
    });
  });

  const servicos: ServicosValores | null = servicosContratados
    ? extrairServicosValores(contrato.id, servicosContratados)
    : null;

  const relatorios = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Relatorio);
    return await repo.find({
      where: { cliente_id: cliente.id, competencia, escritorio_id: escritorioId, relatorio_ativo: true },
    });
  });

  const items = buildComparacaoItems({ servicos, relatorios });
  const cobranca = servicos
    ? buildCobrancaData({
        contrato,
        servicos,
        relatorios,
        exedentes,
      })
    : null;

  return { contrato: { id: contrato.id }, items, cobranca };
}

export async function findClienteByCnpj(escritorioId: string, cnpj: string): Promise<Cliente | null> {
  await ensureDatabase();
  let cnpjNormalizado: string;
  try {
    cnpjNormalizado = normalizarCnpj(cnpj);
  } catch {
    return null;
  }
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({ where: { cnpj: cnpjNormalizado, escritorio_id: escritorioId } });
  });
}

export async function findClienteAtivoByCnpj(escritorioId: string, cnpj: string): Promise<Cliente | null> {
  await ensureDatabase();
  let cnpjNormalizado: string;
  try {
    cnpjNormalizado = normalizarCnpj(cnpj);
  } catch {
    return null;
  }
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);
    return await repo.findOne({ where: { cnpj: cnpjNormalizado, escritorio_id: escritorioId, ativo: true } });
  });
}

export async function findOrCreateClienteByCnpj(input: {
  escritorioId: string;
  cnpj: string;
  razaoSocial?: string | null;
}): Promise<Cliente> {
  await ensureDatabase();

  const cnpj = normalizarCnpj(input.cnpj);

  const existing = await findClienteByCnpj(input.escritorioId, cnpj);
  if (existing) return existing;

  // Só depois do retorno antecipado acima: cliente já cadastrado nunca é bloqueado
  // pelo teto, mesmo com o escritório acima do limite. E antes da consulta pública
  // de CNPJ, pelo mesmo motivo de `createCliente`.
  await assertLimiteClientes(input.escritorioId);

  const razaoSocial = input.razaoSocial?.trim() || `Cliente ${cnpj}`;
  // Best-effort: a API vence quando tiver o dado, o nome passado pelo chamador (ou o placeholder)
  // só entra como fallback. Indisponibilidade/inexistência não bloqueiam a criação do cliente.
  const consulta = await consultarCnpjSemBloquear(cnpj);

  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Cliente);

    // Insert idempotente. O `findClienteByCnpj` acima é um check-then-insert, e a
    // janela entre os dois é grande (a consulta pública de CNPJ roda no meio), então
    // ingestões concorrentes do MESMO CNPJ chegavam todas aqui: uma vencia e as
    // outras estouravam `UQ_..._cnpj`, virando HTTP 400 no canal de ingestão IA.
    // `ON CONFLICT DO NOTHING` faz a corrida ter um vencedor e nenhum perdedor.
    const inserido = await repo
      .createQueryBuilder()
      .insert()
      .values({
        escritorio_id: input.escritorioId,
        cnpj,
        razao_social: consulta?.razao_social || razaoSocial,
        nome_fantasia: consulta?.nome_fantasia ?? null,
        regime_tributario: normalizarRegimeParaDocumento(consulta?.regime_tributario_sugerido, cnpj) ?? null,
        endereco: consulta?.endereco_sugerido ?? null,
        uf: normalizarUfOuNulo(consulta?.uf) ?? null,
        representante_legal: null,
        informacoes_gerais: null,
        ativo: true,
      })
      .orIgnore()
      .returning("*")
      .execute();

    const novoCliente = (inserido.raw as Cliente[] | undefined)?.[0] ?? null;
    if (!novoCliente) {
      // Perdemos a corrida: o cliente que o vencedor criou é o correto. Não
      // sincronizamos grupo econômico aqui — quem inseriu já fez isso.
      const vencedor = await repo.findOne({ where: { cnpj, escritorio_id: input.escritorioId } });
      if (vencedor) return vencedor;
      // Sem linha inserida e sem linha visível: o conflito veio de outro
      // escritório (a UNIQUE é só por `cnpj`), então não há o que reaproveitar.
      throw new Error(`Não foi possível criar o cliente ${cnpj}: CNPJ já cadastrado fora deste escritório.`);
    }

    // Ingestão nunca informa `holding_id` explícito, então sempre é elegível para a
    // auto-associação de grupo econômico por raiz de CNPJ.
    await sincronizarGrupoEconomicoPorCnpj(manager, input.escritorioId, novoCliente);

    return novoCliente;
  });
}

export type ClienteSearchResult = {
  id: string;
  cnpj: string;
  razao_social: string;
  nome_fantasia: string | null;
  regime_tributario: string | null;
};

export async function searchClientes(
  escritorioId: string,
  query: string,
  limit = 10,
): Promise<ClienteSearchResult[]> {
  await ensureDatabase();
  const term = `%${query.trim()}%`;
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Cliente)
      .createQueryBuilder("cliente")
      .select([
        "cliente.id",
        "cliente.cnpj",
        "cliente.razao_social",
        "cliente.nome_fantasia",
        "cliente.regime_tributario",
      ])
      .where(
        new Brackets((sub) => {
          sub
            .where("cliente.cnpj ILIKE :term", { term })
            .orWhere("cliente.razao_social ILIKE :term", { term })
            .orWhere("cliente.nome_fantasia ILIKE :term", { term });
        }),
      )
      .andWhere("cliente.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("cliente.ativo = :ativo", { ativo: true })
      .orderBy("cliente.razao_social", "ASC")
      .limit(limit);

    const clientes = await qb.getMany();
    return clientes.map((c) => ({
      id: c.id,
      cnpj: c.cnpj,
      razao_social: c.razao_social,
      nome_fantasia: c.nome_fantasia ?? null,
      regime_tributario: c.regime_tributario ?? null,
    }));
  });
}
