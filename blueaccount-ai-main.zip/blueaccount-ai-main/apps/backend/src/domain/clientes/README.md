# `src/domain/clientes`

Esta pasta concentra a regra de negócio de clientes.

## Responsabilidades

- listar clientes visíveis para um escritório
- carregar um cliente com contratos e relatórios
- criar clientes manualmente
- atualizar dados permitidos do cliente
- montar a comparação de cobrança do cliente
- normalizar o documento do cliente antes de criar ou localizar clientes (`normalizarCnpj`)
- backfill de dados do cliente a partir de um contrato (`fillClienteNullFieldsFromContrato`): campos autoritativos do contrato (`regime_tributario`, `endereco`, `uf`) e fill-if-null (`representante_legal`, `informacoes_gerais`). Com `{ preencherIdentificacao: true }` (usado no primeiro contrato do cliente), também preenche `razao_social` — apenas quando for placeholder `Cliente <cnpj>` ou vazia — e `nome_fantasia` quando null; nunca sobrescreve nome real já cadastrado
- enriquecimento por consulta pública de CNPJ (`razao_social`, `nome_fantasia`, `regime_tributario`, `endereco`, `uf`) em `createCliente`, `findOrCreateClienteByCnpj` e `fillClienteNullFieldsFromContrato`
- `findOrCreateClienteByCnpj` é **idempotente sob concorrência**: o insert usa `ON CONFLICT (cnpj) DO
  NOTHING ... RETURNING *` e, quando não volta linha, relê o cliente que venceu a corrida. O
  check-then-insert anterior tinha uma janela grande (a consulta pública de CNPJ roda entre o
  `findClienteByCnpj` e o insert), então ingestões paralelas do mesmo CNPJ — 19 agentes de relatório
  disparados por um processamento em lote do conector, no incidente de 2026-08-07 — faziam todas
  passar pela verificação e as perdedoras estouravam `UQ_..._cnpj`, virando HTTP 400 no canal de
  ingestão por IA. `sincronizarGrupoEconomicoPorCnpj` roda **só para quem inseriu**; o perdedor não
  repete o trabalho do vencedor
- derivar o perfil fiscal de IBS/CBS do cliente (`resolverPerfilFiscalCliente`), consumido pelas simulações da reforma tributária para gatear débito de receita e crédito de despesa
- auto-associação de grupo econômico por raiz de CNPJ (`sincronizarGrupoEconomicoPorCnpj`, ver seção própria abaixo)
- lookup/validação de CNAE contra a classificação oficial do IBGE, com cache lazy (`consulta-cnae.service.ts`), e o gate puro de crédito de ICMS por CNAE de fornecedor (`permiteCreditoPorCnaeFornecedor`) ou por NCM da linha (`permiteCreditoPorNcm`, com precedência sobre o de CNAE), ver seção própria abaixo

## Grupo econômico automático por raiz de CNPJ (matriz ↔ filiais)

Além da associação manual via `holding_id` (PATCH/POST informando o campo — ver
`grupo.service.ts`), `createCliente` e `findOrCreateClienteByCnpj` disparam
`sincronizarGrupoEconomicoPorCnpj` (`grupo.service.ts`) logo após persistir o cliente,
dentro da mesma transação:

- Cliente novo é **filial** (CNPJ cujo sufixo de 4 dígitos é diferente de `0001`) e
  ainda não tem `holding_id`: procura no escritório uma matriz já cadastrada com a
  mesma raiz (8 primeiros dígitos) e sufixo `0001`, e se associa a ela.
- Cliente novo é **matriz** (sufixo `0001`): procura filiais já cadastradas no
  escritório com a mesma raiz e ainda sem grupo (`holding_id IS NULL`), e associa
  cada uma a esta matriz.

A convenção matriz = sufixo `0001` é heurística (não vem de nenhuma consulta
externa — a BrasilAPI expõe `identificador_matriz_filial`, mas esse campo não é
parseado por `consulta-cnpj.service.ts` hoje). CPF nunca participa (não tem raiz de
CNPJ). A busca compara pelo prefixo mascarado da coluna `cnpj` (`LIKE`), já que a
coluna guarda o valor mascarado, não dígitos crus — mesma armadilha que
`findClienteByCnpj` já resolve para o valor completo.

**Best-effort e nunca sobrescreve escolha manual.** A associação reaproveita
`validarAssociacaoHolding` (mesmas regras do PATCH manual: sem auto-referência,
holding não pode já ser membro de outro grupo, membro não pode já ser holding de
outros); uma candidata que falhar essa validação é só pulada, com aviso no log —
nunca bloqueia a criação do cliente que disparou a busca. Em `createCliente`, a
busca automática só roda quando o chamador **não informou** `holding_id`
explicitamente no payload (`undefined`) — um valor explícito, incluindo `null`,
sempre vence sobre a inferência. `findOrCreateClienteByCnpj` (ingestão via
contrato/relatório/documento) nunca recebe `holding_id`, então é sempre elegível.

Nenhuma outra regra de grupo (`resolverModoGrupo`, `resolverAlvoConsolidacao`,
cobrança consolidada vs. por-empresa) muda: todas já operam puramente a partir de
`holding_id`, que é o único campo que esta sincronização popula automaticamente.

## Teto de clientes por escritório

`escritorios.max_clientes` limita quantos clientes um escritório pode cadastrar. `null` (o valor de
todo escritório que nunca teve o campo configurado) significa ilimitado. **Não é limite de trial**:
vale para qualquer escritório, independente de `is_trial`, e por isso mora em
`domain/escritorios/limite-clientes.ts` e não em `trial-limits.ts`.

`assertLimiteClientes` é chamada nos **dois** choke points de inserção deste domínio, e só neles
(`grupo.service.ts` apenas atualiza `holding_id`; `simulacoes/entrada-contraparte.ts` cria
`Fornecedor`, não `Cliente`):

- `createCliente` — antes de `consultarCnpjSemBloquear`. A consulta de CNPJ é I/O externo; gastá-la
  numa criação já recusada é desperdício puro.
- `findOrCreateClienteByCnpj` — **depois** do `findClienteByCnpj`, nunca antes. Cliente já cadastrado
  jamais é bloqueado, então um escritório no teto continua conseguindo ingerir documentos da carteira
  que já tem; só CNPJ novo é barrado.

Duas propriedades deliberadas:

- o lookup de `max_clientes` é **fail-open** (erro de consulta não derruba a criação de cliente de um
  pagante), mas o teto em si é fail-closed;
- a contagem inclui **clientes inativos**: o limite é de cadastro, não de uso.

`LimiteClientesError` estende `ForbiddenException`, então vira **403** com
`code: "CLIENTE_LIMIT_EXCEEDED"`, `limit` e `used` sem filtro novo. O texto legível sai de
`mensagemLimiteClientes` — `HttpException.message` devolveria "Forbidden", porque o corpo é um objeto
sem a chave `message`.

Quem chama em laço aborta no primeiro bloqueio em vez de repetir o 403 por linha: a importação em
lote (abaixo) e `finalizarIngestaoRelatoriosPlanilha`
(`domain/relatorios/relatorio.service.ts`, código de erro `limite_clientes_atingido`).

Não há trava contra corrida: dois `createCliente` simultâneos podem passar a contagem e fechar em
`limite + 1`. É um teto comercial, não invariante de cobrança; um advisory lock não se paga.

## Importação em lote

`importar-clientes-lote.ts` cria vários clientes numa chamada **reusando `createCliente` por item**,
sem caminho paralelo: mesma consulta de CNPJ, mesma precedência de campos, mesmas validações. Existe
para a importação a partir do cliente local do Domínio (`apps/client`).

Duas decisões definem o comportamento:

1. **Sequencial, nunca `Promise.all`.** Cada item faz uma consulta de CNPJ na rede, e criações
   concorrentes do mesmo documento correriam entre si — o mesmo motivo pelo qual
   `finalizarIngestaoRelatoriosPlanilha` também é sequencial.
2. **Resultado por item, nunca tudo-ou-nada.** Um CNPJ inválido no meio do lote não pode descartar as
   criações que já commitaram. Cada item é uma transação curta e independente dentro de
   `createCliente`.

`ClienteJaExisteError` vira `ja_existe`, não erro: é isso que torna seguro reenviar uma página que
falhou no meio. Um documento repetido dentro da própria requisição vira `duplicado_no_lote` — o
`geempre` do Domínio tem o mesmo CNPJ em `codi_emp` diferentes.

`LimiteClientesError` é a exceção à regra do "resultado por item": ele **aborta** o lote. A linha que
disparou e todas as seguintes voltam como `limite_atingido` (contado em `limite_atingido` no resumo).
Sem o abort, cada linha restante gastaria uma consulta de CNPJ para receber o mesmo 403 e apareceria
como `erro`, escondendo a causa real.

`LIMITE_LOTE_CLIENTES` (100) existe porque a consulta de CNPJ é uma ida à rede por item num cache
frio; um lote maior estoura o timeout do ALB/CloudFront antes de terminar.

`dominio_empresa_id` (`codi_emp`) é aceito e devolvido para o chamador correlacionar, mas **não
persistido**: o vínculo `codi_emp` → `cliente` é uma tabela própria que ainda não existe.

## Enriquecimento por consulta pública de CNPJ: a API vence

`createCliente` (cadastro manual), `findOrCreateClienteByCnpj` (cliente novo criado a partir de
contrato ou relatório) e `fillClienteNullFieldsFromContrato` (backfill do cliente já existente,
chamado só pelo fluxo de contrato) chamam `consultarCnpjSemBloquear` — a mesma consulta pública de
CNPJ (BrasilAPI + cache `cadastros_cnpj`) que `domain/fornecedores/consulta-cnpj.service.ts` já
mantinha para fornecedor, agora exportada de lá e reusada aqui.

**A precedência é o INVERSO da de fornecedor.** Em `fornecedor.service.ts`,
`completarInputComConsulta` só preenche o que ficou em branco — o digitado/extraído sempre vence. Em
`cliente.service.ts`, a API vence quando tiver o campo (`razao_social`, `nome_fantasia`,
`regime_tributario` via `regime_tributario_sugerido`, `endereco` via `endereco_sugerido`, `uf`); o
valor digitado no formulário manual ou extraído do contrato só é usado como fallback, quando a API
não tiver o dado ou a consulta falhar. Isso vale inclusive para o cadastro manual: a API pode
sobrescrever o que o usuário digitou.

`endereco_sugerido` é composto (`comporEndereco`, em `consulta-cnpj.service.ts`) a partir de
logradouro/número/complemento/bairro/município/UF/CEP da resposta da fonte — campos que só existem
no `payload` jsonb cacheado (não viraram coluna própria de `cadastros_cnpj`, e não são PII, então
`higienizarPayloadCnpj` não os remove).

`uf` é campo novo em `clientes` (coluna, sem backfill — nasce `NULL` para cadastro legado). A
extração de contrato nunca fornece esse campo, então dentro de `fillClienteNullFieldsFromContrato`
ele só chega pela consulta de CNPJ; está no mesmo balde autoritativo de `regime_tributario`/
`endereco` (sobrescreve o valor atual do cliente quando a API tiver o dado).

**Nunca bloqueia a criação/atualização do cliente.** `consultarCnpjSemBloquear` intercepta
`CnpjNaoEncontradoError`/`ConsultaCnpjIndisponivelError` e devolve `null`; todo merge é
`consulta?.campo ?? fallback`. CPF (11 dígitos) nunca toca a consulta (`consultarCnpj` devolve `null`
de imediato) — cliente pessoa física segue 100% pelo valor digitado/extraído.

A chamada de rede nunca acontece dentro de uma transação `runQueryWithRls` aberta — mesma regra que
`enriquecerFornecedorPorCnpj` já seguia. Em `contrato.service.ts`, os três pontos que chamam
`fillClienteNullFieldsFromContrato` (`confirmarContratoExtracted`, `criarContratoManual`,
`updateContrato`) resolvem a consulta antes de abrir a transação principal e passam o resultado via
`opts.consulta`; `updateContrato` precisa de uma leitura leve extra antes da transação só para achar
o CNPJ do cliente, já que ali o `cliente_id` só é conhecido depois de ler o contrato.

## Perfil fiscal de IBS/CBS do cliente (`opcao_ibs_cbs`)

O cliente mantém somente `opcao_ibs_cbs` (`regime_unico | regime_regular`). Os percentuais de
crédito transferido existem exclusivamente no fornecedor; a migration `1787100000000` remove as
antigas colunas presumidas do cliente. A opção é digitação do contador, sem fallback de consulta
pública, e só é lida quando `regime_tributario === "Simples Nacional"`.

### `resolverPerfilFiscalCliente` (`regime-credito.ts`)

Função pura, análoga a `resolverCreditoFornecedor` (`domain/fornecedores/regime-credito.ts`), mas
resolvendo uma pergunta diferente: não "quanto de crédito esta compra transfere", e sim "o cliente
desta simulação pode debitar/creditar IBS/CBS pela alíquota normal, ou está limitado/zerado". É
consumida por `domain/simulacoes/simulacao.service.ts` (`mapearSimulacaoParaInput`) para popular
`SimulacaoInput.clienteCredito` — ver `domain/simulacoes/README.md` para como esse perfil entra na
cadeia de precedência do motor (cliente é o teto: vence outright sobre fornecedor/linha).

| `regime_tributario` | `opcao_ibs_cbs` | perfil | efeito |
| --- | --- | --- | --- |
| `Pessoa Física` | irrelevante | `sem_credito` | débito de receita e crédito de despesa de IBS/CBS zerados na simulação inteira |
| `MEI` | irrelevante | `sem_credito` | **diverge deliberadamente do fornecedor**, onde MEI cai em `presumido`. Para o cliente o gate também zera o próprio DÉBITO de receita, não só o crédito que um terceiro tomaria da nota — MEI não pode optar pelo regime regular de IBS/CBS |
| `Simples Nacional` | `regime_regular` | `integral` | opção híbrida (LC 214/2025, art. 41): comportamento histórico, sem ajuste |
| `Simples Nacional` | `regime_unico` ou nulo | `sem_credito` | não apura débitos nem apropria créditos próprios fora do Simples |
| `Lucro Presumido` / `Lucro Real` / nulo | irrelevante | `integral` | apuração regular |

A tabela é deliberadamente diferente da de `resolverCreditoFornecedor` no ponto do MEI — é a
divergência mais fácil de "corrigir" por engano se alguém copiar a tabela do fornecedor sem ler
esta nota. `tests/regime-credito.test.ts` trava esse caso explicitamente.

## CNAE/NCM do cliente, allowlists e gate de crédito de ICMS (LC 214/2025)

`clientes` ganhou quatro colunas de CNAE, todas sem backfill (migration `1785900000000`, nascem
`NULL` para cliente já cadastrado):

- `cnae_principal` (`varchar(7)`) e `cnae_principal_descricao` (`text`) — CNAE do PRÓPRIO cliente,
  espelhando `fornecedores.cnae_principal`/`cnae_principal_descricao`. Preenchidos pela consulta
  pública de CNPJ na criação (`createCliente`), editáveis depois.
- `cnaes_secundarios` (`jsonb`, `CnaeSecundario[] | null`) — lista de CNAEs secundários do cliente,
  também vinda da consulta de CNPJ.
- `cnaes_fornecedores_permitidos` (`jsonb`, `CnaeSecundario[] | null`) — allowlist **manual** de CNAE
  de FORNECEDOR que o contador considera elegível a gerar crédito de ICMS/IBS/CBS para este cliente
  (LC 214/2025 restringe crédito a insumos ligados à atividade econômica do contribuinte). Conceito
  sem equivalente em `Fornecedor`: nunca vem da consulta de CNPJ (que resolve o CNAE do próprio
  cliente, não de terceiros) — é dado 100% de digitação do contador. `NULL`/lista vazia = nenhuma
  restrição cadastrada.

Uma quinta coluna, `ncms_permitidos` (`jsonb`, `NcmPermitido[] | null`, migration `1786800000000`),
é a mesma ideia de allowlist manual mas chaveada pelo **NCM da linha** (`simulacao_entradas.ncm`,
classificação fiscal da mercadoria) em vez do CNAE do fornecedor. Mesmo shape de `CnaeSecundario`
(`{codigo, descricao}`), mas com 8 dígitos em vez de 7. **Também sem backfill e também nunca vem de
consulta/lookup externo** — 100% digitação do contador, mesma categoria de
`cnaes_fornecedores_permitidos`.

**Diferença estrutural importante em relação ao CNAE**: CNAE tem uma cadeia de precedência de 2
níveis (`resolverCnaeEntrada`, override da linha > `fornecedores.cnae_principal` do fornecedor
vinculado) porque existem duas fontes possíveis para o CNAE efetivo de uma linha. **NCM não tem
segunda fonte** — não existe `fornecedores.ncm`, então não há override a resolver. O NCM efetivo da
linha é simplesmente `simulacao_entradas.ncm`, direto, editável pelo usuário no frontend
(`NcmCell`). Por isso a implementação da allowlist de NCM **não** introduziu uma coluna
`ncm_override`: seria duplicar o mesmo dado sem nenhuma semântica nova para distinguir.

### Lookup/validação de CNAE (`consulta-cnae.service.ts`)

`consultarCnae(codigoBruto)` resolve um código de 7 dígitos contra a classificação oficial do IBGE,
com cache lazy **sem TTL** em `cnaes_referencia` (schema `public`, não por tenant — é classificação
pública, igual para todo escritório). Devolve `null` para código inexistente (o chamador trata como
404, sem try/catch); relança `CnaeIndisponivelError` quando a fonte está fora do ar (503) — nunca
confunde os dois casos, para não ensinar à UI que um código válido não existe só porque o IBGE caiu.
Resultado negativo nunca é cacheado (uma revisão futura do IBGE pode passar a reconhecer o código).

Exposto via `GET /api/cnaes/:codigo` (`modules/cnaes`), consumido pelo frontend (`resolveCnae()`) para
validação on-blur ao digitar um CNAE manual — em `ClienteDetailPage.tsx` e, desde a integração com
`domain/simulacoes`, também no editor de simulação (linha a linha). `GET /api/ncms/:codigo`
(`consulta-ncm.service.ts`, `modules/ncms`) é o equivalente para NCM, com o mesmo papel de validação
de UX — nenhum dos dois endpoints é fonte de dado das respectivas allowlists.

### `permiteCreditoPorCnaeFornecedor` e `permiteCreditoPorNcm` — os gates puros

Duas funções puras em `regime-credito.ts`, sem banco/rede, mesma forma:

- `permiteCreditoPorCnaeFornecedor(cnaesPermitidos, cnaeFornecedor)`: lista ausente/vazia = sem
  restrição (sempre `true`); CNAE do fornecedor ausente = não elegível (`false`); caso contrário,
  compara dígitos normalizados (`padStart(7, "0")`) contra a lista.
- `permiteCreditoPorNcm(ncmsPermitidos, ncmEfetivo)`: mesma lógica, `padStart(8, "0")` em vez de 7.
  O `padStart` aqui é puramente defensivo — `simulacao_entradas.ncm` já chega gravado com
  exatamente 8 dígitos (`ncmOuNulo`, que lança se não for), então nunca deveria alterar o valor
  comparado.

**Consumidas por `domain/simulacoes/calculo.ts`** (`calcularEntrada`), que combina as duas com
precedência do NCM sobre o CNAE:

```
usaGateNcm = ncmsPermitidosCliente não vazia AND entrada.ncm != null

permiteIcms = usaGateNcm
    ? permiteCreditoPorNcm(ncmsPermitidosCliente, entrada.ncm)                  // NCM decide sozinho
    : permiteCreditoPorCnaeFornecedor(cnaesPermitidosCliente, cnaeEfetivo.valor) // comportamento atual
```

Ou seja: (a) cliente com allowlist de NCM cadastrada e linha com NCM preenchido → só o NCM decide,
CNAE nem é consultado; (b) allowlist de NCM cadastrada mas a linha **não tem** NCM (ex.: lançamento
manual, não veio de importação de NF-e) → cai para o gate de CNAE de sempre, sem regressão; (c)
sem allowlist de NCM cadastrada → idêntico ao comportamento anterior à existência deste campo. Como
o gate de NCM roda **antes** do de CNAE quando aplicável, um NCM permitido gera crédito mesmo que o
CNAE do fornecedor não esteja na allowlist de CNAE — aquele branch do combinador nunca chega a olhar
para CNAE.

Ambos gateiam exclusivamente crédito de ICMS de despesa, nunca IBS/CBS (esses seguem o perfil fiscal
de `resolverPerfilFiscalCliente`, seção acima) nem débito algum. O CNAE efetivo da linha vem de
`resolverCnaeEntrada` (override da linha > `fornecedores.cnae_principal` do fornecedor vinculado);
o NCM efetivo é só `entrada.ncm`, sem cadeia — ver
`domain/simulacoes/README.md` → "CNAE por linha e crédito de ICMS por CNAE do fornecedor" para a
cadeia completa e os campos calculados (`cnae_efetivo`, `origem_cnae`,
`credito_icms_bloqueado_por_cnae`, `credito_icms_bloqueado_por_ncm`).

## Documento do cliente: `cnpj` aceita CPF

O campo se chama `cnpj` em toda a stack (coluna `clientes.cnpj`, payloads de API, tools MCP e
prompts de extração). É uma **exceção deliberada de nomenclatura**, mantida por compatibilidade de
contrato público: o campo guarda os dois documentos, porque um cliente pode ser pessoa física
(ex.: um profissional liberal que contrata o escritório no CPF).

`normalizarCnpj(value)` (`cliente.service.ts`) é o único portão. Ele tira a máscara e devolve o
valor mascarado conforme o comprimento:

| Dígitos | Documento | Máscara devolvida |
| --- | --- | --- |
| 14 | CNPJ | `##.###.###/####-##` |
| 11 | CPF | `###.###.###-##` |
| outro | — | lança `DocumentoClienteInvalidoError` |

Regras que valem para quem mexer aqui:

- **Só o comprimento é validado.** Não há verificação de dígito verificador, de propósito: isso
  rejeitaria dado legado e documento vindo de OCR imperfeito.
- `DocumentoClienteInvalidoError` é tratado como **400** pelos controllers de clientes, contratos e
  relatórios. Não trocar por `Error` genérico, senão a resposta volta a ser 500.
- Mesma regra vale para `createCliente`: documento duplicado no escritório lança
  `ClienteJaExisteError` (**409**), e `holding_id` inválido/já associado lança `HoldingInvalidaError`
  (**400**) — ambos registrados em `clientes.controller.ts`. Um `Error` genérico nesses pontos vira
  500 sem explicação nenhuma pro usuário, que foi exatamente o bug que motivou essas duas classes.
- Toda busca exata por documento precisa passar por `normalizarCnpj` primeiro — a coluna guarda o
  valor mascarado, então comparar com dígitos crus nunca casa. Use `findClienteByCnpj` /
  `findClienteAtivoByCnpj`, que já normalizam e devolvem `null` em comprimento inválido.
- Os normalizadores de extração em `apps/services/relatorios/src/shared/extraction.ts` e
  `apps/services/contratos/src/lambdas/extract-termos-gerais/index.ts` são cópias com a mesma regra
  (só devolvem `null` em vez de lançar). Mantê-los em sincronia.

Limitação conhecida: a simulação de reforma tributária agrupa notas por **raiz de CNPJ**
(`domain/simulacoes/nfe/classificador.ts`), conceito que não existe para CPF. Nota de cliente
pessoa física fica inclassificável, com motivo legível — não quebra, mas também não simula.

## Regime tributário: enum + pareamento com o documento

`regime-tributario.ts` é a fonte da verdade dos cinco valores canônicos:

| Valor | Documento exigido |
| --- | --- |
| `Simples Nacional` | CNPJ (14 dígitos) |
| `Lucro Presumido` | CNPJ (14 dígitos) |
| `Lucro Real` | CNPJ (14 dígitos) |
| `MEI` | CNPJ (14 dígitos) |
| `Pessoa Física` | **CPF (11 dígitos)** |

`normalizarRegimeTributario` aceita variantes e devolve o valor canônico —
`"Simples"`/`"simples"`/`"SN"` → `Simples Nacional`, `"PF"`/`"autônomo"`/`"profissional liberal"` →
`Pessoa Física`, e assim por diante (mapa completo em `VARIANTES`). `null`, `undefined` e string
vazia devolvem `null`; **valor irreconhecível lança `RegimeTributarioInvalidoError`**.

Esse "lança em vez de virar `null`" é deliberado e é o ponto central do módulo. Regime e documento são
redundantes de propósito, então um par inconsistente prova que um dos dois campos está errado — e esse
é o teste de acurácia mais barato que temos sobre a extração automática de contratos. Silenciar o
valor desconhecido (como `normalizarIndiceReajuste` faz) apagaria justamente esse sinal.

`validarRegimeComDocumento(regime, documento)` cruza os dois. Não valida quando falta um dos dois nem
quando o documento tem comprimento fora de 11/14 (aí o erro é de documento, e `normalizarCnpj` já
reclama). `normalizarRegimeParaDocumento` faz as duas coisas numa passada e é o que os caminhos de
escrita usam.

### Onde o gate roda

| Camada | Onde | Efeito |
| --- | --- | --- |
| MCP (zod) | `apps/mcp/src/tools/contratos.ts`, no `superRefine` de `TERMOS_GERAIS_EXTRAIDOS_SCHEMA` | O agente falha na validação da tool, **antes** de qualquer HTTP. Cruza `regime_tributario` com o `cnpj_cliente` do mesmo payload |
| Submissão da extração | `validateSecaoItemsIA("termos_gerais", …)` em `../documentos/documentos-parsing.ts` | Seção marcada inválida, `status_extracao = "erro"`, nenhum contrato criado. O agente reenvia só essa seção |
| Escrita no cliente | `createCliente`, `patchCliente`, `fillClienteNullFieldsFromContrato` | `RegimeTributarioInvalidoError` → **400** nos controllers de clientes, contratos e relatórios |

Regras para quem mexer aqui:

- A lista dos cinco valores é **duplicada** em `apps/mcp/src/shared.ts`,
  `apps/frontend/src/lib/regime-tributario.ts`, `apps/services/contratos/src/lambdas/extract-termos-gerais/index.ts`
  e nos prompts de extração. Não há pacote compartilhado entre os runtimes — ao mexer aqui, mexer nos
  quatro. `tests/regime-tributario.test.ts` trava a lista para a divergência quebrar o build.
- O frontend filtra as opções do dropdown pelo documento do cliente
  (`regimesParaDocumento`), então a combinação inválida não é selecionável pela UI. É isso que impede
  o 400 de virar um beco sem saída na tela de review.
- **Não há migration de backfill.** A normalização acontece na próxima escrita de cada cliente, então
  valor legado tipo `"Simples"` só vira `"Simples Nacional"` quando aquele cliente for editado.

## Arquivos

- `cliente.service.ts`: coordena acesso ao banco e montagem do payload de negócio
- `grupo.service.ts`: regras de grupo econômico (hierarquia por `holding_id`, modo consolidado x
  por-empresa, alvo de consolidação, pagador) e a auto-associação por raiz de CNPJ
  (`sincronizarGrupoEconomicoPorCnpj`)
- `regime-tributario.ts`: enum canônico do regime, normalização de variantes e o cruzamento com o documento
- `regime-credito.ts`: núcleo **puro** — `resolverPerfilFiscalCliente` mapeia regime + `opcao_ibs_cbs`
  do cliente para o perfil que gateia débito/crédito de IBS/CBS na simulação; `permiteCreditoPorCnaeFornecedor`
  gateia crédito de ICMS pela allowlist de CNAE de fornecedor; `permiteCreditoPorNcm` gateia pela
  allowlist de NCM da linha, com precedência sobre o de CNAE (combinador em `domain/simulacoes/calculo.ts`).
  Sem banco, sem rede.
- `consulta-cnae.service.ts`: lookup/validação de CNAE contra a classificação do IBGE, com cache lazy
  em `cnaes_referencia` (schema `public`). Exposto via `GET /api/cnaes/:codigo` (`modules/cnaes`).
- `consulta-ncm.service.ts`: equivalente para NCM. Exposto via `GET /api/ncms/:codigo`
  (`modules/ncms`), mesmo papel de validação de UX no frontend — não é fonte de dado de
  `ncms_permitidos`.

## Testes

- `tests/cliente.service.test.ts` (inclui `ncms_permitidos`: validação/persistência/replace no
  create e no patch, espelhando os casos de `cnaes_fornecedores_permitidos`)
- `tests/grupo.service.test.ts` (inclui a auto-associação por raiz de CNPJ)
- `tests/regime-tributario.test.ts`
- `tests/regime-credito.test.ts` (tabela de decisão, incluindo o caso MEI divergente do fornecedor,
  `permiteCreditoPorCnaeFornecedor` e `permiteCreditoPorNcm`)
- `tests/consulta-cnae.service.test.ts` (cache, não-encontrado vs. indisponível, sem cache de negativo)
- `tests/consulta-ncm.service.test.ts` (equivalente para NCM)

## O que não deve ficar aqui

- `express`
- `req` e `res`
- validação de rota
- detalhes de autenticação HTTP

Esses detalhes ficam na camada `src/http`.

## Composição de fornecedores por cliente

`fornecedores-cliente.ts` consulta identidades reais vinculadas a despesas nas simulações e,
quando `NOTAS_FISCAIS_FONTE=postgres`, emitentes de notas de entrada publicadas. Usa RLS,
cliente e escritório explícitos, deduplica CPF/CNPJ entre cenários/acervo e lê o regime, a UF e o
CNAE atuais do cadastro. Sem cadastro, preserva identidade e classificação nula. Genéricos, documentos
sem identidade e homologação no acervo não entram. Não agrega valores de cenários alternativos.
Em Athena, retorna `fonte=simulacoes` e a UI informa a cobertura limitada; não inicia scan externo.

`listarCompradoresCliente` reutiliza a composição para clientes compradores: notas de saída do
acervo Postgres e notas das simulações, sempre com CPF/CNPJ da contraparte. NF-e/NFC-e usam
identidade e tipo de operação; NFS-e usa prestador/tomador; planilhas usam movimento declarado.
Nota própria de saída usa destinatário; nota de entrada emitida pelo comprador usa emitente.
Deduplica documento, exclui a própria empresa, homologação e consumidor sem documento.
O cadastro de cliente comprador no mesmo escritório tem precedência, campo a campo (inclusive na
UF, via `COALESCE(c.uf, f.uf)`), sobre o cadastro de fornecedor da mesma identidade; ausência
continua nula. Não usa CRT do vendedor
para classificar o comprador nem consulta/enriquece CNPJ ao abrir a tela.

## Catálogo NCM local versionado

`consulta-ncm.service.ts` consulta somente registros exatos de oito dígitos da versão publicada.
`resolverFatoresPorNcms` deduplica e consulta lotes de até 1.000 códigos; o resolver unitário usa o
mesmo caminho. Não há chamadas externas, formação de árvore, gravação lazy ou edição pelo admin.
A fonte é `NCM_Fator_IVA_IBS_CBS.xlsx`, preservada com checksum e metodologia no repositório.

A planilha **não** é a única fonte: o importador a reconcilia com o manifesto
`regras-ncm-revisadas-20260916.ts` (texto da LC 214/2025, 201 regras de prefixo), porque a própria
planilha se declara material de apoio lido em espelhos comunitários. `situacao_revisao` grava a
decisão — `automatica` só quando as duas fontes concordam (316 códigos com benefício), `conflito`
quando divergem no fator (345) e `condicional` para condição legal, anexo não revisado e medicamento
(1.261). Em tudo que não seja `automatica` o fator publicado é sugestão e o automático fica em 1;
`evidencias_revisao` carrega a leitura de cada fonte para a decisão do contador na entrada.
Código ausente retorna `catalogado=false`, `situacao_revisao=fora_catalogo` e revisão; não prova NCM inexistente.
O frontend permite salvar oito dígitos ausentes com aviso. Fatores manuais continuam prioritários.
Consulta de catálogo não certifica elegibilidade da allowlist de crédito de ICMS do cliente.

A migration pública `1792900000000` arquiva a base anterior e publica a fonte. Não reescreve
fatores nem recalcula simulações existentes, não invalida caches e não enfileira cópias vinculadas.
Guia operacional: `docs/operations/CATALOGO_NCM_LOCAL.md`. A revisão hierárquica de setembro não
resolve mais prefixos em runtime, mas continua sendo a segunda fonte do importador: alterá-la sem
regerar o catálogo deixa o manifesto publicado divergente do manifesto revisado.

O serviço confere uma vez por processo se `METADADOS_CATALOGO_NCM.versao` consta em
`public.ncm_catalogo_versoes` e registra erro quando não consta — sem isso, código no ar antes da
migration resolveria todo NCM como `fora_catalogo` em silêncio.
