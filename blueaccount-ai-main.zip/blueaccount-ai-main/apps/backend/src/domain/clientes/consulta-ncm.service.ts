import { Logger } from "@nestjs/common";
import { In } from "typeorm";
import { AppDataSource } from "../../database/data-source.js";
import { NcmReferencia } from "../../database/modules/public/entities/ncm-referencia.entity.js";
import { METADADOS_CATALOGO_NCM } from "../../database/modules/public/migrations/dados/ncm-metadados-20260916.js";

export type SituacaoNcm = "automatica" | "condicional" | "conflito" | "fora_catalogo";
export type FatoresNcmResolvidos = {
  ncm: string; codigo_regra: string | null;
  fator_ibs_sugerido: number; fator_cbs_sugerido: number;
  fator_ibs_automatico: number; fator_cbs_automatico: number;
  aplicacao_automatica: boolean; requer_confirmacao: boolean;
  fundamento_legal: string | null; condicoes_aplicacao: string | null;
  catalogado: boolean; situacao_revisao: SituacaoNcm; motivos_revisao: string[];
  versao_catalogo: string;
};
export type OpcoesCatalogoNcm = { pagina?: unknown; tamanho?: unknown; busca?: unknown; categoria?: unknown; fator?: unknown; situacao?: unknown };

/** Aceita somente código e sua pontuação de apresentação; nunca inventa zeros. */
export function normalizarNcm(codigo: unknown): string | null {
  if (typeof codigo !== "string" || !/^[\d.\s]+$/.test(codigo)) return null;
  const digitos = codigo.replace(/[.\s]/g, "");
  return /^\d{8}$/.test(digitos) ? digitos : null;
}
const logger = new Logger("ConsultaNcm");
let versaoConferida: Promise<void> | null = null;

/**
 * Toda consulta filtra por `versao_catalogo = METADADOS.versao`, que é fixado no bundle. Se o código
 * subir antes da migration de publicação (ou ela falhar), o filtro não casa com nada e cada NCM vira
 * `fora_catalogo` com fator 1 — sem erro e sem alarme. A checagem abaixo roda uma vez por processo e
 * transforma esse silêncio em log de erro; não derruba a requisição porque `fora_catalogo` já é o
 * estado conservador e visível na tela.
 */
async function conferirVersaoPublicada(): Promise<void> {
  let versoes: string[];
  try {
    const publicadas: { versao: string }[] = await AppDataSource.query(
      `SELECT versao FROM public.ncm_catalogo_versoes ORDER BY publicado_em DESC LIMIT 5`,
    );
    versoes = publicadas.map((linha) => linha.versao);
  } catch (erro) {
    logger.error(`Não foi possível ler public.ncm_catalogo_versoes: ${String(erro)}`);
    return;
  }
  if (versoes.includes(METADADOS_CATALOGO_NCM.versao)) return;
  logger.error(`Catálogo NCM ${METADADOS_CATALOGO_NCM.versao} não está publicado no banco (publicadas: ${versoes.join(", ") || "nenhuma"}). `
    + "Todo NCM será resolvido como fora_catalogo com fator 1 provisório até a migration de publicação rodar.");
}

async function repositorioNcm() {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  versaoConferida ??= conferirVersaoPublicada();
  await versaoConferida;
  return AppDataSource.getRepository(NcmReferencia);
}

function resolverRegistro(ncm: string, registro?: NcmReferencia | null): FatoresNcmResolvidos {
  const automatica = registro?.aplicacao_automatica === true;
  return {
    ncm, codigo_regra: registro?.codigo ?? null,
    fator_ibs_sugerido: Number(registro?.fator_ibs ?? 1), fator_cbs_sugerido: Number(registro?.fator_cbs ?? 1),
    fator_ibs_automatico: automatica ? Number(registro!.fator_ibs) : 1,
    fator_cbs_automatico: automatica ? Number(registro!.fator_cbs) : 1,
    aplicacao_automatica: automatica, requer_confirmacao: !automatica,
    fundamento_legal: registro?.fundamento_legal_fatores ?? null,
    condicoes_aplicacao: registro?.condicoes_aplicacao_fatores ?? null,
    catalogado: Boolean(registro), situacao_revisao: registro?.situacao_revisao ?? "fora_catalogo",
    motivos_revisao: registro?.motivos_revisao ?? ["fora_catalogo"], versao_catalogo: METADADOS_CATALOGO_NCM.versao,
  };
}

function apresentarNcm(ncm: NcmReferencia) {
  const regra = resolverRegistro(ncm.codigo, ncm);
  return {
    codigo: ncm.codigo, descricao: ncm.descricao, descricao_oficial: ncm.descricao,
    // Campos legados preservados apenas para compatibilidade de transporte.
    descricoes_hierarquia: [] as string[], data_inicio: null, data_fim: null, tipo_ato: null, numero_ato: null, ano_ato: null,
    fator_ibs: regra.fator_ibs_sugerido, fator_cbs: regra.fator_cbs_sugerido,
    fator_ibs_automatico: regra.fator_ibs_automatico, fator_cbs_automatico: regra.fator_cbs_automatico,
    fatores_configurados: true, aplicacao_automatica: regra.aplicacao_automatica, requer_confirmacao: regra.requer_confirmacao,
    fundamento_legal_fatores: regra.fundamento_legal, condicoes_aplicacao_fatores: regra.condicoes_aplicacao,
    origem_configuracao_fatores: METADADOS_CATALOGO_NCM.versao,
    categoria: ncm.categoria, observacao: ncm.observacao, situacao_revisao: regra.situacao_revisao,
    motivos_revisao: regra.motivos_revisao, evidencias_revisao: ncm.evidencias_revisao,
    versao_catalogo: regra.versao_catalogo,
    fonte: { arquivo: METADADOS_CATALOGO_NCM.arquivo, sha256: METADADOS_CATALOGO_NCM.sha256,
      data: METADADOS_CATALOGO_NCM.data_fonte, aba: METADADOS_CATALOGO_NCM.aba, linha: ncm.fonte_linha },
  };
}
export type NcmReferenciaListada = ReturnType<typeof apresentarNcm>;

export async function consultarNcm(codigoBruto: unknown): Promise<NcmReferenciaListada | null> {
  const codigo = normalizarNcm(codigoBruto);
  if (!codigo) return null;
  const registro = await (await repositorioNcm()).findOneBy({ codigo, versao_catalogo: METADADOS_CATALOGO_NCM.versao });
  return registro ? apresentarNcm(registro) : null;
}

/** Uma consulta por lote de códigos distintos. Sem rede, escrita ou resolução por prefixo. */
export async function resolverFatoresPorNcms(codigosBrutos: readonly unknown[]): Promise<Map<string, FatoresNcmResolvidos>> {
  const codigos = [...new Set(codigosBrutos.map(normalizarNcm).filter((c): c is string => c !== null))];
  if (!codigos.length) return new Map();
  const repositorio = await repositorioNcm();
  const registros = new Map<string, NcmReferencia>();
  for (let inicio = 0; inicio < codigos.length; inicio += 1000) {
    const lote = await repositorio.findBy({ codigo: In(codigos.slice(inicio, inicio + 1000)), versao_catalogo: METADADOS_CATALOGO_NCM.versao });
    for (const registro of lote) registros.set(registro.codigo, registro);
  }
  return new Map(codigos.map(c => [c, resolverRegistro(c, registros.get(c))]));
}
export async function resolverFatoresPorNcm(codigoBruto: unknown): Promise<FatoresNcmResolvidos | null> {
  const codigo = normalizarNcm(codigoBruto);
  if (!codigo) return null;
  return (await resolverFatoresPorNcms([codigo])).get(codigo)!;
}

export async function listarNcmsReferencia(opcoes: OpcoesCatalogoNcm = {}) {
  const pagina = Math.max(1, Number.parseInt(String(opcoes.pagina ?? "1"), 10) || 1);
  const tamanho = Math.min(100, Math.max(1, Number.parseInt(String(opcoes.tamanho ?? "25"), 10) || 25));
  const busca = typeof opcoes.busca === "string" ? opcoes.busca.trim().slice(0, 100) : "";
  const consulta = (await repositorioNcm()).createQueryBuilder("ncm")
    .where("ncm.versao_catalogo = :versao", { versao: METADADOS_CATALOGO_NCM.versao });
  if (busca) {
    if (/^[\d.\s]+$/.test(busca)) consulta.andWhere("ncm.codigo LIKE :busca", { busca: `${busca.replace(/[.\s]/g, "")}%` });
    else consulta.andWhere("ncm.descricao ILIKE :busca", { busca: `%${busca.replace(/[\\%_]/g, "\\$&")}%` });
  }
  if (typeof opcoes.categoria === "string" && opcoes.categoria) consulta.andWhere("ncm.categoria = :categoria", { categoria: opcoes.categoria });
  if (opcoes.fator !== undefined && opcoes.fator !== "") {
    const fator = Number(opcoes.fator);
    if (!Number.isFinite(fator) || fator < 0 || fator > 1) throw new Error("Fator deve estar entre 0 e 1.");
    consulta.andWhere("ncm.fator_ibs = :fator", { fator });
  }
  if (opcoes.situacao) {
    if (!["automatica", "condicional", "conflito"].includes(String(opcoes.situacao))) throw new Error("Situação NCM inválida.");
    consulta.andWhere("ncm.situacao_revisao = :situacao", { situacao: opcoes.situacao });
  }
  const [registros, total] = await consulta.orderBy("ncm.codigo", "ASC").skip((pagina - 1) * tamanho).take(tamanho).getManyAndCount();
  return { items: registros.map(apresentarNcm), pagina, tamanho, total, total_paginas: Math.max(1, Math.ceil(total / tamanho)), catalogo: METADADOS_CATALOGO_NCM };
}
