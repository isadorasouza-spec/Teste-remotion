import { runQueryWithRls } from "../../database/data-source.js";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { settings } from "../../settings.js";

export function listarFornecedoresCliente(escritorioId: string, clienteId: string) {
  return listarContrapartesCliente(escritorioId, clienteId, "fornecedores");
}

export function listarCompradoresCliente(escritorioId: string, clienteId: string) {
  return listarContrapartesCliente(escritorioId, clienteId, "compradores");
}

/** Identidades comerciais conhecidas; nunca soma valores de cenários alternativos. */
async function listarContrapartesCliente(escritorioId: string, clienteId: string, tipo: "fornecedores" | "compradores") {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const cliente = await manager.getRepository(Cliente).findOne({
      where: { id: clienteId, escritorio_id: escritorioId }, select: { id: true, cnpj: true },
    });
    if (!cliente) return null;
    const usaAcervo = settings.NOTAS_FISCAIS_FONTE === "postgres";
    const compradores = tipo === "compradores";
    // Fragmentos fechados controlados pelo servidor, sem interpolação de parâmetros HTTP.
    const movimento = compradores ? "saida" : "entrada";
    const simulacoes = compradores ? `
      SELECT regexp_replace(CASE WHEN regexp_replace(n.emitente_documento, '[^0-9]', '', 'g') = $3
        THEN n.destinatario_documento ELSE n.emitente_documento END, '[^0-9]', '', 'g') AS documento,
        CASE WHEN regexp_replace(n.emitente_documento, '[^0-9]', '', 'g') = $3
          THEN n.destinatario_nome ELSE n.emitente_nome END AS nome
      FROM simulacao_notas_fiscais n
      JOIN simulacoes s ON s.id = n.simulacao_id AND s.escritorio_id = n.escritorio_id
      WHERE n.escritorio_id = $1::uuid AND s.cliente_id = $2::uuid AND n.ambiente = 1
        AND ((regexp_replace(n.emitente_documento, '[^0-9]', '', 'g') = $3
          AND (n.modelo IS NULL OR n.tipo_operacao = 1))
          OR (regexp_replace(n.destinatario_documento, '[^0-9]', '', 'g') = $3
            AND n.modelo IN (55, 65) AND n.tipo_operacao = 0))
    ` : `
      SELECT regexp_replace(f.cnpj, '[^0-9]', '', 'g') AS documento, f.razao_social AS nome
      FROM fornecedores f
      WHERE f.escritorio_id = $1::uuid AND f.generico = false AND EXISTS (
        SELECT 1 FROM simulacao_entradas e
        JOIN simulacoes s ON s.id = e.simulacao_id AND s.escritorio_id = e.escritorio_id
        WHERE e.fornecedor_id = f.id AND e.escritorio_id = $1::uuid
          AND s.cliente_id = $2::uuid AND e.tipo IN ('custo', 'custo_direto', 'outra_despesa')
      )`;
    const acervo = usaAcervo ? `
      UNION ALL
      SELECT regexp_replace((CASE WHEN regexp_replace(n.emitente->>'cnpj_cpf', '[^0-9]', '', 'g') = $3
          THEN n.destinatario ELSE n.emitente END)->>'cnpj_cpf', '[^0-9]', '', 'g') AS documento,
        (CASE WHEN regexp_replace(n.emitente->>'cnpj_cpf', '[^0-9]', '', 'g') = $3
          THEN n.destinatario ELSE n.emitente END)->>'razao_social' AS nome
      FROM documentos_fiscais_totais n
      WHERE n.escritorio_id = $1::text AND n.cliente_id = $2::text AND n.carga_concluida = true
        AND n.tipo_documento IN ('nfe', 'nfce', 'nfse')
        AND (n.ambiente IS NULL OR n.ambiente = '1')
        AND CASE WHEN n.proveniencia->>'origem' = 'planilha_fiscal'
          THEN n.movimento_declarado = '${movimento}'
          ELSE (regexp_replace(n.destinatario->>'cnpj_cpf', '[^0-9]', '', 'g') = $3
            AND regexp_replace(n.emitente->>'cnpj_cpf', '[^0-9]', '', 'g') <> $3
            AND (${compradores ? "n.tipo_documento IN ('nfe', 'nfce')" : "n.tipo_documento = 'nfse' OR n.tipo_operacao = '1'"})
            ${compradores ? "AND n.tipo_operacao = '0'" : ""})
            OR (regexp_replace(n.emitente->>'cnpj_cpf', '[^0-9]', '', 'g') = $3
              AND (${compradores ? "n.tipo_documento = 'nfse' OR n.tipo_operacao = '1'" : "n.tipo_documento IN ('nfe', 'nfce') AND n.tipo_operacao = '0'"})) END
    ` : "";
    const items = await manager.query(`WITH vinculados AS (
      ${simulacoes} ${acervo}
    ), identidades AS (
      SELECT documento, max(nome) AS nome FROM vinculados
      WHERE length(documento) IN (11, 14) AND documento <> $3 GROUP BY documento
    ) SELECT f.id, i.documento, ${compradores ? "COALESCE(c.razao_social, f.razao_social, i.nome, i.documento)" : "COALESCE(f.razao_social, i.nome, i.documento)"} AS razao_social,
      ${compradores ? "COALESCE(c.regime_tributario, f.regime_tributario)" : "f.regime_tributario"} AS regime_tributario,
      ${compradores ? "COALESCE(c.uf, f.uf)" : "f.uf"} AS uf,
      ${compradores ? "COALESCE(c.cnae_principal, f.cnae_principal)" : "f.cnae_principal"} AS cnae_principal,
      ${compradores ? "CASE WHEN c.cnae_principal IS NOT NULL THEN c.cnae_principal_descricao ELSE f.cnae_principal_descricao END" : "f.cnae_principal_descricao"} AS cnae_principal_descricao
      FROM identidades i LEFT JOIN fornecedores f
        ON f.escritorio_id = $1::uuid AND f.generico = false
        AND regexp_replace(f.cnpj, '[^0-9]', '', 'g') = i.documento
      ${compradores ? `LEFT JOIN clientes c ON c.escritorio_id = $1::uuid
        AND regexp_replace(c.cnpj, '[^0-9]', '', 'g') = i.documento` : ""}
      ORDER BY razao_social, i.documento`, [escritorioId, clienteId, cliente.cnpj.replace(/\D/g, "")]);
    return { items, fonte: usaAcervo ? "acervo_e_simulacoes" : "simulacoes" };
  });
}
