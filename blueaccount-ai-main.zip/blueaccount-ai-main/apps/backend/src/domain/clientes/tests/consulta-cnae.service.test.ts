import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const cnaeRepo = {
    findOneBy: vi.fn(),
    upsert: vi.fn(),
  };

  const AppDataSource = {
    isInitialized: true,
    initialize: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "CnaeReferencia") return cnaeRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
  };

  const requisitarCnae = vi.fn();

  return { cnaeRepo, AppDataSource, requisitarCnae };
});

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: mocks.AppDataSource,
}));

vi.mock("../../../infrastructure/external-services/ibge-cnae.client.js", async () => {
  const actual = await vi.importActual<typeof import("../../../infrastructure/external-services/ibge-cnae.client.js")>(
    "../../../infrastructure/external-services/ibge-cnae.client.js",
  );
  return {
    ...actual,
    requisitarCnae: mocks.requisitarCnae,
  };
});

const { consultarCnae } = await import("../consulta-cnae.service.js");
const { CnaeNaoEncontradoError, CnaeIndisponivelError } = await import(
  "../../../infrastructure/external-services/ibge-cnae.client.js"
);

function resultadoIbge(codigo = "6204000", descricao = "Consultoria em TI") {
  return {
    codigo,
    descricao,
    classe_codigo: "62040",
    classe_descricao: "Consultoria em tecnologia da informação",
    grupo_codigo: "620",
    grupo_descricao: "Atividades dos serviços de tecnologia da informação",
    divisao_codigo: "62",
    divisao_descricao: "Atividades dos serviços de tecnologia da informação",
    secao_codigo: "J",
    secao_descricao: "Informação e comunicação",
    atividades: ["Consultoria em TI"],
    observacoes: ["Observação da subclasse"],
    observacoes_classe: ["Observação da classe"],
    resposta_ibge: { id: codigo, descricao },
  };
}

describe("domain/clientes/consultarCnae", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("cache hit: devolve o registro cacheado sem chamar o cliente HTTP", async () => {
    mocks.cnaeRepo.findOneBy.mockResolvedValue({
      codigo: "6204000",
      descricao: "Consultoria em TI",
      resposta_ibge: { id: "6204000" },
    });

    const resultado = await consultarCnae("6204000");

    expect(resultado).toEqual({ codigo: "6204000", descricao: "Consultoria em TI" });
    expect(mocks.requisitarCnae).not.toHaveBeenCalled();
    expect(mocks.cnaeRepo.upsert).not.toHaveBeenCalled();
  });

  it("cache miss + encontrado: consulta a fonte, grava no cache e devolve o resultado", async () => {
    mocks.cnaeRepo.findOneBy.mockResolvedValue(null);
    const resultadoIbgeCompleto = resultadoIbge();
    mocks.requisitarCnae.mockResolvedValue(resultadoIbgeCompleto);

    const resultado = await consultarCnae("6204000");

    expect(resultado).toEqual({ codigo: "6204000", descricao: "Consultoria em TI" });
    expect(mocks.requisitarCnae).toHaveBeenCalledWith("6204000");
    expect(mocks.cnaeRepo.upsert).toHaveBeenCalledWith(
      resultadoIbgeCompleto,
      ["codigo"],
    );
  });

  it("cache legado sem snapshot: consulta IBGE uma vez, enriquece e mantém a resposta pública", async () => {
    mocks.cnaeRepo.findOneBy.mockResolvedValue({ codigo: "6204000", descricao: "Consultoria em TI", resposta_ibge: null });
    const resultadoIbgeCompleto = resultadoIbge();
    mocks.requisitarCnae.mockResolvedValue(resultadoIbgeCompleto);

    await expect(consultarCnae("6204000")).resolves.toEqual({ codigo: "6204000", descricao: "Consultoria em TI" });
    expect(mocks.requisitarCnae).toHaveBeenCalledWith("6204000");
    expect(mocks.cnaeRepo.upsert).toHaveBeenCalledWith(resultadoIbgeCompleto, ["codigo"]);
  });

  it("cache miss + não encontrado: devolve null e NÃO grava no cache", async () => {
    mocks.cnaeRepo.findOneBy.mockResolvedValue(null);
    mocks.requisitarCnae.mockRejectedValue(new CnaeNaoEncontradoError("9999999"));

    const resultado = await consultarCnae("9999999");

    expect(resultado).toBeNull();
    expect(mocks.cnaeRepo.upsert).not.toHaveBeenCalled();
  });

  it("cache miss + indisponibilidade: relança o erro (não vira null)", async () => {
    mocks.cnaeRepo.findOneBy.mockResolvedValue(null);
    mocks.requisitarCnae.mockRejectedValue(new CnaeIndisponivelError("timeout"));

    await expect(consultarCnae("6204000")).rejects.toBeInstanceOf(CnaeIndisponivelError);
    expect(mocks.cnaeRepo.upsert).not.toHaveBeenCalled();
  });

  it("entrada malformada/vazia/sem dígitos: devolve null sem tocar rede nem banco", async () => {
    await expect(consultarCnae("")).resolves.toBeNull();
    await expect(consultarCnae(null)).resolves.toBeNull();
    await expect(consultarCnae("abc")).resolves.toBeNull();

    expect(mocks.AppDataSource.getRepository).not.toHaveBeenCalled();
    expect(mocks.requisitarCnae).not.toHaveBeenCalled();
  });
});
