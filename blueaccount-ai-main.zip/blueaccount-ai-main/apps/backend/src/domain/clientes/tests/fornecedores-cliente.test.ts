import { DatabaseSync } from "node:sqlite";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ run: vi.fn(), find: vi.fn(), settings: { NOTAS_FISCAIS_FONTE: "postgres" } }));
vi.mock("../../../database/data-source.js", () => ({ runQueryWithRls: mocks.run }));
vi.mock("../../../database/modules/tenant/entities/cliente.entity.js", () => ({ Cliente: class {} }));
vi.mock("../../../settings.js", () => ({ settings: mocks.settings }));
import { listarFornecedoresCliente, listarCompradoresCliente } from "../fornecedores-cliente.js";
let banco: DatabaseSync;
beforeEach(() => {
  banco = new DatabaseSync(":memory:");
  banco.function("regexp_replace", (v, p, r, _flags) => v == null ? null : String(v).replace(new RegExp(String(p), "g"), String(r)));
  banco.exec(`CREATE TABLE fornecedores (id TEXT, escritorio_id TEXT, cnpj TEXT, razao_social TEXT, generico INTEGER, regime_tributario TEXT, uf TEXT, cnae_principal TEXT, cnae_principal_descricao TEXT);
    CREATE TABLE clientes (escritorio_id TEXT, cnpj TEXT, razao_social TEXT, regime_tributario TEXT, uf TEXT, cnae_principal TEXT, cnae_principal_descricao TEXT);
    CREATE TABLE simulacao_notas_fiscais (simulacao_id TEXT, escritorio_id TEXT, emitente_documento TEXT, destinatario_documento TEXT, emitente_nome TEXT, destinatario_nome TEXT, ambiente INTEGER, modelo INTEGER, tipo_operacao INTEGER);
    CREATE TABLE simulacoes (id TEXT, escritorio_id TEXT, cliente_id TEXT);
    CREATE TABLE simulacao_entradas (simulacao_id TEXT, escritorio_id TEXT, fornecedor_id TEXT, tipo TEXT);
    CREATE TABLE documentos_fiscais_totais (escritorio_id TEXT, cliente_id TEXT, carga_concluida INTEGER, tipo_documento TEXT, ambiente TEXT, emitente TEXT, destinatario TEXT, tipo_operacao TEXT, proveniencia TEXT, movimento_declarado TEXT);
    INSERT INTO fornecedores VALUES ('f','office','22.222.222/0001-22','Fornecedor',0,'Simples Nacional','SP',NULL,NULL),
      ('outro','other','22222222000122','Outro escritório',0,'Lucro Real','RJ',NULL,NULL),
      ('generico','office',NULL,'Genérico',1,'MEI',NULL,NULL,NULL),
      ('receita','office','33333333000133','Comprador',0,'Lucro Real','MG',NULL,NULL),
      ('comprador','office','88888888000188','Comprador cadastrado como fornecedor',0,'Lucro Real','BA',NULL,NULL);
    INSERT INTO simulacoes VALUES ('s','office','client'),('copia','office','client'),('outro','office','other-client');
    INSERT INTO simulacao_entradas VALUES ('s','office','f','custo'),('copia','office','f','custo_direto'),
      ('s','office','generico','custo'),('s','office','receita','receita'),('outro','office','receita','custo');`);
  mocks.settings.NOTAS_FISCAIS_FONTE = "postgres";
  mocks.find.mockResolvedValue({ id: "client", cnpj: "11111111000111" });
  mocks.run.mockImplementation(async (_contexto, cb) => cb({ getRepository: () => ({ findOne: mocks.find }),
    query: async (sql: string, params: string[]) => banco.prepare(sql.replace(/::(?:uuid|text)/g, "")).all({ $1: params[0], $2: params[1], $3: params[2] }),
  }));
});
afterEach(() => banco.close());
function nota(documento: string, extra: { cliente?: string; movimento?: string; origem?: string; operacao?: string; ambiente?: string; destino?: string } = {}) {
  banco.prepare("INSERT INTO documentos_fiscais_totais VALUES (?,?,?,?,?,?,?,?,?,?)").run("office", extra.cliente ?? "client", 1, "nfe", extra.ambiente ?? "1", JSON.stringify({ cnpj_cpf: documento, razao_social: documento }), JSON.stringify({ cnpj_cpf: extra.destino ?? "11111111000111" }), extra.operacao ?? "1", JSON.stringify({ origem: extra.origem ?? "xml" }), extra.movimento ?? null);
}
describe("fornecedores do cliente", () => {
  it("deduplica cenários e acervo, preserva desconhecidos e isola cliente/escritório", async () => {
    nota("22222222000122"); nota("44444444000144"); nota("55555555000155", { cliente: "other-client" });
    nota("66666666000166", { ambiente: "2" }); nota("77777777000177", { operacao: "0" });
    const resultado = await listarFornecedoresCliente("office", "client");
    expect(resultado?.items).toHaveLength(2);
    expect(resultado?.items).toEqual(expect.arrayContaining([
      expect.objectContaining({ documento: "22222222000122", regime_tributario: "Simples Nacional", uf: "SP" }),
      expect.objectContaining({ documento: "44444444000144", regime_tributario: null, uf: null }),
    ]));
    expect(mocks.run).toHaveBeenCalledWith({ escritorio_id: "office" }, expect.any(Function));
    expect(mocks.find).toHaveBeenCalledWith(expect.objectContaining({ where: { id: "client", escritorio_id: "office" } }));
  });
  it("respeita movimento declarado da planilha e não inventa movimento", async () => {
    nota("44444444000144", { origem: "planilha_fiscal", movimento: "saida" });
    nota("55555555000155", { origem: "planilha_fiscal" });
    nota("66666666000166", { origem: "planilha_fiscal", movimento: "entrada", destino: "" });
    const resultado = await listarFornecedoresCliente("office", "client");
    expect(resultado?.items.map((i: { documento: string }) => i.documento).sort()).toEqual(["22222222000122", "66666666000166"]);
  });
  it("identifica contraparte de nota própria de entrada sem contar o cliente", async () => {
    nota("11111111000111", { operacao: "0", destino: "88888888000188" });
    nota("11111111000111", { operacao: "1", destino: "99999999000199" });
    const resultado = await listarFornecedoresCliente("office", "client");
    expect(resultado?.items.map((i: { documento: string }) => i.documento).sort()).toEqual(["22222222000122", "88888888000188"]);
  });
  it("informa cobertura restrita a simulações em Athena", async () => {
    mocks.settings.NOTAS_FISCAIS_FONTE = "athena"; nota("44444444000144");
    const resultado = await listarFornecedoresCliente("office", "client");
    expect(resultado?.fonte).toBe("simulacoes"); expect(resultado?.items).toHaveLength(1);
  });
  it("não consulta fornecedores de cliente inacessível", async () => {
    mocks.find.mockResolvedValue(null);
    expect(await listarFornecedoresCliente("office", "missing")).toBeNull();
  });
});

describe("clientes compradores", () => {
  it("separa vendas de compras, deduplica cenários/acervo e usa o cadastro do comprador", async () => {
    banco.exec(`INSERT INTO clientes VALUES ('office','88888888000188','Cliente comprador','Lucro Presumido','PR','1234567','Atividade'),
      ('other','99999999000199','Outro escritório','Lucro Real','RS',NULL,NULL);
      INSERT INTO simulacao_notas_fiscais VALUES
      ('s','office','11111111000111','88888888000188','Empresa','Comprador',1,55,1),
      ('copia','office','11111111000111','88888888000188','Empresa','Comprador',1,55,1),
      ('outro','office','11111111000111','77777777000177','Empresa','Outro cliente',1,55,1),
      ('s','other','11111111000111','66666666000166','Empresa','Outro escritório',1,55,1),
      ('s','office','11111111000111','55555555000155','Empresa','Homologação',2,55,1);
    `);
    nota("11111111000111", { destino: "88888888000188" });
    nota("11111111000111", { destino: "99999999000199" });
    nota("22222222000122"); // Compra da empresa, não cliente comprador.
    const resultado = await listarCompradoresCliente("office", "client");
    expect(resultado?.items).toHaveLength(2);
    expect(resultado?.items).toEqual(expect.arrayContaining([
      expect.objectContaining({ documento: "88888888000188", regime_tributario: "Lucro Presumido", uf: "PR", cnae_principal: "1234567" }),
      expect.objectContaining({ documento: "99999999000199", regime_tributario: null, uf: null }),
    ]));
  });
  it("respeita saídas declaradas, exclui consumidor sem documento e reconhece nota de entrada do comprador", async () => {
    nota("44444444000144", { origem: "planilha_fiscal", movimento: "saida", destino: "" });
    nota("55555555000155", { origem: "planilha_fiscal", movimento: "entrada", destino: "" });
    nota("66666666000166", { operacao: "0" });
    nota("11111111000111", { destino: "" });
    const resultado = await listarCompradoresCliente("office", "client");
    expect(resultado?.items.map((i: { documento: string }) => i.documento).sort()).toEqual(["44444444000144", "66666666000166"]);
  });
  it("preserva CPF sem inventar regime e funciona somente com notas de simulações", async () => {
    mocks.settings.NOTAS_FISCAIS_FONTE = "athena";
    banco.exec(`INSERT INTO simulacao_notas_fiscais VALUES ('s','office','11111111000111','12345678901','Empresa','Pessoa',1,NULL,1);`);
    const resultado = await listarCompradoresCliente("office", "client");
    expect(resultado?.fonte).toBe("simulacoes");
    expect(resultado?.items).toEqual([expect.objectContaining({ documento: "12345678901", regime_tributario: null })]);
  });
});
