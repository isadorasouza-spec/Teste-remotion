import { describe, expect, it } from "vitest";
import {
  permiteCreditoPorCnaeFornecedor,
  permiteCreditoPorNcm,
  resolverPerfilFiscalCliente,
} from "../regime-credito.js";

const base = {
  regime_tributario: null as string | null,
  opcao_ibs_cbs: null as "regime_unico" | "regime_regular" | null,
};

describe("resolverPerfilFiscalCliente", () => {
  it("Lucro Real e Lucro Presumido geram perfil integral e ignoram opcao_ibs_cbs", () => {
    for (const regime of ["Lucro Real", "Lucro Presumido"]) {
      const resultado = resolverPerfilFiscalCliente({
        ...base,
        regime_tributario: regime,
        opcao_ibs_cbs: "regime_unico",
      });
      expect(resultado.perfil).toBe("integral");
    }
  });

  it("Simples Nacional com opção híbrida gera perfil integral e cita o art. 41", () => {
    const resultado = resolverPerfilFiscalCliente({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_regular",
    });
    expect(resultado.perfil).toBe("integral");
    expect(resultado.justificativa).toContain("art. 41");
  });

  it("Simples Nacional em regime único não apropria crédito próprio e cita o art. 47", () => {
    const resultado = resolverPerfilFiscalCliente({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_unico",
    });
    expect(resultado.perfil).toBe("sem_credito");
    expect(resultado.justificativa).toContain("art. 47");
  });

  it("Simples Nacional sem opcao_ibs_cbs informada assume regime único sem crédito", () => {
    const resultado = resolverPerfilFiscalCliente({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: null,
    });
    expect(resultado.perfil).toBe("sem_credito");
  });

  it("MEI é sem_credito para cliente — diverge do fornecedor (que cai em presumido)", () => {
    expect(
      resolverPerfilFiscalCliente({ ...base, regime_tributario: "MEI", opcao_ibs_cbs: "regime_regular" })
        .perfil,
    ).toBe("sem_credito");

    expect(
      resolverPerfilFiscalCliente({ ...base, regime_tributario: "MEI", opcao_ibs_cbs: "regime_unico" })
        .perfil,
    ).toBe("sem_credito");

    expect(resolverPerfilFiscalCliente({ ...base, regime_tributario: "MEI" }).perfil).toBe("sem_credito");
  });

  it("Pessoa Física é sem_credito para cliente, igual ao fornecedor", () => {
    const resultado = resolverPerfilFiscalCliente({
      ...base,
      regime_tributario: "Pessoa Física",
      opcao_ibs_cbs: "regime_regular",
    });
    expect(resultado.perfil).toBe("sem_credito");
    expect(resultado.justificativa).toContain("não contribuinte");
  });

  it("regime não informado devolve integral, preservando o comportamento histórico", () => {
    expect(resolverPerfilFiscalCliente(base).perfil).toBe("integral");
    expect(resolverPerfilFiscalCliente({ ...base, regime_tributario: "   " }).perfil).toBe("integral");
  });

});

describe("permiteCreditoPorCnaeFornecedor", () => {
  it("lista null: sem restrição cadastrada, sempre elegível", () => {
    expect(permiteCreditoPorCnaeFornecedor(null, "6201500")).toBe(true);
    expect(permiteCreditoPorCnaeFornecedor(null, null)).toBe(true);
  });

  it("lista vazia: sem restrição cadastrada, sempre elegível", () => {
    expect(permiteCreditoPorCnaeFornecedor([], "6201500")).toBe(true);
  });

  it("código do fornecedor bate com a allowlist: elegível", () => {
    const permitidos = [{ codigo: "6201500", descricao: "Desenvolvimento de programas" }];
    expect(permiteCreditoPorCnaeFornecedor(permitidos, "6201500")).toBe(true);
  });

  it("código do fornecedor não bate com a allowlist: não elegível", () => {
    const permitidos = [{ codigo: "6201500", descricao: "Desenvolvimento de programas" }];
    expect(permiteCreditoPorCnaeFornecedor(permitidos, "4711301")).toBe(false);
  });

  it("CNAE do fornecedor nulo com allowlist não vazia: não elegível", () => {
    const permitidos = [{ codigo: "6201500", descricao: "Desenvolvimento de programas" }];
    expect(permiteCreditoPorCnaeFornecedor(permitidos, null)).toBe(false);
  });
});

describe("permiteCreditoPorNcm", () => {
  it("lista null: sem restrição cadastrada, sempre elegível", () => {
    expect(permiteCreditoPorNcm(null, "12019000")).toBe(true);
    expect(permiteCreditoPorNcm(null, null)).toBe(true);
  });

  it("lista vazia: sem restrição cadastrada, sempre elegível", () => {
    expect(permiteCreditoPorNcm([], "12019000")).toBe(true);
  });

  it("NCM da linha ausente com allowlist não vazia: não elegível", () => {
    const permitidos = [{ codigo: "12019000", descricao: "Soja" }];
    expect(permiteCreditoPorNcm(permitidos, null)).toBe(false);
  });

  it("NCM da linha bate com a allowlist: elegível", () => {
    const permitidos = [{ codigo: "12019000", descricao: "Soja" }];
    expect(permiteCreditoPorNcm(permitidos, "12019000")).toBe(true);
  });

  it("NCM da linha não bate com a allowlist: não elegível", () => {
    const permitidos = [{ codigo: "12019000", descricao: "Soja" }];
    expect(permiteCreditoPorNcm(permitidos, "10019900")).toBe(false);
  });

  it("normaliza dígitos e preenche até 8 posições antes de comparar (defensivo — ncmOuNulo já entrega 8 dígitos)", () => {
    const permitidos = [{ codigo: "00019000", descricao: "Código com zeros à esquerda" }];
    expect(permiteCreditoPorNcm(permitidos, "19000")).toBe(true);
    expect(permiteCreditoPorNcm(permitidos, "19019000")).toBe(false);
  });
});
