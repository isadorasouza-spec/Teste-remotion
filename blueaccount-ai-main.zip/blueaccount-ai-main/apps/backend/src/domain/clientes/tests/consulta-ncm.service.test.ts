import { Logger } from "@nestjs/common";
import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => {
  const consulta: any = {};
  for (const nome of ["where", "andWhere", "orderBy", "skip", "take"]) consulta[nome] = vi.fn(() => consulta);
  consulta.getManyAndCount = vi.fn();
  const repo = { findOneBy: vi.fn(), findBy: vi.fn(), createQueryBuilder: vi.fn(() => consulta), save: vi.fn(), upsert: vi.fn() };
  const query = vi.fn();
  return { repo, consulta, query };
});
vi.mock("../../../database/data-source.js", () => ({ AppDataSource: { isInitialized: true, getRepository: () => mocks.repo, query: mocks.query } }));
import { consultarNcm, listarNcmsReferencia, resolverFatoresPorNcm, resolverFatoresPorNcms } from "../consulta-ncm.service.js";
const registro = { codigo: "07141000", descricao: "Mandioca", fator_ibs: 0, fator_cbs: 0, aplicacao_automatica: true, situacao_revisao: "automatica", motivos_revisao: [], evidencias_revisao: [] };
describe("catálogo NCM local", () => {
  beforeEach(() => { vi.clearAllMocks(); mocks.repo.findBy.mockResolvedValue([]); mocks.query.mockResolvedValue([{ versao: "ncm-20260916-v2" }]); vi.stubGlobal("fetch", vi.fn(() => { throw new Error("Rede proibida"); })); });
  it("consulta exata normalizada preserva zeros sem rede nem escrita", async () => {
    mocks.repo.findOneBy.mockResolvedValue(registro);
    expect(await consultarNcm("0714.10.00")).toMatchObject({ codigo: "07141000", descricao: "Mandioca", descricoes_hierarquia: [], fator_ibs_automatico: 0 });
    expect(mocks.repo.findOneBy).toHaveBeenCalledWith({ codigo: "07141000", versao_catalogo: "ncm-20260916-v2" });
    expect(fetch).not.toHaveBeenCalled(); expect(mocks.repo.save).not.toHaveBeenCalled(); expect(mocks.repo.upsert).not.toHaveBeenCalled();
  });
  it("não resolve prefixos e marca código ausente como provisório", async () => {
    expect(await resolverFatoresPorNcm("0714")).toBeNull();
    expect(await resolverFatoresPorNcm("99999999")).toMatchObject({ codigo_regra: null, catalogado: false, fator_ibs_automatico: 1, requer_confirmacao: true, situacao_revisao: "fora_catalogo" });
    expect(fetch).not.toHaveBeenCalled();
  });
  it("deduplica lote e mantém sugestão distinta do fator automático condicionado", async () => {
    mocks.repo.findBy.mockResolvedValue([{ ...registro, fator_ibs: 0.4, fator_cbs: 0.4, aplicacao_automatica: false, situacao_revisao: "condicional", motivos_revisao: ["medicamento_requer_confirmacao"] }]);
    const resultado = await resolverFatoresPorNcms(["07141000", "0714.10.00", null, "07141000"]);
    expect(resultado.size).toBe(1); expect(mocks.repo.findBy).toHaveBeenCalledTimes(1);
    expect(resultado.get("07141000")).toMatchObject({ fator_ibs_sugerido: 0.4, fator_ibs_automatico: 1, requer_confirmacao: true });
  });
  it("combina filtros antes da paginação sem consultas por linha", async () => {
    mocks.consulta.getManyAndCount.mockResolvedValue([[registro], 26]);
    const resultado = await listarNcmsReferencia({ busca: "0714.10", categoria: "Alimentos", fator: "0", situacao: "automatica", pagina: 2 });
    expect(resultado).toMatchObject({ total: 26, total_paginas: 2, catalogo: { total: 10938 } });
    expect(mocks.consulta.andWhere).toHaveBeenCalledWith("ncm.codigo LIKE :busca", { busca: "071410%" });
    expect(mocks.consulta.andWhere).toHaveBeenCalledWith("ncm.fator_ibs = :fator", { fator: 0 });
    expect(mocks.consulta.skip).toHaveBeenCalledWith(25); expect(mocks.repo.findBy).not.toHaveBeenCalled();
  });
  it("rejeita filtros inválidos", async () => {
    await expect(listarNcmsReferencia({ fator: "60" })).rejects.toThrow();
    await expect(listarNcmsReferencia({ situacao: "desconhecida" })).rejects.toThrow();
  });
  // Sem este alarme, subir o código antes da migration resolve todo NCM como fora_catalogo em silêncio.
  it("registra erro uma única vez quando a versão do bundle não está publicada", async () => {
    vi.resetModules();
    const erros: string[] = [];
    const spy = vi.spyOn(Logger.prototype, "error").mockImplementation((mensagem: unknown) => { erros.push(String(mensagem)); });
    mocks.query.mockResolvedValue([{ versao: "ncm-20260916-v1" }]);
    mocks.repo.findBy.mockResolvedValue([]);
    const { resolverFatoresPorNcms: resolver } = await import("../consulta-ncm.service.js");
    expect((await resolver(["07141000"])).get("07141000")).toMatchObject({ catalogado: false, situacao_revisao: "fora_catalogo" });
    await resolver(["96190000"]);
    expect(mocks.query).toHaveBeenCalledTimes(1);
    expect(erros).toHaveLength(1);
    expect(erros[0]).toContain("ncm-20260916-v2");
    spy.mockRestore();
  });
});
