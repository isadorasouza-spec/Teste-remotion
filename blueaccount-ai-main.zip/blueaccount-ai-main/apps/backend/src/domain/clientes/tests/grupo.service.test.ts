import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  ehMatrizMascarada,
  getGrupoDoCliente,
  listarMembrosComContratoAtivo,
  prefixoMascaradoDaRaiz,
  raizCnpjMascarado,
  resolverAlvoConsolidacao,
  resolverClientePagador,
  resolverModoGrupo,
  sincronizarGrupoEconomicoPorCnpj,
  validarAssociacaoHolding,
  validarAtivacaoContrato,
  GrupoEconomicoError,
} from "../grupo.service.js";

const ESCRITORIO = "office-1";
const HOLDING = { id: "hold-1", escritorio_id: ESCRITORIO, cnpj: "111", razao_social: "Holding", holding_id: null, pagador_grupo: null } as any;
const MEMBRO = { id: "memb-1", escritorio_id: ESCRITORIO, cnpj: "222", razao_social: "Filial", holding_id: "hold-1", pagador_grupo: null } as any;
const ISOLADO = { id: "iso-1", escritorio_id: ESCRITORIO, cnpj: "333", razao_social: "Isolado", holding_id: null, pagador_grupo: null } as any;

const clienteRepo = { find: vi.fn(), findOne: vi.fn(), update: vi.fn() };
const contratoRepo = { find: vi.fn(), findOne: vi.fn() };

const manager = {
  getRepository: vi.fn((entity: { name?: string }) => {
    if (entity?.name === "Cliente") return clienteRepo;
    if (entity?.name === "Contrato") return contratoRepo;
    throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
  }),
} as any;

beforeEach(() => {
  vi.clearAllMocks();
});

describe("getGrupoDoCliente", () => {
  it("identifica cliente isolado (sem holding e sem membros)", async () => {
    clienteRepo.findOne.mockResolvedValue(ISOLADO);
    clienteRepo.find.mockResolvedValue([]);

    const grupo = await getGrupoDoCliente(manager, ESCRITORIO, ISOLADO.id);
    expect(grupo).toEqual({ papel: "isolado", holding: null, membros: [] });
  });

  it("identifica membro e devolve holding + membros do grupo", async () => {
    clienteRepo.findOne.mockResolvedValueOnce(MEMBRO).mockResolvedValueOnce(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]);

    const grupo = await getGrupoDoCliente(manager, ESCRITORIO, MEMBRO.id);
    expect(grupo.papel).toBe("membro");
    expect(grupo.holding).toEqual(HOLDING);
    expect(grupo.membros).toEqual([MEMBRO]);
  });

  it("identifica holding pelos membros que apontam para ela", async () => {
    clienteRepo.findOne.mockResolvedValue(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]);

    const grupo = await getGrupoDoCliente(manager, ESCRITORIO, HOLDING.id);
    expect(grupo.papel).toBe("holding");
    expect(grupo.holding).toEqual(HOLDING);
  });
});

describe("resolverModoGrupo", () => {
  it("contrato ativo na holding → consolidado", async () => {
    contratoRepo.findOne.mockResolvedValueOnce({ id: "c-1", contrato_ativo: true });
    expect(await resolverModoGrupo(manager, ESCRITORIO, HOLDING.id, [MEMBRO])).toBe("consolidado");
  });

  it("contrato ativo em membro (holding sem contrato) → por_empresa", async () => {
    contratoRepo.findOne.mockResolvedValueOnce(null).mockResolvedValueOnce({ id: "c-2", contrato_ativo: true });
    expect(await resolverModoGrupo(manager, ESCRITORIO, HOLDING.id, [MEMBRO])).toBe("por_empresa");
  });

  it("nenhum contrato ativo → sem_contrato", async () => {
    contratoRepo.findOne.mockResolvedValue(null);
    expect(await resolverModoGrupo(manager, ESCRITORIO, HOLDING.id, [MEMBRO])).toBe("sem_contrato");
  });
});

describe("resolverAlvoConsolidacao", () => {
  it("cliente isolado mantém o próprio alvo", async () => {
    clienteRepo.findOne.mockResolvedValue(ISOLADO);
    clienteRepo.find.mockResolvedValue([]);

    const alvo = await resolverAlvoConsolidacao(manager, ESCRITORIO, ISOLADO.id);
    expect(alvo).toEqual({ clienteIdAlvo: ISOLADO.id, redirecionado: false, grupoConsolidado: false });
  });

  it("membro sem contrato próprio em grupo consolidado redireciona para a holding", async () => {
    clienteRepo.findOne.mockResolvedValueOnce(MEMBRO).mockResolvedValueOnce(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]);
    // 1ª chamada: contrato da holding (modo); 2ª: contrato próprio do membro (não tem)
    contratoRepo.findOne.mockResolvedValueOnce({ id: "c-1", contrato_ativo: true }).mockResolvedValueOnce(null);

    const alvo = await resolverAlvoConsolidacao(manager, ESCRITORIO, MEMBRO.id);
    expect(alvo).toEqual({ clienteIdAlvo: HOLDING.id, redirecionado: true, grupoConsolidado: true });
  });

  it("filha com contrato próprio em grupo consolidado consolida o próprio VAC e sinaliza refresh da holding", async () => {
    clienteRepo.findOne.mockResolvedValueOnce(MEMBRO).mockResolvedValueOnce(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]);
    // 1ª chamada: contrato da holding (modo consolidado); 2ª: contrato próprio da filha
    contratoRepo.findOne
      .mockResolvedValueOnce({ id: "c-h", contrato_ativo: true })
      .mockResolvedValueOnce({ id: "c-f", contrato_ativo: true });

    const alvo = await resolverAlvoConsolidacao(manager, ESCRITORIO, MEMBRO.id);
    expect(alvo).toEqual({
      clienteIdAlvo: MEMBRO.id,
      redirecionado: false,
      grupoConsolidado: false,
      holdingParaRefresh: HOLDING.id,
    });
  });

  it("membro de grupo por_empresa mantém o próprio alvo", async () => {
    clienteRepo.findOne.mockResolvedValueOnce(MEMBRO).mockResolvedValueOnce(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]);
    contratoRepo.findOne.mockResolvedValueOnce(null).mockResolvedValueOnce({ id: "c-2", contrato_ativo: true });

    const alvo = await resolverAlvoConsolidacao(manager, ESCRITORIO, MEMBRO.id);
    expect(alvo).toEqual({ clienteIdAlvo: MEMBRO.id, redirecionado: false, grupoConsolidado: false });
  });
});

describe("listarMembrosComContratoAtivo", () => {
  it("retorna apenas membros com contrato ativo, pareados com o contrato", async () => {
    const outroMembro = { ...MEMBRO, id: "memb-2", cnpj: "444" };
    const contratoDoMembro = { id: "c-f", cliente_id: MEMBRO.id, contrato_ativo: true };
    contratoRepo.find.mockResolvedValue([contratoDoMembro]);

    const result = await listarMembrosComContratoAtivo(manager, ESCRITORIO, [MEMBRO, outroMembro]);
    expect(result).toEqual([{ cliente: MEMBRO, contrato: contratoDoMembro }]);
  });

  it("retorna vazio sem membros", async () => {
    expect(await listarMembrosComContratoAtivo(manager, ESCRITORIO, [])).toEqual([]);
    expect(contratoRepo.find).not.toHaveBeenCalled();
  });
});

describe("validarAssociacaoHolding", () => {
  it("rejeita auto-referência", async () => {
    await expect(validarAssociacaoHolding(manager, ESCRITORIO, "x", "x")).rejects.toThrow(GrupoEconomicoError);
  });

  it("rejeita holding que já é membro de outro grupo (um nível)", async () => {
    clienteRepo.findOne.mockResolvedValue({ ...HOLDING, holding_id: "outra-holding" });
    await expect(validarAssociacaoHolding(manager, ESCRITORIO, ISOLADO.id, HOLDING.id)).rejects.toThrow(/um nível/i);
  });

  it("rejeita cliente que já é holding de outras empresas", async () => {
    clienteRepo.findOne.mockResolvedValue(HOLDING);
    clienteRepo.find.mockResolvedValue([MEMBRO]); // o cliente tem membros próprios
    await expect(validarAssociacaoHolding(manager, ESCRITORIO, "outra-holding", HOLDING.id)).rejects.toThrow(/holding de outras empresas/i);
  });

  it("aceita associação com contrato ativo no cliente E na holding (modo híbrido)", async () => {
    clienteRepo.findOne.mockResolvedValue(HOLDING);
    clienteRepo.find.mockResolvedValue([]);
    contratoRepo.findOne.mockResolvedValue({ id: "c", contrato_ativo: true });
    await expect(validarAssociacaoHolding(manager, ESCRITORIO, ISOLADO.id, HOLDING.id)).resolves.toBeUndefined();
  });

  it("aceita associação válida", async () => {
    clienteRepo.findOne.mockResolvedValue(HOLDING);
    clienteRepo.find.mockResolvedValue([]);
    contratoRepo.findOne.mockResolvedValue(null);
    await expect(validarAssociacaoHolding(manager, ESCRITORIO, ISOLADO.id, HOLDING.id)).resolves.toBeUndefined();
  });
});

describe("validarAtivacaoContrato", () => {
  it("permite ativação para cliente isolado", async () => {
    await expect(validarAtivacaoContrato(manager, ESCRITORIO, ISOLADO.id)).resolves.toBeUndefined();
  });

  it("permite contrato na holding mesmo com membro contratado (modo híbrido)", async () => {
    await expect(validarAtivacaoContrato(manager, ESCRITORIO, HOLDING.id)).resolves.toBeUndefined();
  });

  it("permite contrato em membro mesmo com a holding contratada (modo híbrido)", async () => {
    await expect(validarAtivacaoContrato(manager, ESCRITORIO, MEMBRO.id)).resolves.toBeUndefined();
  });
});

describe("resolverClientePagador", () => {
  it("cliente sem holding paga as próprias cobranças", async () => {
    expect(await resolverClientePagador(manager, ESCRITORIO, ISOLADO)).toBe(ISOLADO);
  });

  it("filha de grupo sempre paga na holding (pagador_grupo deprecado é ignorado)", async () => {
    const holdingPagadora = { ...HOLDING, pagador_grupo: "empresa" };
    clienteRepo.findOne.mockResolvedValue(holdingPagadora);
    expect(await resolverClientePagador(manager, ESCRITORIO, MEMBRO)).toEqual(holdingPagadora);
  });

  it("filha cuja holding não existe paga as próprias cobranças (defensivo)", async () => {
    clienteRepo.findOne.mockResolvedValue(null);
    expect(await resolverClientePagador(manager, ESCRITORIO, MEMBRO)).toBe(MEMBRO);
  });
});

describe("raizCnpjMascarado", () => {
  it("extrai a raiz de 8 dígitos de um CNPJ mascarado", () => {
    expect(raizCnpjMascarado("11.222.333/0001-81")).toBe("11222333");
    expect(raizCnpjMascarado("11.222.333/0002-62")).toBe("11222333");
  });

  it("devolve null para CPF (não tem raiz de empresa)", () => {
    expect(raizCnpjMascarado("111.222.333-96")).toBeNull();
  });
});

describe("ehMatrizMascarada", () => {
  it("identifica sufixo 0001 como matriz", () => {
    expect(ehMatrizMascarada("11.222.333/0001-81")).toBe(true);
  });

  it("sufixo diferente de 0001 não é matriz", () => {
    expect(ehMatrizMascarada("11.222.333/0002-62")).toBe(false);
  });

  it("CPF nunca é matriz", () => {
    expect(ehMatrizMascarada("111.222.333-96")).toBe(false);
  });
});

describe("prefixoMascaradoDaRaiz", () => {
  it("reconstrói o prefixo mascarado a partir da raiz", () => {
    expect(prefixoMascaradoDaRaiz("11222333")).toBe("11.222.333/");
  });
});

describe("sincronizarGrupoEconomicoPorCnpj", () => {
  it("cliente novo é filial e encontra a matriz já cadastrada: associa e atualiza o objeto em memória", async () => {
    const filial = { id: "filial-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0002-62", holding_id: null } as any;
    const matriz = { id: "matriz-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0001-81", holding_id: null } as any;
    // 1ª chamada: busca da matriz (dentro do sync); 2ª e 3ª: validarAssociacaoHolding
    // (holding existe? / membros do próprio filial)
    clienteRepo.findOne.mockResolvedValueOnce(matriz).mockResolvedValueOnce(matriz);
    clienteRepo.find.mockResolvedValue([]);

    await sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, filial);

    expect(clienteRepo.update).toHaveBeenCalledWith(
      { id: "filial-1", escritorio_id: ESCRITORIO },
      { holding_id: "matriz-1" },
    );
    expect(filial.holding_id).toBe("matriz-1");
  });

  it("cliente novo é filial e não há matriz cadastrada: no-op", async () => {
    const filial = { id: "filial-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0002-62", holding_id: null } as any;
    clienteRepo.findOne.mockResolvedValue(null);

    await sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, filial);

    expect(clienteRepo.update).not.toHaveBeenCalled();
    expect(filial.holding_id).toBeNull();
  });

  it("cliente filial já associado manualmente não dispara busca automática", async () => {
    const filial = { id: "filial-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0002-62", holding_id: "outra-holding" } as any;

    await sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, filial);

    expect(clienteRepo.findOne).not.toHaveBeenCalled();
    expect(clienteRepo.update).not.toHaveBeenCalled();
  });

  it("cliente novo é matriz e associa filiais pré-cadastradas sem grupo", async () => {
    const novaMatriz = { id: "matriz-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0001-81", holding_id: null } as any;
    const filialA = { id: "filial-a", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0002-62", holding_id: null };
    const filialB = { id: "filial-b", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0003-43", holding_id: null };
    clienteRepo.find
      .mockResolvedValueOnce([filialA, filialB]) // busca de candidatas
      .mockResolvedValueOnce([]) // validarAssociacaoHolding: filialA sem membros próprios
      .mockResolvedValueOnce([]); // validarAssociacaoHolding: filialB sem membros próprios
    // validarAssociacaoHolding, para cada filial: holding existe (a própria matriz)
    clienteRepo.findOne.mockResolvedValue(novaMatriz);

    await sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, novaMatriz);

    expect(clienteRepo.update).toHaveBeenCalledWith({ id: "filial-a", escritorio_id: ESCRITORIO }, { holding_id: "matriz-1" });
    expect(clienteRepo.update).toHaveBeenCalledWith({ id: "filial-b", escritorio_id: ESCRITORIO }, { holding_id: "matriz-1" });
  });

  it("matriz nova pula candidata inválida (já é holding de outras empresas) sem lançar", async () => {
    const novaMatriz = { id: "matriz-1", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0001-81", holding_id: null } as any;
    const filialJaHolding = { id: "filial-a", escritorio_id: ESCRITORIO, cnpj: "11.222.333/0002-62", holding_id: null };
    clienteRepo.find
      .mockResolvedValueOnce([filialJaHolding]) // candidatas
      .mockResolvedValueOnce([{ id: "neta-1" }]); // validarAssociacaoHolding: filialJaHolding já tem membros próprios
    clienteRepo.findOne.mockResolvedValue(novaMatriz);

    await expect(sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, novaMatriz)).resolves.toBeUndefined();
    expect(clienteRepo.update).not.toHaveBeenCalled();
  });

  it("CPF nunca participa de grupo econômico (no-op sem consultar o banco)", async () => {
    const clientePf = { id: "pf-1", escritorio_id: ESCRITORIO, cnpj: "111.222.333-96", holding_id: null } as any;

    await sincronizarGrupoEconomicoPorCnpj(manager, ESCRITORIO, clientePf);

    expect(clienteRepo.find).not.toHaveBeenCalled();
    expect(clienteRepo.findOne).not.toHaveBeenCalled();
    expect(clienteRepo.update).not.toHaveBeenCalled();
  });
});
