import { beforeEach, describe, expect, it, vi } from "vitest";

const clientesMocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();
  const runQueryWithRls = vi.fn();

  // `insertCliente` é o `execute()` do INSERT ... ON CONFLICT DO NOTHING que
  // `findOrCreateClienteByCnpj` usa: o teste controla se a corrida foi ganha
  // (raw com a linha) ou perdida (raw vazio).
  const insertCliente = vi.fn();
  const clienteRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
    save: vi.fn(),
    update: vi.fn(),
    createQueryBuilder: () => ({
      insert: () => ({
        values: (valores: Record<string, unknown>) => ({
          orIgnore: () => ({
            returning: () => ({ execute: () => insertCliente(valores) }),
          }),
        }),
      }),
    }),
  };
  const contratoRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
  };
  const relatorioRepo = {
    find: vi.fn(),
  };
  const clausulasRepo = {
    find: vi.fn(),
  };
  const servicosRepo = {
    findOne: vi.fn(),
  };

  const buildComparacaoItems = vi.fn();
  const buildCobrancaData = vi.fn();
  const consultarCnpjSemBloquear = vi.fn();
  const assertLimiteClientes = vi.fn();

  return {
    ensureDatabase,
    runQueryWithRls,
    clienteRepo,
    insertCliente,
    contratoRepo,
    relatorioRepo,
    clausulasRepo,
    servicosRepo,
    buildComparacaoItems,
    buildCobrancaData,
    consultarCnpjSemBloquear,
    assertLimiteClientes,
  };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: clientesMocks.ensureDatabase,
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: clientesMocks.runQueryWithRls,
}));

vi.mock("../../cobrancas/cobranca.service.js", () => ({
  buildComparacaoItems: clientesMocks.buildComparacaoItems,
  buildCobrancaData: clientesMocks.buildCobrancaData,
}));

// Consulta pública de CNPJ: mockada por padrão como "sem resultado" (rede indisponível/inexistente),
// para os testes que não versam sobre o enriquecimento continuarem exercitando só o fallback.
vi.mock("../../fornecedores/consulta-cnpj.service.js", () => ({
  consultarCnpjSemBloquear: clientesMocks.consultarCnpjSemBloquear,
}));

// Teto de clientes do escritório: dublado para o teste controlar quando bloqueia.
// A regra em si é testada em `domain/escritorios/tests/limite-clientes.test.ts`;
// aqui o que importa é ONDE ela é chamada nos dois choke points de inserção.
vi.mock("../../escritorios/limite-clientes.js", async (importOriginal) => {
  const original = await importOriginal<typeof import("../../escritorios/limite-clientes.js")>();
  return { ...original, assertLimiteClientes: clientesMocks.assertLimiteClientes };
});

const { LimiteClientesError } = await import("../../escritorios/limite-clientes.js");

const {
  listClientes,
  patchCliente,
  createCliente,
  getComparacaoCliente,
  findClienteByCnpj,
  findClienteAtivoByCnpj,
  findOrCreateClienteByCnpj,
  fillClienteNullFieldsFromContrato,
  normalizarCnpj,
  DocumentoClienteInvalidoError,
  CnaeInvalidoError,
  NcmPermitidoInvalidoError,
  ClienteJaExisteError,
  HoldingInvalidaError,
} = await import("../cliente.service.js");

const { RegimeTributarioInvalidoError } = await import("../regime-tributario.js");

function makeManager() {
  return {
    getRepository(entity: { name?: string }) {
      switch (entity?.name) {
        case "Cliente":
          return clientesMocks.clienteRepo;
        case "Contrato":
          return clientesMocks.contratoRepo;
        case "Relatorio":
          return clientesMocks.relatorioRepo;
        case "ClausulasExcedentes":
          return clientesMocks.clausulasRepo;
        case "ServicosContratados":
          return clientesMocks.servicosRepo;
        default:
          throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
      }
    },
  };
}

describe("cliente service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    clientesMocks.runQueryWithRls.mockImplementation(async (_rls: unknown, callback: (manager: ReturnType<typeof makeManager>) => Promise<unknown>) => {
      return callback(makeManager());
    });
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue(null);
    // Default: escritório sem teto. Testes de limite sobrescrevem.
    clientesMocks.assertLimiteClientes.mockResolvedValue(undefined);
    // `clearAllMocks` não reseta implementações de `mockResolvedValue` de um teste para o
    // outro (só o histórico de chamadas) — sem isto, a busca de grupo econômico por CNPJ
    // (`sincronizarGrupoEconomicoPorCnpj`, chamada por `createCliente`/`findOrCreateClienteByCnpj`)
    // herdaria `find`/`findOne` deixados por um teste anterior. Default seguro: nenhuma
    // candidata encontrada; testes que precisam de outro cenário sobrescrevem depois.
    clientesMocks.clienteRepo.find.mockResolvedValue([]);
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    // Default: o INSERT vence a corrida e devolve a linha criada, espelhando o
    // RETURNING do Postgres quando não houve conflito.
    clientesMocks.insertCliente.mockImplementation(async (valores: Record<string, unknown>) => ({
      raw: [{ id: "cliente-novo", ...valores }],
    }));
  });

  it("lists clientes with counts", async () => {
    clientesMocks.clienteRepo.find.mockResolvedValue([
      {
        id: "client-1",
        cnpj: "123",
        razao_social: "Acme",
        email: null,
        regime_tributario: "Simples",
        endereco: null,
        representante_legal: null,
        informacoes_gerais: null,
        contratos: [{ id: "contract-1" }],
        relatorios: [{ id: "report-1" }, { id: "report-2" }],
      },
    ]);

    const result = await listClientes("office-1");

    expect(clientesMocks.ensureDatabase).toHaveBeenCalledTimes(1);
    expect(result).toEqual([
      {
        id: "client-1",
        cnpj: "123",
        razao_social: "Acme",
        email: null,
        regime_tributario: "Simples",
        endereco: null,
        uf: undefined,
        opcao_ibs_cbs: null,
        representante_legal: null,
        cnae_principal: null,
        cnae_principal_descricao: null,
        informacoes_gerais: null,
        contratos_count: 1,
        relatorios_count: 2,
        aniversario_contrato: null,
        vencimento_contrato: null,
        holding_id: null,
        pagador_grupo: null,
        membros_count: 0,
        ativo: undefined,
      },
    ]);
  });

  it("patches cliente fields", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      nome_fantasia: null,
      email: null,
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });
    clientesMocks.clienteRepo.save.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme Ltda",
      nome_fantasia: "Acme",
      email: "financeiro@acme.com.br",
      regime_tributario: "Lucro Real",
      endereco: "Rua A, 123",
      representante_legal: "Maria Silva",
      informacoes_gerais: { origem: "contrato" },
    });

    const result = await patchCliente("office-1", "client-1", {
      razao_social: "  Acme Ltda  ",
      nome_fantasia: "  Acme  ",
      email: " Financeiro@Acme.com.br ",
      regime_tributario: "  Lucro Real  ",
      endereco: " Rua A, 123 ",
      representante_legal: " Maria Silva ",
      informacoes_gerais: { origem: "contrato" },
    });

    expect(result).toEqual({
      ok: true,
      cliente: {
        id: "client-1",
        cnpj: "123",
        razao_social: "Acme Ltda",
        nome_fantasia: "Acme",
        email: "financeiro@acme.com.br",
        regime_tributario: "Lucro Real",
        endereco: "Rua A, 123",
        uf: undefined,
        opcao_ibs_cbs: null,
        representante_legal: "Maria Silva",
        cnae_principal: null,
        cnae_principal_descricao: null,
        informacoes_gerais: { origem: "contrato" },
        holding_id: null,
        pagador_grupo: null,
      },
    });
    expect(clientesMocks.clienteRepo.save).toHaveBeenCalled();
  });

  it("creates cliente records", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockResolvedValue({
      id: "client-2",
      cnpj: "12.345.678/0001-90",
      razao_social: "Nova Empresa",
      nome_fantasia: "Nova",
      email: "contas@nova.com.br",
      regime_tributario: "Simples",
      endereco: "Rua B",
      uf: null,
      representante_legal: "João",
      informacoes_gerais: { fonte: "manual" },
    });

    const result = await createCliente("office-1", {
      cnpj: "12 345.678/0001-90",
      razao_social: "  Nova Empresa ",
      nome_fantasia: " Nova ",
      email: " Contas@Nova.com.br ",
      regime_tributario: " Simples ",
      endereco: " Rua B ",
      representante_legal: " João ",
      informacoes_gerais: { fonte: "manual" },
    });

    expect(result).toEqual({
      ok: true,
      cliente: {
        id: "client-2",
        cnpj: "12.345.678/0001-90",
        razao_social: "Nova Empresa",
        nome_fantasia: "Nova",
        email: "contas@nova.com.br",
        regime_tributario: "Simples",
        endereco: "Rua B",
        uf: null,
        opcao_ibs_cbs: null,
        representante_legal: "João",
        cnae_principal: null,
        cnae_principal_descricao: null,
        informacoes_gerais: { fonte: "manual" },
        holding_id: null,
        pagador_grupo: null,
      },
    });
    // O regime enviado (" Simples ") é gravado no valor canônico, não como veio.
    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ regime_tributario: "Simples Nacional" }),
    );
  });

  it("grupo econômico: cliente filial novo se associa automaticamente à matriz já cadastrada", async () => {
    // `mockReset` (não `mockClear`/`clearAllMocks`): evita herdar uma resposta "once" não
    // consumida deixada por outro teste (ver nota no `beforeEach`).
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null) // não existe cliente duplicado com este cnpj
      .mockResolvedValueOnce({ id: "matriz-1", cnpj: "11.222.333/0001-81", holding_id: null }) // busca da matriz pela raiz
      .mockResolvedValueOnce({ id: "matriz-1", cnpj: "11.222.333/0001-81", holding_id: null }); // validarAssociacaoHolding: holding existe
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => ({ id: "filial-1", ...cliente }));

    const result = await createCliente("office-1", {
      cnpj: "11.222.333/0002-62",
      razao_social: "Filial Nova LTDA",
    });

    expect(result.cliente.holding_id).toBe("matriz-1");
    expect(clientesMocks.clienteRepo.update).toHaveBeenCalledWith(
      { id: "filial-1", escritorio_id: "office-1" },
      { holding_id: "matriz-1" },
    );
  });

  it("grupo econômico: holding_id explícito no payload vence sobre a busca automática", async () => {
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null) // não existe cliente duplicado
      .mockResolvedValueOnce({ id: "holding-explicita", cnpj: "99.888.777/0001-00", holding_id: null }); // holding informada existe
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => ({ id: "filial-2", ...cliente }));

    const result = await createCliente("office-1", {
      cnpj: "11.222.333/0002-62",
      razao_social: "Filial Nova LTDA",
      holding_id: "holding-explicita",
    });

    expect(result.cliente.holding_id).toBe("holding-explicita");
    // busca automática nunca roda: só 2 chamadas de findOne (duplicidade + holding explícita)
    expect(clientesMocks.clienteRepo.findOne).toHaveBeenCalledTimes(2);
    expect(clientesMocks.clienteRepo.update).not.toHaveBeenCalled();
  });

  it("rejects duplicate cnpj with ClienteJaExisteError instead of a generic Error (regression: virava 500 sem explicação)", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({ id: "client-existente", cnpj: "11.222.333/0001-81" });

    await expect(
      createCliente("office-1", {
        cnpj: "11.222.333/0001-81",
        razao_social: "Empresa Duplicada LTDA",
      }),
    ).rejects.toThrow(ClienteJaExisteError);

    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("rejects holding_id inexistente com HoldingInvalidaError instead of a generic Error (regression: virava 500 sem explicação)", async () => {
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null) // não existe cliente duplicado
      .mockResolvedValueOnce(null); // holding_id informado não existe

    await expect(
      createCliente("office-1", {
        cnpj: "11.222.333/0002-62",
        razao_social: "Filial Nova LTDA",
        holding_id: "holding-inexistente",
      }),
    ).rejects.toThrow(HoldingInvalidaError);

    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("creates cliente with opcao_ibs_cbs and ignores removed client presumed-credit fields", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    // Consulta de CNPJ não expõe esses campos: mesmo devolvendo dado, não deve sobrescrevê-los.
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue({ razao_social: "Razão da Receita" });

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nova Empresa",
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_unico",
      // @ts-expect-error campo removido do contrato do cliente
      aliquota_credito_presumido_ibs: 0.02,
    });

    expect(result.cliente).toEqual(
      expect.objectContaining({
        opcao_ibs_cbs: "regime_unico",
      }),
    );
    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        opcao_ibs_cbs: "regime_unico",
      }),
    );
  });

  it("rejects an invalid opcao_ibs_cbs on creation without silently coercing it", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);

    await expect(
      createCliente("office-1", {
        cnpj: "12.345.678/0001-90",
        razao_social: "Nova Empresa",
        // @ts-expect-error valor inválido de propósito
        opcao_ibs_cbs: "regime_qualquer",
      }),
    ).rejects.toThrow("opcao_ibs_cbs deve ser");
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("patches opcao_ibs_cbs without persisting removed client presumed-credit fields", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      opcao_ibs_cbs: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await patchCliente("office-1", "client-1", {
      opcao_ibs_cbs: "regime_regular",
      // @ts-expect-error campo removido do contrato do cliente
      aliquota_credito_presumido_ibs: 0.03,
    });

    expect(result?.cliente).toEqual(
      expect.objectContaining({
        opcao_ibs_cbs: "regime_regular",
      }),
    );

    // Explicit null limpa a opção; os percentuais não pertencem mais ao cliente.
    const limpo = await patchCliente("office-1", "client-1", {
      opcao_ibs_cbs: null,
    });
    expect(limpo?.cliente).toEqual(
      expect.objectContaining({
        opcao_ibs_cbs: null,
      }),
    );
  });

  it("rejects an invalid opcao_ibs_cbs on patch without silently coercing it", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
    });

    await expect(
      patchCliente("office-1", "client-1", {
        // @ts-expect-error valor inválido de propósito
        opcao_ibs_cbs: "regime_qualquer",
      }),
    ).rejects.toThrow("opcao_ibs_cbs deve ser");
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("prefers data from the CNPJ lookup over the typed values on creation", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue({
      razao_social: "Razão da Receita",
      nome_fantasia: "Fantasia pública",
      regime_tributario_sugerido: "Lucro Real",
      endereco_sugerido: "Avenida Paulista, 1000, São Paulo/SP",
      uf: "SP",
    });

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nome digitado errado",
      nome_fantasia: "Apelido digitado",
      regime_tributario: "Lucro Presumido",
      endereco: "Endereço digitado",
    });

    expect(clientesMocks.consultarCnpjSemBloquear).toHaveBeenCalledWith("12.345.678/0001-90");
    expect(result.cliente).toEqual(
      expect.objectContaining({
        razao_social: "Razão da Receita",
        nome_fantasia: "Fantasia pública",
        regime_tributario: "Lucro Real",
        endereco: "Avenida Paulista, 1000, São Paulo/SP",
        uf: "SP",
      }),
    );
  });

  it("falls back to the typed values when the CNPJ lookup fails or is unavailable", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    // Best-effort: indisponibilidade/404 devolvem null (contrato de consultarCnpjSemBloquear); a
    // criação do cliente nunca deve lançar por causa disso.
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue(null);

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nome Digitado LTDA",
      endereco: "Endereço digitado",
    });

    expect(result.cliente).toEqual(
      expect.objectContaining({
        razao_social: "Nome Digitado LTDA",
        endereco: "Endereço digitado",
        uf: null,
      }),
    );
  });

  it("rejects a pessoa jurídica regime for a client with a CPF", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);

    await expect(
      createCliente("office-1", {
        cnpj: "046.318.779-52",
        razao_social: "Dr. House",
        regime_tributario: "Lucro Real",
      }),
    ).rejects.toThrow(RegimeTributarioInvalidoError);

    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("rejects Pessoa Física for a client with a CNPJ", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);

    await expect(
      createCliente("office-1", {
        cnpj: "12.345.678/0001-90",
        razao_social: "Padaria Modelo LTDA",
        regime_tributario: "Pessoa Física",
      }),
    ).rejects.toThrow(RegimeTributarioInvalidoError);
  });

  it("accepts Pessoa Física for a client with a CPF", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockResolvedValue({
      id: "client-pf",
      cnpj: "046.318.779-52",
      razao_social: "Dr. House",
      regime_tributario: "Pessoa Física",
    });

    await createCliente("office-1", {
      cnpj: "04631877952",
      razao_social: "Dr. House",
      regime_tributario: "autônomo",
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ cnpj: "046.318.779-52", regime_tributario: "Pessoa Física" }),
    );
  });

  it("normalizes CNPJ after removing non-digits and rejects invalid lengths", () => {
    expect(normalizarCnpj("12 345.678/0001-90")).toBe("12.345.678/0001-90");
    expect(normalizarCnpj("12345678000190")).toBe("12.345.678/0001-90");
    expect(() => normalizarCnpj("123")).toThrow("cnpj deve conter 11 dígitos (CPF) ou 14 dígitos (CNPJ).");
  });

  it("normalizes an 11-digit CPF for pessoa física clients", () => {
    expect(normalizarCnpj("04631877952")).toBe("046.318.779-52");
    expect(normalizarCnpj("046.318.779-52")).toBe("046.318.779-52");
    expect(normalizarCnpj(" 046 318 779 52 ")).toBe("046.318.779-52");
  });

  it("rejects document lengths that are neither CPF nor CNPJ", () => {
    for (const invalido of ["1234567890", "123456789012", "1234567890123", "123456789012345"]) {
      expect(() => normalizarCnpj(invalido)).toThrow(DocumentoClienteInvalidoError);
    }
    expect(() => normalizarCnpj(null)).toThrow(DocumentoClienteInvalidoError);
  });

  it("updates cliente regime and address from a new contract", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: "Simples Nacional",
      endereco: "Rua Antiga",
      representante_legal: "Representante Atual",
      informacoes_gerais: { origem: "cadastro", regime_tributario: "Simples Nacional" },
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await fillClienteNullFieldsFromContrato(makeManager() as any, "office-1", "client-1", {
      regime_tributario: "Lucro Real",
      endereco: "Rua Nova, 123, Curitiba - PR, 80000-000",
      representante_legal: "Novo Representante",
      informacoes_gerais: {
        regime_tributario: "Lucro Real",
        endereco: "Rua Nova, 123, Curitiba - PR, 80000-000",
      },
    });

    expect(result).toEqual(expect.objectContaining({
      id: "client-1",
      regime_tributario: "Lucro Real",
      endereco: "Rua Nova, 123, Curitiba - PR, 80000-000",
      representante_legal: "Representante Atual",
      informacoes_gerais: {
        origem: "cadastro",
        regime_tributario: "Lucro Real",
        endereco: "Rua Nova, 123, Curitiba - PR, 80000-000",
      },
    }));
    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      regime_tributario: "Lucro Real",
      endereco: "Rua Nova, 123, Curitiba - PR, 80000-000",
      representante_legal: "Representante Atual",
    }));
  });

  it("backfills placeholder razao_social and null nome_fantasia on first contract", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Cliente 11222333000144",
      nome_fantasia: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await fillClienteNullFieldsFromContrato(
      makeManager() as any,
      "office-1",
      "client-1",
      { razao_social: "Empresa Real Ltda", nome_fantasia: "Empresa Real" },
      { preencherIdentificacao: true },
    );

    expect(result).toEqual(expect.objectContaining({
      razao_social: "Empresa Real Ltda",
      nome_fantasia: "Empresa Real",
    }));
  });

  it("never overwrites a real razao_social even on first contract", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Nome Ja Cadastrado Ltda",
      nome_fantasia: "Apelido",
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await fillClienteNullFieldsFromContrato(
      makeManager() as any,
      "office-1",
      "client-1",
      { razao_social: "Outro Nome", nome_fantasia: "Outro Apelido" },
      { preencherIdentificacao: true },
    );

    expect(result).toEqual(expect.objectContaining({
      razao_social: "Nome Ja Cadastrado Ltda",
      nome_fantasia: "Apelido",
    }));
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("does not touch identification fields when preencherIdentificacao is off", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Cliente 11222333000144",
      nome_fantasia: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await fillClienteNullFieldsFromContrato(
      makeManager() as any,
      "office-1",
      "client-1",
      { razao_social: "Empresa Real Ltda", nome_fantasia: "Empresa Real" },
    );

    expect(result).toEqual(expect.objectContaining({
      razao_social: "Cliente 11222333000144",
      nome_fantasia: null,
    }));
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("prefers the CNPJ lookup over the contract for identity/regime/address, and sets uf from it alone", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Cliente 11222333000144",
      nome_fantasia: null,
      regime_tributario: "Simples Nacional",
      endereco: "Endereço do contrato antigo",
      uf: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const result = await fillClienteNullFieldsFromContrato(
      makeManager() as any,
      "office-1",
      "client-1",
      {
        razao_social: "Nome extraído do contrato",
        nome_fantasia: "Apelido extraído",
        regime_tributario: "Lucro Presumido",
        endereco: "Endereço extraído do contrato",
      },
      {
        preencherIdentificacao: true,
        consulta: {
          razao_social: "Razão da Receita",
          nome_fantasia: "Fantasia pública",
          regime_tributario_sugerido: "Lucro Real",
          endereco_sugerido: "Endereço da Receita, 100",
          uf: "SP",
        } as any,
      },
    );

    // API vence identidade (via preencherIdentificacao), regime e endereço; uf só existe via consulta.
    expect(result).toEqual(expect.objectContaining({
      razao_social: "Razão da Receita",
      nome_fantasia: "Fantasia pública",
      regime_tributario: "Lucro Real",
      endereco: "Endereço da Receita, 100",
      uf: "SP",
    }));
  });

  it("finds or creates cliente by cnpj", async () => {
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({
        id: "client-3",
        cnpj: "12.345.678/0001-90",
        razao_social: "Cliente 12.345.678/0001-90",
      });
    clientesMocks.insertCliente.mockResolvedValue({
      raw: [{
        id: "client-3",
        cnpj: "12.345.678/0001-90",
        razao_social: "Cliente 12.345.678/0001-90",
      }],
    });

    const created = await findOrCreateClienteByCnpj({
      escritorioId: "office-1",
      cnpj: "12345678000190",
    });

    expect(created).toEqual({
      id: "client-3",
      cnpj: "12.345.678/0001-90",
      razao_social: "Cliente 12.345.678/0001-90",
    });
    expect(clientesMocks.insertCliente).toHaveBeenCalledWith({
      escritorio_id: "office-1",
      cnpj: "12.345.678/0001-90",
      razao_social: "Cliente 12.345.678/0001-90",
      nome_fantasia: null,
      regime_tributario: null,
      endereco: null,
      uf: null,
      representante_legal: null,
      informacoes_gerais: null,
      ativo: true,
    });
  });

  it("teto de clientes bloqueia createCliente antes da consulta pública de CNPJ", async () => {
    // A consulta é I/O externo: não pode ser gasta numa criação já recusada.
    clientesMocks.assertLimiteClientes.mockRejectedValue(new LimiteClientesError(20, 20));

    await expect(
      createCliente("office-1", { cnpj: "12345678000190", razao_social: "ACME" }),
    ).rejects.toBeInstanceOf(LimiteClientesError);

    expect(clientesMocks.consultarCnpjSemBloquear).not.toHaveBeenCalled();
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("teto de clientes nunca bloqueia um cliente que já existe", async () => {
    // `findOrCreateClienteByCnpj` retorna antes do assert: escritório acima do teto
    // continua conseguindo ingerir documentos dos clientes que já cadastrou.
    clientesMocks.assertLimiteClientes.mockRejectedValue(new LimiteClientesError(20, 25));
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-existente",
      cnpj: "12.345.678/0001-90",
    });

    const cliente = await findOrCreateClienteByCnpj({
      escritorioId: "office-1",
      cnpj: "12345678000190",
    });

    expect(cliente).toMatchObject({ id: "client-existente" });
    expect(clientesMocks.assertLimiteClientes).not.toHaveBeenCalled();
  });

  it("teto de clientes bloqueia findOrCreateClienteByCnpj para um CNPJ novo", async () => {
    clientesMocks.assertLimiteClientes.mockRejectedValue(new LimiteClientesError(20, 20));
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);

    await expect(
      findOrCreateClienteByCnpj({ escritorioId: "office-1", cnpj: "12345678000190" }),
    ).rejects.toBeInstanceOf(LimiteClientesError);

    expect(clientesMocks.consultarCnpjSemBloquear).not.toHaveBeenCalled();
    expect(clientesMocks.insertCliente).not.toHaveBeenCalled();
  });

  it("cnpj criado por uma ingestão concorrente devolve o cliente vencedor sem estourar a UNIQUE", async () => {
    // Regressão do incidente 2026-08-07: 19 agentes de relatório rodando em
    // paralelo para o mesmo CNPJ faziam todos passar pelo check-then-insert, e os
    // perdedores viravam HTTP 400 "duplicate key value violates unique constraint".
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.find.mockReset();
    clientesMocks.clienteRepo.find.mockResolvedValue([]);
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null) // findClienteByCnpj: ainda não existia quando olhamos
      .mockResolvedValueOnce({ id: "vencedor-1", cnpj: "98.765.432/0001-10" }); // releitura pós-conflito
    clientesMocks.insertCliente.mockResolvedValue({ raw: [] }); // ON CONFLICT DO NOTHING

    const cliente = await findOrCreateClienteByCnpj({
      escritorioId: "office-1",
      cnpj: "98765432000110",
    });

    expect(cliente).toEqual({ id: "vencedor-1", cnpj: "98.765.432/0001-10" });
    // O vencedor da corrida já sincronizou o grupo econômico; o perdedor não repete.
    expect(clientesMocks.clienteRepo.update).not.toHaveBeenCalled();
  });

  it("grupo econômico: ingestão que cria a matriz puxa filial pré-cadastrada para o grupo", async () => {
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.find.mockReset();
    clientesMocks.clienteRepo.findOne
      .mockResolvedValueOnce(null) // findClienteByCnpj: matriz ainda não existe
      .mockResolvedValueOnce({ id: "matriz-2", cnpj: "22.333.444/0001-05", holding_id: null }); // validarAssociacaoHolding: holding (a nova matriz) existe
    clientesMocks.clienteRepo.find
      .mockResolvedValueOnce([{ id: "filial-3", cnpj: "22.333.444/0002-88", holding_id: null }]) // candidatas por raiz
      .mockResolvedValueOnce([]); // validarAssociacaoHolding: filial-3 sem membros próprios
    clientesMocks.insertCliente.mockResolvedValue({
      raw: [{ id: "matriz-2", cnpj: "22.333.444/0001-05" }],
    });

    await findOrCreateClienteByCnpj({ escritorioId: "office-1", cnpj: "22333444000105" });

    expect(clientesMocks.clienteRepo.update).toHaveBeenCalledWith(
      { id: "filial-3", escritorio_id: "office-1" },
      { holding_id: "matriz-2" },
    );
  });

  it("uses the razão social from the CNPJ lookup instead of the placeholder for a new cliente", async () => {
    // mockReset (não mockClear): a suíte de "finds or creates cliente by cnpj" acima deixa uma
    // resposta "once" não consumida na fila, que vazaria para esta chamada.
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne.mockResolvedValueOnce(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue({
      razao_social: "Razão da Receita LTDA",
      uf: "SP",
    });

    const created = await findOrCreateClienteByCnpj({
      escritorioId: "office-1",
      cnpj: "12345678000190",
    });

    expect(created).toEqual(
      expect.objectContaining({
        razao_social: "Razão da Receita LTDA",
        uf: "SP",
      }),
    );
  });

  it("finds cliente by CNPJ ignoring punctuation from lambda payloads", async () => {
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-4",
      cnpj: "74.838.226/0001-00",
      razao_social: "Revestia",
    });

    const result = await findClienteByCnpj("office-1", "74.838.226/0001-00");

    expect(result).toEqual({
      id: "client-4",
      cnpj: "74.838.226/0001-00",
      razao_social: "Revestia",
    });
    expect(clientesMocks.clienteRepo.findOne).toHaveBeenCalledWith({
      where: { cnpj: "74.838.226/0001-00", escritorio_id: "office-1" },
    });
  });

  it("finds only active cliente by CNPJ for report confirmation", async () => {
    clientesMocks.clienteRepo.findOne.mockReset();
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-4",
      cnpj: "74.838.226/0001-00",
      razao_social: "Revestia",
      ativo: true,
    });

    const result = await findClienteAtivoByCnpj("office-1", "74.838.226/0001-00");

    expect(result).toEqual(expect.objectContaining({
      id: "client-4",
      ativo: true,
    }));
    expect(clientesMocks.clienteRepo.findOne).toHaveBeenCalledWith({
      where: { cnpj: "74.838.226/0001-00", escritorio_id: "office-1", ativo: true },
    });
  });

  it("builds comparison payloads for a cliente", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      regime_tributario: "Simples",
    });
    clientesMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      servicos_contratados: [
        {
          numero_de_documentos: 100,
          numero_de_colaboradores: 10,
          numero_de_prolabores: 2,
        },
      ],
    });
    clientesMocks.clausulasRepo.find.mockResolvedValue([{ id: "exc-1" }]);
    clientesMocks.servicosRepo.findOne.mockResolvedValue({
      dados: {
        valores_contratados: {
          numero_de_documentos: { valor: 100 },
          numero_de_colaboradores: { valor: 10 },
          numero_de_prolabores: { valor: 2 },
        },
      },
      resumo_normalizado: {},
    });
    clientesMocks.relatorioRepo.find.mockResolvedValue([{ id: "report-1" }]);
    clientesMocks.buildComparacaoItems.mockReturnValue([{ label: "Itens" }]);
    clientesMocks.buildCobrancaData.mockReturnValue({ valor_excedente_folha: 1, valor_excedente_doc: 2 });

    const result = await getComparacaoCliente("office-1", "client-1", "2024-01");

    expect(result).toEqual({
      contrato: { id: "contract-1" },
      items: [{ label: "Itens" }],
      cobranca: { valor_excedente_folha: 1, valor_excedente_doc: 2 },
    });
    expect(clientesMocks.buildComparacaoItems).toHaveBeenCalledWith({
      servicos: {
        contrato_id: "contract-1",
        numero_de_documentos: 100,
        numero_de_colaboradores: 10,
        numero_de_prolabores: 2,
        numero_de_estabelecimentos: null,
      },
      relatorios: [{ id: "report-1" }],
    });
    expect(clientesMocks.buildCobrancaData).toHaveBeenCalled();
  });

  it("populates CNAE fields from the CNPJ lookup on creation, with no fallback to typed values", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue({
      razao_social: "Razão da Receita",
      cnae_principal: "6201500",
      cnae_principal_descricao: "Desenvolvimento de programas de computador sob encomenda",
      cnaes_secundarios: [{ codigo: "6202300", descricao: "Desenvolvimento e licenciamento de programas" }],
    });

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nome digitado errado",
      // Mesmo se o chamador tentar digitar um CNAE diferente, a consulta de CNPJ vence outright.
      cnae_principal: "9999999",
    });

    expect(result.cliente).toEqual(
      expect.objectContaining({
        cnae_principal: "6201500",
        cnae_principal_descricao: "Desenvolvimento de programas de computador sob encomenda",
      }),
    );
    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        cnae_principal: "6201500",
        cnae_principal_descricao: "Desenvolvimento de programas de computador sob encomenda",
        cnaes_secundarios: [{ codigo: "6202300", descricao: "Desenvolvimento e licenciamento de programas" }],
      }),
    );
  });

  it("persists a manually typed cnaes_fornecedores_permitidos allowlist on creation — never from the CNPJ lookup", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue(null);

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nova Empresa",
      cnaes_fornecedores_permitidos: [{ codigo: "4711302", descricao: "Comércio varejista" }],
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        cnaes_fornecedores_permitidos: [{ codigo: "4711302", descricao: "Comércio varejista" }],
        // Sem consulta bem-sucedida, os campos derivados da API ficam null.
        cnae_principal: null,
        cnae_principal_descricao: null,
        cnaes_secundarios: null,
      }),
    );
    expect(result.cliente).not.toHaveProperty("cnaes_fornecedores_permitidos");
  });

  it("sets and clears all 4 CNAE fields via patch", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      cnae_principal: null,
      cnae_principal_descricao: null,
      cnaes_secundarios: null,
      cnaes_fornecedores_permitidos: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const setResult = await patchCliente("office-1", "client-1", {
      cnae_principal: "6201-5/00",
      cnae_principal_descricao: "Desenvolvimento de programas",
      cnaes_secundarios: [{ codigo: "6202300", descricao: "Licenciamento" }],
      cnaes_fornecedores_permitidos: [{ codigo: "4711302", descricao: "Comércio varejista" }],
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        cnae_principal: "6201500",
        cnae_principal_descricao: "Desenvolvimento de programas",
        cnaes_secundarios: [{ codigo: "6202300", descricao: "Licenciamento" }],
        cnaes_fornecedores_permitidos: [{ codigo: "4711302", descricao: "Comércio varejista" }],
      }),
    );
    expect(setResult?.cliente).toEqual(
      expect.objectContaining({
        cnae_principal: "6201500",
        cnae_principal_descricao: "Desenvolvimento de programas",
      }),
    );

    // Explicit null limpa (replace completo) os 4 campos.
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      cnae_principal: "6201500",
      cnae_principal_descricao: "Desenvolvimento de programas",
      cnaes_secundarios: [{ codigo: "6202300", descricao: "Licenciamento" }],
      cnaes_fornecedores_permitidos: [{ codigo: "4711302", descricao: "Comércio varejista" }],
    });

    const clearResult = await patchCliente("office-1", "client-1", {
      cnae_principal: null,
      cnae_principal_descricao: null,
      cnaes_secundarios: null,
      cnaes_fornecedores_permitidos: null,
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        cnae_principal: null,
        cnae_principal_descricao: null,
        cnaes_secundarios: null,
        cnaes_fornecedores_permitidos: null,
      }),
    );
    expect(clearResult?.cliente).toEqual(
      expect.objectContaining({
        cnae_principal: null,
        cnae_principal_descricao: null,
      }),
    );
  });

  it("rejects a non-array cnaes_fornecedores_permitidos on patch with CnaeInvalidoError", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
    });

    await expect(
      patchCliente("office-1", "client-1", {
        // @ts-expect-error valor inválido de propósito
        cnaes_fornecedores_permitidos: "6201500",
      }),
    ).rejects.toThrow(CnaeInvalidoError);
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });

  it("persists a manually typed ncms_permitidos allowlist on creation — never from the CNPJ lookup", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue(null);

    const result = await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nova Empresa",
      ncms_permitidos: [{ codigo: "12019000", descricao: "Soja" }],
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        ncms_permitidos: [{ codigo: "12019000", descricao: "Soja" }],
      }),
    );
    expect(result.cliente).not.toHaveProperty("ncms_permitidos");
  });

  it("normalizes ncms_permitidos codes to 8 digits and drops malformed items on creation", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue(null);
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    clientesMocks.consultarCnpjSemBloquear.mockResolvedValue(null);

    await createCliente("office-1", {
      cnpj: "12.345.678/0001-90",
      razao_social: "Nova Empresa",
      ncms_permitidos: [
        { codigo: "1201.90.00", descricao: "Soja com pontuação" },
        // item malformado (sem codigo válido) é descartado silenciosamente
        { codigo: "", descricao: "Sem código" },
      ],
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        ncms_permitidos: [{ codigo: "12019000", descricao: "Soja com pontuação" }],
      }),
    );
  });

  it("sets and clears ncms_permitidos via patch (replace completo do array, não merge)", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      ncms_permitidos: null,
    });
    clientesMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);

    const setResult = await patchCliente("office-1", "client-1", {
      ncms_permitidos: [{ codigo: "12019000", descricao: "Soja" }],
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        ncms_permitidos: [{ codigo: "12019000", descricao: "Soja" }],
      }),
    );
    expect(setResult).not.toBeNull();

    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
      ncms_permitidos: [{ codigo: "12019000", descricao: "Soja" }],
    });

    const clearResult = await patchCliente("office-1", "client-1", {
      ncms_permitidos: null,
    });

    expect(clientesMocks.clienteRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ ncms_permitidos: null }),
    );
    expect(clearResult).not.toBeNull();
  });

  it("rejects a non-array ncms_permitidos on patch with NcmPermitidoInvalidoError", async () => {
    clientesMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      cnpj: "123",
      razao_social: "Acme",
    });

    await expect(
      patchCliente("office-1", "client-1", {
        // @ts-expect-error valor inválido de propósito
        ncms_permitidos: "12019000",
      }),
    ).rejects.toThrow(NcmPermitidoInvalidoError);
    expect(clientesMocks.clienteRepo.save).not.toHaveBeenCalled();
  });
});
