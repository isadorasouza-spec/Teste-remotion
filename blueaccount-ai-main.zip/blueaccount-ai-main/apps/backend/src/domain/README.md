# `src/domain`

Esta pasta representa a camada de regra de negócio da aplicação BlueAccount.

Ela deve concentrar a lógica que responde à pergunta:

> "O que a aplicação precisa fazer com os dados?"

O objetivo é manter a regra de negócio fora do HTTP e fora das dependências técnicas, para que os casos de uso fiquem testáveis, previsíveis e fáceis de evoluir.

## Papel da camada

`src/domain` deve conter:

- serviços de domínio
- regras de cálculo
- validações de negócio
- normalização de dados
- coordenação de fluxos de caso de uso
- contratos e tipos específicos de cada domínio

## Estrutura alvo

A pasta é organizada por domínio de negócio:

```txt
src/domain/
  acoes-ai/
  agentes/
  autenticacao/
  clientes/
  cobrancas/
  complexidades-cobranca/
  complexidades-extracao-contrato/
  contratos/
  documentos/
  escritorios/
  extracao/
  faturamento/
  modelos-extracao/
  oauth/
  relatorios/
  usage/
  valores-a-cobrar/
```

Domínios ativos:

- `acoes-ai`
- `agentes`
- `autenticacao`
- `clientes`
- `cobrancas`
- `complexidades-cobranca`
- `complexidades-extracao-contrato`
- `contratos`
- `documentos`
- `escritorios`
- `extracao`
- `faturamento`
- `feedback`
- `modelos-extracao`
- `oauth`
- `oportunidades-recuperacao`
- `relatorios`
- `seed-runs`
- `servicos-contratados`
- `simulacoes`
- `usage`
- `valores-a-cobrar`

Cada domínio pode manter seus testes em uma subpasta `tests/` ao lado do serviço principal.

## Responsabilidades esperadas

### `clientes`

Regras relacionadas a clientes e seus relacionamentos.

Exemplos:

- carregar cliente com contratos e relatórios
- atualizar campos permitidos
- validar consistência de dados do cliente

### `contratos`

Regras relacionadas a contratos, serviços contratados e cláusulas.

Exemplos:

- carregar contrato ativo
- atualizar campos de contrato
- manipular `servicos_contratados`
- substituir cláusulas de excedentes

### `relatorios`

Regras relacionadas a relatórios operacionais.

Exemplos:

- atualizar relatórios por tipo
- normalizar tipos de relatório
- tratar campos específicos de cada extração

### `cobrancas`

Regras de cálculo comparativo, emissão, provedores e avaliação de cobrança.

Exemplos:

- montar preview e emissão de cobrança
- sincronizar provider externo e webhooks
- aplicar desconto, approval e lifecycle

### `valores-a-cobrar`

Regras de consolidação dos valores observados e calculados por competência.

Exemplos:

- consolidar competência por cliente
- comparar versões e gerar delta
- aplicar edições manuais, mitigação e fechamento

### `documentos`

Fluxos relacionados ao upload, listagem e metadados de documentos por cliente.

Exemplos:

- validar extensões permitidas
- montar `storage_key` com timestamp Unix
- persistir metadados de upload
- listar documentos por cliente e por módulo
- ler artefatos OCR/markdown persistidos

### `autenticacao`

Regras ligadas à identidade do usuário e sessão da aplicação.

Exemplos:

- resolver usuário local a partir do Cognito
- criar sessão da aplicação
- normalizar e-mails
- revogar sessão

### `complexidades-cobranca`

Catálogo de níveis de cobrança usados por contratos, pelo agente de cobrança e pelo cockpit admin.

### `complexidades-extracao-contrato`

Catálogo de níveis/modelos usados para extração de contratos.

### `modelos-extracao`

Configuração singleton dos modelos Bedrock usados pelas state machines de extração com OCR.

## Estado atual do projeto

As regras centrais já vivem majoritariamente em `src/domain`. Acesso relacional, entidades, migrations e integrações técnicas continuam em `src/database` e `src/infrastructure`.

## O que não deve ficar aqui

Evite colocar em `src/domain`:

- `express`
- `multer`
- `req` e `res`
- detalhes de `TypeORM`
- clients de AWS
- logging técnico
- configuração de infraestrutura

Essas dependências devem ficar em `src/http` ou `src/infrastructure`.

## Regra prática

Se o código puder ser testado sem conhecer a camada HTTP, ele provavelmente pertence a `src/domain`.

Se o código resolver um problema do negócio, mas estiver amarrado a banco, rede ou framework, ele ainda precisa ser extraído para cá.
