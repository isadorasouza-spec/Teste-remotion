import { randomBytes, createHash } from "node:crypto";
import { IsNull, MoreThan } from "typeorm";
import {
  authenticateCognitoUser,
  completeCognitoNewPasswordChallenge,
  confirmCognitoPasswordReset,
  createCognitoUserInProvider,
  type CriarUsuarioCognitoOpcoes,
  deleteCognitoUserInProvider,
  getCognitoUserFromAccessToken,
  requestCognitoPasswordReset,
} from "../../infrastructure/security/cognito-auth.client.js";
import { AppDataSource } from "../../database/data-source.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Sessao } from "../../database/modules/public/entities/sessao.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import { buildEscritorioSchemaName } from "../../database/tenant-naming.js";
import { settings } from "../../settings.js";

export const AUTH_COOKIE_NAME = "blueaccount_session_id";
const SESSION_TTL_SECONDS = 60 * 60 * 24;
export const INTERNAL_AGENT_SESSION_TTL_SECONDS = 10 * 60;

export type UsuarioComEscritorioResumo = {
  id: string;
  nome: string;
  email: string;
  cognito_sub: string | null;
  admin_escritorio: boolean;
  papel: "administrador" | "operador" | "consulta";
  ativo: boolean;
  escritorio: {
    id: string;
    nome: string;
    ativo: boolean;
    provedor_ia: "chatgpt" | "claude";
    modo_plataforma: "escritorio" | "empresa";
    locale: "pt" | "en";
  } | null;
};

type AuthenticatedSession = {
  email: string | null;
  sub: string | null;
  usuario: UsuarioComEscritorioResumo;
};

export type ApplicationSessionContext = {
  id: string;
  usuario_id: string;
  escritorio_id: string;
  schema_name: string;
  expires_at: Date;
  revoked_at: Date | null;
  last_seen_at: Date | null;
  created_at: Date;
  reautenticado_em: Date | null;
  usuario: UsuarioComEscritorioResumo;
};

export async function ensureDatabase() {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

export function normalizeEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return normalized || null;
}

function isE2eLocalAuthEnabled(): boolean {
  const value = settings.KONTIVA_E2E_LOCAL_AUTH.trim().toLowerCase();
  const enabled = value === "true" || value === "1" || value === "yes" || value === "on";
  if (enabled && isProduction()) {
    throw new Error("KONTIVA_E2E_LOCAL_AUTH não pode ser habilitada com NODE_ENV=production.");
  }
  return enabled;
}

export function decodeJwtPayload(token: string): Record<string, unknown> {
  const parts = String(token || "").split(".");
  if (parts.length < 2) {
    throw new Error("JWT inválido.");
  }

  const payload = parts[1]
    .replace(/-/g, "+")
    .replace(/_/g, "/");
  const padded = payload.padEnd(Math.ceil(payload.length / 4) * 4, "=");

  try {
    const decoded = Buffer.from(padded, "base64").toString("utf8");
    const parsed = JSON.parse(decoded);
    if (!parsed || typeof parsed !== "object") {
      throw new Error("JWT inválido.");
    }
    return parsed as Record<string, unknown>;
  } catch {
    throw new Error("JWT inválido.");
  }
}

function isProduction(): boolean {
  return settings.IS_PRODUCTION;
}

export function parseCookieHeader(header: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!header) return cookies;

  for (const chunk of header.split(";")) {
    const part = chunk.trim();
    if (!part) continue;
    const eq = part.indexOf("=");
    if (eq === -1) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (key) cookies[key] = decodeURIComponent(value);
  }

  return cookies;
}

export function buildAuthCookie(value: string, maxAgeSeconds = 60 * 60 * 24): string {
  const parts = [
    `${AUTH_COOKIE_NAME}=${encodeURIComponent(value)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAgeSeconds}`,
  ];

  if (isProduction()) {
    parts.push("Secure");
  }

  return parts.join("; ");
}

export function buildClearAuthCookie(): string {
  const parts = [
    `${AUTH_COOKIE_NAME}=`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    "Max-Age=0",
  ];

  if (isProduction()) {
    parts.push("Secure");
  }

  return parts.join("; ");
}

export function extractAuthToken(req: { headers: { cookie?: string; authorization?: string | string[] | undefined }; body?: any }): string {
  const cookieToken = parseCookieHeader(req.headers.cookie)?.[AUTH_COOKIE_NAME]?.trim();
  if (cookieToken) return cookieToken;

  const authHeader = typeof req.headers.authorization === "string" ? req.headers.authorization : "";
  if (authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }

  const bodyToken =
    (typeof req.body?.token === "string" ? req.body.token.trim() : "") ||
    (typeof req.body?.id_token === "string" ? req.body.id_token.trim() : "");

  return bodyToken;
}

export function generateSessionId(): string {
  return randomBytes(32).toString("base64url");
}

export function hashSessionId(sessionId: string): string {
  return createHash("sha256").update(sessionId).digest("hex");
}

export const INATIVIDADE_SESSAO_MS = {
  administrador: 30 * 60 * 1000,
  operador: 24 * 60 * 60 * 1000,
  consulta: 24 * 60 * 60 * 1000,
} as const;

async function findSessionByHash(
  sessionIdHash: string,
  opções: { aplicarInatividade?: boolean } = {},
): Promise<Sessao | null> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(Sessao);
  const session = await repo.findOne({
    where: { session_id_hash: sessionIdHash },
    relations: ["usuario", "escritorio", "usuario.escritorio"],
  });

  if (!session) return null;
  if (session.revoked_at) return null;
  if (session.expires_at.getTime() <= Date.now()) return null;
  if (opções.aplicarInatividade === false) return session;
  const papel = session.usuario?.papel ?? (session.usuario?.admin_escritorio ? "administrador" : "operador");
  const limiteInatividade = INATIVIDADE_SESSAO_MS[papel] ?? INATIVIDADE_SESSAO_MS.operador;
  const ultimaAtividade = session.last_seen_at ?? session.created_at;
  if (ultimaAtividade.getTime() <= Date.now() - limiteInatividade) {
    await repo.update(session.id, { revoked_at: new Date() });
    return null;
  }

  return session;
}

function mapSessionToContext(session: Sessao): ApplicationSessionContext {
  const usuario = session.usuario && typeof session.usuario === "object"
    ? {
        id: session.usuario.id,
        nome: session.usuario.nome,
        email: session.usuario.email,
        cognito_sub: session.usuario.cognito_sub,
        admin_escritorio: session.usuario.admin_escritorio,
        papel: session.usuario.papel ?? (session.usuario.admin_escritorio ? "administrador" : "operador"),
        ativo: session.usuario.ativo,
        escritorio: session.usuario.escritorio
          ? {
              id: session.usuario.escritorio.id,
              nome: session.usuario.escritorio.nome,
              ativo: session.usuario.escritorio.ativo,
              provedor_ia: (session.usuario.escritorio.provedor_ia === "claude" ? "claude" : "chatgpt") as "chatgpt" | "claude",
              modo_plataforma: (session.usuario.escritorio.modo_plataforma === "empresa" ? "empresa" : "escritorio") as "empresa" | "escritorio",
              locale: (session.usuario.escritorio.locale === "en" ? "en" : "pt") as "pt" | "en",
            }
          : null,
      }
    : null;

  if (!usuario) {
    throw new Error("Sessão da aplicação sem usuário associado.");
  }

  return {
    id: session.id,
    usuario_id: session.usuario_id,
    escritorio_id: session.escritorio_id,
    schema_name: buildEscritorioSchemaName(session.escritorio_id),
    expires_at: session.expires_at,
    revoked_at: session.revoked_at,
    last_seen_at: session.last_seen_at,
    created_at: session.created_at,
    reautenticado_em: session.reautenticado_em ?? null,
    usuario,
  };
}

async function findUsuarioComEscritorioByEmail(email: string): Promise<UsuarioComEscritorioResumo | null> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(Usuario);
  const usuario = await repo.findOne({
    where: { email },
    relations: ["escritorio"],
  });

  if (!usuario) return null;

  return {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    cognito_sub: usuario.cognito_sub,
    admin_escritorio: usuario.admin_escritorio,
    papel: usuario.papel ?? (usuario.admin_escritorio ? "administrador" : "operador"),
    ativo: usuario.ativo,
    escritorio: usuario.escritorio
      ? {
          id: usuario.escritorio.id,
          nome: usuario.escritorio.nome,
          ativo: usuario.escritorio.ativo,
          provedor_ia: usuario.escritorio.provedor_ia === "claude" ? "claude" : "chatgpt",
          modo_plataforma: usuario.escritorio.modo_plataforma === "empresa" ? "empresa" : "escritorio",
          locale: usuario.escritorio.locale === "en" ? "en" : "pt",
        }
      : null,
  };
}

export async function resolveUsuarioComEscritorioByEmail(email: string): Promise<UsuarioComEscritorioResumo | null> {
  const normalized = normalizeEmail(email);
  if (!normalized) return null;
  return findUsuarioComEscritorioByEmail(normalized);
}

async function findUsuarioComEscritorioBySub(cognitoSub: string): Promise<UsuarioComEscritorioResumo | null> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(Usuario);
  const usuario = await repo.findOne({
    where: { cognito_sub: cognitoSub },
    relations: ["escritorio"],
  });

  if (!usuario) return null;

  return {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    cognito_sub: usuario.cognito_sub,
    admin_escritorio: usuario.admin_escritorio,
    papel: usuario.papel ?? (usuario.admin_escritorio ? "administrador" : "operador"),
    ativo: usuario.ativo,
    escritorio: usuario.escritorio
      ? {
          id: usuario.escritorio.id,
          nome: usuario.escritorio.nome,
          ativo: usuario.escritorio.ativo,
          provedor_ia: usuario.escritorio.provedor_ia === "claude" ? "claude" : "chatgpt",
          modo_plataforma: usuario.escritorio.modo_plataforma === "empresa" ? "empresa" : "escritorio",
          locale: usuario.escritorio.locale === "en" ? "en" : "pt",
        }
      : null,
  };
}

export async function createApplicationSession(input: {
  usuario: UsuarioComEscritorioResumo;
  userAgent?: string | null;
  ipAddress?: string | null;
  ttlSeconds?: number;
}): Promise<{ session: ApplicationSessionContext; cookie: string; sessionId: string }> {
  await ensureDatabase();

  if (!input.usuario.escritorio?.id) {
    throw new Error("Usuário autenticado não possui escritório associado.");
  }

  const sessionId = generateSessionId();
  const sessionIdHash = hashSessionId(sessionId);
  const ttlSeconds = input.ttlSeconds ?? SESSION_TTL_SECONDS;
  const expiresAt = new Date(Date.now() + ttlSeconds * 1000);

  const repo = AppDataSource.getRepository(Sessao);
  const saved = await repo.save(repo.create({
    session_id_hash: sessionIdHash,
    usuario_id: input.usuario.id,
    escritorio_id: input.usuario.escritorio.id,
    expires_at: expiresAt,
    revoked_at: null,
    last_seen_at: new Date(),
    user_agent: input.userAgent?.trim() || null,
    ip_address: input.ipAddress?.trim() || null,
  }));

  const session = await findSessionByHash(saved.session_id_hash);
  if (!session) {
    throw new Error("Não foi possível criar a sessão da aplicação.");
  }

  return {
    session: mapSessionToContext(session),
    cookie: buildAuthCookie(sessionId, ttlSeconds),
    sessionId,
  };
}

export async function createApplicationSessionForEscritorio(input: {
  escritorioId: string;
  userAgent?: string | null;
  ipAddress?: string | null;
  ttlSeconds?: number;
}): Promise<{ session: ApplicationSessionContext; sessionId: string }> {
  await ensureDatabase();

  const escritorioId = input.escritorioId.trim();
  if (!escritorioId) {
    throw new Error("escritorio_id é obrigatório.");
  }

  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  const escritorio = await escritorioRepo.findOne({
    where: { id: escritorioId },
    relations: ["ai_user"],
  });
  if (!escritorio || !escritorio.ativo) {
    throw new Error("Escritório não encontrado ou inativo.");
  }

  const usuario = await ensureAiUserForEscritorio(escritorio);

  const appSession = await createApplicationSession({
    usuario: mapUsuarioEntityToResumo(usuario, escritorio),
    userAgent: input.userAgent ?? null,
    ipAddress: input.ipAddress ?? null,
    ttlSeconds: input.ttlSeconds ?? INTERNAL_AGENT_SESSION_TTL_SECONDS,
  });

  return {
    session: appSession.session,
    sessionId: appSession.sessionId,
  };
}

export async function ensureAiUserForEscritorio(escritorio: Escritorio): Promise<Usuario> {
  const existingAiUser = escritorio.ai_user as Usuario | null;
  if (existingAiUser?.ativo && !existingAiUser.deleted_at) {
    return existingAiUser;
  }

  const usuarioRepo = AppDataSource.getRepository(Usuario);
  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  const email = buildAiUserEmail(escritorio.id);
  let usuario = await usuarioRepo.findOne({
    where: { email },
    relations: ["escritorio"],
  });

  if (!usuario) {
    usuario = await usuarioRepo.save(usuarioRepo.create({
      escritorio_id: escritorio.id,
      nome: "Kontiva AI",
      email,
      cognito_sub: null,
      admin_escritorio: false,
      papel: "operador",
      ativo: true,
      deleted_at: null,
    }));
  } else if (!usuario.ativo || usuario.deleted_at) {
    await usuarioRepo.update(usuario.id, {
      ativo: true,
      deleted_at: null,
      nome: usuario.nome || "Kontiva AI",
    });
    usuario.ativo = true;
    usuario.deleted_at = null;
    usuario.nome = usuario.nome || "Kontiva AI";
  }

  if (escritorio.ai_user_id !== usuario.id) {
    await escritorioRepo.update(escritorio.id, { ai_user_id: usuario.id });
    escritorio.ai_user_id = usuario.id;
  }

  usuario.escritorio = escritorio;
  return usuario;
}

function buildAiUserEmail(escritorioId: string): string {
  return `ai+${escritorioId}@internal.kontiva.ai`;
}

function mapUsuarioEntityToResumo(usuario: Usuario, escritorio: Escritorio): UsuarioComEscritorioResumo {
  return {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    cognito_sub: usuario.cognito_sub,
    admin_escritorio: usuario.admin_escritorio,
    papel: usuario.papel ?? (usuario.admin_escritorio ? "administrador" : "operador"),
    ativo: usuario.ativo,
    escritorio: {
      id: escritorio.id,
      nome: escritorio.nome,
      ativo: escritorio.ativo,
      provedor_ia: escritorio.provedor_ia === "claude" ? "claude" : "chatgpt",
      modo_plataforma: escritorio.modo_plataforma === "empresa" ? "empresa" : "escritorio",
      locale: escritorio.locale === "en" ? "en" : "pt",
    },
  };
}

export async function createApplicationSessionForEmail(input: {
  email: string;
  userAgent?: string | null;
  ipAddress?: string | null;
}): Promise<{ session: ApplicationSessionContext; cookie: string }> {
  const normalized = normalizeEmail(input.email);
  if (!normalized) {
    throw new Error("E-mail Google ausente.");
  }

  const usuario = await findUsuarioComEscritorioByEmail(normalized);
  if (!usuario || !usuario.ativo || !usuario.escritorio?.ativo) {
    throw new Error("Conta Google sem usuário ativo vinculado a um escritório Kontiva.");
  }

  return createApplicationSession({
    usuario,
    userAgent: input.userAgent ?? null,
    ipAddress: input.ipAddress ?? null,
  });
}

export async function resolveApplicationSessionFromId(sessionId: string): Promise<ApplicationSessionContext | null> {
  if (!sessionId) return null;

  const session = await findSessionByHash(hashSessionId(sessionId));
  return touchAndMapApplicationSession(session);
}

/**
 * Resolve pelo hash da sessão — caminho exclusivo do OAuth (authorization code,
 * refresh e access token guardam o `session_id_hash` da sessão que os originou).
 *
 * A expiração por inatividade **não** se aplica aqui: um conector MCP
 * (Claude/ChatGPT) fica legitimamente parado por horas e a revogação da linha em
 * `sessoes` derrubaria a família de tokens inteira no próximo refresh
 * (`expired_session`), forçando novo consentimento OAuth. Para esses clientes o
 * prazo é o TTL/rotação do próprio token OAuth. As sessões de cookie continuam
 * sujeitas ao limite de inatividade em `resolveApplicationSessionFromId`.
 */
export async function resolveApplicationSessionFromHash(sessionIdHash: string): Promise<ApplicationSessionContext | null> {
  if (!sessionIdHash) return null;

  const session = await findSessionByHash(sessionIdHash, { aplicarInatividade: false });
  return touchAndMapApplicationSession(session);
}

async function touchAndMapApplicationSession(session: Sessao | null): Promise<ApplicationSessionContext | null> {
  if (!session) return null;

  const now = new Date();
  const repo = AppDataSource.getRepository(Sessao);
  await repo.update(session.id, { last_seen_at: now });
  session.last_seen_at = now;

  return mapSessionToContext(session);
}

export async function revokeApplicationSessionFromId(sessionId: string): Promise<void> {
  if (!sessionId) return;

  const repo = AppDataSource.getRepository(Sessao);
  const session = await findSessionByHash(hashSessionId(sessionId));
  if (!session) return;

  await repo.update(session.id, { revoked_at: new Date() });
}

/**
 * Revoga TODAS as sessões ativas do usuário dono da sessão informada
 * ("sign out everywhere"). Resolve o usuário a partir do hash do token —
 * sem o filtro de findSessionByHash — para funcionar mesmo que a sessão
 * atual já tenha expirado.
 */
export async function revokeAllApplicationSessionsFromId(sessionId: string): Promise<void> {
  if (!sessionId) return;

  await ensureDatabase();
  const repo = AppDataSource.getRepository(Sessao);
  const current = await repo.findOne({ where: { session_id_hash: hashSessionId(sessionId) } });
  if (!current) return;

  await repo.update(
    { usuario_id: current.usuario_id, revoked_at: IsNull() },
    { revoked_at: new Date() },
  );
}

/** Marca a sessão como reautenticada agora (step-up auth confirmado). */
export async function registrarReautenticacaoSessao(sessionId: string): Promise<void> {
  await ensureDatabase();
  await AppDataSource.getRepository(Sessao).update(
    { session_id_hash: hashSessionId(sessionId) },
    { reautenticado_em: new Date() },
  );
}

export async function revokeAllApplicationSessionsByEmail(email: string): Promise<void> {
  const normalized = normalizeEmail(email);
  if (!normalized) return;
  await ensureDatabase();
  const usuario = await AppDataSource.getRepository(Usuario).findOneBy({ email: normalized });
  if (!usuario) return;
  await AppDataSource.getRepository(Sessao).update(
    { usuario_id: usuario.id, revoked_at: IsNull() },
    { revoked_at: new Date() },
  );
}

export type AdminApplicationSessionView = {
  id: string;
  usuario_id: string;
  usuario_nome: string | null;
  usuario_email: string | null;
  escritorio_id: string;
  escritorio_nome: string | null;
  ip_address: string | null;
  user_agent: string | null;
  last_seen_at: Date | null;
  expires_at: Date;
  created_at: Date;
};

export async function listApplicationSessions(): Promise<AdminApplicationSessionView[]> {
  await ensureDatabase();

  const repo = AppDataSource.getRepository(Sessao);
  const sessions = await repo.find({
    where: { revoked_at: IsNull(), expires_at: MoreThan(new Date()) },
    relations: ["usuario", "escritorio"],
    order: { created_at: "DESC" },
  });

  return sessions.map((session) => ({
    id: session.id,
    usuario_id: session.usuario_id,
    usuario_nome: session.usuario?.nome ?? null,
    usuario_email: session.usuario?.email ?? null,
    escritorio_id: session.escritorio_id,
    escritorio_nome: session.escritorio?.nome ?? null,
    ip_address: session.ip_address,
    user_agent: session.user_agent,
    last_seen_at: session.last_seen_at,
    expires_at: session.expires_at,
    created_at: session.created_at,
  }));
}

export async function revokeApplicationSessionByEntityId(id: string): Promise<boolean> {
  if (!id) return false;

  await ensureDatabase();
  const repo = AppDataSource.getRepository(Sessao);
  const session = await repo.findOne({ where: { id } });
  if (!session) return false;

  if (!session.revoked_at) {
    await repo.update(session.id, { revoked_at: new Date() });
  }
  return true;
}

export async function resolveSessionUserFromAccessToken(accessToken: string): Promise<AuthenticatedSession> {
  if (!accessToken) {
    throw new Error("Token de acesso ausente.");
  }

  const { email, sub } = await getCognitoUserFromAccessToken(accessToken);
  const usuario =
    (email ? await findUsuarioComEscritorioByEmail(email) : null) ??
    (sub ? await findUsuarioComEscritorioBySub(sub) : null);

  if (!usuario) {
    throw new Error("Usuário autenticado no Cognito não possui vínculo local em usuarios/escritorios.");
  }

  return {
    email,
    sub,
    usuario,
  };
}

export async function createCognitoUser(
  email: string,
  opcoes: CriarUsuarioCognitoOpcoes = {},
): Promise<string> {
  if (isE2eLocalAuthEnabled()) {
    return `local-e2e-${createHash("sha256").update(email).digest("hex").slice(0, 24)}`;
  }

  return createCognitoUserInProvider(email, opcoes);
}

export async function deleteCognitoUser(email: string): Promise<void> {
  if (isE2eLocalAuthEnabled()) return;

  await deleteCognitoUserInProvider(email);
}

export async function authenticateWithCognito(email: string, password: string) {
  if (isE2eLocalAuthEnabled()) {
    const expectedPassword = settings.E2E_USER_PASSWORD.trim();
    if (!expectedPassword) {
      throw new Error("E2E_USER_PASSWORD é obrigatória quando KONTIVA_E2E_LOCAL_AUTH está habilitada.");
    }

    const usuario = password === expectedPassword
      ? await findUsuarioComEscritorioByEmail(email)
      : null;
    if (!usuario) {
      const error = new Error("Credenciais inválidas.");
      error.name = "NotAuthorizedException";
      throw error;
    }

    return { usuario };
  }

  const response = await authenticateCognitoUser(email, password);
  if (response.kind === "challenge") {
    return {
      challengeName: response.challengeName,
      session: response.session,
      challengeParameters: response.challengeParameters,
    };
  }

  // Os tokens do Cognito (access/refresh) não são retornados: a sessão é
  // sustentada pelo cookie HttpOnly. O idToken é usado apenas aqui, para
  // resolver o usuário local a partir dos claims.
  const claims = decodeJwtPayload(response.idToken);
  const tokenEmail = normalizeEmail(claims.email);
  const tokenSub = typeof claims.sub === "string" ? claims.sub : null;
  const usuario =
    (tokenEmail ? await findUsuarioComEscritorioByEmail(tokenEmail) : null) ??
    (tokenSub ? await findUsuarioComEscritorioBySub(tokenSub) : null);

  if (!usuario) {
    throw new Error("Usuário autenticado no Cognito não possui vínculo local em usuarios/escritorios.");
  }

  return { usuario };
}

export async function completeNewPasswordChallenge(session: string, email: string, newPassword: string) {
  // Tokens do Cognito não são retornados (ver authenticateWithCognito).
  const idToken = await completeCognitoNewPasswordChallenge({ session, email, newPassword });
  const claims = decodeJwtPayload(idToken);
  const tokenEmail = normalizeEmail(claims.email);
  const tokenSub = typeof claims.sub === "string" ? claims.sub : null;
  const usuario =
    (tokenEmail ? await findUsuarioComEscritorioByEmail(tokenEmail) : null) ??
    (tokenSub ? await findUsuarioComEscritorioBySub(tokenSub) : null);

  if (!usuario) {
    throw new Error("Usuário autenticado no Cognito não possui vínculo local em usuarios/escritorios.");
  }

  return { usuario };
}

export async function requestPasswordReset(email: string): Promise<void> {
  await requestCognitoPasswordReset(email);
}

export async function confirmPasswordReset(email: string, code: string, newPassword: string): Promise<void> {
  await confirmCognitoPasswordReset(email, code, newPassword);
}
