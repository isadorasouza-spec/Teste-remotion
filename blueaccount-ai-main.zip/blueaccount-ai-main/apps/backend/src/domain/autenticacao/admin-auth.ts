import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { AppDataSource } from "../../database/data-source.js";
import { AdminSession } from "../../database/modules/public/entities/admin-session.entity.js";
import { settings } from "../../settings.js";

export const ADMIN_COOKIE_NAME = "blueaccount_admin_session";
const ADMIN_USERNAME = "admin";
const ADMIN_SESSION_TTL_SECONDS = 60 * 60 * 12;

export type AdminSessionContext = {
  id?: string;
  username: "admin";
  expires_at: Date;
  created_at: Date;
  reautenticado_em: Date | null;
};

function isProduction(): boolean {
  return settings.IS_PRODUCTION;
}

function getAdminPassword(): string {
  const password = settings.APPLICATION_ADMIN_PASSWORD.trim();
  if (!password) {
    throw new Error("Variável de ambiente APPLICATION_ADMIN_PASSWORD não configurada.");
  }
  return password;
}

export function validateAdminPasswordConfiguration(): void {
  if (isProduction() && getAdminPassword().length < 20) {
    throw new Error("APPLICATION_ADMIN_PASSWORD deve ter pelo menos 20 caracteres em produção.");
  }
}

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
  }
}

function generateSessionId(): string {
  return randomBytes(32).toString("base64url");
}

function hashSessionId(sessionId: string): string {
  return createHash("sha256").update(sessionId).digest("hex");
}

function buildCookieParts(value: string, maxAgeSeconds: number): string[] {
  const parts = [
    `${ADMIN_COOKIE_NAME}=${encodeURIComponent(value)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAgeSeconds}`,
  ];

  if (isProduction()) {
    parts.push("Secure");
  }

  return parts;
}

export function normalizeAdminUsername(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.trim().toLowerCase();
  return normalized === ADMIN_USERNAME ? ADMIN_USERNAME : null;
}

export function buildAdminAuthCookie(value: string, maxAgeSeconds = ADMIN_SESSION_TTL_SECONDS): string {
  return buildCookieParts(value, maxAgeSeconds).join("; ");
}

export function buildClearAdminAuthCookie(): string {
  return buildCookieParts("", 0).join("; ");
}

export function extractAdminAuthToken(req: {
  headers: { cookie?: string; authorization?: string | string[] | undefined };
  body?: any;
}): string {
  const cookies = parseCookieHeader(req.headers.cookie);
  const cookieToken = cookies[ADMIN_COOKIE_NAME]?.trim();
  if (cookieToken) return cookieToken;

  const authHeader = typeof req.headers.authorization === "string" ? req.headers.authorization : "";
  if (authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }

  const bodyToken =
    (typeof req.body?.token === "string" ? req.body.token.trim() : "") ||
    (typeof req.body?.session === "string" ? req.body.session.trim() : "");

  return bodyToken;
}

async function findAdminSessionByHash(sessionIdHash: string): Promise<AdminSession | null> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(AdminSession);
  const session = await repo.findOne({
    where: { session_id_hash: sessionIdHash },
  });

  if (!session) return null;
  if (session.username !== ADMIN_USERNAME) return null;
  if (session.revoked_at) return null;
  if (session.expires_at.getTime() <= Date.now()) return null;
  const ultimaAtividade = session.last_seen_at ?? session.created_at;
  if (ultimaAtividade.getTime() <= Date.now() - 30 * 60 * 1000) {
    await repo.update(session.id, { revoked_at: new Date() });
    return null;
  }

  return session;
}

export async function authenticateAdmin(
  username: string,
  password: string,
  input?: {
    userAgent?: string | null;
    ipAddress?: string | null;
    ttlSeconds?: number;
  },
): Promise<{ session: AdminSessionContext; cookie: string }> {
  validarCredenciaisAdmin(username, password);

  return criarSessaoAdmin(input);
}

export function validarCredenciaisAdmin(username: string, password: string): void {
  const normalizedUsername = normalizeAdminUsername(username);
  const suppliedDigest = createHash("sha256").update(password).digest();
  const expectedDigest = createHash("sha256").update(getAdminPassword()).digest();
  if (!normalizedUsername || !timingSafeEqual(suppliedDigest, expectedDigest)) {
    throw new Error("Credenciais inválidas.");
  }
}

export async function criarSessaoAdmin(input?: {
  userAgent?: string | null;
  ipAddress?: string | null;
  ttlSeconds?: number;
}): Promise<{ session: AdminSessionContext; cookie: string }> {

  await ensureDatabase();
  const sessionId = generateSessionId();
  const sessionIdHash = hashSessionId(sessionId);
  const ttlSeconds = input?.ttlSeconds ?? ADMIN_SESSION_TTL_SECONDS;
  const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
  const repo = AppDataSource.getRepository(AdminSession);

  await repo.save(repo.create({
    session_id_hash: sessionIdHash,
    username: ADMIN_USERNAME,
    expires_at: expiresAt,
    revoked_at: null,
    last_seen_at: new Date(),
    user_agent: input?.userAgent?.trim() || null,
    ip_address: input?.ipAddress?.trim() || null,
  }));

  return {
    session: {
      username: ADMIN_USERNAME,
      expires_at: expiresAt,
      created_at: new Date(),
      reautenticado_em: null,
    },
    cookie: buildAdminAuthCookie(sessionId, ttlSeconds),
  };
}

/**
 * Confirma a senha do admin da plataforma e marca a sessão como reautenticada.
 * Sem isto, o gate de ação crítica do `AdminGuard` só passaria nos 10 minutos
 * seguintes ao login, sem caminho de recuperação além de deslogar.
 */
export async function reautenticarAdmin(sessionToken: string, password: string): Promise<boolean> {
  if (!sessionToken) return false;
  const suppliedDigest = createHash("sha256").update(password).digest();
  const expectedDigest = createHash("sha256").update(getAdminPassword()).digest();
  if (!timingSafeEqual(suppliedDigest, expectedDigest)) return false;

  const session = await findAdminSessionByHash(hashSessionId(sessionToken));
  if (!session) return false;
  await AppDataSource.getRepository(AdminSession).update(session.id, { reautenticado_em: new Date() });
  return true;
}

export async function resolveAdminSessionFromId(sessionToken: string): Promise<AdminSessionContext | null> {
  if (!sessionToken) return null;

  const session = await findAdminSessionByHash(hashSessionId(sessionToken));
  if (!session) return null;

  const repo = AppDataSource.getRepository(AdminSession);
  await repo.update(session.id, { last_seen_at: new Date() });

  return {
    id: session.id,
    username: ADMIN_USERNAME,
    expires_at: session.expires_at,
    created_at: session.created_at,
    reautenticado_em: session.reautenticado_em ?? null,
  };
}

export async function revokeAdminSessionFromId(sessionToken: string): Promise<void> {
  if (!sessionToken) return;

  const session = await findAdminSessionByHash(hashSessionId(sessionToken));
  if (!session) return;

  const repo = AppDataSource.getRepository(AdminSession);
  await repo.update(session.id, { revoked_at: new Date() });
}

function parseCookieHeader(header: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!header) return cookies;

  for (const chunk of header.split(";")) {
    const part = chunk.trim();
    if (!part) continue;
    const eq = part.indexOf("=");
    if (eq === -1) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (key) cookies[key] = decodeURIComponent(value);
  }

  return cookies;
}
