import { beforeEach, describe, expect, it, vi } from "vitest";

const sessaoRepo = vi.hoisted(() => ({
  findOne: vi.fn(),
  update: vi.fn(),
}));

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: {
    isInitialized: true,
    initialize: vi.fn(),
    getRepository: vi.fn(() => sessaoRepo),
  },
}));

import {
  AUTH_COOKIE_NAME,
  buildAuthCookie,
  buildClearAuthCookie,
  decodeJwtPayload,
  extractAuthToken,
  generateSessionId,
  hashSessionId,
  normalizeEmail,
  parseCookieHeader,
  resolveApplicationSessionFromHash,
  resolveApplicationSessionFromId,
  revokeAllApplicationSessionsFromId,
} from "../autenticacao.service.js";

describe("autenticacao service", () => {
  it("normalizes email and cookie helpers", () => {
    expect(normalizeEmail("  Maria@Example.com ")).toBe("maria@example.com");
    expect(normalizeEmail(123)).toBeNull();
    expect(parseCookieHeader("foo=bar; token=a%20b").token).toBe("a b");
    expect(buildAuthCookie("abc")).toContain(`${AUTH_COOKIE_NAME}=abc`);
    expect(buildClearAuthCookie()).toContain("Max-Age=0");
  });

  it("extracts auth tokens from supported sources", () => {
    expect(extractAuthToken({ headers: { cookie: `${AUTH_COOKIE_NAME}=cookie-token` } })).toBe("cookie-token");
    expect(extractAuthToken({ headers: { authorization: "Bearer bearer-token" } })).toBe("bearer-token");
    expect(extractAuthToken({ headers: {}, body: { token: "body-token" } })).toBe("body-token");
  });

  it("handles JWT and session id helpers", () => {
    const payload = Buffer.from(JSON.stringify({ sub: "sub-1", email: "maria@example.com" })).toString("base64url");
    const token = `header.${payload}.sig`;
    expect(decodeJwtPayload(token)).toMatchObject({ sub: "sub-1", email: "maria@example.com" });

    const sessionId = generateSessionId();
    expect(sessionId.length).toBeGreaterThan(20);
    expect(hashSessionId("abc")).toHaveLength(64);
  });

  describe("revokeAllApplicationSessionsFromId", () => {
    beforeEach(() => {
      sessaoRepo.findOne.mockReset();
      sessaoRepo.update.mockReset();
    });

    it("revokes every active session of the session's owner, not just the current one", async () => {
      sessaoRepo.findOne.mockResolvedValue({ id: "sess-current", usuario_id: "user-1" });

      await revokeAllApplicationSessionsFromId("raw-token");

      expect(sessaoRepo.update).toHaveBeenCalledTimes(1);
      const [criteria, patch] = sessaoRepo.update.mock.calls[0];
      // Critério por usuário (todas as sessões ativas), não pelo id da sessão atual.
      expect(criteria).toMatchObject({ usuario_id: "user-1" });
      expect(criteria).toHaveProperty("revoked_at");
      expect(patch).toMatchObject({ revoked_at: expect.any(Date) });
    });

    it("does nothing when the token does not match any session", async () => {
      sessaoRepo.findOne.mockResolvedValue(null);

      await revokeAllApplicationSessionsFromId("raw-token");

      expect(sessaoRepo.update).not.toHaveBeenCalled();
    });

    it("ignores empty tokens", async () => {
      await revokeAllApplicationSessionsFromId("");

      expect(sessaoRepo.findOne).not.toHaveBeenCalled();
      expect(sessaoRepo.update).not.toHaveBeenCalled();
    });
  });

  describe("expiração por inatividade", () => {
    const sessaoParada = (papel: "administrador" | "operador", minutosParada: number) => ({
      id: "sess-1",
      session_id_hash: "hash-1",
      usuario_id: "user-1",
      escritorio_id: "office-1",
      expires_at: new Date(Date.now() + 60 * 60 * 1_000),
      revoked_at: null,
      created_at: new Date(Date.now() - 48 * 60 * 60 * 1_000),
      last_seen_at: new Date(Date.now() - minutosParada * 60 * 1_000),
      reautenticado_em: null,
      usuario: {
        id: "user-1",
        nome: "Maria",
        email: "maria@example.com",
        cognito_sub: "sub-1",
        admin_escritorio: papel === "administrador",
        papel,
        ativo: true,
        escritorio: { id: "office-1", nome: "Alpha", ativo: true },
      },
    });

    beforeEach(() => {
      sessaoRepo.findOne.mockReset();
      sessaoRepo.update.mockReset();
      sessaoRepo.update.mockResolvedValue({ affected: 1 });
    });


    it.each(["empresa", "escritorio"] as const)("propaga modo %s em sessões autenticadas sem alterar o tenant", async (modo) => {
      const sessao = sessaoParada("operador", 1);
      Object.assign(sessao.usuario.escritorio, { modo_plataforma: modo });
      sessaoRepo.findOne.mockResolvedValue(sessao);
      const resultado = await resolveApplicationSessionFromId("token");
      expect(resultado).toMatchObject({ escritorio_id: "office-1", usuario: { escritorio: { modo_plataforma: modo } } });
    });

    it("revoga a sessão de cookie de administrador parada há mais de 30 minutos", async () => {
      sessaoRepo.findOne.mockResolvedValue(sessaoParada("administrador", 31));

      await expect(resolveApplicationSessionFromId("raw-token")).resolves.toBeNull();
      expect(sessaoRepo.update).toHaveBeenCalledWith("sess-1", { revoked_at: expect.any(Date) });
    });

    it("mantém a sessão de cookie de operador dentro das 24 horas", async () => {
      sessaoRepo.findOne.mockResolvedValue(sessaoParada("operador", 60));

      await expect(resolveApplicationSessionFromId("raw-token")).resolves.not.toBeNull();
      expect(sessaoRepo.update).not.toHaveBeenCalledWith("sess-1", { revoked_at: expect.any(Date) });
    });

    it("não aplica inatividade na resolução por hash (conector OAuth/MCP)", async () => {
      // Regressão: revogar aqui derrubava a família de tokens no refresh seguinte e
      // obrigava o usuário a refazer todo o consentimento OAuth.
      sessaoRepo.findOne.mockResolvedValue(sessaoParada("administrador", 24 * 60));

      await expect(resolveApplicationSessionFromHash("hash-1")).resolves.not.toBeNull();
      expect(sessaoRepo.update).not.toHaveBeenCalledWith("sess-1", { revoked_at: expect.any(Date) });
    });
  });
});
