import { afterEach, describe, expect, it } from "vitest";
import { buildAdminAuthCookie, validateAdminPasswordConfiguration } from "../admin-auth.js";

const previousNodeEnv = process.env.NODE_ENV;
const previousPassword = process.env.APPLICATION_ADMIN_PASSWORD;

afterEach(() => {
  process.env.NODE_ENV = previousNodeEnv;
  process.env.APPLICATION_ADMIN_PASSWORD = previousPassword;
});

describe("admin authentication security", () => {
  it("rejects weak production administrator secrets", () => {
    process.env.NODE_ENV = "production";
    process.env.APPLICATION_ADMIN_PASSWORD = "too-short";
    expect(() => validateAdminPasswordConfiguration()).toThrow(/20 caracteres/);
  });

  it("accepts strong production secrets and always emits secure cookies", () => {
    process.env.NODE_ENV = "production";
    process.env.APPLICATION_ADMIN_PASSWORD = "a-strong-production-password";
    expect(() => validateAdminPasswordConfiguration()).not.toThrow();
    expect(buildAdminAuthCookie("session-id")).toContain("Secure");
    expect(buildAdminAuthCookie("session-id")).toContain("HttpOnly");
    expect(buildAdminAuthCookie("session-id")).toContain("SameSite=Lax");
  });
});
