import { describe, expect, it } from "vitest";
import { JANELA_REAUTENTICACAO_MS, exigeReautenticacao } from "../reautenticacao.js";

describe("exigeReautenticacao", () => {
  const agora = new Date("2026-08-14T12:00:00.000Z").getTime();
  const minutosAtras = (minutos: number) => new Date(agora - minutos * 60_000);

  it("libera logo após o login, sem reautenticação explícita", () => {
    expect(exigeReautenticacao({ created_at: minutosAtras(2), reautenticado_em: null }, agora)).toBe(false);
  });

  it("exige senha quando o login já passou da janela", () => {
    expect(exigeReautenticacao({ created_at: minutosAtras(11), reautenticado_em: null }, agora)).toBe(true);
  });

  it("aceita login antigo com reautenticação recente", () => {
    expect(exigeReautenticacao({ created_at: minutosAtras(600), reautenticado_em: minutosAtras(1) }, agora)).toBe(false);
  });

  it("volta a exigir quando a própria reautenticação envelhece", () => {
    expect(exigeReautenticacao({ created_at: minutosAtras(600), reautenticado_em: minutosAtras(11) }, agora)).toBe(true);
  });

  it("é fail-closed sem marco de tempo conhecido", () => {
    expect(exigeReautenticacao({}, agora)).toBe(true);
    expect(exigeReautenticacao({ created_at: null, reautenticado_em: null }, agora)).toBe(true);
  });

  it("usa exatamente a janela publicada", () => {
    const limite = new Date(agora - JANELA_REAUTENTICACAO_MS + 1);
    expect(exigeReautenticacao({ created_at: limite }, agora)).toBe(false);
    expect(exigeReautenticacao({ created_at: new Date(agora - JANELA_REAUTENTICACAO_MS - 1) }, agora)).toBe(true);
  });
});
