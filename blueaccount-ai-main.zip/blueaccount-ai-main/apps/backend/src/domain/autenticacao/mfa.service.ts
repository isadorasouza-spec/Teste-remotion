import { Inject, Injectable } from "@nestjs/common";
import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { IsNull, type EntityManager } from "typeorm";
import { AppDataSource } from "../../database/data-source.js";
import { DesafioMfa, type OrigemDesafioMfa } from "../../database/modules/public/entities/desafio-mfa.entity.js";
import { FatorMfaAdminPlataforma } from "../../database/modules/public/entities/fator-mfa-admin-plataforma.entity.js";
import { FatorMfaUsuario } from "../../database/modules/public/entities/fator-mfa-usuario.entity.js";
import { EventoAuditoriaSeguranca } from "../../database/modules/public/entities/evento-auditoria-seguranca.entity.js";
import { OAuthAccessToken } from "../../database/modules/public/entities/oauth-access-token.entity.js";
import { OAuthRefreshToken } from "../../database/modules/public/entities/oauth-refresh-token.entity.js";
import { Sessao } from "../../database/modules/public/entities/sessao.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import { CryptoService } from "../../infrastructure/security/crypto.service.js";
import { AgentLogger } from "../../infrastructure/logging/agent.logger.js";
import { settings } from "../../settings.js";
import { parseCookieHeader } from "./autenticacao.service.js";

export const MFA_CHALLENGE_COOKIE_NAME = "blueaccount_mfa_challenge";
export const MFA_CHALLENGE_TTL_SECONDS = 10 * 60;
export const MFA_MAX_TENTATIVAS = 5;
const TOTP_PERIODO_SEGUNDOS = 30;
const TOTP_DIGITOS = 6;
const ADMIN_USERNAME = "admin";
const logger = new AgentLogger("admin-usuarios");

export type MfaChallengeName = "MFA_SETUP_REQUIRED" | "MFA_REQUIRED";

export class MfaError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "MfaError";
  }
}

function base32Encode(input: Buffer): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0;
  let value = 0;
  let output = "";
  for (const byte of input) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) output += alphabet[(value << (5 - bits)) & 31];
  return output;
}

function base32Decode(input: string): Buffer {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0;
  let value = 0;
  const output: number[] = [];
  for (const char of input.toUpperCase().replace(/=+$/g, "")) {
    const index = alphabet.indexOf(char);
    if (index < 0) throw new Error("Segredo TOTP inválido.");
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(output);
}

function gerarCodigoParaPasso(segredo: string, passo: number): string {
  const contador = Buffer.alloc(8);
  contador.writeBigUInt64BE(BigInt(passo));
  const digest = createHmac("sha1", base32Decode(segredo)).update(contador).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binario = (digest.readUInt32BE(offset) & 0x7fffffff) % (10 ** TOTP_DIGITOS);
  return String(binario).padStart(TOTP_DIGITOS, "0");
}

export function gerarSegredoTotp(): string {
  return base32Encode(randomBytes(20));
}

export function validarCodigoTotp(
  segredo: string,
  codigo: string,
  agora = Date.now(),
  ultimoPassoAceito: string | null = null,
): number | null {
  if (!/^\d{6}$/.test(codigo)) return null;
  const passoAtual = Math.floor(agora / 1000 / TOTP_PERIODO_SEGUNDOS);
  for (const passo of [passoAtual - 1, passoAtual, passoAtual + 1]) {
    const esperado = Buffer.from(gerarCodigoParaPasso(segredo, passo));
    const recebido = Buffer.from(codigo);
    if (esperado.length === recebido.length && timingSafeEqual(esperado, recebido)) {
      if (ultimoPassoAceito !== null && BigInt(passo) <= BigInt(ultimoPassoAceito)) return null;
      return passo;
    }
  }
  return null;
}

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function buildChallengeCookie(value: string, maxAgeSeconds: number): string {
  const parts = [
    `${MFA_CHALLENGE_COOKIE_NAME}=${encodeURIComponent(value)}`,
    "Path=/api",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (settings.IS_PRODUCTION) parts.push("Secure");
  return parts.join("; ");
}

export function buildClearMfaChallengeCookie(): string {
  return buildChallengeCookie("", 0);
}

export function extractMfaChallengeToken(req: { headers: { cookie?: string } }): string {
  return parseCookieHeader(req.headers.cookie)[MFA_CHALLENGE_COOKIE_NAME]?.trim() ?? "";
}

function safeReturnTo(value: string | null | undefined): string | null {
  if (!value || !value.startsWith("/") || value.length > 2048) return null;
  let decoded: string;
  try { decoded = decodeURIComponent(value); } catch { return null; }
  if (decoded.startsWith("//") || decoded.includes("\\") || /[\u0000-\u001f\u007f]/.test(decoded)) return null;
  const parsed = new URL(value, "https://kontiva.invalid");
  if (parsed.origin !== "https://kontiva.invalid") return null;
  return `${parsed.pathname}${parsed.search}${parsed.hash}`;
}

@Injectable()
export class MfaService {
  constructor(@Inject(CryptoService) private readonly crypto: CryptoService) {}

  isRequired(): boolean {
    return settings.MFA_REQUIRED;
  }

  async iniciarDesafioUsuario(input: {
    usuario: { id: string; email: string };
    origem: Exclude<OrigemDesafioMfa, "admin">;
    returnTo?: string | null;
  }) {
    await this.ensureDatabase();
    const factor = await AppDataSource.getRepository(FatorMfaUsuario).findOneBy({ usuario_id: input.usuario.id });
    return this.criarDesafio({
      usuarioId: input.usuario.id,
      adminUsername: null,
      conta: input.usuario.email,
      origem: input.origem,
      cadastro: !factor,
      returnTo: safeReturnTo(input.returnTo),
    });
  }

  async iniciarDesafioAdmin() {
    await this.ensureDatabase();
    const factor = await AppDataSource.getRepository(FatorMfaAdminPlataforma).findOneBy({ username: ADMIN_USERNAME });
    return this.criarDesafio({
      usuarioId: null,
      adminUsername: ADMIN_USERNAME,
      conta: "admin@kontiva.ai",
      origem: "admin",
      cadastro: !factor,
      returnTo: "/admin",
    });
  }

  async contexto(token: string, tipo: "usuario" | "admin") {
    const desafio = await this.buscarDesafioValido(token, tipo);
    const base = {
      challenge_name: desafio.finalidade === "cadastro" ? "MFA_SETUP_REQUIRED" : "MFA_REQUIRED",
      expires_at: desafio.expires_at.toISOString(),
      return_to: desafio.return_to,
    } as Record<string, unknown>;
    if (desafio.finalidade === "cadastro") {
      const segredo = this.decryptPendingSecret(desafio);
      const conta = desafio.usuario_id
        ? (await AppDataSource.getRepository(Usuario).findOneByOrFail({ id: desafio.usuario_id })).email
        : "admin@kontiva.ai";
      base.secret = segredo;
      base.otpauth_uri = `otpauth://totp/${encodeURIComponent(`Kontiva:${conta}`)}?secret=${encodeURIComponent(segredo)}&issuer=Kontiva&algorithm=SHA1&digits=6&period=30`;
    }
    return base;
  }

  async verificarUsuario(token: string, codigo: unknown): Promise<Usuario> {
    const result = await this.verificar(token, codigo, "usuario");
    return result.usuario!;
  }

  async verificarAdmin(token: string, codigo: unknown): Promise<void> {
    await this.verificar(token, codigo, "admin");
  }

  async validarSegundoFatorUsuario(usuarioId: string, codigo: unknown): Promise<boolean> {
    return this.validarFatorAtivoUsuario(usuarioId, codigo);
  }

  async validarSegundoFatorAdmin(codigo: unknown): Promise<boolean> {
    return this.validarFatorAtivoAdmin(codigo);
  }

  async statusUsuarios(usuarioIds: string[]): Promise<Map<string, "pending" | "active">> {
    await this.ensureDatabase();
    if (usuarioIds.length === 0) return new Map();
    const rows = await AppDataSource.getRepository(FatorMfaUsuario)
      .createQueryBuilder("f")
      .select("f.usuario_id", "usuario_id")
      .where("f.usuario_id IN (:...ids)", { ids: usuarioIds })
      .getRawMany<{ usuario_id: string }>();
    const ativos = new Set(rows.map((row) => row.usuario_id));
    return new Map(usuarioIds.map((id) => [id, ativos.has(id) ? "active" : "pending"]));
  }

  async resetarUsuario(usuarioId: string): Promise<boolean> {
    await this.ensureDatabase();
    const usuario = await AppDataSource.getRepository(Usuario).findOneBy({ id: usuarioId, deleted_at: IsNull() });
    if (!usuario) return false;
    const now = new Date();
    await AppDataSource.transaction(async (manager) => {
      await manager.getRepository(FatorMfaUsuario).delete({ usuario_id: usuarioId });
      await manager.getRepository(DesafioMfa).delete({ usuario_id: usuarioId });
      await manager.getRepository(Sessao).update({ usuario_id: usuarioId, revoked_at: IsNull() }, { revoked_at: now });
      await manager.getRepository(OAuthAccessToken).update({ usuario_id: usuarioId, revoked_at: IsNull() }, { revoked_at: now });
      await manager.getRepository(OAuthRefreshToken).update({ usuario_id: usuarioId, revoked_at: IsNull() }, { revoked_at: now });
      await this.registrarAuditoria(manager, "mfa_reset", "usuario", usuarioId, "sucesso");
    });
    logger.info("mfa_usuario_resetado", { usuario_id: usuarioId });
    return true;
  }

  private async criarDesafio(input: {
    usuarioId: string | null;
    adminUsername: "admin" | null;
    conta: string;
    origem: OrigemDesafioMfa;
    cadastro: boolean;
    returnTo: string | null;
  }) {
    const token = randomBytes(32).toString("base64url");
    const expiresAt = new Date(Date.now() + MFA_CHALLENGE_TTL_SECONDS * 1000);
    const segredo = input.cadastro ? gerarSegredoTotp() : null;
    const encrypted = segredo ? this.crypto.encrypt(segredo) : null;
    await AppDataSource.transaction(async (manager) => {
      const identidadeLock = input.usuarioId ? `usuario:${input.usuarioId}` : "admin:admin";
      await manager.query("SELECT pg_advisory_xact_lock(hashtext($1))", [`mfa:${identidadeLock}`]);
      const repo = manager.getRepository(DesafioMfa);
      if (input.usuarioId) {
        await repo.update({ usuario_id: input.usuarioId, consumido_em: IsNull() }, { consumido_em: new Date() });
      } else {
        await repo.update({ admin_username: ADMIN_USERNAME, consumido_em: IsNull() }, { consumido_em: new Date() });
      }
      await repo.save(repo.create({
        token_hash: hashToken(token),
        usuario_id: input.usuarioId,
        admin_username: input.adminUsername,
        finalidade: input.cadastro ? "cadastro" : "verificacao",
        origem: input.origem,
        segredo_pendente_encrypted: encrypted?.ciphertext ?? null,
        segredo_pendente_iv: encrypted?.iv ?? null,
        segredo_pendente_tag: encrypted?.tag ?? null,
        return_to: input.returnTo,
        tentativas: 0,
        expires_at: expiresAt,
        consumido_em: null,
      }));
    });
    return {
      cookie: buildChallengeCookie(token, MFA_CHALLENGE_TTL_SECONDS),
      challengeName: (input.cadastro ? "MFA_SETUP_REQUIRED" : "MFA_REQUIRED") as MfaChallengeName,
      expiresAt,
    };
  }

  private async buscarDesafioValido(token: string, tipo: "usuario" | "admin"): Promise<DesafioMfa> {
    if (!token) throw new MfaError(401, "MFA_CHALLENGE_REQUIRED", "Desafio MFA ausente.");
    await this.ensureDatabase();
    const desafio = await AppDataSource.getRepository(DesafioMfa).findOne({
      where: {
        token_hash: hashToken(token),
        consumido_em: IsNull(),
      },
    });
    const tipoValido = tipo === "usuario" ? Boolean(desafio?.usuario_id) : desafio?.admin_username === ADMIN_USERNAME;
    if (!desafio || !tipoValido) throw new MfaError(401, "MFA_CHALLENGE_EXPIRED", "Desafio MFA inválido ou expirado.");
    if (desafio.expires_at.getTime() <= Date.now()) {
      await AppDataSource.getRepository(DesafioMfa).update({ id: desafio.id, consumido_em: IsNull() }, { consumido_em: new Date() });
      throw new MfaError(401, "MFA_CHALLENGE_EXPIRED", "Desafio MFA inválido ou expirado.");
    }
    if (desafio.tentativas >= MFA_MAX_TENTATIVAS) {
      await AppDataSource.getRepository(DesafioMfa).update({ id: desafio.id, consumido_em: IsNull() }, { consumido_em: new Date() });
      throw new MfaError(429, "MFA_ATTEMPTS_EXCEEDED", "Limite de tentativas excedido.");
    }
    return desafio;
  }

  private async verificar(token: string, codigoRaw: unknown, tipo: "usuario" | "admin") {
    const codigo = typeof codigoRaw === "string" ? codigoRaw.trim() : "";
    if (!/^\d{6}$/.test(codigo)) throw new MfaError(400, "MFA_CODE_INVALID", "Informe um código de seis dígitos.");
    const desafioInicial = await this.buscarDesafioValido(token, tipo);

    const resultado = await AppDataSource.transaction(async (manager) => {
      const desafio = await manager.getRepository(DesafioMfa).findOne({
        where: { id: desafioInicial.id },
        lock: { mode: "pessimistic_write" },
      });
      if (!desafio || desafio.consumido_em || desafio.expires_at.getTime() <= Date.now()) {
        throw new MfaError(401, "MFA_CHALLENGE_EXPIRED", "Desafio MFA inválido ou expirado.");
      }
      if (desafio.tentativas >= MFA_MAX_TENTATIVAS) {
        throw new MfaError(429, "MFA_ATTEMPTS_EXCEEDED", "Limite de tentativas excedido.");
      }

      let segredo: string;
      let ultimoPasso: string | null = null;
      let fatorUsuario: FatorMfaUsuario | null = null;
      let fatorAdmin: FatorMfaAdminPlataforma | null = null;
      if (desafio.finalidade === "cadastro") {
        segredo = this.decryptPendingSecret(desafio);
      } else if (tipo === "usuario") {
        fatorUsuario = await manager.getRepository(FatorMfaUsuario).findOne({
          where: { usuario_id: desafio.usuario_id! },
          lock: { mode: "pessimistic_write" },
        });
        if (!fatorUsuario) throw new MfaError(401, "MFA_SETUP_REQUIRED", "O segundo fator precisa ser configurado.");
        segredo = this.crypto.decrypt({ ciphertext: fatorUsuario.segredo_encrypted, iv: fatorUsuario.segredo_iv, tag: fatorUsuario.segredo_tag });
        ultimoPasso = fatorUsuario.ultimo_passo_aceito;
      } else {
        fatorAdmin = await manager.getRepository(FatorMfaAdminPlataforma).findOne({
          where: { username: ADMIN_USERNAME },
          lock: { mode: "pessimistic_write" },
        });
        if (!fatorAdmin) throw new MfaError(401, "MFA_SETUP_REQUIRED", "O segundo fator precisa ser configurado.");
        segredo = this.crypto.decrypt({ ciphertext: fatorAdmin.segredo_encrypted, iv: fatorAdmin.segredo_iv, tag: fatorAdmin.segredo_tag });
        ultimoPasso = fatorAdmin.ultimo_passo_aceito;
      }

      const passo = validarCodigoTotp(segredo, codigo, Date.now(), ultimoPasso);
      if (passo === null) {
        desafio.tentativas += 1;
        if (desafio.tentativas >= MFA_MAX_TENTATIVAS) desafio.consumido_em = new Date();
        await manager.getRepository(DesafioMfa).save(desafio);
        await this.registrarAuditoria(
          manager,
          "mfa_verificacao",
          tipo === "usuario" ? "usuario" : "admin_plataforma",
          desafio.usuario_id,
          "falha",
          { tentativas: desafio.tentativas, esgotado: desafio.tentativas >= MFA_MAX_TENTATIVAS },
        );
        logger.warn("mfa_verificacao_falhou", {
          usuario_id: desafio.usuario_id,
          tipo: tipo === "usuario" ? "usuario" : "admin_plataforma",
          tentativas: desafio.tentativas,
        });
        return {
          erro: new MfaError(
            desafio.tentativas >= MFA_MAX_TENTATIVAS ? 429 : 401,
            desafio.tentativas >= MFA_MAX_TENTATIVAS ? "MFA_ATTEMPTS_EXCEEDED" : "MFA_CODE_INVALID",
            desafio.tentativas >= MFA_MAX_TENTATIVAS ? "Limite de tentativas excedido." : "Código inválido.",
          ),
          usuario: null,
        };
      }

      const encrypted = this.crypto.encrypt(segredo);
      if (tipo === "usuario") {
        if (desafio.finalidade === "cadastro") {
          await manager.getRepository(FatorMfaUsuario).save(manager.getRepository(FatorMfaUsuario).create({
            usuario_id: desafio.usuario_id!,
            segredo_encrypted: encrypted.ciphertext,
            segredo_iv: encrypted.iv,
            segredo_tag: encrypted.tag,
            ultimo_passo_aceito: String(passo),
            ativado_em: new Date(),
          }));
          logger.info("mfa_usuario_ativado", { usuario_id: desafio.usuario_id });
          await this.registrarAuditoria(manager, "mfa_setup", "usuario", desafio.usuario_id, "sucesso");
        } else {
          fatorUsuario!.ultimo_passo_aceito = String(passo);
          await manager.getRepository(FatorMfaUsuario).save(fatorUsuario!);
        }
      } else if (desafio.finalidade === "cadastro") {
        await manager.getRepository(FatorMfaAdminPlataforma).save(manager.getRepository(FatorMfaAdminPlataforma).create({
          username: ADMIN_USERNAME,
          segredo_encrypted: encrypted.ciphertext,
          segredo_iv: encrypted.iv,
          segredo_tag: encrypted.tag,
          ultimo_passo_aceito: String(passo),
          ativado_em: new Date(),
        }));
        logger.info("mfa_admin_plataforma_ativado", { tipo: "admin_plataforma" });
        await this.registrarAuditoria(manager, "mfa_setup", "admin_plataforma", null, "sucesso");
      } else {
        fatorAdmin!.ultimo_passo_aceito = String(passo);
        await manager.getRepository(FatorMfaAdminPlataforma).save(fatorAdmin!);
      }

      desafio.consumido_em = new Date();
      await manager.getRepository(DesafioMfa).save(desafio);
      logger.info("mfa_verificacao_sucesso", {
        usuario_id: desafio.usuario_id,
        tipo: tipo === "usuario" ? "usuario" : "admin_plataforma",
      });
      await this.registrarAuditoria(
        manager,
        "mfa_verificacao",
        tipo === "usuario" ? "usuario" : "admin_plataforma",
        desafio.usuario_id,
        "sucesso",
        { origem: desafio.origem },
      );
      const usuario = desafio.usuario_id
        ? await manager.getRepository(Usuario).findOne({ where: { id: desafio.usuario_id }, relations: ["escritorio"] })
        : null;
      if (tipo === "usuario" && !usuario) throw new MfaError(401, "MFA_IDENTITY_INVALID", "Usuário não encontrado.");
      return { erro: null, usuario };
    });
    if (resultado.erro) throw resultado.erro;
    return { usuario: resultado.usuario };
  }

  private async validarFatorAtivoUsuario(usuarioId: string, codigoRaw: unknown): Promise<boolean> {
    const codigo = typeof codigoRaw === "string" ? codigoRaw.trim() : "";
    if (!/^\d{6}$/.test(codigo)) return false;
    await this.ensureDatabase();
    return AppDataSource.transaction(async (manager) => {
      const factor = await manager.getRepository(FatorMfaUsuario).findOne({
        where: { usuario_id: usuarioId },
        lock: { mode: "pessimistic_write" },
      });
      if (!factor) return false;
      const segredo = this.crypto.decrypt({ ciphertext: factor.segredo_encrypted, iv: factor.segredo_iv, tag: factor.segredo_tag });
      const passo = validarCodigoTotp(segredo, codigo, Date.now(), factor.ultimo_passo_aceito);
      if (passo === null) return false;
      factor.ultimo_passo_aceito = String(passo);
      await manager.getRepository(FatorMfaUsuario).save(factor);
      return true;
    });
  }

  private async validarFatorAtivoAdmin(codigoRaw: unknown): Promise<boolean> {
    const codigo = typeof codigoRaw === "string" ? codigoRaw.trim() : "";
    if (!/^\d{6}$/.test(codigo)) return false;
    await this.ensureDatabase();
    return AppDataSource.transaction(async (manager) => {
      const factor = await manager.getRepository(FatorMfaAdminPlataforma).findOne({
        where: { username: ADMIN_USERNAME },
        lock: { mode: "pessimistic_write" },
      });
      if (!factor) return false;
      const segredo = this.crypto.decrypt({ ciphertext: factor.segredo_encrypted, iv: factor.segredo_iv, tag: factor.segredo_tag });
      const passo = validarCodigoTotp(segredo, codigo, Date.now(), factor.ultimo_passo_aceito);
      if (passo === null) return false;
      factor.ultimo_passo_aceito = String(passo);
      await manager.getRepository(FatorMfaAdminPlataforma).save(factor);
      return true;
    });
  }

  private decryptPendingSecret(desafio: DesafioMfa): string {
    if (!desafio.segredo_pendente_encrypted || !desafio.segredo_pendente_iv || !desafio.segredo_pendente_tag) {
      throw new MfaError(401, "MFA_CHALLENGE_INVALID", "Desafio de cadastro inválido.");
    }
    return this.crypto.decrypt({
      ciphertext: desafio.segredo_pendente_encrypted,
      iv: desafio.segredo_pendente_iv,
      tag: desafio.segredo_pendente_tag,
    });
  }

  private async registrarAuditoria(
    manager: EntityManager,
    evento: string,
    identidadeTipo: "usuario" | "admin_plataforma",
    usuarioId: string | null,
    resultado: "sucesso" | "falha",
    metadados: Record<string, string | number | boolean | null> | null = null,
  ): Promise<void> {
    const repo = manager.getRepository(EventoAuditoriaSeguranca);
    await repo.save(repo.create({
      evento,
      identidade_tipo: identidadeTipo,
      usuario_id: usuarioId,
      resultado,
      metadados,
    }));
  }

  private async ensureDatabase(): Promise<void> {
    if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  }
}
