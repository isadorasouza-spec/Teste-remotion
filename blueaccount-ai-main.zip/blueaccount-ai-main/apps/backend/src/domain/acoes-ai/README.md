# `src/domain/acoes-ai`

Regra de negócio das **ações de IA**: sugestões/recomendações geradas por regras ou agentes que o escritório revisa e aciona.

## Responsabilidades

- listar ações de IA (com filtros e versão paginada) por escritório
- consultar uma ação e seu histórico de transições
- criar ação de IA
- atualizar campos e status da ação (com trilha de histórico)
- deletar ação
- gerar ações a partir de regras determinísticas (`gerarAcoesPorRegras`)
- criar de forma idempotente uma ação de revisão quando um contrato novo fica pronto para revisão

## Arquivos

- `acoes-ai.service.ts`: consultas, mutações, histórico, geração por regras e alertas determinísticos (usa `runQueryWithRls` sob a entidade `AcaoAi`)

## Gatilhos determinísticos

- `registrarAcaoContratoProntoParaRevisao()` cria uma ação `revisao_contrato` quando um documento de contrato já tem cliente e `payload_normalizado_ui` pronto para revisão.
- A idempotência usa `payload.motivo = "contrato_pronto_para_revisao"` e `payload.documento_id`, evitando duplicar ações abertas para o mesmo documento.

## Testes

- `tests/acoes-ai.service.test.ts`

## Regra prática

Se a lógica decide como uma ação de IA nasce, muda de status ou é listada para o escritório, ela pertence aqui. A camada Nest (`modules/agentes`) só orquestra HTTP.
