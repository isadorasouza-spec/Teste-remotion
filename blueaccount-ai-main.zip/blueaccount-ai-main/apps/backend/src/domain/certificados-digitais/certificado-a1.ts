import forge from "node-forge";

/**
 * Leitura de certificado digital A1 (PKCS#12) para uso em mTLS contra a SEFAZ.
 *
 * Domínio puro: só recebe bytes e senha, devolve metadados. Nada de Nest, HTTP, S3 ou banco.
 *
 * O Node não parseia PKCS#12 nativamente (`crypto.X509Certificate` só lê DER/PEM), por isso o
 * `node-forge`. A alternativa sem dependência (`tls.createSecureContext`) apenas valida a senha e
 * não entrega CNPJ nem validade — insuficiente para recusar certificado de CNPJ errado ou vencido.
 */

export type CodigoErroCertificadoA1 =
  | "PKCS12_ILEGIVEL"
  | "SENHA_INVALIDA"
  | "CERTIFICADO_AUSENTE"
  | "CERTIFICADO_SEM_CNPJ";

export class ErroCertificadoA1 extends Error {
  constructor(readonly codigo: CodigoErroCertificadoA1, mensagem: string) {
    super(mensagem);
    this.name = "ErroCertificadoA1";
  }
}

export type MetadadosCertificadoA1 = {
  /** Somente dígitos, extraído do CN. e-CNPJ ICP-Brasil traz o CN como `NOME:CNPJ`. */
  cnpj_titular: string;
  titular_nome: string;
  emissor: string;
  /** Serial do X.509 em hexadecimal maiúsculo, sem zeros à esquerda. */
  serie: string;
  valido_de: Date;
  valido_ate: Date;
};

export function normalizarCnpj(valor: string | null | undefined): string {
  return (valor ?? "").replace(/\D+/g, "");
}

/** Divide o CN de e-CNPJ ICP-Brasil (`NOME:CNPJ`) em nome e CNPJ. */
export function separarCnDeECnpj(cn: string): { nome: string; cnpj: string } {
  const posicao = cn.lastIndexOf(":");
  if (posicao < 0) return { nome: cn.trim(), cnpj: "" };
  const cnpj = normalizarCnpj(cn.slice(posicao + 1));
  return { nome: cn.slice(0, posicao).trim(), cnpj: cnpj.length === 14 ? cnpj : "" };
}

function primeiroValor(atributos: forge.pki.CertificateField[], nome: string): string {
  for (const atributo of atributos) {
    if (atributo.shortName === nome || atributo.name === nome) {
      return String(atributo.value ?? "");
    }
  }
  return "";
}

/**
 * Escolhe a folha entre os certificados do PKCS#12. O bag costuma trazer a cadeia inteira
 * (a sondagem de 2026-09-10 com o A1 real trouxe 3 intermediários), e só a folha carrega o CNPJ
 * do titular no CN. Pegar "o primeiro" traria a AC intermediária em alguns emissores.
 */
function escolherFolha(certificados: forge.pki.Certificate[]): forge.pki.Certificate {
  const comCnpj = certificados.filter(
    (cert) => separarCnDeECnpj(primeiroValor(cert.subject.attributes, "CN")).cnpj !== "",
  );
  if (comCnpj.length > 0) return comCnpj[0]!;
  const naoAutoAssinados = certificados.filter(
    (cert) => forge.pki.certificateToPem(cert) && !cert.isIssuer(cert),
  );
  const escolhido = naoAutoAssinados[0] ?? certificados[0];
  if (!escolhido) throw new ErroCertificadoA1("CERTIFICADO_AUSENTE", "PKCS#12 sem certificado.");
  return escolhido;
}

export function lerCertificadoA1(pfx: Buffer, senha: string): MetadadosCertificadoA1 {
  let p12: forge.pkcs12.Pkcs12Pfx;
  try {
    const asn1 = forge.asn1.fromDer(forge.util.createBuffer(pfx.toString("binary")));
    p12 = forge.pkcs12.pkcs12FromAsn1(asn1, senha);
  } catch (erro: unknown) {
    const mensagem = erro instanceof Error ? erro.message : String(erro);
    // O forge usa a mesma exceção para senha errada e MAC inválido; a mensagem distingue.
    if (/password|mac/i.test(mensagem)) {
      throw new ErroCertificadoA1("SENHA_INVALIDA", "Senha do certificado inválida.");
    }
    throw new ErroCertificadoA1("PKCS12_ILEGIVEL", "Arquivo não é um PKCS#12 legível.");
  }

  const bags = p12.getBags({ bagType: forge.pki.oids.certBag })[forge.pki.oids.certBag] ?? [];
  const certificados = bags.flatMap((bag) => (bag.cert ? [bag.cert] : []));
  if (certificados.length === 0) {
    throw new ErroCertificadoA1("CERTIFICADO_AUSENTE", "PKCS#12 sem certificado.");
  }

  const folha = escolherFolha(certificados);
  const { nome, cnpj } = separarCnDeECnpj(primeiroValor(folha.subject.attributes, "CN"));
  if (!cnpj) {
    throw new ErroCertificadoA1(
      "CERTIFICADO_SEM_CNPJ",
      "Certificado sem CNPJ no titular: é preciso um e-CNPJ (A1) da empresa.",
    );
  }

  return {
    cnpj_titular: cnpj,
    titular_nome: nome,
    emissor: folha.issuer.attributes.map((atributo) => String(atributo.value ?? "")).filter(Boolean).join(", "),
    serie: folha.serialNumber.replace(/^0+/, "").toUpperCase(),
    valido_de: folha.validity.notBefore,
    valido_ate: folha.validity.notAfter,
  };
}

/** Dias inteiros até o vencimento. Negativo = já vencido. */
export function diasParaVencer(valido_ate: Date, agora = new Date()): number {
  return Math.floor((valido_ate.getTime() - agora.getTime()) / 86_400_000);
}
