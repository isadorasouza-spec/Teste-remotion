import { describe, expect, it } from "vitest";
import forge from "node-forge";
import {
  diasParaVencer,
  ErroCertificadoA1,
  lerCertificadoA1,
  normalizarCnpj,
  separarCnDeECnpj,
} from "../certificado-a1.js";

/**
 * Gera um PKCS#12 de verdade no próprio teste. Nenhum certificado real entra no repositório:
 * o A1 da empresa não pode ser fixture, e um fixture binário fake não exercitaria o parser.
 */
function gerarPfx(opcoes: {
  cn: string;
  senha: string;
  diasValidade?: number;
  comCadeia?: boolean;
}): Buffer {
  const criar = (cn: string, dias: number) => {
    const chaves = forge.pki.rsa.generateKeyPair(1024);
    const cert = forge.pki.createCertificate();
    cert.publicKey = chaves.publicKey;
    cert.serialNumber = "00b4d6908f5028bff7";
    cert.validity.notBefore = new Date(Date.now() - 86_400_000);
    cert.validity.notAfter = new Date(Date.now() + dias * 86_400_000);
    const sujeito = [{ shortName: "CN", value: cn }, { shortName: "C", value: "BR" }];
    cert.setSubject(sujeito);
    cert.setIssuer([{ shortName: "CN", value: "AC SyngularID Multipla" }, { shortName: "C", value: "BR" }]);
    cert.sign(chaves.privateKey, forge.md.sha256.create());
    return { cert, chave: chaves.privateKey };
  };

  const folha = criar(opcoes.cn, opcoes.diasValidade ?? 365);
  // Intermediária primeiro, de propósito: replica a ordem real e prova que a folha é escolhida
  // pelo CNPJ no CN, não por posição no bag.
  const cadeia = opcoes.comCadeia === false ? [] : [criar("AC Intermediaria Sem Cnpj", 3650).cert];
  const asn1 = forge.pkcs12.toPkcs12Asn1(folha.chave, [...cadeia, folha.cert], opcoes.senha, {
    algorithm: "3des",
  });
  return Buffer.from(forge.asn1.toDer(asn1).getBytes(), "binary");
}

describe("separarCnDeECnpj", () => {
  it("separa nome e CNPJ do CN de e-CNPJ ICP-Brasil", () => {
    expect(separarCnDeECnpj("BLUEMETRICS TECNOLOGIA DA INFORMACAO LTDA:44309057000142")).toEqual({
      nome: "BLUEMETRICS TECNOLOGIA DA INFORMACAO LTDA",
      cnpj: "44309057000142",
    });
  });

  it("devolve CNPJ vazio para e-CPF (11 dígitos)", () => {
    expect(separarCnDeECnpj("PESSOA FISICA:12345678901").cnpj).toBe("");
  });

  it("devolve CNPJ vazio para CN sem separador", () => {
    expect(separarCnDeECnpj("AC Intermediaria").cnpj).toBe("");
  });

  it("aceita nome que contém dois-pontos", () => {
    expect(separarCnDeECnpj("EMPRESA A:B LTDA:44309057000142")).toEqual({
      nome: "EMPRESA A:B LTDA",
      cnpj: "44309057000142",
    });
  });
});

describe("normalizarCnpj", () => {
  it("remove máscara", () => expect(normalizarCnpj("44.309.057/0001-42")).toBe("44309057000142"));
  it("tolera nulo", () => expect(normalizarCnpj(null)).toBe(""));
});

describe("lerCertificadoA1", () => {
  const senha = "senha-de-teste";

  it("extrai metadados da folha, ignorando a cadeia", () => {
    const pfx = gerarPfx({ cn: "EMPRESA TESTE LTDA:44309057000142", senha });
    const meta = lerCertificadoA1(pfx, senha);
    expect(meta.cnpj_titular).toBe("44309057000142");
    expect(meta.titular_nome).toBe("EMPRESA TESTE LTDA");
    expect(meta.emissor).toContain("AC SyngularID Multipla");
    expect(meta.serie).toBe("B4D6908F5028BFF7");
    expect(meta.valido_ate.getTime()).toBeGreaterThan(meta.valido_de.getTime());
  });

  it("rejeita senha errada com SENHA_INVALIDA", () => {
    const pfx = gerarPfx({ cn: "EMPRESA TESTE LTDA:44309057000142", senha });
    expect(() => lerCertificadoA1(pfx, "errada")).toThrowError(
      expect.objectContaining({ codigo: "SENHA_INVALIDA" }) as unknown as Error,
    );
  });

  it("valida PKCS#12 BER de comprimento indefinido e ainda rejeita senha errada", () => {
    const der = gerarPfx({ cn: "EMPRESA TESTE LTDA:44309057000142", senha });
    const inicioConteudo = der[1]! < 0x80 ? 2 : 2 + (der[1]! & 0x7f);
    const ber = Buffer.concat([
      Buffer.from([0x30, 0x80]), der.subarray(inicioConteudo), Buffer.from([0x00, 0x00]),
    ]);
    expect(lerCertificadoA1(ber, senha).cnpj_titular).toBe("44309057000142");
    expect(() => lerCertificadoA1(ber, "errada")).toThrowError(
      expect.objectContaining({ codigo: "SENHA_INVALIDA" }) as unknown as Error,
    );
    expect(() => lerCertificadoA1(ber.subarray(0, -2), senha)).toThrowError(
      expect.objectContaining({ codigo: "PKCS12_ILEGIVEL" }) as unknown as Error,
    );
  });

  it("rejeita binário que não é PKCS#12", () => {
    try {
      lerCertificadoA1(Buffer.from("%PDF-1.7 nao sou um certificado"), senha);
      throw new Error("deveria ter lançado");
    } catch (erro) {
      expect(erro).toBeInstanceOf(ErroCertificadoA1);
      expect((erro as ErroCertificadoA1).codigo).toBe("PKCS12_ILEGIVEL");
    }
  });

  it("rejeita e-CPF: sem CNPJ no titular não serve para a SEFAZ", () => {
    const pfx = gerarPfx({ cn: "PESSOA FISICA:12345678901", senha, comCadeia: false });
    expect(() => lerCertificadoA1(pfx, senha)).toThrowError(
      expect.objectContaining({ codigo: "CERTIFICADO_SEM_CNPJ" }) as unknown as Error,
    );
  });
});

describe("diasParaVencer", () => {
  const agora = new Date("2026-09-10T12:00:00Z");
  it("conta dias restantes", () => {
    expect(diasParaVencer(new Date("2026-10-30T12:00:00Z"), agora)).toBe(50);
  });
  it("é negativo para vencido", () => {
    expect(diasParaVencer(new Date("2026-09-01T12:00:00Z"), agora)).toBe(-9);
  });
});
