# `src/data_manipulation`

Rotinas auxiliares de manipulação e agregação de dados.

## Conteúdo

- [`retrieve_batch_data.ts`](./retrieve_batch_data.ts) — recupera dados agregados de folha (resumes de funcionários) para uso em agentes e relatórios

## Propósito

Esta pasta concentra utilitários de manipulação de dados que servem múltiplos contextos (agents, domain, controllers) mas não fazem parte da regra de negócio core.

## Notas

Esta pasta é mais **transitória** — conforme a regra de negócio for migrando para `src/domain`, esses utilitários devem ser reavaliados e potencialmente movidos ou integrados aos serviços de domínio correspondentes.

## Uso

Importado por:
- `src/modules/agentes/acoes-ai.service.ts` — para resumos de folha em agentes
