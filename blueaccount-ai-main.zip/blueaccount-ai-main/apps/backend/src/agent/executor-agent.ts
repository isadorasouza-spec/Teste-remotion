/**
 * ExecutorAgent - Converts user intent into structured BlueAccount actions.
 *
 * This agent is the planning layer for the future chat-driven UI. It does not
 * directly mutate the interface; instead, it returns a JSON action plan that
 * the front-end or backend orchestrator can execute safely.
 *
 * Operationally, the agent:
 * - inspects the current UI context
 * - optionally queries the database for client information
 * - produces semantic UI actions instead of DOM clicks
 * - logs each model invocation with token usage and latency
 *
 * Failure modes are intentionally soft:
 * - malformed model output is normalized when possible
 * - common navigation requests have deterministic heuristics
 * - if planning fails, a clarification request is returned instead of a crash
 */

import "reflect-metadata";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  Agent,
  BedrockModel,
  BeforeModelCallEvent,
  AfterModelCallEvent,
} from "@strands-agents/sdk";
import { settings } from "../settings.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";
import {
  inspectServerCatalog,
  queryCliente,
  queryContratosByCliente,
  queryRelatoriosByCliente,
  searchClientes,
} from "../tools/index.js";
import { SERVER_API_CATALOG } from "../server-api-catalog.js";

export type ExecutorAction =
  | { type: "open_tab"; tab: string }
  | { type: "select_cliente"; cliente_id?: string; cnpj?: string; query?: string }
  | { type: "load_comparacao"; cliente_id: string; competencia: string }
  | { type: "load_excedentes"; page?: number }
  | { type: "refresh_view" }
  | { type: "ask_clarification"; question: string }
  | { type: "noop" };

export type ExecutorPlan = {
  message: string;
  actions: ExecutorAction[];
  should_update_ui: boolean;
  needs_clarification: boolean;
};

export type ExecutorContext = {
  current_tab?: string;
  current_cliente_id?: string | null;
  current_cliente_cnpj?: string | null;
  current_cliente_nome?: string | null;
  current_competencia?: string | null;
  ui_state?: Record<string, unknown>;
};

export type ExecutorRequest = {
  message: string;
  context?: ExecutorContext;
};

export interface ExecutorAgentConfig {
  modelId?: string;
  inferenceProfileId?: string;
  region?: string;
  instructionsPath?: string;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
}

interface ResolvedConfig {
  modelId: string;
  inferenceProfileId: string;
  region: string;
  instructionsPath: string;
  temperature: number;
  topP: number;
  maxTokens: number;
}

/**
 * resolveConfig
 * Merges caller overrides with the default settings used by the project.
 */
function resolveConfig(cfg?: ExecutorAgentConfig): ResolvedConfig {
  return {
    modelId: settings.EXECUTOR_AGENT_BEDROCK_INFERENCE_PROFILE_ID,
    inferenceProfileId: cfg?.inferenceProfileId ?? "",
    region: cfg?.region ?? settings.REGION,
    instructionsPath: cfg?.instructionsPath ?? settings.INSTRUCTIONS_PATH,
    temperature: cfg?.temperature ?? 0.2,
    topP: cfg?.topP ?? 1,
    maxTokens: cfg?.maxTokens ?? 2500,
  };
}

/**
 * stripCodeFences
 * Removes markdown fences so model output can be parsed as raw JSON.
 */
function stripCodeFences(text: string): string {
  return text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

/**
 * extractJsonObject
 * Pulls the first JSON object from a model response.
 * The parsing is intentionally tolerant because the model may wrap JSON in
 * explanatory text or fenced code blocks.
 */
function extractJsonObject(text: string): string | null {
  const cleaned = stripCodeFences(text);
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  return cleaned.slice(start, end + 1);
}

/**
 * normalizePlan
 * Converts raw LLM output into the executor plan contract.
 * When parsing fails, it returns a safe fallback so the caller can still
 * reply to the user. This is the main defense against malformed responses
 * or accidental prose around the JSON payload.
 */
function normalizePlan(raw: unknown, fallbackMessage: string): ExecutorPlan {
  const base: ExecutorPlan = {
    message: fallbackMessage,
    actions: [],
    should_update_ui: false,
    needs_clarification: false,
  };

  if (typeof raw !== "string") return base;

  const jsonText = extractJsonObject(raw);
  if (!jsonText) return { ...base, message: raw.trim() || fallbackMessage };

  try {
    const parsed = JSON.parse(jsonText) as Partial<ExecutorPlan> & { actions?: unknown };
    const actions = Array.isArray(parsed.actions) ? parsed.actions : [];
    return {
      message: typeof parsed.message === "string" && parsed.message.trim() ? parsed.message.trim() : fallbackMessage,
      actions: actions.filter((action): action is ExecutorAction => typeof action === "object" && action !== null) as ExecutorAction[],
      should_update_ui: Boolean(parsed.should_update_ui),
      needs_clarification: Boolean(parsed.needs_clarification),
    };
  } catch {
    return { ...base, message: raw.trim() || fallbackMessage };
  }
}

/**
 * heuristicPlan
 * Applies deterministic handling for a few common navigation requests.
 * This keeps frequent commands responsive even if the model output is empty
 * or malformed. It is intentionally narrow: only predictable navigation
 * shortcuts should live here.
 */
function heuristicPlan(request: ExecutorRequest): ExecutorPlan | null {
  const message = request.message.toLowerCase();

  if (message.includes("excedent")) {
    return {
      message: "Vou abrir a aba de excedentes.",
      actions: [{ type: "open_tab", tab: "excedentes" }],
      should_update_ui: true,
      needs_clarification: false,
    };
  }

  if (message.includes("compara") && request.context?.current_cliente_id) {
    return {
      message: "Vou carregar a comparação do cliente atual.",
      actions: [
        {
          type: "load_comparacao",
          cliente_id: request.context.current_cliente_id,
          competencia: request.context.current_competencia ?? "",
        },
      ],
      should_update_ui: true,
      needs_clarification: !request.context.current_competencia,
    };
  }

  return null;
}

/**
 * buildPrompt
 * Assembles the planning prompt with the current UI context, user message and
 * the official backend catalog.
 *
 * The prompt is the agent's contract with the model. It includes:
 * - the backend route catalog as a capabilities reference
 * - the current UI context as runtime state
 * - the user message as the task to solve
 */
function buildPrompt(request: ExecutorRequest, instructions: string): string {
  return [
    "Você é o ExecutorAgent do BlueAccount.",
    "Transforme a intenção do usuário em um plano de ações estruturado.",
    "Responda apenas com JSON válido.",
    "Se a intenção for ambígua, use uma ação ask_clarification.",
    "",
    "=== CATÁLOGO OFICIAL DO BACKEND ===",
    JSON.stringify(SERVER_API_CATALOG, null, 2),
    "",
    "=== CONTEXTO ATUAL ===",
    JSON.stringify(request.context ?? {}, null, 2),
    "",
    "=== MENSAGEM DO USUÁRIO ===",
    request.message,
    "",
    "=== INSTRUÇÕES DO AGENTE ===",
    instructions,
    "",
    "Retorne um objeto JSON com:",
    "{ message: string, actions: array, should_update_ui: boolean, needs_clarification: boolean }",
  ].join("\n");
}

export class ExecutorAgent {
  static readonly agentName = "ExecutorAgent";

  private readonly config: ResolvedConfig;
  private readonly logger: AgentLogger;

  constructor(cfg?: ExecutorAgentConfig) {
    this.config = resolveConfig(cfg);
    this.logger = new AgentLogger(ExecutorAgent.agentName);
  }

  /**
   * readInstructions
   * Loads the executor instruction file from disk.
   */
  private readInstructions(): string {
    const instructionsFile = resolve(
      this.config.instructionsPath,
      ExecutorAgent.agentName,
      `${ExecutorAgent.agentName}_instrucoes.md`,
    );
    return readFileSync(instructionsFile, "utf-8");
  }

  /**
   * createAgent
   * Builds the underlying Strands agent with the tools needed for planning.
   *
   * The agent is intentionally read-only from the UI perspective. Its tools
   * are limited to inspection/query operations so planning stays safe.
   */
  async createAgent(): Promise<Agent> {
    const model = new BedrockModel({
      region: this.config.region,
      modelId: this.config.inferenceProfileId || this.config.modelId,
      maxTokens: this.config.maxTokens,
      temperature: this.config.temperature,
      topP: this.config.topP,
    });

    const agent = new Agent({
      model,
      systemPrompt: this.readInstructions(),
      tools: [
        inspectServerCatalog,
        searchClientes,
        queryCliente,
        queryContratosByCliente,
        queryRelatoriosByCliente,
      ],
    });

    agent.addHook(BeforeModelCallEvent, (event: BeforeModelCallEvent) => {
      // Nova/Bedrock can emit blank text blocks alongside tool calls.
      // Removing them avoids invalid follow-up turns and keeps planning stable.
      for (const msg of event.agent.messages) {
        (msg as { content: typeof msg.content }).content = msg.content.filter(
          (block) => !(block.type === "textBlock" && "text" in block && block.text === ""),
        );
      }
    });

    agent.addHook(AfterModelCallEvent, (event: AfterModelCallEvent) => {
      const stopReason = event.stopData?.stopReason ?? "unknown";
      if (event.error) {
        // Model failures are logged as errors, but the caller still gets a
        // fallback plan or clarification path from `plan()`.
        this.logger.error("model_call_error", {
          stopReason,
          error: event.error.message,
        });
      } else {
        this.logger.info("model_call_completed", {
          stopReason,
          messageBlocks: event.stopData?.message?.content?.length ?? 0,
        });
      }
    });

    return agent;
  }

  /**
   * plan
   * Produces a structured action plan from the user message and current UI
   * context. The result is safe for the chat layer to consume.
   *
   * Exceptions are handled in two layers:
   * - model errors are logged and converted to a clarification response
   * - malformed responses are normalized before they reach the UI
   */
  async plan(request: ExecutorRequest): Promise<ExecutorPlan> {
    const heuristic = heuristicPlan(request);
    const agent = await this.createAgent();
    const instructions = this.readInstructions();
    const prompt = buildPrompt(request, instructions);
    const modelId = this.config.inferenceProfileId || this.config.modelId;

    // Execution flow:
    // 1. log the request context
    // 2. invoke the planning model
    // 3. record token usage and latency
    // 4. normalize the JSON response
    // 5. fall back to heuristics or a clarification prompt when needed
    this.logger.info("plan_started", {
      currentTab: request.context?.current_tab ?? null,
      hasClient: Boolean(request.context?.current_cliente_id),
      messageLength: request.message.length,
      usingHeuristicFallback: Boolean(heuristic),
    });

    try {
      const result = await agent.invoke(prompt);
      const metrics = (result as { metrics?: { accumulatedUsage?: { inputTokens?: number; outputTokens?: number }; accumulatedMetrics?: { latencyMs?: number }; cycleCount?: number } }).metrics;
      if (metrics) {
        this.logger.logLlmUsage(
          "llm_invocation",
          {
            modelId,
            inputTokens: metrics.accumulatedUsage?.inputTokens,
            outputTokens: metrics.accumulatedUsage?.outputTokens,
            latencyMs: metrics.accumulatedMetrics?.latencyMs,
          },
          {
            cycleCount: metrics.cycleCount,
            usingHeuristicFallback: Boolean(heuristic),
            currentTab: request.context?.current_tab ?? null,
            hasClient: Boolean(request.context?.current_cliente_id),
          },
        );
      }
      const normalized = normalizePlan(result.toString(), request.message);
      if (normalized.actions.length > 0 || normalized.should_update_ui || normalized.needs_clarification) {
        this.logger.info("plan_completed", {
          actionCount: normalized.actions.length,
          shouldUpdateUi: normalized.should_update_ui,
          needsClarification: normalized.needs_clarification,
          currentTab: request.context?.current_tab ?? null,
        });
        return normalized;
      }
      // If the model produced a valid but empty plan, deterministic heuristics
      // can still handle common navigation shortcuts.
      this.logger.info("plan_completed", {
        actionCount: heuristic?.actions.length ?? 0,
        shouldUpdateUi: heuristic?.should_update_ui ?? false,
        needsClarification: heuristic?.needs_clarification ?? false,
        currentTab: request.context?.current_tab ?? null,
      });
      return heuristic ?? normalized;
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      // Hard failures should never bubble up to the UI as an exception.
      // The user receives a safe clarification prompt instead, or a heuristic
      // response when a deterministic shortcut is available.
      this.logger.error("plan_failed", { error: message });
      return heuristic ?? {
        message: "Não consegui interpretar o pedido agora. Pode reformular?",
        actions: [{ type: "ask_clarification", question: "Pode reformular o pedido?" }],
        should_update_ui: false,
        needs_clarification: true,
      };
    }
  }
}

/**
 * createExecutorAgent
 * Convenience factory for callers that only need the raw Strands agent.
 */
export async function createExecutorAgent(cfg?: ExecutorAgentConfig): Promise<Agent> {
  const executor = new ExecutorAgent(cfg);
  return executor.createAgent();
}
