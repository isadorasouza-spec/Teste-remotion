import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const send = vi.fn();
  const invokeCommand = vi.fn(function InvokeAgentRuntimeCommand(input: unknown) {
    return { input };
  });
  const info = vi.fn();
  const logLlmUsage = vi.fn();
  return { send, invokeCommand, info, logLlmUsage };
});

vi.mock("@aws-sdk/client-bedrock-agentcore", () => ({
  BedrockAgentCoreClient: vi.fn(function BedrockAgentCoreClient() {
    return { send: mocks.send };
  }),
  InvokeAgentRuntimeCommand: mocks.invokeCommand,
}));

vi.mock("../../infrastructure/logging/agent.logger.js", () => ({
  AgentLogger: vi.fn(function AgentLogger() {
    return {
      info: mocks.info,
      logLlmUsage: mocks.logLlmUsage,
    };
  }),
}));

describe("KontivaAgent", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.KONTIVA_AGENT_RUNTIME_ARN = "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/KontivaAgent";
    process.env.KONTIVA_AGENT_RUNTIME_QUALIFIER = "";
  });

  it("sends configured agent instructions to AgentCore", async () => {
    const { KontivaAgent } = await import("../kontiva-agent.js");
    mocks.send.mockResolvedValue({
      response: {
        transformToString: vi.fn().mockResolvedValue(JSON.stringify({ acoes: [], resumo: "ok" })),
      },
    });

    const agent = new KontivaAgent();
    const result = await agent.gerarAcoes(
      {
        message: "Analise o escritorio",
        sessionId: "session-1",
        instrucoes: "Priorize inadimplencia acima de R$ 1.000.",
        agenteId: "agente-1",
      },
      { escritorioId: "office-1", traceId: "trace-1" },
    );

    expect(result).toEqual({ acoes: [], resumo: "ok" });
    expect(mocks.invokeCommand).toHaveBeenCalledTimes(1);

    const commandInput = mocks.invokeCommand.mock.calls[0][0] as { payload: Buffer };
    const payload = JSON.parse(commandInput.payload.toString("utf-8")) as Record<string, unknown>;

    expect(payload).toEqual(
      expect.objectContaining({
        message: "Analise o escritorio",
        session_id: "session-1",
        agente_id: "agente-1",
        instrucoes: "Priorize inadimplencia acima de R$ 1.000.",
        instructions: "Priorize inadimplencia acima de R$ 1.000.",
      }),
    );
    expect(payload.prompt).toBe("Priorize inadimplencia acima de R$ 1.000.");
    expect(mocks.info).toHaveBeenCalledWith(
      "agentcore_invoke_started",
      expect.objectContaining({
        prompt: payload.prompt,
        original_message: "Analise o escritorio",
      }),
    );
  });
});
