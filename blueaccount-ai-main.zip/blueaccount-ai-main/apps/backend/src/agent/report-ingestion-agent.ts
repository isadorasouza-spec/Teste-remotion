/**
 * ReportIngestionAgent – Extracts operational data from Domínio system reports.
 *
 * Flow:
 *   1. Read report file from S3 or local file/buffer
 *   2. Build extraction prompt from report instructions
 *   3. Convert DOC/DOCX → PDF when needed (via LibreOffice)
 *   4. Invoke Bedrock Converse (multimodal) for structured extraction
 *   5. Parse and return JSON extraction result
 */

import { existsSync, readFileSync, mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { resolve, extname, basename, parse as parsePath, join } from "node:path";
import { execSync } from "node:child_process";
import { tmpdir } from "node:os";

import {
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import {
  ConverseCommand,
  type ContentBlock,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";

import { settings } from "../settings.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";
import { ExternalServicesFactoryService } from "../infrastructure/external-services/external-services.factory.js";

// ─── Types ─────────────────────────────────────────────────────────────────────

export type ReportType =
  | "resumo_folha"
  | "relatorio_excedente"
  | "numero_notas_fiscais"
  | "numero_de_documentos"
  | "lancamentos_contabeis"
  ;

export interface ReportExtractionBase {
  cnpj_cliente: string | null;
  razao_social: string | null;
  tipo_relatorio: ReportType;
  competencia: string | null;
}

export interface ResumoFolhaExtraction extends ReportExtractionBase {
  tipo_relatorio: "resumo_folha";
  colaboradores_ativos: number | null;
  prolabores_ativos: number | null;
  admissoes: number | null;
  rescisoes: number | null;
  afastados: number | null;
}

export interface NotasFiscaisExtraction extends ReportExtractionBase {
  tipo_relatorio: "numero_notas_fiscais" | "numero_de_documentos";
  total_notas_fiscais: number | null;
  notas_entrada: number | null;
  notas_saida: number | null;
  notas_servico: number | null;
}

export interface LancamentosContabeisExtraction extends ReportExtractionBase {
  tipo_relatorio: "lancamentos_contabeis";
  total_lancamentos: number | null;
  lancamentos_debito: number | null;
  lancamentos_credito: number | null;
}

export interface ExcedenteItem {
  referencia: string;
  quantidade_contratada: number | null;
  quantidade_realizada: number | null;
  quantidade_excedente: number | null;
  valor_unitario: number | null;
  valor_total: number | null;
}

export interface ExcedentesExtraction extends ReportExtractionBase {
  tipo_relatorio: "relatorio_excedente";
  itens_excedentes: ExcedenteItem[];
}

export type ReportExtraction =
  | ResumoFolhaExtraction
  | NotasFiscaisExtraction
  | LancamentosContabeisExtraction
  | ExcedentesExtraction;

export interface ReportExtractionBatch {
  relatorios: Record<string, unknown>[];
  metadados_extracao: {
    arquivo_origem: string;
    quantidade_itens: number;
    warnings: string[];
  };
}

// ─── Config ────────────────────────────────────────────────────────────────────

export interface ReportAgentConfig {
  inputBucket?: string;
  modelId?: string;
  inferenceProfileId?: string;
  region?: string;
  instructionsPath?: string;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
}

interface ResolvedConfig {
  inputBucket: string;
  modelId: string;
  inferenceProfileId: string;
  region: string;
  instructionsPath: string;
  temperature: number;
  topP: number;
  maxTokens: number;
}

function resolveConfig(cfg?: ReportAgentConfig): ResolvedConfig {
  return {
    inputBucket: cfg?.inputBucket ?? settings.DOCUMENT_INPUT_BUCKET,
    modelId: cfg?.modelId ?? settings.REPORT_DEFAULT_MODEL_ID,
    inferenceProfileId:
      cfg?.inferenceProfileId ??
      settings.REPORT_BEDROCK_INFERENCE_PROFILE_ID ??
      "",
    region: cfg?.region ?? settings.REGION,
    instructionsPath: cfg?.instructionsPath ?? settings.INSTRUCTIONS_PATH,
    temperature: cfg?.temperature ?? 0,
    topP: cfg?.topP ?? 1,
    maxTokens: cfg?.maxTokens ?? 4000,
  };
}

// ─── Agent ─────────────────────────────────────────────────────────────────────

export type InferenceOverrides = Partial<{
  temperature: number;
  topP: number;
  maxTokens: number;
}>;

export class ReportIngestionAgent {
  static readonly agentName = "ReportIngestionAgent";

  private readonly config: ResolvedConfig;
  private readonly logger: AgentLogger;
  private readonly s3: ReturnType<ExternalServicesFactoryService["createS3Client"]>;
  private readonly bedrock: ReturnType<ExternalServicesFactoryService["createBedrockRuntimeClient"]>;
  private readonly services = new ExternalServicesFactoryService();

  constructor(cfg?: ReportAgentConfig, logger?: AgentLogger) {
    this.config = resolveConfig(cfg);
    this.logger =
      logger ??
      new AgentLogger(
        ReportIngestionAgent.agentName,
        undefined,
        (settings.LOG_LEVEL as "debug" | "info" | "warn" | "error") ?? "info",
      );

    this.s3 = this.services.createS3Client(this.config.region);
    this.bedrock = this.services.createBedrockRuntimeClient(this.config.region);

    this.logger.info("agent_bootstrap_complete", {
      region: this.config.region,
      inputBucket: this.config.inputBucket,
      modelId: this.config.modelId,
      inferenceProfileId: this.config.inferenceProfileId || "(none)",
      instructionsPath: this.config.instructionsPath,
    });
  }

  private resolveInference(
    overrides?: InferenceOverrides,
  ): { temperature: number; topP: number; maxTokens: number } {
    return {
      temperature: overrides?.temperature ?? this.config.temperature,
      topP: overrides?.topP ?? this.config.topP,
      maxTokens: overrides?.maxTokens ?? this.config.maxTokens,
    };
  }

  /**
   * Ingest a report from S3 and return the structured extraction as a JSON string.
   */
  async ingest(
    inputKey: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<string> {
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_started", { inputKey, inferenceConfig });

    const inputBytes = await this.readS3Object(
      this.config.inputBucket,
      inputKey,
    );
    this.logger.info("input_loaded", {
      inputKey,
      sizeBytes: inputBytes.length,
    });

    const extracted = await this.extractFromBytes(inputBytes, inputKey, inferenceConfig);
    const result = JSON.stringify(extracted, null, 2);
    this.logger.info("ingest_completed", {
      outputMode: "text",
      resultSizeChars: result.length,
      quantidade_itens: extracted.metadados_extracao.quantidade_itens,
    });
    return result;
  }

  /**
   * Ingest a report from a local file path.
   */
  async ingestFromFile(
    filePath: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<ReportExtractionBatch> {
    const resolved = resolve(filePath);
    if (!existsSync(resolved)) {
      throw new Error(`File not found: ${resolved}`);
    }
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_from_file_started", { filePath: resolved });

    const inputBytes = readFileSync(resolved);
    this.logger.info("input_loaded", {
      filePath: resolved,
      sizeBytes: inputBytes.length,
    });

    const extracted = await this.extractFromBytes(
      Buffer.from(inputBytes),
      basename(resolved),
      inferenceConfig,
    );
    this.logger.info("ingest_from_file_completed", {
      filePath: resolved,
      quantidade_itens: extracted.metadados_extracao.quantidade_itens,
      warnings_count: extracted.metadados_extracao.warnings.length,
    });
    return extracted;
  }

  /**
   * Ingest a report from an in-memory buffer.
   */
  async ingestFromBuffer(
    buffer: Buffer,
    filename: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<ReportExtractionBatch> {
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_from_buffer_started", {
      filename,
      sizeBytes: buffer.length,
    });

    const extracted = await this.extractFromBytes(buffer, filename, inferenceConfig);
    this.logger.info("ingest_from_buffer_completed", {
      filename,
      quantidade_itens: extracted.metadados_extracao.quantidade_itens,
      warnings_count: extracted.metadados_extracao.warnings.length,
    });
    return extracted;
  }

  // ─────────────────────────── Core extraction ──────────────────────────────

  private async extractFromBytes(
    inputBytes: Buffer,
    nameHint: string,
    inferenceConfig: { temperature: number; topP: number; maxTokens: number },
  ): Promise<ReportExtractionBatch> {
    const promptText = this.buildExtractionPrompt();

    const { payload, effectiveKey } = this.prepareDocumentPayload(
      nameHint,
      inputBytes,
    );
    const { documentKind, mediaFormat } = this.inferDocumentType(effectiveKey);
    this.logger.info("payload_prepared", {
      effectiveKey,
      payloadSizeBytes: payload.length,
      documentKind,
      mediaFormat,
    });

    const rawResponse = await this.invokeMultimodalExtraction({
      modelIdentifier:
        this.config.inferenceProfileId || this.config.modelId,
      promptText,
      payloadBytes: payload,
      documentKind,
      mediaFormat,
      filename: this.sanitizeDocumentName(basename(effectiveKey)),
      inferenceConfig,
    });

    return this.buildExtractionBatch(rawResponse, basename(nameHint));
  }

  // ─────────────────────────── Prompt ───────────────────────────────────────

  private buildExtractionPrompt(): string {
    const instructionsFile = resolve(
      this.config.instructionsPath,
      ReportIngestionAgent.agentName,
      `${ReportIngestionAgent.agentName}_instrucoes.md`,
    );
    const instructions = readFileSync(instructionsFile, "utf-8");
    this.logger.info("instructions_loaded", { instructionsFile });

    return [
      "Voce e um extrator especializado em dados de relatorios contabeis do sistema Dominio (Thomson Reuters).",
      "Analise o documento e extraia APENAS os campos definidos nas instrucoes abaixo.",
      "Separe o resultado em itens atomicos, um item por combinacao de cliente e competencia.",
      "Se o documento tiver mais de um cliente ou mais de uma competencia, retorne multiplos itens.",
      "Use sempre o formato canonico com relatorios[] e metadados_extracao.",
      "",
      "=== INSTRUCOES DE EXTRACAO ===",
      instructions,
      "=== FIM DAS INSTRUCOES ===",
      "",
      "Retorne o JSON final agora.",
    ].join("\n");
  }

  // ─────────────────────────── S3 ───────────────────────────────────────────

  private async readS3Object(bucket: string, key: string): Promise<Buffer> {
    const cmd = new GetObjectCommand({ Bucket: bucket, Key: key });
    const resp = await this.s3.send(cmd);
    const stream = resp.Body;
    if (!stream) throw new Error(`S3 object body is empty: s3://${bucket}/${key}`);
    return Buffer.from(await stream.transformToByteArray());
  }

  // ─────────────────────────── Bedrock ──────────────────────────────────────

  private async invokeMultimodalExtraction(opts: {
    modelIdentifier: string;
    promptText: string;
    payloadBytes: Buffer;
    documentKind: "document" | "image";
    mediaFormat: string;
    filename: string;
    inferenceConfig: { temperature: number; topP: number; maxTokens: number };
  }): Promise<string> {
    const content: ContentBlock[] = [{ text: opts.promptText }];

    if (opts.documentKind === "document") {
      content.push({
        document: {
          name: opts.filename,
          format: opts.mediaFormat as "pdf",
          source: { bytes: opts.payloadBytes },
        },
      });
    } else {
      content.push({
        image: {
          format: opts.mediaFormat as "jpeg" | "png",
          source: { bytes: opts.payloadBytes },
        },
      });
    }

    const messages: Message[] = [{ role: "user", content }];

    const cmd = new ConverseCommand({
      modelId: opts.modelIdentifier,
      messages,
      inferenceConfig: {
        temperature: opts.inferenceConfig.temperature,
        topP: opts.inferenceConfig.topP,
        maxTokens: opts.inferenceConfig.maxTokens,
      },
    });

    const resp = await this.bedrock.send(cmd);

    // Log LLM usage
    this.logger.logLlmUsage("llm_invocation", {
      modelId: opts.modelIdentifier,
      inputTokens: resp.usage?.inputTokens,
      outputTokens: resp.usage?.outputTokens,
      latencyMs: resp.metrics?.latencyMs,
    }, { filename: opts.filename });

    const blocks = resp.output?.message?.content ?? [];
    const textParts = blocks
      .filter((b): b is ContentBlock & { text: string } => "text" in b && typeof b.text === "string")
      .map((b) => b.text);

    const final = textParts.join("\n").trim();
    if (!final) throw new Error("Bedrock retornou resposta vazia.");
    return final;
  }

  // ─────────────────────────── JSON parsing ─────────────────────────────────

  private extractJsonFromResponse(text: string): Record<string, unknown> | unknown[] {
    const trimmed = text.trim();
    try {
      const data = JSON.parse(trimmed);
      if (typeof data !== "object" || data === null) {
        throw new Error("JSON de extracao invalido: esperado objeto ou lista no nivel raiz.");
      }
      return data as Record<string, unknown> | unknown[];
    } catch {
      const objectStart = trimmed.indexOf("{");
      const objectEnd = trimmed.lastIndexOf("}");
      const arrayStart = trimmed.indexOf("[");
      const arrayEnd = trimmed.lastIndexOf("]");

      const hasObject = objectStart !== -1 && objectEnd !== -1 && objectEnd > objectStart;
      const hasArray = arrayStart !== -1 && arrayEnd !== -1 && arrayEnd > arrayStart;

      if (!hasObject && !hasArray) {
        throw new Error("Resposta do modelo nao contem JSON valido.");
      }

      const useArray = hasArray && (!hasObject || arrayStart < objectStart);
      const slice = useArray
        ? trimmed.slice(arrayStart, arrayEnd + 1)
        : trimmed.slice(objectStart, objectEnd + 1);

      const data = JSON.parse(slice);
      if (typeof data !== "object" || data === null) {
        throw new Error("JSON de extracao invalido: esperado objeto ou lista no nivel raiz.");
      }
      return data as Record<string, unknown> | unknown[];
    }
  }

  private buildExtractionBatch(text: string, sourceFilename: string): ReportExtractionBatch {
    const parsed = this.extractJsonFromResponse(text);
    const warnings: string[] = [];

    const rawItems = this.unwrapExtractionItems(parsed);
    const relatorios: Record<string, unknown>[] = [];

    for (let i = 0; i < rawItems.length; i += 1) {
      const normalized = this.normalizeSingleReportItem(rawItems[i], sourceFilename);
      const cnpj = this.toNullableTrimmedString(normalized.cnpj_cliente);
      const competencia = this.toNullableTrimmedString(normalized.competencia);

      if (!cnpj || !competencia) {
        warnings.push(`item_${i + 1}: sem chave minima (cnpj_cliente e/ou competencia)`);
      }

      relatorios.push(normalized);
    }

    return {
      relatorios,
      metadados_extracao: {
        arquivo_origem: sourceFilename,
        quantidade_itens: relatorios.length,
        warnings,
      },
    };
  }

  private unwrapExtractionItems(parsed: Record<string, unknown> | unknown[]): Record<string, unknown>[] {
    if (Array.isArray(parsed)) {
      return parsed.filter((item): item is Record<string, unknown> => this.isObjectRecord(item));
    }

    const maybeItems = parsed.relatorios;
    if (Array.isArray(maybeItems)) {
      return maybeItems.filter((item): item is Record<string, unknown> => this.isObjectRecord(item));
    }

    return [parsed];
  }

  private normalizeSingleReportItem(item: Record<string, unknown>, sourceFilename: string): Record<string, unknown> {
    const normalized: Record<string, unknown> = { ...item };

    if (normalized.arquivo_origem == null) {
      normalized.arquivo_origem = sourceFilename;
    }

    const normalizedType = this.normalizeReportType(normalized.tipo_relatorio, normalized);
    if (normalizedType) {
      normalized.tipo_relatorio = normalizedType;
    }

    return normalized;
  }

  private normalizeReportType(
    value: unknown,
    item: Record<string, unknown>,
  ): ReportType | null {
    if (typeof value !== "string") return null;
    const raw = value.trim();
    if (!raw) return null;

    if (
      raw === "resumo_folha" ||
      raw === "relatorio_excedente" ||
      raw === "numero_notas_fiscais" ||
      raw === "numero_de_documentos" ||
      raw === "lancamentos_contabeis"
    ) {
      return raw;
    }

    if (raw === "notas_fiscais") {
      const looksLikeDocuments =
        "total_documentos" in item ||
        "documentos_entrada" in item ||
        "documentos_saida" in item ||
        "documentos_servico" in item;
      return looksLikeDocuments ? "numero_de_documentos" : "numero_notas_fiscais";
    }

    if (raw === "excedentes") {
      return "relatorio_excedente";
    }

    return null;
  }

  private isObjectRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }

  private toNullableTrimmedString(value: unknown): string | null {
    if (typeof value !== "string") {
      return null;
    }
    const trimmed = value.trim();
    return trimmed ? trimmed : null;
  }

  // ─────────────────────────── Document handling ────────────────────────────

  private prepareDocumentPayload(
    inputKey: string,
    payloadBytes: Buffer,
  ): { payload: Buffer; effectiveKey: string } {
    const ext = extname(inputKey).toLowerCase();
    if (ext !== ".doc" && ext !== ".docx") {
      return { payload: payloadBytes, effectiveKey: inputKey };
    }
    const pdfBytes = this.convertWordToPdf(payloadBytes, basename(inputKey));
    const stem = parsePath(inputKey).name;
    return { payload: pdfBytes, effectiveKey: `${stem}.pdf` };
  }

  private inferDocumentType(
    objectKey: string,
  ): { documentKind: "document" | "image"; mediaFormat: string } {
    const ext = extname(objectKey).toLowerCase();
    switch (ext) {
      case ".pdf":
        return { documentKind: "document", mediaFormat: "pdf" };
      case ".doc":
      case ".docx":
        return { documentKind: "document", mediaFormat: "pdf" };
      case ".jpg":
      case ".jpeg":
        return { documentKind: "image", mediaFormat: "jpeg" };
      case ".png":
        return { documentKind: "image", mediaFormat: "png" };
      default:
        throw new Error(
          `Formato nao suportado: ${ext}. Use PDF, DOC, DOCX, JPG ou PNG.`,
        );
    }
  }

  private convertWordToPdf(wordBytes: Buffer, sourceName: string): Buffer {
    const soffice = this.resolveSofficeBinary();
    const suffix = extname(sourceName) || ".docx";
    const tmp = mkdtempSync(join(tmpdir(), "word_to_pdf_"));

    try {
      const inputPath = join(tmp, `source${suffix}`);
      writeFileSync(inputPath, wordBytes);

      execSync(
        `"${soffice}" --headless --convert-to pdf --outdir "${tmp}" "${inputPath}"`,
        { stdio: "pipe" },
      );

      const outputPath = join(tmp, "source.pdf");
      return readFileSync(outputPath);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  }

  private resolveSofficeBinary(): string {
    try {
      const result = execSync("which soffice", { stdio: "pipe", encoding: "utf-8" }).trim();
      if (result) return result;
    } catch {
      // not in PATH
    }
    const macPath = "/Applications/LibreOffice.app/Contents/MacOS/soffice";
    if (existsSync(macPath)) return macPath;
    throw new Error(
      "Conversao DOC/DOCX requer LibreOffice (soffice). Instale o LibreOffice ou adicione no PATH.",
    );
  }

  private sanitizeDocumentName(rawName: string): string {
    let name = parsePath(rawName).name;
    name = name.replace(/[_./]+/g, "-");
    name = name.replace(/[^A-Za-z0-9\s\-()[\]]/g, "");
    name = name.replace(/\s+/g, " ").trim();
    return name || "document";
  }
}
