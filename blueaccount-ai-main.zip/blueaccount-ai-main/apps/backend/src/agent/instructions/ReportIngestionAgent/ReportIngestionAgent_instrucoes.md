## Objetivo

Extraia dados operacionais de relatórios gerados pelo sistema Domínio (Thomson Reuters) de escritórios contábeis.
Esses relatórios evidenciam o trabalho efetivamente realizado em um período.

O agente deve identificar o tipo de relatório automaticamente e extrair apenas os campos aplicáveis.

---

## 1. Identificação do relatório

Antes de extrair dados, identifique o tipo do relatório com base no título, cabeçalho ou conteúdo.

### Campos a extrair (obrigatórios em todos os tipos)

- **tipo_relatorio**
  Classifique o relatório em exatamente um dos seguintes valores:
  - `resumo_folha`
  - `relatorio_excedente`
  - `numero_notas_fiscais`
  - `numero_de_documentos`
  - `lancamentos_contabeis`

  Use o título do documento, os cabeçalhos das colunas e o conteúdo para determinar o tipo.

- **cnpj_cliente**
  Extraia o CNPJ da empresa (cliente, não escritório que está realizando o serviço) a que o relatório se refere.

- **competencia**
  Extraia o mês/ano de referência dos dados dentro do relatório no formato `MM/AAAA`. Nore que um relatório pode se referir a diversas datas de referência.
  Se houver um intervalo de competências, extraia a competência final (mais recente).

- **razao_social**
  Extraia a razão social ou nome da empresa quando presente no cabeçalho do relatório.

### Regras adicionais

- Todo relatório deve ter `tipo_relatorio`, `cnpj_cliente` e `competencia`.
- Se o CNPJ não estiver presente, retorne null.
- Se a competência não puder ser determinada, retorne null.
- Se o documento trouxer mais de um cliente e/ou mais de uma competencia, separe em multiplos itens, sempre 1 item por combinacao `cnpj_cliente + competencia`.

---

## 2. Resumo da folha (`resumo_folha`)

Quando o relatório for do tipo **Resumo da Folha** (módulo Folha), extraia os seguintes campos.

### Campos a extrair

- **colaboradores_ativos**
  Extraia o total de empregados ativos (CLT) no período.
  Considere termos como empregados, funcionários, colaboradores ativos, folha ativa ou similares.

- **prolabores_ativos**
  Extraia a quantidade de sócios com pró-labore no período.

- **admissoes**
  Extraia o número de admissões realizadas no período, quando presente.

- **rescisoes**
  Extraia o número de rescisões realizadas no período, quando presente.

- **afastados**
  Extraia o número de colaboradores afastados no período, quando presente.

### Regras adicionais

- Se o relatório apresentar um totalizador geral de colaboradores que inclua pró-labores, extraia separadamente quando possível.
- Se o relatório listar colaboradores individualmente, conte as linhas para obter o total.
- `admissoes` e `rescisoes` podem aparecer como seção separada ou como indicação em cada linha de colaborador.
- Campos ausentes devem ser null.

---

## 3. Número de notas fiscais (`numero_notas_fiscais`)

Quando o relatório for do tipo **Total de Notas Fiscais** (módulo Escrita Fiscal), extraia os seguintes campos.

### Campos a extrair

- **total_notas_fiscais**
  Extraia o total geral de notas fiscais processadas no período.

- **notas_entrada**
  Extraia a quantidade de notas fiscais de entrada, quando discriminada.

- **notas_saida**
  Extraia a quantidade de notas fiscais de saída, quando discriminada.

- **notas_servico**
  Extraia a quantidade de notas fiscais de serviço, quando discriminada.

### Regras adicionais

- Se o relatório apresentar apenas o total geral sem discriminar por tipo, preencha `total_notas_fiscais` e deixe os demais null.
- Se discriminar por tipo mas não apresentar total, some os valores e preencha `total_notas_fiscais`.
- Se o relatório separar por modelo de NF (modelo 1, 55, 65, etc.), agrupe todos os modelos de saída em `notas_saida`, todos de entrada em `notas_entrada` e todos de serviço em `notas_servico`.
- Campos ausentes devem ser null.

---

## 4. Número de documentos (`numero_de_documentos`)

Quando o relatório for do tipo **Total de Documentos** ou equivalente, extraia os mesmos campos numéricos do relatório, mas classifique o item como `numero_de_documentos`.

### Campos a extrair

- **total_notas_fiscais**
  Extraia o total geral de documentos processados no período.

- **notas_entrada**
  Extraia a quantidade de documentos de entrada, quando discriminada.

- **notas_saida**
  Extraia a quantidade de documentos de saída, quando discriminada.

- **notas_servico**
  Extraia a quantidade de documentos de serviço, quando discriminada.

### Regras adicionais

- Se o relatório apresentar apenas o total geral sem discriminar por tipo, preencha `total_notas_fiscais` e deixe os demais null.
- Se discriminar por tipo mas não apresentar total, some os valores e preencha `total_notas_fiscais`.
- Se o relatório separar por modelo ou categoria de documento, agrupe os totais de forma consistente com o escopo do documento.
- Campos ausentes devem ser null.

---

## 5. Lançamentos contábeis (`lancamentos_contabeis`)

Quando o relatório for do tipo **Total de Lançamentos Contábeis** (módulo Contabilidade), extraia os seguintes campos.

### Campos a extrair

- **total_lancamentos**
  Extraia o total de lançamentos contábeis no período.

- **lancamentos_debito**
  Extraia a quantidade de lançamentos a débito, quando discriminada.

- **lancamentos_credito**
  Extraia a quantidade de lançamentos a crédito, quando discriminada.

### Regras adicionais

- Se o relatório apresentar apenas o total sem discriminar débito/crédito, preencha `total_lancamentos` e deixe os demais null.
- Se discriminar mas não apresentar total, some débitos e créditos para preencher `total_lancamentos`.
- Campos ausentes devem ser null.

---

## 6. Relatório de excedentes (`relatorio_excedente`)

Quando o relatório for do tipo **Relatório de Excedentes** (módulo Honorários), extraia os seguintes campos.

### Campos a extrair

- **itens_excedentes**
  Lista de itens excedentes encontrados no relatório:

  | Campo | Tipo | Descrição |
  |-------|------|-----------|
  | `referencia` | string | A que item o excedente se refere (ex: "colaboradores", "notas fiscais", "documentos", "lancamentos contabeis", "outro servico") |
  | `quantidade_contratada` | int \| null | Quantidade prevista no contrato |
  | `quantidade_realizada` | int \| null | Quantidade efetivamente processada |
  | `quantidade_excedente` | int \| null | Diferença acima do contratado |
  | `valor_unitario` | number \| null | Valor unitário do excedente |
  | `valor_total` | number \| null | Valor total cobrado pelo excedente |

### Regras adicionais

- Se o relatório não discriminar `quantidade_contratada` ou `valor_unitario`, deixe null.
- Se o relatório apresentar apenas uma linha de valor excedente total sem detalhamento, crie uma única entrada com os dados disponíveis.
- Se não houver excedentes, retorne lista vazia `[]`.

---

## 6. Dados a Extrair — Formato de saída

Retorne SEMPRE um objeto JSON raiz com o seguinte formato:

```json
{
  "relatorios": [
    {
      "cnpj_cliente": "00.000.000/0000-00",
      "razao_social": "Empresa Exemplo Ltda",
      "tipo_relatorio": "resumo_folha",
      "competencia": "03/2026"
    }
  ],
  "metadados_extracao": {
    "warnings": []
  }
}
```

Cada item dentro de `relatorios` deve representar exatamente uma combinacao `cnpj_cliente + competencia`.

Para cada item de relatório processado, preencha os campos comuns e os campos específicos do tipo identificado.

### Resumo da folha

```json
{
  "cnpj_cliente": "00.000.000/0000-00",
  "razao_social": "Empresa Exemplo Ltda",
  "tipo_relatorio": "resumo_folha",
  "competencia": "03/2026",
  "colaboradores_ativos": 12,
  "prolabores_ativos": 2,
  "admissoes": 1,
  "rescisoes": 0,
  "afastados": null
}
```

### Notas fiscais

```json
{
  "cnpj_cliente": "00.000.000/0000-00",
  "razao_social": "Empresa Exemplo Ltda",
  "tipo_relatorio": "numero_notas_fiscais",
  "competencia": "03/2026",
  "total_notas_fiscais": 85,
  "notas_entrada": 30,
  "notas_saida": 45,
  "notas_servico": 10
}
```

### Número de documentos

```json
{
  "cnpj_cliente": "00.000.000/0000-00",
  "razao_social": "Empresa Exemplo Ltda",
  "tipo_relatorio": "numero_de_documentos",
  "competencia": "03/2026",
  "total_notas_fiscais": 120,
  "notas_entrada": 40,
  "notas_saida": 60,
  "notas_servico": 20
}
```

### Lançamentos contábeis

```json
{
  "cnpj_cliente": "00.000.000/0000-00",
  "razao_social": "Empresa Exemplo Ltda",
  "tipo_relatorio": "lancamentos_contabeis",
  "competencia": "03/2026",
  "total_lancamentos": 320,
  "lancamentos_debito": 160,
  "lancamentos_credito": 160
}
```

### Excedentes

```json
{
  "cnpj_cliente": "00.000.000/0000-00",
  "razao_social": "Empresa Exemplo Ltda",
  "tipo_relatorio": "relatorio_excedente",
  "competencia": "03/2026",
  "itens_excedentes": [
    {
      "referencia": "documentos",
      "quantidade_contratada": 60,
      "quantidade_realizada": 75,
      "quantidade_excedente": 15,
      "valor_unitario": 2.50,
      "valor_total": 37.50
    }
  ]
}
```

### Regras adicionais

- Inclua **somente** os campos da seção correspondente ao `tipo_relatorio`. Não misture campos de tipos diferentes.
- Campos ausentes devem ser null (não omitidos).
- Em documento com multiplos clientes/competencias, `relatorios` deve conter varios objetos.
- Nunca agregue valores de clientes diferentes no mesmo objeto.

---

## Regras gerais de formato

1. Retorne somente JSON válido (sem markdown e sem comentários).
2. Use exatamente os nomes de campo definidos neste documento.
3. Campos ausentes devem ser null.
4. Para campos do tipo lista, retorne lista JSON ou `[]`.
5. Datas e competências no formato `DD/MM/AAAA` ou `MM/AAAA` conforme indicado.
6. Valores monetários como decimal com ponto, sem símbolo de moeda.
7. Quantidades como números inteiros.
8. O campo `tipo_relatorio` determina quais seções de campos devem ser preenchidas. Campos de outras seções não devem aparecer no resultado.
