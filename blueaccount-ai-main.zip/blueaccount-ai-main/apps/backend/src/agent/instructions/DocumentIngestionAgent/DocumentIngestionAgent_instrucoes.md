## 1. Termos gerais

Extraia os campos da seção **Termos gerais** a partir das cláusulas de identificação, vigência, faturamento e características gerais do contrato.

### Campos a extrair

- **cnpj_cliente**  
  Extraia o CNPJ da empresa contratante.

- **tipo_contrato**  
  Extraia o tipo de contrato exatamente como descrito no documento, pode ser mensal, trimestral, anual, etc.

- **data_emissao**  
  Extraia a data de emissão, assinatura ou celebração do contrato, quando ela representar a data em que o contrato foi gerado.

- **data_inicio**  
  Extraia a data de início da vigência ou da prestação dos serviços.

- **dia_vencimento**  
  Extraia o dia do mês em que o pagamento mensal vence.  
  Retorne apenas o número do dia.

- **inicio_faturamento**  
  Extraia a competência ou data a partir da qual os valores começam a ser cobrados.

- **mes_vencimento**  
  Extraia o mês em que ocorre o primeiro vencimento da cobrança.

- **data_termino**  
  Extraia a data de término do contrato apenas quando houver prazo determinado explicitamente informado.  
  Se o contrato for por prazo indeterminado ou não trouxer essa informação, retorne vazio.

- **regime_tributario**  
  Extraia o regime contábil/tributário da contratante, se estiver explícito no contrato.  
  Padronize o valor usando exatamente uma destas opções: `Simples Nacional`, `Lucro Presumido`, `Lucro Real`, `MEI`, `Pessoa Física`.  
  Use `Pessoa Física` quando a contratante for pessoa física — nesse caso `cnpj_cliente` deve ser um CPF (11 dígitos).  
  Para os outros quatro regimes, `cnpj_cliente` deve ser um CNPJ (14 dígitos).  
  Se não estiver claro ou não corresponder a uma dessas opções, retorne vazio.

- **endereco**  
  Extraia o endereço da empresa contratante, se disponível.  
  Padronize o valor no formato `Rua, Número, Cidade - Estado, CEP`.  
  Se algum valor não estiver disponível, preencha com o que estiver disponível, mantendo a ordem dos componentes conhecidos.

### Regras adicionais

- Considere apenas informações explicitamente descritas no contrato.
- Não invente valores e não deduza informações ausentes.
- Se houver mais de uma data possível, escolha a que melhor corresponde ao nome do campo.
- Se o contrato mencionar renovação automática, isso não substitui **data_termino**.
- Preserve os valores exatamente como aparecem no contrato, salvo orientação contrária do sistema.
- Se um campo não estiver claramente presente, retorne vazio.

## 2. Valores e reajustes

Extraia os campos da seção **Valores e reajustes** a partir das cláusulas financeiras do contrato, considerando valores principais, descontos e regras de reajuste.

### Campos a extrair

- **valor_original**  
  Extraia o valor originalmente contratado, sem aplicação de reajustes posteriores.

- **desconto_por_adimplencia**  
  Extraia o valor ou percentual de desconto concedido em caso de pagamento em dia, se estiver explicitamente previsto no contrato.

- **multa_por_inadimplencia**  
  Extraia o valor ou percentual associado à perda de desconto, acréscimo, multa ou condição aplicada em caso de inadimplência, atraso ou não pagamento no prazo, desde que esteja descrito como regra contratual vinculada ao desconto.

- **indice_reajuste**  
  Extraia o índice de reajuste anual previsto em contrato.

### Regras adicionais

- Considere apenas informações explicitamente descritas no contrato.
- Não invente valores e não deduza informações ausentes.
- **valor_original** deve representar o valor base do contrato, sem considerar descontos condicionais, multas, juros ou cobranças excedentes.
- Em **desconto_por_adimplencia**, extraia apenas descontos condicionados ao pagamento pontual.
- Em **multa_por_inadimplencia**, extraia apenas a regra contratual relacionada à perda de desconto, retirada de benefício financeiro ou alteração de valor por atraso.
- Não trate multa moratória, juros de atraso ou correção monetária isoladamente como **multa_por_inadimplencia**, a menos que o contrato vincule explicitamente esses valores à perda de um desconto.
- Se o contrato mencionar apenas um desconto, preencha somente o campo correspondente.
- Preserve os valores exatamente como aparecem no contrato, salvo orientação contrária do sistema.
- Se um campo não estiver claramente presente, retorne vazio.


## 3. Serviços contratados

Extraia os campos da seção **Serviços contratados** a partir das cláusulas que definem o escopo operacional do contrato, especialmente os limites quantitativos de documentos, colaboradores e demais itens incluídos na mensalidade.

### Campos a extrair

- **numero_de_documentos**  
  Extraia a quantidade de a ser processados documentos incluídos no contrato.

- **numero_de_colaboradores**  
  Extraia a quantidade de colaboradores incluídos no escopo contratado sem cobrança excedente.

- **numero_de_prolabores**  
  Extraia a quantidade de pessoas que recebem pro-labore (socios - nao colaboradores normais).

- **numero_de_estabelecimentos**  
  Extraia a quantidade de estabelecimentos contratados.

- **outros_servicos_contratados**  
  Extraia outros serviços, itens ou franquias incluídos no contrato e estruture como lista JSON no seguinte formato:

  ```json
  {
    "descricao": "string",
    "valor": 0,
    "quantidade": 0
  }
  ```

- **base_de_calculo**  
  Extraia, se disponivel, a base de calculo utilizada para determinar se a empresa permanece nos parametros do contrato. Por exemplo, para fins de excedente, pode-se utilizar a média dos últimos 3 meses. Se nada for mencionado, deve ser o ultimo estado disponivel.

### Regras adicionais

- Considere apenas informações explicitamente descritas no contrato.
- Não invente valores e não deduza informações ausentes.
- Não some valores manualmente quando o contrato trouxer limites separados.
- Em **numero_de_colaboradores**, considere termos equivalentes como empregados, funcionários, colaboradores ativos, folha ativa ou similares, desde que o contexto contratual indique claramente um limite incluído.
- Em **outros_servicos_contratados**, inclua apenas serviços ou itens explicitamente previstos como parte do escopo contratado ou da mensalidade.
- Cada item de **outros_servicos_contratados** deve representar um serviço, franquia ou componente distinto.
- Em **descricao**, registre o nome do serviço ou item conforme o contrato.
- Em **valor**, extraia o valor unitário ou valor associado ao item quando ele estiver explicitamente informado.
- Em **quantidade**, extraia a quantidade incluída quando ela estiver explicitamente informada.
- Não inclua multas, juros, reajustes, excedentes, penalidades ou serviços cobrados apenas sob demanda em **outros_servicos_contratados**.
- Ignore quantidades mencionadas apenas como exemplo, simulação, excedente ou condição futura.
- Preserve os valores exatamente como aparecem no contrato, salvo orientação contrária do sistema.
- Se um campo não estiver claramente presente, retorne vazio.


## 4. Excedentes

Extraia os campos da seção **Excedentes** a partir das cláusulas que descrevem cobranças adicionais aplicáveis quando o cliente ultrapassa os limites do contrato ou contrata serviços adicionais cobrados à parte.

### Campos a extrair

- **excedentes**  
  Extraia todas as regras de excedente e estruture como lista JSON no seguinte formato:

  ```json
  {
    "referencia": "string",
    "descricao": "string",
    "tipo_cobranca": "string",
    "valor": 0,
    "quantidade_inicial": 0,
    "quantidade_final": 0
  }
  ```
** Alguns excedentes podem ser por faixas de cobrança. Por exemplo: **

```text
Até 10 funcionários vale o valor original.
De 11 a 20 funcionários, valor original + valor fixo de R$500
De 21 a 30 funcionários, valor original + valor fixo de R$1000
De 31+ funcionários, valor original + valor fixo de R$1500
```
Nesses casos, você deve extrair cada excedente como uma regra individual de excedente, com quantidade inicial e quantidade final pela banda.

** Tipos de Cobrança **
Cobranças podem ser:
  - por_hora
  - por_funcionario
  - por_documento
  - por_faixa
  - outro

Você deve preencher o campo de acordo com a regra de cobrança do excedente.

### Regras adicionais

- Considere apenas informações explicitamente descritas no contrato.
- Não invente valores e não deduza informações ausentes.
- Extraia uma entrada em **excedentes** para cada regra de cobrança adicional identificada no contrato.
- Pode existir mais de uma regra de excedente para o mesmo item contratual.
- Para cada valor principal do contrato, verifique se existe uma regra de excedente associada, como por exemplo colaboradores excedentes, documentos excedentes, admissões, rescisões, folhas adicionais, empresas adicionais ou serviços similares.
- Também inclua em **excedentes** outros serviços cobrados à parte quando estiverem descritos como cobrança adicional, sob demanda, por evento, por faixa ou fora da mensalidade.
- Em **referencia**, informe a que item a regra se refere, como por exemplo colaboradores, pró-labores, afastados, notas fiscais, documentos, documentos fiscais, documentos tributários, documentos fiscais e tributários, lançamentos contábeis, admissão, rescisão, folha complementar ou outro serviço.
- Lançamentos contábeis/bookkeeping entries devem ser classificados como lançamentos contábeis, não como documentos tributários.
- Em **descricao**, registre a regra completa da cobrança conforme estiver no contrato.
- Em **tipo_cobranca**, classifique a forma de cobrança com `por_hora`, `por_funcionario`, `por_documento`, `por_edificio`, `por_obra`, `por_faixa` ou `outro`, sempre priorizando a forma mais específica possível. Use `por_obra` para obra/projeto de construção e `por_edificio` para prédio/edifício; qualquer valor fora dessa lista é normalizado para `outro`.
- Em **valor**, extraia o valor monetário aplicável à regra.
- Em **quantidade_inicial**, extraia o início da faixa, limite ou ponto a partir do qual a cobrança passa a valer.
- Em **quantidade_final**, extraia o final da faixa quando houver. Se a regra não tiver limite superior explícito, retorne vazio.
- Quando a cobrança for por tiers ou faixas, crie uma entrada separada para cada faixa descrita no contrato.
- Exemplos de regras por tiers incluem faixas como `0 a 5`, `6 a 10`, `11 a 20` empregados, documentos por intervalo, ou qualquer outra progressão de quantidade.
- Quando a regra indicar apenas "acima de" determinada quantidade, preencha **quantidade_inicial** com o ponto inicial aplicável e deixe **quantidade_final** vazio se o contrato não informar limite superior.
- Quando a regra for por evento e não depender de faixa numérica, como admissão ou rescisão, preencha **tipo_cobranca** como `outro` e deixe **quantidade_inicial** e **quantidade_final** vazios, salvo se o contrato informar uma faixa explícita.
- Não inclua mensalidade principal, reajuste anual, multa por atraso, juros de mora ou tributos como **excedentes**, a menos que o contrato os trate explicitamente como cobrança excedente de serviço.
- Preserve os valores exatamente como aparecem no contrato, salvo orientação contrária do sistema.
- Se não houver cláusula de excedentes, retorne lista vazia ou vazio, conforme o formato esperado pelo sistema.


## 5. Adicional anual

Extraia os campos da seção **Adicional anual** a partir das cláusulas que tratam de cobranças recorrentes anuais adicionais ao valor mensal do contrato, como décimo terceiro honorário, honorário extra anual, cobrança adicional em dezembro ou regra equivalente.

### Campos a extrair

- **adicional_anual**  
  Extraia todas as regras de cobrança anual adicional e estruture como lista JSON no seguinte formato:

  ```json
  {
    "descricao": "string",
    "tipo_valor": "string",
    "valor": 0,
    "percentual": 0,
    "mes_cobranca": "string",
    "condicao": "string"
  }
  ```

### Regras adicionais

- Considere apenas informações explicitamente descritas no contrato.
- Não invente valores e não deduza informações ausentes.
- Extraia uma entrada em **adicional_anual** para cada regra de cobrança anual adicional identificada no contrato.
- Em **descricao**, registre a descrição da cobrança conforme estiver no contrato, como por exemplo `13o honorário`, `honorário extra anual`, `parcela adicional anual` ou equivalente.
- Em **tipo_valor**, classifique a forma de definição do adicional com valores como `valor_fixo`, `percentual`, `equivalente_mensalidade`, `proporcional` ou equivalente compatível com a regra descrita.
- Em **valor**, extraia o valor monetário quando ele estiver explicitamente informado.
- Em **percentual**, extraia o percentual quando a regra estiver definida como fração ou percentual do valor do contrato.
- Em **mes_cobranca**, extraia o mês ou competência em que a cobrança adicional anual deve ocorrer.
- Em **condicao**, registre a regra complementar da cobrança, como por exemplo `cobrado em dezembro`, `equivalente a 100% da mensalidade`, `proporcional ao início da vigência`, `não aplicável no primeiro ano` ou equivalente.
- Se a cláusula indicar que o adicional anual corresponde a 100% da mensalidade, preencha **tipo_valor** com `equivalente_mensalidade`, preencha **percentual** quando explicitamente indicado e registre a regra em **condicao**.
- Se houver apenas a regra percentual, mas não o valor em moeda, preencha **percentual** e deixe **valor** vazio.
- Se houver apenas o valor em moeda, preencha **valor** e deixe **percentual** vazio.
- Não trate reajustes anuais, correção monetária, multa por atraso, juros ou tributos como **adicional_anual**.
- Preserve os valores exatamente como aparecem no contrato, salvo orientação contrária do sistema.
