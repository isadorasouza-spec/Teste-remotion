/**
 * DocumentIngestionAgent – TypeScript port of the Python multimodal agent.
 *
 * Flow:
 *   1. Read contract file from S3
 *   2. Build extraction prompt from section instructions
 *   3. Convert DOC/DOCX → PDF when needed (via LibreOffice)
 *   4. Invoke Bedrock Converse (multimodal) for structured extraction
 *   5. Parse and return JSON extraction result
 */

import { existsSync, readFileSync, mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { resolve, extname, basename, parse as parsePath, join } from "node:path";
import { execSync } from "node:child_process";
import { tmpdir } from "node:os";

import {
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import {
  ConverseCommand,
  type ContentBlock,
  type Message,
} from "@aws-sdk/client-bedrock-runtime";

import { settings } from "../settings.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";
import { ExternalServicesFactoryService } from "../infrastructure/external-services/external-services.factory.js";

// ─── Config ────────────────────────────────────────────────────────────────────

export interface AgentConfig {
  inputBucket?: string;
  outputBucket?: string;
  modelId?: string;
  inferenceProfileId?: string;
  region?: string;
  instructionsPath?: string;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
}

interface ResolvedConfig {
  inputBucket: string;
  outputBucket: string;
  modelId: string;
  inferenceProfileId: string;
  region: string;
  instructionsPath: string;
  temperature: number;
  topP: number;
  maxTokens: number;
}

function resolveConfig(cfg?: AgentConfig): ResolvedConfig {
  return {
    inputBucket: cfg?.inputBucket ?? settings.DOCUMENT_INPUT_BUCKET,
    outputBucket: cfg?.outputBucket ?? settings.DOCUMENT_OUTPUT_BUCKET,
    modelId: cfg?.modelId ?? settings.DOCUMENT_DEFAULT_MODEL_ID,
    inferenceProfileId:
      cfg?.inferenceProfileId ??
      settings.DOCUMENT_BEDROCK_INFERENCE_PROFILE_ID ??
      "",
    region: cfg?.region ?? settings.REGION,
    instructionsPath: cfg?.instructionsPath ?? settings.INSTRUCTIONS_PATH,
    temperature: cfg?.temperature ?? 0,
    topP: cfg?.topP ?? 1,
    maxTokens: cfg?.maxTokens ?? 6000,
  };
}

// ─── Agent ─────────────────────────────────────────────────────────────────────

export type InferenceOverrides = Partial<{
  temperature: number;
  topP: number;
  maxTokens: number;
}>;

export class DocumentIngestionAgent {
  static readonly agentName = "DocumentIngestionAgent";

  private readonly config: ResolvedConfig;
  private readonly logger: AgentLogger;
  private readonly s3: ReturnType<ExternalServicesFactoryService["createS3Client"]>;
  private readonly bedrock: ReturnType<ExternalServicesFactoryService["createBedrockRuntimeClient"]>;
  private readonly services = new ExternalServicesFactoryService();

  constructor(cfg?: AgentConfig, logger?: AgentLogger) {
    this.config = resolveConfig(cfg);
    this.logger =
      logger ??
      new AgentLogger(
        DocumentIngestionAgent.agentName,
        undefined,
        (settings.LOG_LEVEL as "debug" | "info" | "warn" | "error") ?? "info",
      );

    this.s3 = this.services.createS3Client(this.config.region);
    this.bedrock = this.services.createBedrockRuntimeClient(this.config.region);

    this.logger.info("agent_bootstrap_complete", {
      region: this.config.region,
      inputBucket: this.config.inputBucket,
      modelId: this.config.modelId,
      inferenceProfileId: this.config.inferenceProfileId || "(none)",
      instructionsPath: this.config.instructionsPath,
    });
  }

  /** Inference config override type. */
  private resolveInference(
    overrides?: InferenceOverrides,
  ): { temperature: number; topP: number; maxTokens: number } {
    return {
      temperature: overrides?.temperature ?? this.config.temperature,
      topP: overrides?.topP ?? this.config.topP,
      maxTokens: overrides?.maxTokens ?? this.config.maxTokens,
    };
  }

  /**
   * Ingest a contract document from S3 and return the structured extraction as a JSON string.
   */
  async ingest(
    inputKey: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<string> {
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_started", { inputKey, inferenceConfig });

    const inputBytes = await this.readS3Object(
      this.config.inputBucket,
      inputKey,
    );
    this.logger.info("input_loaded", {
      inputKey,
      sizeBytes: inputBytes.length,
    });

    const extracted = await this.extractFromBytes(inputBytes, inputKey, inferenceConfig);
    const result = JSON.stringify(extracted, null, 2);
    this.logger.info("ingest_completed", {
      outputMode: "text",
      resultSizeChars: result.length,
    });
    return result;
  }

  /**
   * Ingest a contract from a local file path and return the extraction as a parsed object.
   */
  async ingestFromFile(
    filePath: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<Record<string, unknown>> {
    const resolved = resolve(filePath);
    if (!existsSync(resolved)) {
      throw new Error(`File not found: ${resolved}`);
    }
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_from_file_started", { filePath: resolved });

    const inputBytes = readFileSync(resolved);
    this.logger.info("input_loaded", {
      filePath: resolved,
      sizeBytes: inputBytes.length,
    });

    const extracted = await this.extractFromBytes(
      Buffer.from(inputBytes),
      basename(resolved),
      inferenceConfig,
    );
    this.logger.info("ingest_from_file_completed", {
      filePath: resolved,
      fieldCount: Object.keys(extracted).length,
    });
    return extracted;
  }

  /**
   * Ingest a contract from an in-memory buffer and return the extraction as a parsed object.
   */
  async ingestFromBuffer(
    buffer: Buffer,
    filename: string,
    inferenceOverrides?: InferenceOverrides,
  ): Promise<Record<string, unknown>> {
    const inferenceConfig = this.resolveInference(inferenceOverrides);
    this.logger.info("ingest_from_buffer_started", {
      filename,
      sizeBytes: buffer.length,
    });

    const extracted = await this.extractFromBytes(buffer, filename, inferenceConfig);
    this.logger.info("ingest_from_buffer_completed", {
      filename,
      fieldCount: Object.keys(extracted).length,
    });
    return extracted;
  }

  // ─────────────────────────── Core extraction ──────────────────────────────

  private async extractFromBytes(
    inputBytes: Buffer,
    nameHint: string,
    inferenceConfig: { temperature: number; topP: number; maxTokens: number },
  ): Promise<Record<string, unknown>> {
    const promptText = this.buildExtractionPrompt();

    const { payload, effectiveKey } = this.prepareDocumentPayload(
      nameHint,
      inputBytes,
    );
    const { documentKind, mediaFormat } = this.inferDocumentType(effectiveKey);
    this.logger.info("payload_prepared", {
      effectiveKey,
      payloadSizeBytes: payload.length,
      documentKind,
      mediaFormat,
    });

    const rawResponse = await this.invokeMultimodalExtraction({
      modelIdentifier:
        this.config.inferenceProfileId || this.config.modelId,
      promptText,
      payloadBytes: payload,
      documentKind,
      mediaFormat,
      filename: this.sanitizeDocumentName(basename(effectiveKey)),
      inferenceConfig,
    });

    return this.extractJsonFromResponse(rawResponse);
  }

  // ─────────────────────────── Prompt ───────────────────────────────────────

  private buildExtractionPrompt(): string {
    const instructionsFile = resolve(
      this.config.instructionsPath,
      DocumentIngestionAgent.agentName,
      `${DocumentIngestionAgent.agentName}_instrucoes.md`,
    );
    const instructions = readFileSync(instructionsFile, "utf-8");
    this.logger.info("instructions_loaded", { instructionsFile });

    return [
      "Voce e um extrator especializado em dados de contratos em portugues do Brasil.",
      "Analise o documento e extraia APENAS os campos definidos no schema abaixo,",
      "seguindo rigorosamente as instrucoes de extracao por secao.",
      "",
      "=== INSTRUCOES DE EXTRACAO POR SECAO ===",
      instructions,
      "=== REGRAS DE FORMATO ===",
      "1) Converta os dados extraidos para um formato de chave-valor JSON.",
      "2) Retorne somente JSON valido (sem markdown e sem comentarios).",
      "3) Use exatamente os nomes de campo definidos nas instrucoes.",
      "4) Campos ausentes devem ser null.",
      '5) Para campos do tipo `json_array`, retorne lista JSON ou [].',
      "6) Datas no formato DD/MM/AAAA quando possivel.",
      "7) Valores monetarios como decimal com ponto, sem simbolo de moeda.",
      "",
      "=== SCHEMA DE CAMPOS ===",
      "Retorne o objeto JSON final agora.",
    ].join("\n");
  }

  // ─────────────────────────── S3 ───────────────────────────────────────────

  private async readS3Object(bucket: string, key: string): Promise<Buffer> {
    const cmd = new GetObjectCommand({ Bucket: bucket, Key: key });
    const resp = await this.s3.send(cmd);
    const stream = resp.Body;
    if (!stream) throw new Error(`S3 object body is empty: s3://${bucket}/${key}`);
    return Buffer.from(await stream.transformToByteArray());
  }

  // ─────────────────────────── Bedrock ──────────────────────────────────────

  private async invokeMultimodalExtraction(opts: {
    modelIdentifier: string;
    promptText: string;
    payloadBytes: Buffer;
    documentKind: "document" | "image";
    mediaFormat: string;
    filename: string;
    inferenceConfig: { temperature: number; topP: number; maxTokens: number };
  }): Promise<string> {
    const content: ContentBlock[] = [{ text: opts.promptText }];

    if (opts.documentKind === "document") {
      content.push({
        document: {
          name: opts.filename,
          format: opts.mediaFormat as "pdf",
          source: { bytes: opts.payloadBytes },
        },
      });
    } else {
      content.push({
        image: {
          format: opts.mediaFormat as "jpeg" | "png",
          source: { bytes: opts.payloadBytes },
        },
      });
    }

    const messages: Message[] = [{ role: "user", content }];

    const cmd = new ConverseCommand({
      modelId: opts.modelIdentifier,
      messages,
      inferenceConfig: {
        temperature: opts.inferenceConfig.temperature,
        topP: opts.inferenceConfig.topP,
        maxTokens: opts.inferenceConfig.maxTokens,
      },
    });

    const resp = await this.bedrock.send(cmd);

    // Log LLM usage
    this.logger.logLlmUsage("llm_invocation", {
      modelId: opts.modelIdentifier,
      inputTokens: resp.usage?.inputTokens,
      outputTokens: resp.usage?.outputTokens,
      latencyMs: resp.metrics?.latencyMs,
    }, { filename: opts.filename });

    const blocks = resp.output?.message?.content ?? [];
    const textParts = blocks
      .filter((b): b is ContentBlock & { text: string } => "text" in b && typeof b.text === "string")
      .map((b) => b.text);

    const final = textParts.join("\n").trim();
    if (!final) throw new Error("Bedrock retornou resposta vazia.");
    return final;
  }

  // ─────────────────────────── JSON parsing ─────────────────────────────────

  private extractJsonFromResponse(text: string): Record<string, unknown> {
    const trimmed = text.trim();
    try {
      const data = JSON.parse(trimmed);
      if (typeof data !== "object" || data === null || Array.isArray(data)) {
        throw new Error("JSON de extracao invalido: esperado objeto no nivel raiz.");
      }
      return data as Record<string, unknown>;
    } catch {
      // Try to find embedded JSON object
      const start = trimmed.indexOf("{");
      const end = trimmed.lastIndexOf("}");
      if (start === -1 || end === -1 || end <= start) {
        throw new Error("Resposta do modelo nao contem JSON valido.");
      }
      const data = JSON.parse(trimmed.slice(start, end + 1));
      if (typeof data !== "object" || data === null || Array.isArray(data)) {
        throw new Error("JSON de extracao invalido: esperado objeto no nivel raiz.");
      }
      return data as Record<string, unknown>;
    }
  }

  // ─────────────────────────── Document handling ────────────────────────────

  private prepareDocumentPayload(
    inputKey: string,
    payloadBytes: Buffer,
  ): { payload: Buffer; effectiveKey: string } {
    const ext = extname(inputKey).toLowerCase();
    if (ext !== ".doc" && ext !== ".docx") {
      return { payload: payloadBytes, effectiveKey: inputKey };
    }
    const pdfBytes = this.convertWordToPdf(payloadBytes, basename(inputKey));
    const stem = parsePath(inputKey).name;
    return { payload: pdfBytes, effectiveKey: `${stem}.pdf` };
  }

  private inferDocumentType(
    objectKey: string,
  ): { documentKind: "document" | "image"; mediaFormat: string } {
    const ext = extname(objectKey).toLowerCase();
    switch (ext) {
      case ".pdf":
        return { documentKind: "document", mediaFormat: "pdf" };
      case ".doc":
      case ".docx":
        return { documentKind: "document", mediaFormat: "pdf" };
      case ".jpg":
      case ".jpeg":
        return { documentKind: "image", mediaFormat: "jpeg" };
      case ".png":
        return { documentKind: "image", mediaFormat: "png" };
      default:
        throw new Error(
          `Formato nao suportado: ${ext}. Use PDF, DOC, DOCX, JPG ou PNG.`,
        );
    }
  }

  private convertWordToPdf(wordBytes: Buffer, sourceName: string): Buffer {
    const soffice = this.resolveSofficeBinary();
    const suffix = extname(sourceName) || ".docx";
    const tmp = mkdtempSync(join(tmpdir(), "word_to_pdf_"));

    try {
      const inputPath = join(tmp, `source${suffix}`);
      writeFileSync(inputPath, wordBytes);

      execSync(
        `"${soffice}" --headless --convert-to pdf --outdir "${tmp}" "${inputPath}"`,
        { stdio: "pipe" },
      );

      const outputPath = join(tmp, "source.pdf");
      return readFileSync(outputPath);
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  }

  private resolveSofficeBinary(): string {
    // Check PATH
    try {
      const result = execSync("which soffice", { stdio: "pipe", encoding: "utf-8" }).trim();
      if (result) return result;
    } catch {
      // not in PATH
    }
    // macOS default
    const macPath = "/Applications/LibreOffice.app/Contents/MacOS/soffice";
    if (existsSync(macPath)) return macPath;
    throw new Error(
      "Conversao DOC/DOCX requer LibreOffice (soffice). Instale o LibreOffice ou adicione no PATH.",
    );
  }

  private sanitizeDocumentName(rawName: string): string {
    let name = parsePath(rawName).name;
    name = name.replace(/[_./]+/g, "-");
    name = name.replace(/[^A-Za-z0-9\s\-()[\]]/g, "");
    name = name.replace(/\s+/g, " ").trim();
    return name || "document";
  }
}
